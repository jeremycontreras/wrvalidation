#! /bin/bash

# check variables, like all scripts herein do
WRZ_SCRIPT_NAME=$(basename $0)
if [ -z "${WRZ_BASE_DIR}" ]; then
    WRZ_BASE_DIR=$(cd $(dirname $0)/../../build/ && pwd)
    echo ${WRZ_BASE_DIR}
fi
. ${WRZ_BASE_DIR}/scripts/wrz_functions

wrz_check_vars WRZ_LINUX_TAG

export XILINX_LINUX_REPO="https://raw.githubusercontent.com/Xilinx/linux-xlnx/${WRZ_LINUX_TAG}"
export DTS_FOLDER="arch/arm/boot/dts"

wget ${XILINX_LINUX_REPO}/${DTS_FOLDER}/skeleton.dtsi
wget ${XILINX_LINUX_REPO}/${DTS_FOLDER}/zynq-7000.dtsi

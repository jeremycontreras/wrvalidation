WRZ-OS Changelog
==================

Changelog for the WR-Zynq-OS Firmwares.


Release `v3.0.1` (2020-09-03)
----------------------------

### Bug Fixes

* hald/security: rename ipv4_gw_addr and security/web parameters
* snmp: remove hidden oids for expert parameters
* alerts: alerts and emails sending error fixed
* hald: led messages spam removed
* tmgrd: leap59, leap61 and ptp_timescale messages spam removed
* system: OOM caused by a wrong rsyslog configuration fixed
* snmp: wrong initial configuration forcing snmp reset-force

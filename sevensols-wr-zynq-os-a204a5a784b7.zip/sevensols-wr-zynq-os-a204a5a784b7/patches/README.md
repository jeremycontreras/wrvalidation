Patches to apply in order to fit our ZEN board.

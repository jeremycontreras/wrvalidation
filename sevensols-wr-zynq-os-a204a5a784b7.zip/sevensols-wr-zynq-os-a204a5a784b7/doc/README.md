General documentation: User Guide, etc.

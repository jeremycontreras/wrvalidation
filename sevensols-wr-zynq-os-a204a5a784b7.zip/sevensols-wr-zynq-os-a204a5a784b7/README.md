 Introduction
=======================

This repository contains all the sources to compile the U-boot bootloader
and the Linux kernel for the WR Zynq devices such as WR-ZEN board, WR-ZEN Time Provider. 

The present document describe the procedure to build the needed images and how to make the
board works properly.


The Official Manuals
========================

Nowaydays, This is the current set of manuals that are available:

* **[WR-ZEN TP Userguide]**: A userguide for the WR-ZEN TimeProvider
board.
* **[WR-ZEN Advanced Manual]**: It describes the build procedure and the
low-level details in order to customize this repository to fit your
specific needs. It can be found in `doc/AdvancedManual.md` in the
current project.


Repository structure
========================

The project structure is very similar to the WR Switch Software of the Open Hardware
Repository (OHWR). Here, we describe the main folders: 

* `binaries`: Pre-compiled files needed by the software: BOOT.bin, FSBL.elf and Device Tree
sources.
* `build`: Building scripts to get the images.
* `configs`: Configuration files for Buildroot, Linux kernel and Busybox packages.
* `doc`: General documentation.
* `kernel`: Linux device drivers.
* `patches`: Patches to apply in order to fit with our board.
* `userspace`: Userspace code: libraries, tools, etc.

Building procedure
==========================

All the steps below has been tested and will be supported for Ubuntu LTS 14.04 (32/64 bits).
We strongly recommand you to use the same distro in order to ease the build procedure.

Prerequisite
--------------------

In order to build all the files required by wr-zynq-os you must previously install the following
package in Ubuntu 16.04.

	sudo apt-get install m4 bison flex build-essential texinfo libssl-dev libncursesw5-dev libncursesw5 u-boot-tools device-tree-compiler


Build directory
----------------------

The building procedure is performed into a directory that is called the "build dir". 
It is recommended to create it outside the "source dir". In the following lines of
this tutorial we are going to use:

* "source dir": `~/wr/wr-zynq-os/`
* "build dir":  `~/wr/wrz_output/`

> **_NOTES:_** These directories have been selected as example of how to build the wr-zyns-os. 
> You might use another location that best fit your needs. In the case you change them, please 
> replace them in all the following lines.

The procedure
----------------------


The building procedure is very easy and straighforward. Everything is done by the
`wrz_build-all` script located at `build` folder. This mechanism is inspired by the
WR Switch Software repository from OHWR. Then, the building steps are detailed:

	$ mkdir -p ~/wr/wrz_output/
	$ cd ~/wr/wrz_output/
	$ ~/wr/wr-zynq-os/build/wrz_build-all

When the compilation process ends, a tarball file must be created in the working
directory. It contains the following images:

* `BOOT.bin`: This is a needed binary to boot on a Zynq board. It contains the First
Stage Bootloader (FSBL) that initializes the hardware, the golden bitstream to be 
programmed in the FPGA device and the Second Stage Bootloader, the U-boot, to prepare
the environment to load a Linux kernel. By default this file is not rebuild and is taken directly 
from the `binaries` folder. 
* `devicetree.dtb`: This image stores information about the devices on the board and 
it uses by the Linux kernel to load the drivers.
* `uImage`: The Linux kernel binary.
* `uramdisk.image.gz`: The Root File System (rootfs) with all the configuration files, tools,
kernel modules and libraries.
* A `MD5 file` to check that all the files in the tarball are correct.

Finally, the building procedure can be restored with the same script:

	$ <path_to_wr_zynq_os>/build/wrz_build-all --clean

> **_NOTES:_** The `wrz_build-all` has some advanced features that are not described here. Please, 
> read the [doc/AdvancedManual.md] or see the source code to get more information.

Usage & Installation
================================

At this point, the binary files have been generated and packed into a tarball.
If you want to update your current wr-zynq-os you need to upload this tarball as
`/update/update.tar` and reboot your product.
This step can be done through SSH or through the web interface.

In case you have access to the SD card you can also extract all the files of the
tarball into the first FAT32 partition. 

> ***NOTES:***  For safety reason, we always boot from the QSPI memory and not from the SD card. If you have
> made some modification to the BOOT.bin please read the [WR-ZEN Advanced Manual]. 

Finally, open a serial port terminal such as minicom and connect to the mini-USB UART socket.
If If everything is fine you should see the board Unix prompt where you must introduce

* **User** = `root`
* **Pass** = `root`

Troubleshooting
==========================

Unfortunately, some latest distribution (i.e Ubuntu 17.10) and wrong tool versions could produce errors. This section contains a known bug list.

automake compiled tool
----------------------

When Ubuntu 17.10/18.04 distribution is used the step 8 probably fails due to the automake version. The error is shown at line 3936 in the file `build/buildroot-2017.02/output/host/usr/bin/automake`.

**Solution** : Add `\` to scape the special characters.

~~~~~~~{.sh}
-  $text =~ s/\${([^ \t=:+{}]+)}/substitute_ac_subst_variables_worker ($1)/ge;
+  $text =~ s/\$\{([^ \t=:+{}]+)}/substitute_ac_subst_variables_worker ($1)/ge;
~~~~~~~

Ubuntu 18.0x compilation failed
----------------------

It has been detected that in the latest distributions (i.e: Ubuntu 18+) the uboot raised an error when try to be compiled. This is caused because of a new version of ssl library. In order to solve it, you should downgrade your ssl developer library by running:

`sudo apt-get install libssl1.0-dev`

It will ask you to remove libssl previous version, say YES.

Other package to install are

`sudo apt-get install libelf-dev autoconf`

References
==========================

* [WR-ZEN]: Product page.
* [WR-ZEN Wiki]: The wiki page from OHWR.org
* [WR-ZEN TP Userguide]: The user guide of the WR ZEN time provider
* [WR-ZEN Advanced Manual]: The manual for advanced user `/doc/AdvancedManual.md`.
* [wr-zen-hdl]: Repository of the gateware need to use this SW.
* [wr-switch-sw]: Repository of the WR Switch SW.

[//]: # (LIST OF HIDDEN LINKS BELOW)

[WR-ZEN Advanced Manual]: /doc/AdvancedManual.md
[WR-ZEN Wiki]: http://www.ohwr.org/projects/zen-wr/wiki
[WR-ZEN]: http://www.sevensols.com/en/products/wr-zen.html
[WR-ZEN TP Userguide]: http://www.sevensols/dl/wr-zen-tp/latest_stable.pdf
[wr-zen-hdl]: https://bitbucket.org/sevensols/wr-zen-hdl
[wr-switch-sw]: http://www.ohwr.org/projects/wr-switch-sw/wiki/

Ktmgr driver
========================
The driver called Ktmgr (ktmgr.0.1) has been designed to synchronize the Linux internal clock (the clock used by the syscall gettimeofday() and similar) according to the WhiteRabbit clock which resides in the FPGA (PL) side. This driver also manages the leap second according to the communication between tmgrd and linux system.

In order to make this process more precise and flexible, one interrupt is used. The first one give time enought to read from the WR registers and be ready for the next interrupt to only set the time. These interrupts are generated from the PL using the PPS output signal. 

Arguments
========================
The driver does not support arguments.

To install the driver correctly, run:
` insmod /wr/modules/ktmgr.ko`

Forcing clock update
========================
The driver allows to the user update the clock manually using the sysfs. To force an update, run: 
` echo 1 > /sys/kernel/ktmgr/force_align`
A read to this file will return ever 0. 

Dependencies
========================
The HW dependency required is just the PPS signal routed to the IRQF2P interrupt line, which is directly connected to the GIC.
For linux, in order to recognize this interrupt correctly, a new entry has to be specified in the devicetree file. 

For example, if the PPS interrupt signal is connected to the IRQF2P[9], the DTS will be the following:
```
ktmgr: ktmgr@0 {
	compatible = "ktmgr.0.1";
	status = "okay";
	interrupt-parent = <&intc>;
	interrupts = <0 53 1>;
};
```
Userspace PPS aligned
========================
In order to provide a way for userspace synchronization from the kernel space, the module Ktmgr generates a signal to each assigned userspace software at the moment of receive a PPS signal (IRQ callback). 

By now, there are one userspace program (ToD) that works in this way.

## TimeOfDay (ToD) ##

When Ktmgr is installed, two new entries in sysfs are created:
` /sys/kernel/tod_pid `
This entry contains the PID of the TimeOfDay user program allowing to this module send signals. It is updated automatically from the ToD program. 


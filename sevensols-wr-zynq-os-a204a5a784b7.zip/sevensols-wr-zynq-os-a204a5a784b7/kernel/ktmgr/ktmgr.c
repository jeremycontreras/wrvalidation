/**
 * @file ktmgr.c
 *
 * @brief
 *
 * @author Fidel Rodriguez (fidel.rodriguez@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 20/10/2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of WR-ZEN
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/of_device.h>
#include <linux/of_address.h>
#include <linux/interrupt.h>
#include <linux/gpio.h>       // Required for the GPIO functions
#include <linux/kobject.h>    // Using kobjects for the sysfs bindings
#include <linux/kthread.h>    // Using kthreads for the flashing functionality
#include <linux/delay.h>      // Using this header for the msleep() function
#include <linux/of_irq.h>
#include <linux/miscdevice.h>
#include <linux/pid.h>
#include <net/sock.h>
#include <linux/platform_device.h>
#include <linux/netlink.h>    // Library for the netlink interface.
#include <linux/skbuff.h>     // Library for the memory buffer.
#include <linux/printk.h>
#include <linux/sysfs.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/pid_namespace.h>
#include <linux/pid.h>
#include <asm/siginfo.h>
#include <linux/rcupdate.h>
#include <linux/sched.h>
#include <linux/debugfs.h>
#include <linux/uaccess.h>
#include "sysfs.c"

// MODULE INFO
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Fidel Rodriguez López");
MODULE_DESCRIPTION("KernelTmgr connector");
MODULE_VERSION("0.2");

#define MODULE_NAME	"KTMGR"
static const struct of_device_id ktmgr_id[] = {
		{ .compatible = "ktmgr.0.2" }, /* this name should match one of entries in the compatible field */
		{ }
};

#define DEFAULT_PPS_TO_SYNC          0x14
#define DEFAULT_SECURITY_OFFSET      0x5265C00
#define COMPILATION_TIME             0x12 /* this should be in another environment variable, so take from it */
#define SIGNAL_NUMBER                45

static struct kobject *ktmgr_entry;
static struct kobject *tod_pid_kobject;

struct pps_gen_regs{
	uint32_t adjctrl;
	uint32_t cycles;
	uint32_t lsec;
	uint32_t hsec;
};

struct pps_gen_regs* pps_counter;

int irq_num;
int secure_offset;
int trigger;

uint32_t sec_l;
uint32_t sec_h;
uint32_t rcycles;

/* Signal subsystem */
struct siginfo info;
struct task_struct *t;
/* Ends signal subsystem */

struct timespec64 tp;

static struct kobj_attribute tod_pid_attribute = __ATTR(tod_pid, 0660, pid_tod_show, pid_tod_store);
/* clock properties */
static struct kobj_attribute leap_second_attribute = __ATTR(leap_second, 0660, leap_second_show, leap_second_store);
static struct kobj_attribute clock_accuracy_attribute = __ATTR(clock_accuracy, 0660, clock_accuracy_show, clock_accuracy_store);
static struct kobj_attribute clock_variance_attribute = __ATTR(clock_variance, 0660, clock_variance_show, clock_variance_store);
static struct kobj_attribute clock_class_attribute = __ATTR(clock_class, 0660, clock_class_show, clock_class_store);
static struct kobj_attribute priority1_attribute = __ATTR(priority1, 0660, priority1_show, priority1_store);
static struct kobj_attribute priority2_attribute = __ATTR(priority2, 0660, priority2_show, priority2_store);
static struct kobj_attribute tm_lockstate_attribute = __ATTR(tm_lockstate, 0660, tm_lockstate_show, tm_lockstate_store);
static struct kobj_attribute ptp_timescale_attribute = __ATTR(ptp_timescale, 0660, ptp_timescale_show, ptp_timescale_store);
static struct kobj_attribute freq_traceable_attribute = __ATTR(freq_traceable, 0660, freq_traceable_show, freq_traceable_store);
static struct kobj_attribute time_traceable_attribute = __ATTR(time_traceable, 0660, time_traceable_show, time_traceable_store);
static struct kobj_attribute timesource_attribute = __ATTR(timesource, 0660, timesource_show, timesource_store);
static struct kobj_attribute enable_align_attribute = __ATTR(enable_align, 0660, enable_align_show, enable_align_store);
static struct kobj_attribute leap_59_attribute = __ATTR(leap_59, 0660, leap_59_show, leap_59_store);
static struct kobj_attribute leap_61_attribute = __ATTR(leap_61, 0660, leap_61_show, leap_61_store);
static struct kobj_attribute current_utc_offset_valid_attribute = __ATTR(current_utc_offset_valid, 0660, current_utc_offset_valid_show, current_utc_offset_valid_store);
static struct kobj_attribute update_attribute = __ATTR(update, 0660, update_show, update_store);

static irqreturn_t PPS_RISING_EDGE(int irq_number, void* param) {
	int ret = 0;
	struct timespec64 sw_time;
	/* Stack of calls after a PPS receive event
	@TODO: Create a set of calls "low priority", "high priority"...*/
	if(tod_pid != 0 )
	{
		rcu_read_lock();
		t = pid_task(find_vpid(tod_pid), PIDTYPE_PID);
		if(t==NULL)
		{
			pr_debug("%d PID not found\n",tod_pid);
		}
		else
		{
			send_sig_info(SIGNAL_NUMBER, &info, t); // Send to ToD
		}
		rcu_read_unlock();
	}
	else
		pr_debug("ToD did not write the PID.\n");
	/* Ends of stack */

	/* read from hw */

	sec_l = pps_counter->lsec;
	sec_h = 0; // HACK: Fix temporally until fixed in FPGA.
	rcycles = pps_counter->cycles;

	tp.tv_sec  = sec_h&0xFF;
	tp.tv_sec<<=32;
	tp.tv_sec  = tp.tv_sec|sec_l;
	tp.tv_nsec = 0;

	/* time comes from TAI, so we have to substract */
	tp.tv_sec-=leap_second;

	if(enable_align!=0){ // do not call automatically align if enable_align is set to false
		getnstimeofday64(&sw_time);
		printk(KERN_DEBUG"SW_TIME: %lld.%ld\n",sw_time.tv_sec,sw_time.tv_nsec);
		ret = do_settimeofday64(&tp);
		if(ret){
			printk(KERN_DEBUG"Error synciyng Linux clock (ret=%d) "
					"against hardware, clock_value "
					"[sec48.nsec32]="
					"%lld.%ld\n",
					ret,
					tp.tv_sec,
					tp.tv_nsec);
		} else {
			/* if we have jumps above 1 second, we notice! */
			if(abs(tp.tv_sec - sw_time.tv_sec) > 1){
				printk(KERN_WARNING"FPGA/Linux time alignment "
					"above 1 second (%lld-->%lld)\n",
					sw_time.tv_sec,
					tp.tv_sec);
			}
			printk(KERN_DEBUG"Time set from %lld.%ld\n",sw_time.tv_sec,sw_time.tv_nsec);
			printk(KERN_DEBUG"Time set to %lld.%ld (%d leap second)\n",tp.tv_sec,tp.tv_nsec,leap_second);
		}

	}

	return IRQ_HANDLED;
}

static int ktmgr_drv_probe(struct platform_device* pdev) {
	irq_num = irq_of_parse_and_map(pdev->dev.of_node, 0);
	if (request_irq(irq_num, PPS_RISING_EDGE, IRQF_ONESHOT, "PPS", NULL)) {
		printk(KERN_ERR "%s:PPS: cannot register IRQ %d\n",MODULE_NAME,irq_num);
		return -EIO;
	}
	return 0;
}

static int ktmgr_drv_remove(struct platform_device* pdev) {
	free_irq(irq_num, NULL);
	return 0;
}

static struct platform_driver ktmgr_platform_driver = { .probe =
		ktmgr_drv_probe, .remove = ktmgr_drv_remove, .driver = { .name =
		"ktmgr", .owner = THIS_MODULE, .of_match_table = ktmgr_id, }, };

static void __exit ktmgr_exit(void) {
	printk(KERN_INFO "%s: Removing driver for the PPS management.\n",MODULE_NAME);
	ktmgr_drv_remove(NULL);
	kobject_put(ktmgr_entry);
	kobject_put(tod_pid_kobject);

	return platform_driver_unregister(&ktmgr_platform_driver);
}

static int __init ktmgr_init(void) {
	int error;
	int rc;
	struct device_node *dn;
	uint32_t clk_ref;

	dn = of_find_node_by_path("/amba_pl/ktmgr@0");
	rc = of_property_read_u32(dn, "clk-ref", &clk_ref);

	if(rc)
	{
		printk(KERN_ERR "clk-ref was not defined, please see devicetree\n");
		return -EADDRNOTAVAIL;
	}

	rc = of_property_read_u32(dn, "secure-offset", &secure_offset);

	if(rc)
	{
		secure_offset=DEFAULT_SECURITY_OFFSET;
	}

	/* we set the trigger off because we need at least one iteration */
	trigger=0;

	memset(&info, 0, sizeof(struct siginfo));
	info.si_signo     = SIGNAL_NUMBER;
	info.si_code      = SI_QUEUE;
	info.si_int       = 1234;

	tod_pid=0;

	printk(KERN_INFO "%s: KTMGR starting...\n",MODULE_NAME);

	ktmgr_entry = kobject_create_and_add("ktmgr",kernel_kobj);
	if(!ktmgr_entry)
		return -ENOMEM;

	tod_pid_kobject = kobject_create_and_add("tod_pid",kernel_kobj);
	if(!tod_pid_kobject)
		return -ENOMEM;
	error = sysfs_create_file(tod_pid_kobject, &tod_pid_attribute.attr);
	if (error) {pr_debug("failed to create the tod_pid file in /sys/kernel/tod_pid \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &leap_second_attribute.attr);
	if (error) {pr_debug("failed to create the leap_second file in /sys/kernel/ktmgr/leap_second \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &clock_accuracy_attribute.attr);
	if (error) {pr_debug("failed to create the clock_accuracy file in /sys/kernel/ktmgr/clock_accuracy \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &clock_variance_attribute.attr);
	if (error) {pr_debug("failed to create the clock_variance file in /sys/kernel/ktmgr/clock_variance \n"); return error; }

	error = sysfs_create_file(ktmgr_entry, &clock_class_attribute.attr);
	if (error) {pr_debug("failed to create the clock_class file in /sys/kernel/ktmgr/clock_class \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &priority1_attribute.attr);
	if (error) {pr_debug("failed to create the priority1 file in /sys/kernel/ktmgr/priority1 \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &priority2_attribute.attr);
	if (error) {pr_debug("failed to create the priority2 file in /sys/kernel/ktmgr/priority2 \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &ptp_timescale_attribute.attr);
	if (error) {pr_debug("failed to create the current_utc_offset file in /sys/kernel/ktmgr/ptp_timescale \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &time_traceable_attribute.attr);
	if (error) {pr_debug("failed to create the time_traceable file in /sys/kernel/ktmgr/time_traceable \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &freq_traceable_attribute.attr);
	if (error) {pr_debug("failed to create the freq_traceable file in /sys/kernel/ktmgr/freq_traceable \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &timesource_attribute.attr);
	if (error) {pr_debug("failed to create the timesource file in /sys/kernel/ktmgr/timesource \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &leap_59_attribute.attr);
	if (error) {pr_debug("failed to create the leap_59 file in /sys/kernel/ktmgr/leap_59 \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &leap_61_attribute.attr);
	if (error) {pr_debug("failed to create the leap_61 file in /sys/kernel/ktmgr/leap_61 \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &tm_lockstate_attribute.attr);
	if (error) {pr_debug("failed to create the tm_lockstate file in /sys/kernel/ktmgr/tm_lockstate \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &current_utc_offset_valid_attribute.attr);
	if (error) {pr_debug("failed to create the current_utc_offset_valid file in /sys/kernel/ktmgr/current_utc_offset_valid \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &update_attribute.attr);
	if (error) {pr_debug("failed to create the update file in /sys/kernel/ktmgr/update \n");return error;}

	error = sysfs_create_file(ktmgr_entry, &enable_align_attribute.attr);
	if (error) {pr_debug("failed to create the enable_align file in /sys/kernel/ktmgr/enable_align \n");return error;}

	pps_counter=ioremap(clk_ref,sizeof(struct pps_gen_regs));
	if(!pps_counter)
	{
		pr_debug("failed to map pps_counter (%x) \n",clk_ref);
		return error;
	}

	return platform_driver_register(&ktmgr_platform_driver);
}

MODULE_DEVICE_TABLE( of, ktmgr_id);

module_init( ktmgr_init);
module_exit( ktmgr_exit);

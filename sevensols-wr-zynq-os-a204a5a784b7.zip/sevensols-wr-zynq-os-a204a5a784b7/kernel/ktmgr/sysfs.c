/* Sysfs internal variables */
int tod_pid;
int leap_second = 37;
uint8_t clock_class = 248; //default
uint8_t clock_accuracy = 0xFE; //Unknown
uint16_t clock_variance = 0xFFFF; //Maximum or uncomputed variance
uint8_t timesource = 0xA0; //Internal Oscillator
uint8_t ptp_timescale=1; //1 is PTP, 0 ir ARB
int freq_traceable;
int time_traceable;
int leap_59;
int leap_61;
int enable_align;
uint8_t priority1 = 128;
uint8_t priority2 = 128;
uint8_t tm_lockstate = 0;
int current_utc_offset_valid = 0;
int update = 0;

#define MODULE_NAME	"KTMGR"

/**
 * Time Manager Lock state type
 **/
enum tm_lockstate_t {
	TM_LOCKSTATE_INTERNAL = 0,
	TM_LOCKSTATE_LOCKED,
	TM_LOCKSTATE_HOLDOVER,
	TM_LOCKSTATE_ERROR,
	TM_LOCKSTATE_MANUAL,
	N_TM_LOCKSTATE,
};

/*### PID_TOD FUNCTIONS ###*/
static ssize_t pid_tod_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", tod_pid);
}

static ssize_t pid_tod_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		tod_pid = conv;
		break;
	}

	return count;
}

/*### Tprop functions ###*/

static ssize_t ptp_timescale_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", ptp_timescale);
}

static ssize_t ptp_timescale_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		ptp_timescale = (conv!=0);
		sysfs_notify(kobj, NULL, "ptp_timescale");
		break;
	}

	return count;
}

static ssize_t current_utc_offset_valid_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", current_utc_offset_valid  );
}

static ssize_t current_utc_offset_valid_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		current_utc_offset_valid = (conv!=0);
		sysfs_notify(kobj, NULL, "current_utc_offset_valid");
		break;
	}

	return count;
}

static ssize_t update_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", update  );
}

static ssize_t update_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		update = conv;
		sysfs_notify(kobj, NULL, "update");
		break;
	}

	return count;
}

static ssize_t priority1_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", priority1  );
}

static ssize_t priority1_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "priority1 (%ld)\n", __func__, conv);
			return -1;
		} else {
			priority1 = conv;
			sysfs_notify(kobj, NULL, "priority1");
		}
		break;
	}

	return count;
}

static ssize_t priority2_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", priority2  );
}

static ssize_t priority2_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "priority2 (%ld)\n", __func__, conv);
			return -1;
		} else {
			priority2 = conv;
			sysfs_notify(kobj, NULL, "priority2");
		}
		break;
	}

	return count;
}

static ssize_t tm_lockstate_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", tm_lockstate);
}

static ssize_t tm_lockstate_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv >= N_TM_LOCKSTATE) {
			printk(KERN_ERR "[%s] Value too large for "
			       "tm_lockstate (%ld)\n", __func__, conv);
			return -1;
		} else {
			tm_lockstate = conv;
			sysfs_notify(kobj, NULL, "tm_lockstate");
		}
		break;
	}

	return count;
}

/*### CLOCK FUNCTIONS ###*/
static ssize_t leap_second_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", leap_second);
}

static ssize_t leap_second_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		leap_second = conv;
		sysfs_notify(kobj, NULL, "leap_second");
		break;
	}

	return count;
}

static ssize_t clock_accuracy_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", clock_accuracy);
}

static ssize_t clock_accuracy_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "clock_accuracy (%ld)\n", __func__, conv);
			return -1;
		} else {
			clock_accuracy = conv;
			sysfs_notify(kobj, NULL, "clock_accuracy");
		}
		break;
	}

	return count;
}

static ssize_t clock_variance_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", clock_variance);
}

static ssize_t clock_variance_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xffff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "clock_variance (%ld)\n", __func__, conv);
			return -1;
		} else {
			clock_variance = conv;
			sysfs_notify(kobj, NULL, "clock_variance");
		}
		break;
	}

	return count;
}

static ssize_t clock_class_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", clock_class);
}

static ssize_t clock_class_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "clock_class (%ld)\n", __func__, conv);
			return -1;
		} else {
			clock_class = conv;
			sysfs_notify(kobj, NULL, "clock_class");
		}
		break;
	}

	return count;
}

static ssize_t freq_traceable_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", freq_traceable);
}

static ssize_t freq_traceable_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		freq_traceable = (conv!=0);
		sysfs_notify(kobj, NULL, "freq_traceable");
		break;
	}

	return count;
}

static ssize_t time_traceable_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", time_traceable);
}

static ssize_t time_traceable_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		time_traceable = (conv!=0);
		sysfs_notify(kobj, NULL, "time_traceable");
		break;
	}

	return count;
}

static ssize_t leap_59_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", leap_59);
}

static ssize_t leap_59_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		leap_59 = (conv!=0);
		sysfs_notify(kobj, NULL, "leap_59");
		break;
	}

	return count;
}

static ssize_t leap_61_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", leap_61);
}

static ssize_t leap_61_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		leap_61 = (conv!=0);
		sysfs_notify(kobj, NULL, "leap_61");
		break;
	}

	return count;
}

static ssize_t timesource_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", timesource);
}

static ssize_t timesource_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if (conv > 0xff) {
			printk(KERN_ERR "[%s] Value too large for "
			       "timesource (%ld)\n", __func__, conv);
			return -1;
		} else {
			timesource = conv;
			sysfs_notify(kobj, NULL, "timesource");
		}
		break;
	}

	return count;
}


static ssize_t enable_align_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf) {
	return scnprintf(buf, PAGE_SIZE, "%d\n", enable_align);
}

static ssize_t enable_align_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count) {
	long conv = 0;

	switch(kstrtol(buf, 10, &conv)) {
	case -ERANGE:
		printk(KERN_ERR "[%s] Value out of range (%s)\n",
		       __func__, buf);
		return -1;
	case -EINVAL:
		printk(KERN_ERR "[%s] Parsing error (%s)\n", __func__, buf);
		return -1;
	default:
		if(enable_align != conv)
		{
			printk(KERN_INFO "%s: enable_align = %ld (prev=%d)\n",MODULE_NAME,conv,enable_align);
			enable_align = conv;
			sysfs_notify(kobj, NULL, "enable_align");
		}
		break;
	}

	return count;
}

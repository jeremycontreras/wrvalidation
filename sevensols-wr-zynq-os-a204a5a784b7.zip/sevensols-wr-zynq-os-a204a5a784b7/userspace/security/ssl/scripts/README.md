This directory contains some useful scripts used in security management.

Some of these scripts are called by the webserver.

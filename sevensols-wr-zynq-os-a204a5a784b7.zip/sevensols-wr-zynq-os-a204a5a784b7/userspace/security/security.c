/**
 * @file misc.c
 *
 * @brief
 *
 * @author Cristian G Guerrero (cristian.guerrero@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 06-06-2018
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

/* general includes */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <math.h>

/* libgpa includes */
#include <libgpa.h>
#include <libgpa/msg.h>
#include <libgpa/sysfs.h>

/* own includes */
#include "security.h"
#include "security_auth.h"

struct gpa_rsrc_assoc rassoc []={
		{.oid=1000,.mp="./web"},
		{.oid=2000,.mp="./web/https",.rp="./https"},
		{.oid=3000,.mp="./auth",.rp="./auth"},
		{.oid=3010,.mp="./auth/tacacs",.rp="./auth/tacacs"},
		{.oid=3020,.mp="./auth/radius",.rp="./auth/radius"},
};

void help(const char *pgrname)
{
	printf("Security daemon. \n");
	printf("Usage: %s \n", pgrname);
	printf("-------------------------\n");
	printf("version: %s (%s); compiled at %s %s\n", __GIT_VER__,
			__GIT_USR__, __DATE__, __TIME__);

	exit(1);
}

int main(int argc, char *argv[])
{
	const char *pgrname = argv[0];
	int opt, optind=1;
	int ret;
	/* Module */
	struct gpa_mod* security_module=NULL;

	/* Resources */
	struct gpa_rsrc* mode_rsrc=NULL;
	struct gpa_rsrc* last_rsrc=NULL;
	struct gpa_rsrc* auth_rsrc=NULL;

	/* Parameters */
	struct gpa_prm* mode=NULL;

	gpa_msg_init(argc, argv);

	/* Parsing process */
	while ((opt = getopt(argc, argv, "vVh?")) != -1)
	{
		optind++;
		switch (opt)
		{
			/* Standard options for libgpa modules */
			case 'v': //parsed by wrz_msg_init()
			case 'V': //parsed by wrz_msg_init()
			case 'q': break;
			case '?': help(pgrname); break;
			case 'h': help(pgrname); break;
			default:
					  pr_error("find: illegal option %c (%x)\n",
							opt,opt);
					  help(pgrname);
					  break;
		}
	}
	optind--;
	argc-=optind;
	argv+=optind;

	/* Start of daemon creation */
	security_module = gpa_mod_create_owner(gpa_mod_security,"security",
			GPA_MOD_FLAG_MB_WRITE, SECURITY_NUMBER_MODIRS);
	GPA_RETCHECK_PTR(security_module, errno);

	gpa_mod_add_desc(security_module,"Security (HTTPS, etc.)");

	/* Creation of resources (lists) */
	mode_rsrc = gpa_rsrc_create("https", "Mode (none / generated / uploaded)",
			GPA_RSRC_TYPE_PRIVATE,GPA_RSRC_ENDIANESS_LITTLE);
	GPA_RETCHECK_PTR(mode_rsrc, errno);
	if(mode_rsrc) gpa_rsrc_append_child(security_module->root_rsrc,mode_rsrc);
	/* Creation of params for `mode` resource */
	mode = gpa_prm_create_enum(mode_rsrc,SECURITY_PRM_OID_MODE,"mode",
			GPA_PRM_VTX_ENUM,GPA_ACC_RL|GPA_ACC_INTERNAL,
			NULL,3,GPA_PRM_ENUM_OPT_INDEXED_DIRECT,0);
	GPA_RETCHECK_PTR(mode, errno);

	gpa_prm_set_desc(mode, "HTTP Mode");
	gpa_prm_enum_add_entry(mode, 0, "None");
	gpa_prm_enum_add_entry(mode, 1, "Generated");
	gpa_prm_enum_add_entry(mode, 2, "Uploaded");

	/* Create resources to authentication (Tacacs & Radius) */
	auth_rsrc = gpa_rsrc_create("auth", "Authentication resource",
			GPA_RSRC_TYPE_PRIVATE,GPA_RSRC_ENDIANESS_LITTLE);
	GPA_RETCHECK_PTR(mode_rsrc, errno);
	if(mode_rsrc) gpa_rsrc_append_child(security_module->root_rsrc,auth_rsrc);

	last_rsrc = gpa_rsrc_auth_create(auth_rsrc,"tacacs",
					"Resource to configure authentication using \
					Tacacs");
	if (!last_rsrc)
		pr_error ("Unable to create Tacacs resource\n");

	last_rsrc = gpa_rsrc_auth_create(auth_rsrc,"radius",
					"Resource to configure authentication using \
					Radius");
	if (!last_rsrc)
		pr_error ("Unable to create Radius resource\n");

	/* Binding of the resources to the module */
	ret = gpa_mod_add_rsrcs_assoc(security_module,NULL,rassoc,
			GPA_ARRAY_SIZE(rassoc));

	if(ret != 0)
	{
		pr_err("Error adding resource to module: %s\n",
				security_module->name);
		exit(errno);
	}


	while (1)
	{
		gpa_mod_handle_mb(security_module);
	}

	return GPA_EXIT_OK;
}

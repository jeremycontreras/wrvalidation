/**
 * @file security.h
 *
 * @brief This file contains the header for the security submodule
 *
 * @author Fidel Rodriguez Lopez (fidel.rodriguez@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 10-09-2019
 * @copyright Copyright (c) 2019 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os (security)
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os (security).
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#define SECURITY_PRM_OID_MODE        1
#define SECURITY_NUMBER_MODIRS       5


/**
 * @file security_auth.c
 *
 * @brief security auth resource
 *
 * @author Javier Carrillo Parejo (javier.carrillo@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 11-06-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <libgpa.h>
#include <libgpa/rsrc.h>
#include <libgpa/msg.h>
#include <libgpa/util.h>
#include "security_auth.h"

/**
 * @brief Create the resource for authentication methods (TACACS & RADIUS).
 *
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *gpa_rsrc_auth_create(struct gpa_rsrc *parent,
					const char *key, const char *desc)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(parent,-EINVAL);
	GPA_RETCHECK_PTRERRNO(key,-EINVAL);
	GPA_RETCHECK_PTRERRNO(desc,-EINVAL);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE,
				GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);


	//Create resource parameters
	last_prm = gpa_prm_create_str(self,_SECURITY_AUTH_IP,
			"server_ip",GPA_PRM_VTA_STRING,
			GPA_ACC_RL|GPA_ACC_INTERNAL,
			NULL,SECURITY_PRM_STR_LEN);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Authentication server ip address");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self,_SECURITY_AUTH_SECRET,
			"server_secret",GPA_PRM_VTA_STRING,
			GPA_ACC_RL|GPA_ACC_INTERNAL,
			NULL,SECURITY_PRM_STR_LEN);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Authentication server secret to allow \
				the communication");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	//Append child to parent
	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}
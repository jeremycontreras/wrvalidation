/**
 * @file security_auth.h
 *
 * @brief security authentication headers
 *
 * @author Javier Carrillo Parejo (javier.carrillo@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 11-06-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#ifndef SECURITY_AUTH_H_
#define SECURITY_AUTH_H_
#include <libgpa.h>

#define SECURITY_PRM_STR_LEN                   100

enum
{
	_SECURITY_AUTH_IP = 1,
	_SECURITY_AUTH_SECRET,
};

struct gpa_rsrc *gpa_rsrc_auth_create(struct gpa_rsrc *parent, const char *key, const char *desc);


#endif  /* SECURITY_AUTH_H_ */
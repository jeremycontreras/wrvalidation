/*
 * wdt_start.c
 *
 * Starts the watchdog timer and listens for signals to refresh it or stop it.
 * It can also set the WDT timeout at startup.
 *
 * Copyright (C) 2019 Seven Solutions (www.sevensols.com)
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 *
 * Last updated: Feb 20th, 2019
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <linux/watchdog.h>

#define DEFAULT_TIMEOUT 300

int fd;

void usage(void)
{
	printf("\nwdt_start\n\n"
	"Starts the watchdog timer and manages it.\n\n"
	"Usage:\n"
	"	wdt_start <watchdog_device> [timeout_in_seconds]\n\n"
	"The default timeout is %d seconds.\n"
	"Send SIGUSR1 to the process to refresh the WDT.\n"
	"SIGTERM and SIGINT stop the WDT\n\n",
	DEFAULT_TIMEOUT);
}

void sighandler(int signal)
{
	static const char magic = 'V';

	switch(signal)
	{
	case SIGUSR1:
		if (ioctl(fd, WDIOC_KEEPALIVE, 0))
		{
			fprintf(stderr, "Error refreshing watchdog. "
				"Trying to disable it\n"
				"errno: %d - %s\n", errno, strerror(errno));
			if (write(fd, &magic, 1) == -1)
			{
				fprintf(stderr, "Error disabling the watchdog\n"
					"errno: %d - %s\n", errno, strerror(errno));
			}
			close(fd);
			exit(1);
		}
		break;
	case SIGTERM:
	case SIGINT:
		if (write(fd, &magic, 1) == -1)
		{
			fprintf(stderr, "Error disabling the watchdog\n"
				"errno: %d - %s\n", errno, strerror(errno));
			close(fd);
			exit(1);
		}
		close(fd);
		exit(0);
		break;
	default:
		break;
	}
}

int main(int argc, char **argv)
{
	struct sigaction sa_usr;
	int timeout = DEFAULT_TIMEOUT;

	if (argc < 2)
	{
		usage();
		return 1;
	}

	memset(&sa_usr, 0, sizeof(sa_usr));
	sa_usr.sa_handler = sighandler;
	sigaction(SIGUSR1, &sa_usr, NULL);
	sigaction(SIGTERM, &sa_usr, NULL);
	sigaction(SIGINT, &sa_usr, NULL);

	if ((fd = open(argv[1], O_WRONLY)) < 0)
	{
		fprintf(stderr, "Can't open device file: %s\n"
			"errno: %d - %s\n", argv[1], errno, strerror(errno));
		return 1;
	}

	if (argc == 3) {
		timeout = strtol(argv[2], NULL, 10);
	}
	if (ioctl(fd, WDIOC_SETTIMEOUT, &timeout))
	{
		fprintf(stderr, "Error setting timeout in %s\n"
			"errno: %d - %s\n", argv[1], errno, strerror(errno));
		return 1;
	}
	if (ioctl(fd, WDIOC_KEEPALIVE, 0))
	{
		fprintf(stderr, "Error refreshing watchdog %s\n"
			"errno: %d - %s\n", argv[1], errno, strerror(errno));
		return 1;
	}

	/* Loop forever waiting for signals */
	while (1)
	{
		pause();
	}

	return 0;
}

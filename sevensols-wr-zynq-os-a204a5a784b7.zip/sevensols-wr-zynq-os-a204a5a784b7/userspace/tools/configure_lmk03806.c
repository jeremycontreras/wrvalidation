/*
 * Configure the LMK03806 connected to AXI Quad-SPI core.
 *
 * Copyright (C) 2016 Seven Solutions (www.sevensols.com)
 * Author: Benoit Rat <benoit@sevensols.com>
 *
 * This works has been based from Xilinx FSBL lmk code.
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#define NBUF 1024

#include <libwrz.h>
#include <libwrz/rgxfile.h>

//static void dbg_fpga_writel(uint32_t reg, uint32_t val)
//{
//	_fpga_writel(reg,val);
//	pr_debug("@0x%X => 0x%x\n",reg,val);
//}
//static uint32_t dbg_fpga_readl(uint32_t reg)
//{
//	uint32_t tmp=0xDEADDEAD;
//	tmp= _fpga_readl(reg);
//	pr_debug("@0x%X <= 0x%x\n",reg,tmp);
//	return tmp;
//}

//#define Xil_In32      dbg_fpga_readl
//#define Xil_Out32     dbg_fpga_writel

#define Xil_In32	_fpga_readl
#define Xil_Out32	_fpga_writel


#include <libwrz/xilinx/xspi_l.h>

#define XPS_SYS_CTRL_BASEADDR		0xF8000000	/* AKA SLCR */

/*
 * SLCR Registers
 */
#define PS_RST_CTRL_REG			(XPS_SYS_CTRL_BASEADDR + 0x200)
#define FPGA_RESET_REG			(XPS_SYS_CTRL_BASEADDR + 0x240)
#define RESET_REASON_REG		(XPS_SYS_CTRL_BASEADDR + 0x250)
#define RESET_REASON_CLR		(XPS_SYS_CTRL_BASEADDR + 0x254)
#define REBOOT_STATUS_REG		(XPS_SYS_CTRL_BASEADDR + 0x258)
#define BOOT_MODE_REG			(XPS_SYS_CTRL_BASEADDR + 0x25C)
#define PS_LVL_SHFTR_EN			(XPS_SYS_CTRL_BASEADDR + 0x900)

#define BUFFER_SIZE  25

/*
 * The buffer used for Transmission/Reception of the SPI test data
 */
uint32_t Buffer[BUFFER_SIZE];


struct lmk_reg {
	uint32_t reg;
	uint32_t val;
};

/**
#define XSpi_ReadReg(BaseAddress, RegOffset) \
		_fpga_readl((uint32_t)((BaseAddress) + (RegOffset)))
#define XSpi_WriteReg(BaseAddress, RegOffset, RegisterValue) \
		_fpga_writel((uint32_t)((BaseAddress) + (RegOffset)), (RegisterValue))
**/

int lmk03806_set_freq(int ch, float freq)
{
	uint32_t BaseAddress = 0;
	uint32_t Control;

	pr_info("Setting ch%d @ %f MHz is not implemented\n",ch,freq);
	return -ENOSYS;


	Control = (XSP_CR_MASTER_MODE_MASK | XSP_CR_ENABLE_MASK);
	Control |= XSP_CR_TRANS_INHIBIT_MASK;
	XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, Control);

	XSpi_WriteReg(BaseAddress, XSP_SSR_OFFSET, 0x00000000);


}


int lmk03806_init(struct wrz_rgxf_handler* p_rgx, uint8_t power_cycle)
{
	uint32_t Control;
	uint32_t BaseAddress = 0;
	uint32_t Count;

	WRZ_RETCHECK_PTR(p_rgx,-EFAULT);
	WRZ_RETCHECK_MSG(p_rgx->len>0,-1,"rgx data is empty");

	Control = (XSP_CR_MASTER_MODE_MASK | XSP_CR_ENABLE_MASK);
	Control |= XSP_CR_TRANS_INHIBIT_MASK;
	XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, Control);

	XSpi_WriteReg(BaseAddress, XSP_SSR_OFFSET, 0x00000000);

	//Register for power cycle
	Buffer[0]=0x800201C1; //POWERDOWN
	Buffer[1]=0x800001C1; //POWERUP


	for (Count = 2; Count < BUFFER_SIZE; Count++) {
		Buffer[Count] = wrz_rgxf_get_integer(p_rgx,Count-2,1);
		pr_debug("#%02d: x%08x\n",Count,Buffer[Count]);
	}

	/*
	 * Fill up the transmitter with data, assuming the receiver can hold
	 * the same amount of data.
	 */

	for (Count = (power_cycle)?0:2; Count < BUFFER_SIZE; Count++) {
		pr_info("0x%08x \n",Buffer[Count]);
		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, Buffer[Count]);
		//usleep(100);
		Control = XSpi_ReadReg(BaseAddress, XSP_CR_OFFSET);
		Control |= XSP_CR_ENABLE_MASK;
		Control &= ~XSP_CR_TRANS_INHIBIT_MASK;
		XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, Control);
		while (!(XSpi_ReadReg(BaseAddress, XSP_SR_OFFSET) & XSP_SR_TX_EMPTY_MASK)){}
		Control = XSpi_ReadReg(BaseAddress, XSP_CR_OFFSET);
		Control |= XSP_CR_TRANS_INHIBIT_MASK;
		XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, Control);
		//usleep(100);
	}
	return 0;
}


void help(const char* pgrname)
{
	printf("usage: %s [OPTIONS] [config_file]\n", pgrname);
	printf("where OPTIONS are:\n"
				"   -f Frequency (in MHz) of CLK_TTL output\n"
				"   -p Power cycle (shutdown and reboot lmk)\n"
				"   -0 Use Xilinx SPI @ 0x81E00000 (default)\n"
				"   -1 Use Xilinx SPI @ 0x81E10000\n"
				"   -2 Use Xilinx SPI @ 0x81E20000\n"
				"   -h Show this little help message\n"
				"   -q Quiet mode\n"
				"   -v Verbose mode\n"
				"   -V Very verbose\n"
				"\n");

	pr_debug("version: %s (%s); compiled at %s %s\n",
		__GIT_VER__, __GIT_USR__, __DATE__, __TIME__);

		exit(1);
}

int main(int argc, char ** argv) {
	int ret;
	char func;
	struct wrz_rgxf_handler h_rgx = {0};
	const char *pgrname=argv[0];
	uint8_t f_pwrcyc=0;
	float freq_out=-1;
	uint8_t mmap_id=WRZ_FPGA_MAP_DEVSPI_0;
	char *p;


	wrz_msg_init(argc,argv);

	while(argc>1 && argv[1][0]=='-')
	{
		func=argv[1][1];
		switch(func)
		{
		case 'f':
			freq_out=strtof(argv[2], &p);
			if(*p) {
				pr_error("'%s' is not a valid frequency\n",argv[2]);
				help(pgrname); break;
			}
			argc--;
			argv++;
			break;
		case 'p': f_pwrcyc=1; break;
		case '0': mmap_id=WRZ_FPGA_MAP_DEVSPI_0; break;
		case '1': mmap_id=WRZ_FPGA_MAP_DEVSPI_1; break;
		case '2': mmap_id=WRZ_FPGA_MAP_DEVSPI_2; break;
		case 'h': help(pgrname); break;
		case 'v': //parsed by wrz_msg_init()
		case 'V': //parsed by wrz_msg_init()
		case 'q': break;
		default: pr_error("Unknown OPTIONS -%c\n",func); help(pgrname); break;
		}
		argc--;
		argv++;
	}

	//Open config file if present
	if(argc >1)
	{
		const char *ext=".txt";
		ret=strlen(argv[1])-strlen(ext);
		pr_debug("%s %d -> %s\n",argv[1],ret,argv[1]+ret);
		if(ret<0 || strcmp(argv[1]+ret,ext)!=0)
		{
			pr_err("File %s must have a %s extension\n",argv[1],ext);
			return WRZ_EXIT_CONF;
		}
		ret=wrz_rgxf_init(&h_rgx,argv[1],"R([0-9]+)[^x]*x([0-9a-fA-F]*)","dx");
		if(ret) return WRZ_EXIT_CONF;
		wrz_rgxf_read(&h_rgx);
		for(ret=0;ret<h_rgx.len && wrz_msg_checklvl(LOG_DEBUG);ret++)
		{
			printf("#%02d: R%04x %08x\n",ret,wrz_rgxf_get_integer(&h_rgx,ret,0),(uint32_t)wrz_rgxf_get_integer(&h_rgx,ret,1));
		}
	}

	ret=wrz_fpga_mmap_init(mmap_id);
	if(ret) return WRZ_EXIT_MMAP;

	if(h_rgx.len>0)
		ret=lmk03806_init(&h_rgx,f_pwrcyc);

	if(freq_out>0)
	{
		ret=lmk03806_set_freq(1,freq_out);
	}


	wrz_rgxf_close(&h_rgx);
	wrz_fpga_munmap();

	return ret;
}

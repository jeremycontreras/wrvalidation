/*
 * Trivial tool to set WR date in the Zen from local or NTP time
 *
 * Miguel Jimenez Lopez, 2015, for UGR, 2015. GPL2 or later
 */
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <fcntl.h>
#include <time.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/timex.h>
#include <libgpa/wb/wrc/pps_gen_regs.h>


#ifndef MOD_TAI
#define MOD_TAI 0x80
#endif
#define WRDATE_CFG_FILE "/etc/wr_date.conf"
#define WRDATE_LEAP_FILE "/etc/leap-seconds.list"
// Real path: /usr/local/etc/custom-leap-seconds.list (copied from /media/data/usr/local/etc)
#define WRDATE_USR_LEAP_FILE "/etc/custom-leap-seconds.list"
#define TIMECTRL_LEAP_FILE "/sys/kernel/ktmgr/leap_second"

#define HAL_DEV_NAME_PATH       "/proc/device-tree/dev_info/devname"

/* Ugly, Ugly! */
#define WR_RTS_BASE_ADDR_ZEN    0x43c00000
#define WR_RTS_BASE_ADDR_Z16    0x43d00000
#define WR_RTS_OFFSET_PPSG      0x20500

#define PPSG_STEP_IN_NS 16    /* we count a 62.5MHz */

void help(char *prgname)
{
	fprintf(stderr, "%s: Use: \"%s [<options>] <cmd> [<args>]\n",
		prgname, prgname);
	fprintf(stderr,
		"  The program uses %s as default config file name\n"
		"  -f       force: run even if not on a WR zen\n"
		"  -c <cfg> configfile to use in place of the default\n"
		"  -v       verbose: report what the program does\n"
		"  -n       do not act in practice\n"
		"    get             print WR time to stdout\n"
		"    get tohost      print WR time and set system time\n"
		"    diff            show the difference between WR FPGA time (HW) and linux time (SW)\n"
		"    set <value>     set WR time from scalar seconds\n"
		"    set host        set WR TAI from current host time\n"
		"    adjns host      Adjust WR TAI nanoseconds from current host time\n"
/*		"    set ntp         set TAI from ntp and leap seconds" */
/*		"    set ntp:<ip>    set from specified ntp server\n" */
		, WRDATE_CFG_FILE);
	exit(1);
}

int opt_verbose, opt_force, opt_not;
char *opt_cfgfile = WRDATE_CFG_FILE;
char *prgname;

int wrdate_cfgfile(char *fname)
{
	/* FIXME: parse config file */
	return 0;
}


uint32_t wrz_get_rts_addr(void)
{
	char str[64];
	uint32_t rts_addr=WR_RTS_BASE_ADDR_ZEN;
	FILE * file;
	file = fopen(HAL_DEV_NAME_PATH, "r");
	if (file) {
		fscanf(file, "%63[^\n]", str);
		if(strcmp(str,"WR-ZEN")==0)
		{
			rts_addr=WR_RTS_BASE_ADDR_ZEN;
		}
		else if(strcmp(str,"WR-Z16")==0)
		{
			rts_addr=WR_RTS_BASE_ADDR_Z16;
		}
		else
		{
			fprintf(stderr,"Could not detect device family '%s'\n",str);
			errno=-EINVAL;
		}
		fclose(file);
	}
	else
	{
		fprintf(stderr,"Could not open %s\n",HAL_DEV_NAME_PATH);
	}
	return rts_addr;
}


/* This returns wr time, used for syncing to a second transition */
uint64_t gettimeof_wr(struct timeval *tv, volatile struct PPSG_WB *pps)
{
	uint32_t tai_h,tai_l,nsec, tmp1, tmp2;
	uint64_t tai;

	//Loop to ensure integrity of second
	do {
		tai_h = pps->CNTR_UTCHI & 0xFF;
		tai_l = pps->CNTR_UTCLO;
		nsec = pps->CNTR_NSEC * PPSG_STEP_IN_NS;
		tmp1 = pps->CNTR_UTCHI & 0xFF;
		tmp2 = pps->CNTR_UTCLO;
	} while((tmp1 != tai_h) || (tmp2 != tai_l));

	tai = (uint64_t)(tai_h) << 32 | tai_l;

	tv->tv_sec = tai;
	tv->tv_usec = nsec / 1000;

	return tai;
}

/**
 * Return the number of leap seconds stored in the kernel
 */
int get_kern_leaps(void)
{
	struct timex tx = {0};
	if (adjtimex(&tx) < 0) {
		fprintf(stderr, "%s: adjtimex(): %s\n", prgname,
			strerror(errno));
			return 0;
	}
	return tx.tai;
}

/* create a map, that is never goind to be released */
void *create_map(int fdmem, unsigned long address, unsigned long size)
{
	unsigned long ps = getpagesize();
	unsigned long offset, fragment, len;
	void *mapaddr;

	offset = address & ~(ps -1);
	fragment = address & (ps -1);
	len = address + size - offset;

	mapaddr = mmap(0, len, PROT_READ | PROT_WRITE,
		       MAP_SHARED, fdmem, offset);
	if (mapaddr == MAP_FAILED) {
		fprintf(stderr, "%s: mmap: %s\n", prgname, strerror(errno));
		exit(1);
	}
	return mapaddr + fragment;
}

int wrdate_get(volatile struct PPSG_WB *pps, int tohost)
{
	unsigned long taih, tail, nsec, tmp1, tmp2;
	uint64_t tai;
	time_t t;
	struct timeval hw,sw;
	struct tm tm;
	char utcs[64], tais[64];
	char tlocal[64],tzone[10];
	int tai_offset;

	tai_offset = get_kern_leaps();

	if (opt_not) {
		gettimeofday(&sw, NULL);
		taih = 0;
		tail = sw.tv_sec + tai_offset;
		nsec = sw.tv_usec * 1000;
	} else {
		//Loop to ensure integrity of second
		do {
			taih = pps->CNTR_UTCHI & 0xFF;
			tail = pps->CNTR_UTCLO;
			nsec = pps->CNTR_NSEC * PPSG_STEP_IN_NS;
			tmp1 = pps->CNTR_UTCHI & 0xFF;
			tmp2 = pps->CNTR_UTCLO;
		} while((tmp1 != taih) || (tmp2 != tail));
	}
	gettimeofday(&sw, NULL);

	tai = (uint64_t)(taih) << 32 | tail;

	/* Before printing (which takes time), set host time if so asked to */
	if (tohost) {
		hw.tv_sec = tai - tai_offset;
		hw.tv_usec = nsec / 1000;
		if (settimeofday(&hw, NULL))
			fprintf(stderr, "wr_date: settimeofday(): %s\n",
				strerror(errno));
	}

	t = tai; gmtime_r(&t, &tm);
	strftime(tais, sizeof(tais), "%Y-%m-%d %H:%M:%S", &tm);
	t -= tai_offset; gmtime_r(&t, &tm);
	strftime(utcs, sizeof(utcs), "%Y-%m-%d %H:%M:%S", &tm);
	printf("%lli.%09li TAI\n"
	       "%s.%09li TAI\n"
	       "%s.%09li UTC\n", tai, nsec, tais, nsec, utcs, nsec);

	//Show local
	localtime_r(&t, &tm);
	if(tm.tm_isdst)
	{
		strftime(tlocal, sizeof(tlocal), "%Y-%m-%d %H:%M:%S", &tm);
		strftime(tzone, sizeof(tzone), "%Z", &tm);
		printf("%s.%09li %s\n",tlocal,nsec,tzone);
	}
	if(opt_verbose)
	{
		gmtime_r(&(sw.tv_sec), &tm);
		strftime(utcs, sizeof(utcs), "%Y-%m-%d %H:%M:%S", &tm);
		printf("%s.%09li UTC (linux)\n", utcs, sw.tv_usec*1000);
	}
	return 0;
}


/**
 * Function to subtract timeval in a robust way
 *
 * In order to properly print the result on screen you can use:
 *
 *     int neg=timeval_subtract(&diff, &a, &b);
 *     printf("%c%li.%06li\n",neg?'-':'+',labs(diff.tv_sec),labs(diff.tv_usec));
 *
 * @ref: https://stackoverflow.com/questions/15846762/timeval-subtract-explanation
 * @note for safety reason a copy of x,y is used internally so x,y are never modified
 * @param[inout] result A pointer on a timeval structure where the result will be stored.
 * @param[in] x A pointer on x timeval struct
 * @param[in] y A pointer on y timeval struct
 * @return 1 if result is negative (seconds or useconds)
 *
 *
 */
int timeval_subtract(struct timeval *result, struct timeval *x, struct timeval *y)
{
	struct timeval xx = *x;
	struct timeval yy = *y;
	x = &xx; y = &yy;

	if (x->tv_usec > 999999)
	{
		x->tv_sec += x->tv_usec / 1000000;
		x->tv_usec %= 1000000;
	}

	if (y->tv_usec > 999999)
	{
		y->tv_sec += y->tv_usec / 1000000;
		y->tv_usec %= 1000000;
	}

	result->tv_sec = x->tv_sec - y->tv_sec;
	result->tv_usec = x->tv_usec - y->tv_usec;

	if(result->tv_sec>0 && result->tv_usec < 0)
	{
		result->tv_usec += 1000000;
		result->tv_sec--; // borrow
	}
	else if(result->tv_sec<0 && result->tv_usec > 0)
	{
		result->tv_usec -= 1000000;
		result->tv_sec++; // borrow
	}

	return (result->tv_sec < 0) || (result->tv_usec<0);
}



int wrdate_diff(volatile struct PPSG_WB *pps)
{
	struct timeval sw, hw, diff;
	int neg=0;

	gettimeof_wr(&hw, pps);
	gettimeofday(&sw, NULL);

	neg=timeval_subtract(&diff, &hw, &sw);

	printf("%s%c%li.%06li\n",opt_verbose?("TAI(HW)-UTC(SW): "):(""),neg?'-':'+',labs(diff.tv_sec),labs(diff.tv_usec));
	if(opt_verbose)
	{

		hw.tv_sec-=get_kern_leaps(); //Convert HW clock from TAI to UTC

		neg=timeval_subtract(&diff, &hw, &sw);
		printf("UTC(HW)-UTC(SW): %c%li.%06li\n",neg?'-':'+',labs(diff.tv_sec),labs(diff.tv_usec));
	}
	return 0;
}

/* Fix the TAI representation looking at the leap file */
int fix_host_tai(void)
{
	struct timex t;
	char s[128];
	unsigned long long now, now_2014, leapt, expire = 0, usr_expire = 0;
	int i, *p, sys_tai_offset = 0, usr_tai_offset = 0, tai_offset = 0;
	FILE *f, *f2;

	/* first: get the current offset */
	memset(&t, 0, sizeof(t));
	if (adjtimex(&t) < 0) {
		fprintf(stderr, "%s: adjtimex(): %s\n", prgname,
			strerror(errno));
		return 0;
	}

	/*
	 * At the very start, we believe to be Jan 1st 1970. But
	 * what we really want is counting the tai_offset, so WR
	 * can then set system time by itself.  And, being wrong by
	 * 1-2 seconds is ok (system time is for log messages only),
	 * but being off by 35 seconds is not. So let's use "35" by
	 * default, i.e. be aware we are at least in 2014
	 */
	now_2014 = 1417806803; /* as I write this */

	/* then, find the current time, using such offset */
	now = time(NULL);
	if (now < now_2014)
		now = now_2014;

	now += 2208988800LL; /* (for TAI: + utc_offset) */

	/* Open system leap-seconds file */
	f = fopen(WRDATE_LEAP_FILE, "r");
	if (!f) {
		fprintf(stderr, "%s: %s: %s\n", prgname, WRDATE_LEAP_FILE,
			strerror(errno));
		return 0;
	}

	/* Parse system leap-seconds file (extract expire and tai_offset) */
	while (fgets(s, sizeof(s), f)) {
		if (sscanf(s, "#@ %lli", &expire) == 1)
			continue;
		if (sscanf(s, "%lli %i", &leapt, &i) != 2)
			continue;
		/* check this line, and apply it if it's in the past */
		if (leapt < now)
			sys_tai_offset = i;
	}
	fclose(f);

	/* User custom file for leap-seconds */
	f2 = fopen(WRDATE_USR_LEAP_FILE, "r");

	/* Parse user leap-seconds file if exists (extract expire and tai_offset)
	   Check which is the latest expiration date and load this file */
	if(f2) {
		while (fgets(s, sizeof(s), f2)) {
			if (sscanf(s, "#@ %lli", &usr_expire) == 1)
				continue;
			if (sscanf(s, "%lli %i", &leapt, &i) != 2)
				continue;
			/* check this line, and apply it if it's in the past */
			if (leapt < now)
				usr_tai_offset = i;
		}

		/* TAI offset from latest expiration date file */
		if (expire > usr_expire) {
			fprintf(stderr, "%s: Using system file for leap-seconds (%s) \n",
				prgname, WRDATE_LEAP_FILE);
			tai_offset = sys_tai_offset;
		}
		else {
			fprintf(stderr, "%s: Using User custom file for leap-seconds (%s) \n",
				prgname, WRDATE_USR_LEAP_FILE);
			tai_offset = usr_tai_offset;
		}

		fclose(f2);
	} else {
		/* User leap-seconds file not found, use system one */
		fprintf(stderr, "%s: Using system file for leap-seconds (%s) \n",
			prgname, WRDATE_LEAP_FILE);
		tai_offset = sys_tai_offset;
	}

	p = (int *)(&t.tai);

	if (tai_offset != *p) {
		if (opt_verbose)
			printf("Previous TAI offset: %i\n", *p);
		t.constant = tai_offset;
		t.modes = MOD_TAI;
		if (adjtimex(&t) < 0) {
			fprintf(stderr, "%s: adjtimex(): %s\n", prgname,
				strerror(errno));
			return tai_offset;
		}
	}
	if (opt_verbose)
		printf("Current TAI offset: %i\n", *p);

	/* insert the leap_second in the time manager sysfs control file */
	/* TEMPORALLY!! This should go to the time manager */
	char* cmd=calloc(500,sizeof(char));
	snprintf(cmd,500,"%s%d%s%s","echo ",tai_offset," >",TIMECTRL_LEAP_FILE);

	if(system(cmd))
		fprintf(stderr, "%s: system(): %s\n", prgname, "Error setting the tai_offset, file exists?");

	free(cmd);

	return tai_offset;
}

/* This sets WR time from host time */
int wrdate_internal_set(volatile struct PPSG_WB *pps, int adjns)
{
	struct timeval tvh, tvr; /* host, rabbit */
	signed long long diff64;
	signed long diff;
	int tai_offset;

	tai_offset = fix_host_tai();

	gettimeofday(&tvh, NULL);
	gettimeof_wr(&tvr, pps);

	/* diff is the expected step to be added, so host - WR */
	diff = tvh.tv_usec - tvr.tv_usec;
	diff64 = tvh.tv_sec + tai_offset - tvr.tv_sec;
	if (diff > 500 * 1000) {
		diff64++;
		diff -= 1000 * 1000;
	}
	if (diff < -500 * 1000) {
		diff64--;
		diff += 1000 * 1000;
	}

	if(opt_not)
	{
		if (!opt_verbose) return 0;
		printf("Nothing done: -n option selected\n");
	}
	else if(adjns)
	{
		pps->ADJ_UTCLO = 0;
		pps->ADJ_UTCHI = 0;
		pps->ADJ_NSEC = diff * 64 + diff / 2;
		asm("" : : : "memory"); /* barrier... */
		pps->CR = pps->CR | PPSG_CR_CNT_ADJ;
		if (opt_verbose)
			printf("adjusting by %li usecs\n", diff);
	}
	else if (diff64) {
		/* We must write a signed "adjustment" value */
		pps->ADJ_UTCLO = diff64 & 0xffffffff;
		pps->ADJ_UTCHI = (diff64 >> 32) & 0xff;
		pps->ADJ_NSEC = 0;
		asm("" : : : "memory"); /* barrier... */
		pps->CR = pps->CR | PPSG_CR_CNT_ADJ;
		if (opt_verbose)
			printf("adjusting by %lli seconds\n", diff64);
	}
	else
	{
		if (opt_verbose) printf("Nothing done: wrdate seconds are already correctly set\n");
		return 0;
	}

	//Printf only after setting time to be more deterministic

	/* Warn if more than 200ms away */
	if (diff > 200 * 1000 || diff < -200 * 1000)
		fprintf(stderr, "%s: Warning: fractional second differs by"
			"more than 0.2 (%li ms)\n", prgname, diff / 1000);

	if (opt_verbose) {
		printf("Host time: %9li.%06li\n", (long)(tvh.tv_sec),
		       (long)(tvh.tv_usec));
		printf("WR   time: %9li.%06li\n", (long)(tvr.tv_sec),
		       (long)(tvr.tv_usec));
		printf("Fractional difference: %li usec\n", diff);
	}

	return 0;
}

/* Frontend to the set mechanism: parse the argument */
int wrdate_set(volatile struct PPSG_WB *pps, char *arg, int adjns)
{
	char *s;
	unsigned long t; /* WARNING: 64 bit */
	struct timeval tv;


	if (!strcmp(arg, "host"))
		return wrdate_internal_set(pps,adjns);

	if(adjns)
	{
		fprintf(stderr,"adjns function only support 'host' argument\n");
		return 1;
	}

	s = strdup(arg);
	if (sscanf(arg, "%li%s", &t, s) == 1) {
		tv.tv_sec = t;
		tv.tv_usec = 0;
		if (settimeofday(&tv, NULL) < 0) {
			fprintf(stderr, "%s: settimeofday(%s): %s\n",
				prgname, arg, strerror(errno));
			exit(1);
		}
		return wrdate_internal_set(pps,0);
	}

	/* FIXME: other time formats */
	fprintf(stderr,"Wrong format. Only parse seconds as scalar\n");
	return 1;
}

int main(int argc, char **argv)
{
	int c, fd, tohost = 0,ret = 0;
	char *cmd;
	volatile struct PPSG_WB *pps;

	prgname = argv[0];

	while ( (c = getopt(argc, argv, "fc:vn")) != -1) {
		switch(c) {
		case 'f':
			opt_force = 1;
			break;
		case 'c':
			opt_cfgfile = optarg;
			break;
		case 'v':
			opt_verbose = 1;
			break;
		case 'n':
			opt_not = 1;
			break;
		default:
			help(argv[0]);
		}
	}
	if (optind > argc - 1)
		help(argv[0]);

	cmd = argv[optind++];


	fd = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd < 0) {
		fprintf(stderr, "%s: /dev/mem: %s\n", argv[0], strerror(errno));
		exit(1);
	}

	uint32_t ppsg_addr=wrz_get_rts_addr()+ WR_RTS_OFFSET_PPSG;
	if (opt_verbose)
		printf("Mapping @ 0x%08x\n", ppsg_addr);

	pps = create_map(fd, ppsg_addr, sizeof(*pps));
	close(fd);

	wrdate_cfgfile(opt_cfgfile);

	if (!strcmp(cmd, "get")) {
		/* parse the optional "tohost" argument */
		if (optind == argc - 1 && !strcmp(argv[optind], "tohost"))
			tohost = 1;
		else if (optind < argc)
			help(argv[0]);
		return wrdate_get(pps, tohost);
	}

	if (!strcmp(cmd, "diff")) {
		return wrdate_diff(pps);
	}

	/* only other command is "set", with one argument */
	if (!strcmp(cmd, "adjns")) {
		if (optind == argc - 1)
			return wrdate_set(pps, argv[optind],1);
	}

	if (strcmp(cmd, "set") || optind != argc - 1)
		help(argv[0]);

	ret = wrdate_set(pps, argv[optind],0);

	//Preventive sleep to really apply time to FPGA
	sleep(2);

	return ret;
}

#include <iostream>
#include <unistd.h>
#include <algorithm>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <utility>
#include <list>
#include <map>
#include <regex>
#include <iomanip>

#define GPA_CONVTABLE_PATH "/var/run/gpa_module_translate.dat"
#define GPA_DOTCONFIG_PATH "/root/.config"
#define GPA_DOTCONFIG_REGEX_PREFIX "(\\ )*(CONFIG\\_)\\d+(\\_)\\d+(\\_)\\d+"
#define GPA_DOTCONFIG_REGEX GPA_DOTCONFIG_REGEX_PREFIX"[\\w\\.0-9]+(=)[\\w\\W\"\\.\\_\\ /0-9]+"
#define GPA_DOTCONFIG_REGEX_OLD "(\\ )*(CONFIG\\_)[\\w0-9\\ .]+(=)[\\w\\W\".\\_\\!\\ /0-9]+"
#define GPA_CONVTABLE_REGEX "[\\d\\.]+(;)[\\w0-9\"\\_\\ .]+"
#define VERBOSE_PRINTF(x) ((verbose==false)?void(): void(std::cout << (x) <<"\n"))

/* return values*/
#define GPA_CONFIG_RET_ERROR      -1 // we didnt found value for this oid, update failed...
#define GPA_CONFIG_RET_OID         1 // value was found, in dot-config with oid (i.e: CONFIG_10_1222_12_HALD....)
#define GPA_CONFIG_RET_LEGACY      2 // value was found, in dot-config with conversion (i.e: CONFIG_MISC_NTP_SERVER="")
#define GPA_CONFIG_RET_UPDATED     3 // dot-config was updated successfully

bool verbose = false;

/* @brief class OID_GPA contains the information about an object called "OID",
 *        with the mod_type, modir, prm_oid and some useful methods to work with
 *        avoiding the needing of deal with strings. For example, the format
 *        (12.1222.12) or (12_1222_12).*/
class OID_GPA
{
	public:
		bool valid;     // true if OID_GPA is correctly filled or false otherwise.
		int mod_type;
		int modir;
		int prm_oid;

		/* @brief parse_from_str initializes the object with a string
		 * and set the valid flag to true. This should be the
		 * constructor for this class, instead of the default one.
		 *
		 * @param in std::string the string to initialize the object,
		 *        for example: "12_12222_12" or "15.15555:155", but
		 *        according to the second parameter sep.
		 * @param sep char the char to be separator of the different
		 *        elements of a OID ('_','.', etc...)
		 *
		 * @return bool true if success or false otherwise (i.e: bad
		 *         parsing). This return value is equivalent to the
		 *         valid attribute.
		*/
		bool parse_from_str(std::string in,char sep);

		/* @brief get_key could be the reverse of the parse_from_str()
		 * method/constructor. This method returns the key as string of
		 * the OID. Selecting the separator it will insert it between
		 * different values (mod_type,modir,prm_oid).
		 *
		 * @param sep char is the char to be inserted as separator for
		 *        an oid. For example, giving get_key('.') will return
		 *        the string "12.1222.12", or get_key('_') will
		 *        generate "12_12222_12".
		 *
		 * @return std::string with the string resulting or the string
		 *         "error" if any error is found.
		*/
		std::string get_key(char sep);
};

/* @brief config_table is a class which helps with the parsing of files into
 *        tables. This class has methods to write or read from a file, and make
 *        searchs in a efficiently way.
 *
 *        When a config file (multiple colums are supported) is parsed, it is
 *        include into a internal (but public) dictionary.
 *
 *        For example, given a configuration file:
 *        1;EXAMPLE;TEST;12.12
 *
 *        and after the parsing, the dictionary will be:
 *
 *        KEY  |    0    |    1  |   2   |
 *        ------------------------------
 *        "1"  |"EXAMPLE"| "TEST"| "12.12|
 *        ................................
 *
 *        The first column is the key, saved as string. The rest of params are
 *        inserted into a std::vector<std::string> as values of that key,
 *        allowing a efficient searchs.
 *
 *        IMPORTANT: As you can imagine, only UNIQUE KEY is possible.
 *
 *        This class is used to manage both, dot-config file and conversion
 *        files (tables, snmpd, etc...)
 *        It could be useful to work with CSV format as well.
 */
class config_table
{
	private:
		std::string filename;
		bool valid;
		size_t size;
	public:
		std::map<std::string,std::vector<std::string>> dict;

		/* @brief get_element returns the entry given a key. If the key
		 *        is not found it will return an empty vector.
		 *
		 * @param std::string key with the key to look in the table
		 *        already initialized.
		 *
		 * @return std::vector<std::string> returns the vector with the
		 *         entries associated to the given key. If the key was
		 *         not found, it will return an empty vector of
		 *         strings.
		*/
		std::vector<std::string> get_element(std::string key);

		/* @brief constructor of this class. Given an regular
		 *        expression and a separator for the columns, the file
		 *        specified in the parameter is parsed and initialize
		 *        the internal dictionary.
		 *
		 * @param file std::string filename (absolute path) to the file
		 *        which we want to read.
		 * @param expr_str std::string string with the regular
		 *        expression that EVERY LINE has to match. If the line
		 *        does not match with, it won't be inserted in the
		 *        dictionary.
		 * @param sep char is the separator between columns.
		 *
		 * @return a new object of class config_table.
		*/
		config_table(std::string file, std::string expr_str, char sep);

		/* @brief update is a method specially designed for the
		 *        dot-config libgpa-conversion. It correctly modifies
		 *        all entries to convert the old format
		 *        (CONFIG_XXX_YYY_ZZ=W) into the new format according
		 *        to the definition on a conversion table composed by
		 *        two columns with the OID-EQUIVALENCE.
		 *        If any entry does not have conversion, the line is
		 *        kept as it is.
		 *
		 * @param conv config_table is the conversion table. This
		 *        object is restricted to have as minimum two columns,
		 *        it means, it should be correctly initialized.
		 *
		 * @param new_dot_config std::string is the absolute path to
		 *        the file where we want to write the new converted
		 *        dot-config. Since this function is special for this
		 *        functionality, it adds a = between the first and the
		 *        second parameter.
		 *
		 * @return bool true if the conversion was successfully or
		 *         false otherwise. Take into account that a partial
		 *         conversion could result into a false return (i.e:
		 *         only one parameter was not found in the conversion
		 *         table, the function will return false).
		*/
		bool update(config_table conv,std::string new_dot_config);

		/* @brief print is a function used for a debug or verbose
		 * purposes
		*/
		void print();
};

void config_table::print()
{
	std::cout << "========================================\n";
	std::cout << "FILE (name="<<filename<<")\n";
	std::cout << "----------------------------------------\n";
	if(!valid) std::cout << "Warning: file contains some invalid entries! \n";
	for(auto it = dict.cbegin(); it != dict.cend(); ++it)
	{
		std::cout << std::left << std::setfill(' ')<<std::setw(40)<<it->first;
		for(int i=0;i<it->second.size();++i)
			std::cout<<"| "<<it->second[i]<<std::fixed;
		std::cout<<"\n"<<std::setw(0);
	}
	std::cout << "========================================\n\n";
}

bool config_table::update(config_table conv,std::string new_dot_config)
{
	std::regex expr(GPA_DOTCONFIG_REGEX_PREFIX);
	std::ofstream output_file;
	output_file.open(new_dot_config);
	bool not_found = true;
	if(!output_file.is_open())
	{
		VERBOSE_PRINTF("Error opening the output file "+new_dot_config);
		return false;
	}
	std::vector<std::string> to_remove;
	for(auto it = dict.begin(); it!=dict.end(); ++it)
	{
		if(!std::regex_match(it->first,expr)) // only enters for legacy entries
		{
			/* try conversion... */
			bool converted = false;
			for(auto it2 = conv.dict.begin();it2!=conv.dict.end();++it2)
			{
				if(it->first == it2->second[0]) // found!
				{
					OID_GPA new_oid = OID_GPA();
					new_oid.parse_from_str(it2->first,'.');
					std::vector<std::string> buf = it->second;
					dict.erase(it->first);
					dict.insert(std::make_pair("CONFIG_"+new_oid.get_key('_'),buf));
					converted = true;
					break;
				}
			}
			if(!converted)
			{
				VERBOSE_PRINTF("Not conversion found for CONFIG "+it->first);
				not_found = false;
			}
		}
	}

	output_file<<"#############################################################\n";
	output_file<<"##            AUTO GENERATED FILE : DO NOT MODIFY          ##\n";
	output_file<<"## Please, use the web GUI or gpa_ctrl -s in order to      ##\n";
	output_file<<"## configure the system instead of edit this file manually ##\n";
	output_file<<"#############################################################\n";
	for(auto it = dict.begin(); it!=dict.end(); ++it)
	{
		output_file<<it->first<<"=";
		for(int i=0;i<it->second.size();++i) output_file<<it->second[i]<<"\n";
	}

	return not_found;
}

config_table::config_table(std::string file, std::string expr_str, char sep)
{
	filename = file;
	valid = true;
	size = 0;
	std::string line;
	std::ifstream fd;
	fd.open(file);
	std::regex expr(expr_str);
	std::map<std::string,std::vector<std::string>>::iterator it;
	if(fd.is_open())
	{
		while(getline(fd,line))
		{
			if(line.size()==0 || line.find('#')!=std::string::npos) continue;
			int match = 0;
			if(std::regex_match(line,expr))
				match = 1;
			else
			{
				/* new format will accept old format too */
				if(expr_str == GPA_DOTCONFIG_REGEX)
				{
					std::regex alt(GPA_DOTCONFIG_REGEX_OLD);
					if(std::regex_match(line,alt))
						match = 2;
				}
			}
			if(!match)
			{
				VERBOSE_PRINTF("wrong line: "+line+" parsing "+filename);
				valid = false;
				continue;
			}

			std::vector<std::string> read_values;
			std::string tmp;
			std::istringstream iss(line);
			while(std::getline(iss,tmp,sep))
				read_values.push_back(tmp);
			size++;
			std::string key = read_values[0];

			/* remove all useless whitespaces */
			key.erase(std::remove(key.begin(),key.end(),' '),key.end());
			/* hack: we modify the key in the case we are parsing
			 * the dot-config */
			if(expr_str == GPA_DOTCONFIG_REGEX && match == 1)
			{
				size_t pos = 0;
				for(int i=0;i<4;++i) pos = key.find('_',pos+1);
				key = key.substr(0,pos);
			}

			read_values.erase(read_values.begin()); // remove the first element
			/* remove spaces */
			for(unsigned i=0;i<read_values.size();++i)
				for(unsigned j=0;read_values[i][j]==' ';)
					read_values[i].erase(read_values[i].begin()+j);
 			/* remove previous entry if found */
			it = dict.find(key);
			if(it != dict.end())
				dict.erase(it);

			dict.insert(std::make_pair(key,read_values));
		}
		fd.close();
	}
	else
		VERBOSE_PRINTF("Error opening file "+file);
	return;
}

std::vector<std::string> config_table::get_element(std::string key)
{
	std::map<std::string,std::vector<std::string>>::iterator it = dict.find(key);
	if(it != dict.end())
	{
		std::vector<std::string> res = it->second;
		if(res.size())
			return res;
	}
	return std::vector<std::string>();
}

bool OID_GPA::parse_from_str(std::string in,char sep)
{
	if(in.size() == 0 || std::count(in.begin(), in.end(), sep) != 2)
		return (valid=false);
	else
	{
		std::string tmp;
		std::vector<std::string> read_values;
		std::istringstream iss(in);
		while(std::getline(iss,tmp,sep))
			read_values.push_back(tmp);
		if(read_values.size()!=3)
			return (valid=false);
		valid = true;
		mod_type = std::stoi(read_values[0]);
		modir = std::stoi(read_values[1]);
		prm_oid = std::stoi(read_values[2]);
		return valid;
	}
}

std::string OID_GPA::get_key(char sep)
{
	std::string key;
	if(!valid)
		return "error";
	key+=    std::to_string(mod_type)+sep
		+std::to_string(modir)+sep
		+std::to_string(prm_oid);
	return key;
}

void help(char *prgname)
{
	fprintf(stderr, "%s: Use: \"%s [<options>] <args>\n",
		prgname, prgname);
	fprintf(stderr,
		" return values: -1: error, 1: return from oid, 2: return from legacy, 3:updated successfully\n"
		"  -u <DIR> update: update the dot-config file with libgpa2.0 format,"
		"saving the new dot-config into DIR\n"
		"  -t <OID> get config value of the parameter OID (i.e: 12.2005.12)\n"
		"  -v       verbose mode\n"
		);
	exit(1);
}
int main(int argc, char** argv) {
	int opt_update = 0,c;
	char* prgname = argv[0];
	int ret = 0;
	std::string oid_input="",new_dot_config="";
	std::string output;
	while ( (c = getopt(argc, argv, "u:t:v")) != -1) {
		switch(c) {
		case 'u': /* update: argument, directory to save the updated dot-config */
			opt_update = 1;
			new_dot_config = optarg;
			break;
		case 't': /* get the value for a given OID */
			oid_input = optarg;
			break;
		case 'v':
			verbose = true;
			break;
		default:
			help(argv[0]);
		}
	}
	if (optind > argc)
		help(argv[0]);

	/* we create two needed tables (.config and .convtable) */
	config_table tc(GPA_CONVTABLE_PATH,GPA_CONVTABLE_REGEX,';');
	config_table ct(GPA_DOTCONFIG_PATH,GPA_DOTCONFIG_REGEX,'=');

	if(verbose)
	{
		ct.print();
		tc.print();
	}

	if(opt_update)
	{
		ret = ct.update(tc,new_dot_config);
		if(verbose)
			ct.print();
		if(ret)
			return GPA_CONFIG_RET_UPDATED;
		else
			return GPA_CONFIG_RET_ERROR;
	}

	if(oid_input!="")
	{
		OID_GPA my_oid;
		ret = my_oid.parse_from_str(oid_input,'.');
		if(!ret)
		{
			VERBOSE_PRINTF("Error parsing OID");
			return GPA_CONFIG_RET_ERROR;
		}
		ret = GPA_CONFIG_RET_ERROR; /* by default we assume we didnt find */
		std::vector<std::string> res = ct.get_element("CONFIG_"+my_oid.get_key('_'));
		if(!res.size())
		{
			VERBOSE_PRINTF(".config has not entry for this OID ("+my_oid.get_key('_')+")\n");
			std::string pkey = my_oid.get_key('.'); // 13.1200.12
			std::vector<std::string> res2 = tc.get_element(pkey);
			if(res2.size())
			{
				std::string cckey = res2[0];
				VERBOSE_PRINTF("Equivalence found ("+cckey+"), trying legacy access...");
				std::vector<std::string> ntry = ct.get_element(cckey);
				if(ntry.size())
				{
					VERBOSE_PRINTF("Legacy entry found: "+ntry[0]);
					output = ntry[0];
					ret = GPA_CONFIG_RET_LEGACY;
				}
			}
			else
			{
				VERBOSE_PRINTF("Error: There is not equivalence for this OID in legacy table...");
				ret = GPA_CONFIG_RET_ERROR;
			}
		}
		else
		{
			output = res[0];
			ret = GPA_CONFIG_RET_OID;
		}
		std::cout<<output<<"\n";
	}
	return ret;
}

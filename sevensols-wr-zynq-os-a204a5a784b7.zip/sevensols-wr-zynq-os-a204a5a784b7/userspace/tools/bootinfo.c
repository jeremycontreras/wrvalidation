/*
 * Extracts information about the components of a Xilinx BOOT.BIN file and
 * prints the table of files including their offsets and sizes.
 *
 * Copyright (C) 2019 Seven Solutions (www.sevensols.com)
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 *
 * Last updated: Feb 5th, 2019
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <byteswap.h>

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define machine_int(x) __bswap_32(x)
#else
#define machine_int(x) x
#endif

char usage[] =
	"\nbootinfo: extracts information about the components of a "
	"BOOT.BIN file.\n\n"
	"Usage:\n"
	"./bootinfo <BOOT.BIN>\n";

/* General macros */
#define BUFLEN 0x2000
#define MAX_IMG_NAME_LEN 256

enum return_code
{
	RET_OK,
	RET_ERROR_PARAMS,
	RET_ERROR_IO,
};

/*
 * Boot image header fields.
 * NOTE: All fields are 4-byte long.
 */

#define FIELD_SIZE 4

/* Boot header field offsets */
#define HEADER_SIG              0x24
#define HEADER_VER              0x2c
#define FSBL_IMG_LEN            0x34
#define FSBL_TOTAL_LEN          0x40
#define IMAGE_HDR_TABLE         0x98
#define PART_HDR_TABLE          0x9c

/*
 * Image header table field offsets
 * (starting at offset stored in IMAGE_HDR_TABLE)
 */
#define NUMBER_OF_IMGS          0x4
#define FIRST_PARTITION_HDR     0x8
#define FIRST_IMAGE_HDR         0xc

/*
 * Image header field offsets
 * (starting at each image header)
 */
#define NEXT_IMG_HEADER         0
#define PARTITION_HEADER        0x4
#define NUMBER_OF_PARTS         0xc
#define IMAGE_NAME              0x10

/*
 * Partition header field offsets
 * (starting at each partition header)
 */
#define PARTITION_SIZE          0x8
#define PARTITION_START         0x14

/* Length of a partition table in bytes */
#define PARTITION_TABLE_SIZE    0x3c


/*
 * Data structures
 */

/* Buffer to hold the boot image header */
unsigned char buf[BUFLEN];

/* Image header table */
struct img_header_table
{
	/* Number of image headers (number of "files" in the boot binary). */
	int num_img_headers;
	/*
	 * Offset of the first partition header in 4-byte words, from the start
	 * of the boot binary.
	 */
	unsigned int first_part_header;
	/*
	 * Offset of the first image header in 4-byte words, from the start of
	 * the boot binary.
	 */
	unsigned int first_img_header;
};

/* Partition header */
struct part_header
{
	/*
	 * Offset of the partition in 4-byte words, from the start of the boot
	 * binary.
	 */
	unsigned int start;
	/*
	 * Total partition size in 4-byte words (including the encrypted
	 * information length with padding, the expansion length and the
	 * authentication length).
	 */
	unsigned int size;
};

/* Image header */
struct img_header
{
	/*
	 * Offset of the next image header in 4-byte words from the start of the
	 * boot binary.
	 */
	unsigned int next_img_hdr;
	/*
	 * Offset of the partition header in 4-byte words from the start of the
	 * boot binary.
	 */
	unsigned int part_hdr;
	/* Image name */
	char img_name[MAX_IMG_NAME_LEN];
	/* Number of partitions in the image */
	int num_partitions;
	/* Array of partition headers */
	struct part_header *parts;
};

/*
 * Gets the 4-byte field starting at <offset> from <buf>
 *
 * Parameters
 * buf: Memory buffer to read from
 * offset: field offset
 *
 * Returns the field data as an 4-byte integer.
 *
 * NOTE: The field data is little endian. This function should be
 * endianness-safe but I haven't tested it on a big-endian machine.
 */
unsigned int get_4b_field(const unsigned char *buf, const int offset)
{
	int i = 0;
	unsigned int ret = 0;

	for (i = 0; i < 4; i++)
	{
		ret |= buf[offset + i] << (i * 8);
	}

	return machine_int(ret);
}

/*
 * Extract the image name from an image header.
 *
 * According to the Bootgen User Guide:
 *
 *   Packed in big-endian order. To reconstruct the string, unpack 4 bytes at a
 *   time, reverse the order and concatenate. For example, the string
 *   "FSBL10.ELF" is packed as
 *
 *   0x10: 'L', 'B', 'S', 'F'
 *   0x14: 'E', '.', '0', '1'
 *   0x18: '\0', '\0', 'F', 'L'
 *
 * Parameters
 * buf: pointer to the start of the string in the image header
 * str: pointer to the output buffer
 */
void get_image_name(const unsigned char *buf, char *str)
{
	while (((unsigned int *)(buf))[0])
	{
		str[0] = buf[3];
		str[1] = buf[2];
		str[2] = buf[1];
		str[3] = buf[0];
		str = str + 4;
		buf = buf + 4;
	}
	/* Terminate the string in case we didn't copy any null bytes */
	str[0] = 0;
}

/*
 * Reads the image header table.
 *
 * Parameters
 * buf: Memory buffer to read from.
 * t: image header table to populate. It must be initialized.
 */
void read_img_header_table(const unsigned char *buf, struct img_header_table *t)
{
	int img_hdr = get_4b_field(buf, IMAGE_HDR_TABLE);

	t->num_img_headers   = get_4b_field(buf,
					img_hdr + NUMBER_OF_IMGS);
	t->first_part_header = 4 * get_4b_field(buf,
					img_hdr + FIRST_PARTITION_HDR);
	t->first_img_header  = 4 * get_4b_field(buf,
					img_hdr + FIRST_IMAGE_HDR);
}

/*
 * Reads the image headers and partition headers and returns a newly allocated
 * array of (struct img_header) with the relevant info.
 *
 * Parameters
 * buf: Memory buffer to read from.
 * ht: Populated image header table.
 *
 * Returns a populated array of image headers.
 */
struct img_header *read_img_headers(const unsigned char *buf,
		const struct img_header_table *ht)
{
	int i;
	int j;
	unsigned int ref_offset;
	struct img_header *hdr;

	ref_offset = ht->first_img_header;
	hdr = malloc(sizeof(struct img_header) * ht->num_img_headers);
	for (i = 0; i < ht->num_img_headers; i++)
	{
		/* Read image info */
		hdr[i].next_img_hdr   = 4 * get_4b_field(buf,
						ref_offset + NEXT_IMG_HEADER);
		hdr[i].part_hdr       = 4 * get_4b_field(buf,
						ref_offset + PARTITION_HEADER);
		hdr[i].num_partitions = get_4b_field(buf,
						ref_offset + NUMBER_OF_PARTS);
		get_image_name(buf + ref_offset + IMAGE_NAME, hdr[i].img_name);

		/* Read partitions info */
		hdr[i].parts = malloc(sizeof(struct part_header)
						* hdr[i].num_partitions);
		ref_offset = hdr[i].part_hdr;
		for (j = 0; j < hdr[i].num_partitions; j++)
		{
			hdr[i].parts[j].start = 4 * get_4b_field(buf,
						ref_offset + PARTITION_START);
			hdr[i].parts[j].size = 4 * get_4b_field(buf,
						ref_offset + PARTITION_SIZE);
			ref_offset += PARTITION_TABLE_SIZE;
		}

		/* Move to next image header */
		ref_offset = hdr[i].next_img_hdr;
	}

	return hdr;
}

/*
 * Frees the memory allocated for an array of struct img_header.
 *
 * Parameters
 * ht: Image table header (contains the number of image headers)
 * hdrs: Array of image headers
 */
void free_img_headers(const struct img_header_table *ht,
			struct img_header *hdrs)
{
	int i;

	for (i = 0; i < ht->num_img_headers; i++)
		free(hdrs[i].parts);
	free(hdrs);
}

/*
 * Prints a summary of the information found in the boot header with this
 * format:
 *
 * --------------------------------------------------------
 * <file_1> 0 <offset_of_partition_0> <size_of_partition_0>
 * <file_1> 1 <offset_of_partition_1> <size_of_partition_1>
 * <file_1> ...
 * <file_1> n <offset_of_partition_n> <size_of_partition_n>
 * <file_2> 0 <offset_of_partition_0> <size_of_partition_0>
 * ...
 * <file_n> 0 <offset_of_partition_0> <size_of_partition_0>
 * --------------------------------------------------------
 *
 * All sizes and offsets are in bytes.
 *
 * Parameters
 * ht: Populated header table
 * hdrs: Array of image headers
 */
void print_summary(const struct img_header_table *ht,
			const struct img_header *hdrs)
{
	int i;
	int j;

	for (i = 0; i < ht->num_img_headers; i++)
	{
		for (j = 0; j < hdrs[i].num_partitions; j++)
		{
			printf("%s %d %d %d\n", hdrs[i].img_name, j,
				hdrs[i].parts[j].start, hdrs[i].parts[j].size);
		}
	}
}


int main(int argc, char *argv[])
{
	FILE *fd;
	struct img_header_table img_hdr_tab;
	struct img_header *img_hdrs;

	if (argc != 2)
	{
		printf("Wrong number of parameters.\n");
		puts(usage);
		return RET_ERROR_PARAMS;
	}
	fd = fopen(argv[1], "r");
	if (!fd)
	{
		printf("Can't open file %s\n", argv[1]);
		return RET_ERROR_IO;
	}
	if (!fread(buf, 1, BUFLEN, fd))
	{
		printf("Error reading file %s\n", argv[1]);
		return RET_ERROR_IO;
	}
	fclose(fd);

	read_img_header_table(buf, &img_hdr_tab);
	img_hdrs = read_img_headers(buf, &img_hdr_tab);

	print_summary(&img_hdr_tab, img_hdrs);

	free_img_headers(&img_hdr_tab, img_hdrs);

	return RET_OK;
}

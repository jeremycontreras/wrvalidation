/*
 * This work is part of the White Rabbit project
 *
 * Copyright (C) 2016 UGR (www.ugr.es) (Based on previous works from the wr-switch-sw)
 * Author: Miguel Jimenez Lopez <klyone@ugr.es>
 * Author: Tomasz Wlostowski <tomasz.wlostowski@cern.ch>
 * Author: Alessandro Rubini <rubini@gnudd.com>
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

/*
 * Trivial pll programmer using an spi controller.
 * PLL is AD9516, SPI is opencores
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#define NBUF 1024

#include <libwrz.h>
#include <libwrz/rgxfile.h>
#include <libwrz/util.h>
#include <libwrz/wb/wrc/wrc_syscon_regs.h>

#define Xil_In32	_fpga_readl
#define Xil_Out32	_fpga_writel


#include <libwrz/xilinx/xspi_l.h>
uint32_t BaseAddress;
/*
 * SPI stuff, used by later code
 */

#define SPI_REG_RX0	0
#define SPI_REG_TX0	0
#define SPI_REG_RX1	4
#define SPI_REG_TX1	4
#define SPI_REG_RX2	8
#define SPI_REG_TX2	8
#define SPI_REG_RX3	12
#define SPI_REG_TX3	12

#define SPI_REG_CTRL	16
#define SPI_REG_DIVIDER	20
#define SPI_REG_SS	24

#define SPI_CTRL_ASS		(1<<13)
#define SPI_CTRL_IE		(1<<12)
#define SPI_CTRL_LSB		(1<<11)
#define SPI_CTRL_TXNEG		(1<<10)
#define SPI_CTRL_RXNEG		(1<<9)
#define SPI_CTRL_GO_BSY		(1<<8)
#define SPI_CTRL_CHAR_LEN(x)	((x) & 0x7f)

#define CS_PLL	0 /* AD9516 on SPI CS0 */


#define AD9516_FLD_DIV_OPT1_BIT_NOSYNC   (1 << 6)
#define AD9516_FLD_DIV_OPT2_BIT_NOSYNC   (1 << 3)
#define AD9516_FLD_SYSTEM_BIT_SOFTSYNC    (1 << 0)

#define AD9516_REG_DIV0_OPT1              0x191 //Chan [0-1]
#define AD9516_REG_DIV1_OPT1              0x194 //Chan [2-3]
#define AD9516_REG_DIV2_OPT1              0x197 //Chan [4-5]
#define AD9516_REG_DIV3_OPT2              0x19C //Chan [6-7]
#define AD9516_REG_DIV4_OPT2              0x1A1 //Chan [8-9]
#define AD9516_REG_SYSTEM                 0x230
#define AD9516_REG_UPDATE_ALL             0x232

#define AD9516_REG_OUTx                    0xF0
#define AD9516_REG_OUTx_BIT_INV            1 << 4
#define AD9516_REG_OUTx_BIT_DOWN           1 << 0


uint8_t pll_out_allsync[] = {0,2,4,6,8};
uint8_t pll_out_wrnosync_zen_v2x[] = { 0, 2, 4};
uint8_t pll_out_wrnosync_zen_v3x[] = { 0, 2 , 3, 4};
uint8_t pll_out_wrnosync_lenp_v1x[] = { 0, 3, 4, 5, 6, 7};
uint8_t pll_out_wrnosync_z16_v2x[] = { 0, 2, 4, 6, 8}; //Z16 needs sync only on LMK
uint8_t pll_out_wrnosync_z16_v4x[] = { 0, 2, 4, 6 };

enum {
	PLL_SYNC_ALL=0,
	PLL_SYNC_WRNOSYNC_LENp_V1x,
	PLL_SYNC_WRNOSYNC_ZEN_V2x,
	PLL_SYNC_WRNOSYNC_ZEN_V3x,
	PLL_SYNC_WRNOSYNC_Z16_V2x,
	PLL_SYNC_WRNOSYNC_Z16_V4x,
	_PLL_SYNC_LAST
};

struct pll_sync_chans {
	uint8_t *data;
	size_t size;
};

#define PLL_SYNC_ADD_CHANS(chans) {chans,sizeof(chans)}

struct pll_sync_chans pll_synctabs[_PLL_SYNC_LAST]={
		PLL_SYNC_ADD_CHANS(pll_out_allsync),
		PLL_SYNC_ADD_CHANS(pll_out_wrnosync_lenp_v1x),
		PLL_SYNC_ADD_CHANS(pll_out_wrnosync_zen_v2x),
		PLL_SYNC_ADD_CHANS(pll_out_wrnosync_zen_v3x),
		PLL_SYNC_ADD_CHANS(pll_out_wrnosync_z16_v2x),
		PLL_SYNC_ADD_CHANS(pll_out_wrnosync_z16_v4x),
};


struct ad9516_reg {
	uint32_t reg;
	uint32_t val;
};

struct ad9516_delay
{
	uint8_t bypass;   //1bit
	uint8_t ramp_cap; //3bits
	uint8_t ramp_cur; //2bits
	uint8_t fraction; //8bits
};

#include "ad9516_config.h"

#define spi_writel(val,reg) _fpga_writel((uint32_t)(BASE_SPI_AD9516)+reg,val)
#define spi_readl(reg) _fpga_readl((uint32_t)(BASE_SPI_AD9516)+reg)
static int f_xil=0, f_gpiorst=0;

static char pll_name[24];

static int oc_spi_init()
{
	spi_writel(100, SPI_REG_DIVIDER);
	return 0;
}

static int oc_spi_txrx(int ss, int nbits, uint32_t in, uint32_t *out)
{
	uint32_t rval;

	if (!out)
		out = &rval;

	spi_writel(SPI_CTRL_ASS | SPI_CTRL_CHAR_LEN(nbits)
			| SPI_CTRL_TXNEG,
			SPI_REG_CTRL);

	spi_writel(in, SPI_REG_TX0);
	spi_writel((1 << ss), SPI_REG_SS);
	spi_writel(SPI_CTRL_ASS | SPI_CTRL_CHAR_LEN(nbits)
			| SPI_CTRL_TXNEG | SPI_CTRL_GO_BSY,
			SPI_REG_CTRL);

	while(spi_readl(SPI_REG_CTRL) & SPI_CTRL_GO_BSY)
		;
	*out = spi_readl(SPI_REG_RX0);
	return 0;
}


static void xil_spi_sleep()
{
	usleep(10);
}


static int xil_spi_init_txrx(int ss)
{
	uint32_t cr=0;
	cr = (XSP_CR_MASTER_MODE_MASK | XSP_CR_ENABLE_MASK);
	cr |= XSP_CR_TRANS_INHIBIT_MASK;
	cr |= XSP_CR_TXFIFO_RESET_MASK | XSP_CR_RXFIFO_RESET_MASK;
	XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, cr);

	if(ss>=0) XSpi_WriteReg(BaseAddress, XSP_SSR_OFFSET, ss);

	xil_spi_sleep();

	return 0;

}


/**
 * Transfer using AXI SPI Dual/Quad Core
 *
 * The core must be configured with
 *
 *    - FIFO of at least 16 depth
 *    - 8bits width transfers
 *
 * By doing this we can use the FIFO to transmit 3x8bits
 * and thus communicate with the AD9516 that needs 24bits
 *
 * @param ss: Slave selection
 * @param nbits: Number of bits to send (32,24,16,8)
 * @param in: Input value
 * @param out: Pointer on outputs value
 */
static int xil_spi_txrx(int ss, int nbits, uint32_t in, uint32_t *out)
{
	uint32_t cr;

	//Setup the mode
	xil_spi_init_txrx(ss);


	//Write the data
	if(nbits==24)
	{
		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, (uint8_t)((in >> 16) & 0xFF));
		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, (uint8_t)((in >> 8) & 0xFF));
		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, (uint8_t)(in & 0xFF));
		//		in <<=8;
		//		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, in);
	}
	else
	{
		XSpi_WriteReg((BaseAddress), XSP_DTR_OFFSET, in);
	}

	xil_spi_sleep();

	//Ask for write transfer (enable=1, inihibit=0)
	cr = XSpi_ReadReg(BaseAddress, XSP_CR_OFFSET);
	cr |= XSP_CR_ENABLE_MASK;
	cr &= ~XSP_CR_TRANS_INHIBIT_MASK;
	XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET, cr);

	//Pool TX completed
	while (!(XSpi_ReadReg(BaseAddress, XSP_SR_OFFSET) & XSP_SR_TX_EMPTY_MASK)){}

	xil_spi_sleep();

	//Clear transfer
	cr = XSpi_ReadReg(BaseAddress, XSP_CR_OFFSET);
	cr |= XSP_CR_TRANS_INHIBIT_MASK;
	XSpi_WriteReg(BaseAddress, XSP_CR_OFFSET,cr);

	xil_spi_sleep();



	if(out) {;
	//Read receiver FIFO until its empty
	while (!(XSpi_ReadReg(BaseAddress, XSP_SR_OFFSET) & XSP_SR_RX_EMPTY_MASK))
	{
		*out = XSpi_ReadReg(BaseAddress, XSP_DRR_OFFSET);
		//printf("out=x%02x ",*out & 0xFF);
	}
	*out &=0xFF; //We only care about the last byte.
	//printf("\n");
	}

	return 0;
}



/*
 * AD9516 stuff, using SPI, used by later code.
 * "reg" is 12 bits, "val" is 8 bits, but both are better used as int
 */

static void ad9516_write_reg(uint16_t reg, uint8_t val)
{
	//pr_debug("W: i=%08x\n",(reg << 8) | val);
	if(f_xil) xil_spi_txrx(CS_PLL, 24, (reg << 8) | val, NULL);
	else oc_spi_txrx(CS_PLL, 24, (reg << 8) | val, NULL);

}

static uint8_t ad9516_read_reg(uint16_t reg)
{
	uint32_t rval;
	if(f_xil) xil_spi_txrx(CS_PLL, 24, (reg << 8) | (1 << 23), &rval);
	else oc_spi_txrx(CS_PLL, 24, (reg << 8) | (1 << 23), &rval);
	//pr_debug("R: i=%08x o=%08x\n",(reg << 8) | (1 << 23), rval);
	return rval & 0xff;
}

static void ad9516_load_regset(const struct ad9516_reg *regs, int n_regs, int commit)
{
	int i;
	/**int cnt_ok = 0;
	int r;**/

	for(i=0; i<n_regs; i++)
	{
		if((uint16_t)regs[i].reg!=AD9516_REG_UPDATE_ALL)
			ad9516_write_reg((uint16_t)regs[i].reg, (uint8_t)regs[i].val);
	}

	if(commit)
		ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);

	/**for(i=0; i<n_regs; i++) {
		r = ad9516_read_reg(regs[i].reg);

		if(r == regs[i].val) {
			cnt_ok++;
			printf("SUCCESS. PLL[0x%x] => Read: 0x%x, Expected: 0x%x \n",regs[i].reg,r,regs[i].val);
		} else {
			printf("FAIL. PLL[0x%x] => Read: 0x%x, Expected: 0x%x \n",regs[i].reg,r,regs[i].val);
		}
	}

	if(cnt_ok == n_regs) {
		printf("AD9516 PLL has been programmed successfully!\n");
	}
	else {
		printf("AD9516 PLL program failed!\n");
	}**/
}

#define ETIME       62  /* Timer expired */

/**
 * Check the first bit of PLL readback register to get the digital lock detect
 *
 */
static int ad9516_wait_lock(int nsec)
{
	int ret=0;
	int count=0;
	int maxcount=nsec*10;

	while ((ad9516_read_reg(0x1f) & 1) == 0)
	{
		usleep(100000); //100ms
		if(count++>maxcount)
		{
			pr_info("PLL readback: 0x%02x\n",ad9516_read_reg(0x1f));
			ret=-ETIME;
			break;
		}
		if(count%10==0)
		{
			printf(".");
			fflush(stdout);
			pr_debug("PLL readback: 0x%02x\n",ad9516_read_reg(0x1f));
		}
	}
	if(count>10) printf("\n");
	return ret;
}

#define SECONDARY_DIVIDER 0x100

int ad9516_set_output_divider(int output, int ratio, int phase_offset)
{
	uint8_t lcycles = (ratio/2) - 1;
	uint8_t hcycles = (ratio - (ratio / 2)) - 1;
	int secondary = (output & SECONDARY_DIVIDER) ? 1 : 0;
	output &= 0xf;

	if(output >= 0 && output < 6) /* LVPECL outputs */
	{
		uint16_t base = (output / 2) * 0x3 + 0x190;

		if(ratio == 1)  /* bypass the divider */
		{
			uint8_t div_ctl = ad9516_read_reg(base + 1);
			ad9516_write_reg(base + 1, div_ctl | (1<<7) | (phase_offset & 0xf)); 
		} else {
			uint8_t div_ctl = ad9516_read_reg(base + 1);
			ad9516_write_reg(base + 1, (div_ctl & (~(1<<7))) | (phase_offset & 0xf));  /* disable bypass bit */
			ad9516_write_reg(base, (lcycles << 4) | hcycles);
		}
	} else { /* LVDS/CMOS outputs */

		uint16_t base = ((output - 6) / 2) * 0x5 + 0x199;

		printf("Output [divider %d]: %d ratio: %d base %x lc %d hc %d\n", secondary, output, ratio, base, lcycles ,hcycles);

		if(!secondary)
		{
			if(ratio == 1)  /* bypass the divider 1 */
				ad9516_write_reg(base + 3, ad9516_read_reg(base + 3) | 0x10); 
			else {
				ad9516_write_reg(base, (lcycles << 4) | hcycles); 
				ad9516_write_reg(base + 1, phase_offset & 0xf);
			}
		} else {
			if(ratio == 1)  /* bypass the divider 2 */
				ad9516_write_reg(base + 3, ad9516_read_reg(base + 3) | 0x20); 
			else {
				ad9516_write_reg(base + 2, (lcycles << 4) | hcycles); 
				//				ad9516_write_reg(base + 1, phase_offset & 0xf);

			}
		}		
	}

	/* update */
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x0);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x1);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x0);
	return 0;
}

int ad9516_set_vco_divider(int ratio) /* Sets the VCO divider (2..6) or 0 to enable static output */
{
	if(ratio == 0)
		ad9516_write_reg(0x1e0, 0x5); /* static mode */
	else
		ad9516_write_reg(0x1e0, (ratio-2));
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x1);
	return 0;
}




/**
 * Calculate the fine delay (ps) given the AD9516 regs.
 *
 * @return the fine-delay adjustment in picoseconds
 */
uint32_t ad9516_finedel_calc(struct ad9516_delay* pdelay)
{
	float iramp;
	float nofcap;
	float delayrange;
	float offset;
	float fdelay=0;

	//uint8_t ncaps_lut[8]={0,1,1,2,1,2,2,3};
	uint8_t ncaps_lut[8]={4,3,3,2,3,2,2,1};

	WRZ_RETCHECK_PTR(pdelay,-EFAULT);

	iramp=200*(pdelay->ramp_cur+1);
	nofcap=ncaps_lut[pdelay->ramp_cap];
	delayrange=200.f*((nofcap+3.f)/iramp)*1.3286f;
	offset=0.34+(1600-iramp)*0.0001+((nofcap-1)/iramp)*6;
	fdelay=delayrange*(pdelay->fraction/63.f)+offset;

	pr_info("clkttl delay: cap=%d cur=%d frac=%02d\n"
			"* fine delay (ns):%f\n"
			"* delay_full_scale (ns):%f\n"
			"* offset (ns):%f\n"
			"* delay_range (ns):%f\n"
			"* iramp:%1f\n"
			"* nofcaps: %1f\n",
			pdelay->ramp_cap,
			pdelay->ramp_cur,
			pdelay->fraction,
			fdelay,
			delayrange+offset,
			offset,
			delayrange,
			iramp,
			nofcap);

	return (uint32_t)(fdelay*1000);

}


static int ad9516_toggle_phase(uint8_t invert, uint8_t ch)
{
	uint32_t reg_offset, bmask=AD9516_REG_OUTx_BIT_INV;

	reg_offset=AD9516_REG_OUTx+ch; //Invert field
	uint8_t val_rd = ad9516_read_reg(reg_offset);
	uint8_t val_w=(val_rd & ~bmask);
	if(invert) val_w |= bmask;

	pr_debug("i:%d (ch:%d@x%X) = x%x > x%x\n",invert,ch,reg_offset,val_rd,val_w);
	ad9516_write_reg(reg_offset, val_w);

	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);

	return 0;
}



static int ad9516_enable_sync(uint8_t enable, uint8_t *chan, uint8_t nchan)
{
	uint16_t reg;
	uint8_t bit,val;

	for(int i=0;i<nchan;i++)
	{
		if(chan[i]>9)
		{
			pr_warning("PLL output channel must be below 9 (%d)\n",chan[i]);
			continue;
		}

		if(chan[i]<6) bit=AD9516_FLD_DIV_OPT1_BIT_NOSYNC;
		else bit=AD9516_FLD_DIV_OPT2_BIT_NOSYNC;

		if(chan[i]<=1) reg=AD9516_REG_DIV0_OPT1;
		else if(chan[i]<=3) reg=AD9516_REG_DIV1_OPT1;
		else if(chan[i]<=5) reg=AD9516_REG_DIV2_OPT1;
		else if(chan[i]<=7) reg=AD9516_REG_DIV3_OPT2;
		else reg=AD9516_REG_DIV4_OPT2;

		val=ad9516_read_reg(reg);
		pr_debug("ch%d @ 0%03x < x%02x\n",chan[i],reg,val);
		if(enable) val&=~bit;
		else val|=bit;

		ad9516_write_reg(reg, val);

		pr_debug("ch%d @ 0%03x > x%02x (sync=%d)\n",chan[i],reg,val,enable);
	}

	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);
	return 0;
}


static int ad9516_finedel_adjust(struct ad9516_delay* pdelay, uint8_t outx)
{
	uint32_t reg_offset,ramp;
	WRZ_RETCHECK_PTR(pdelay,-EFAULT);
	WRZ_RETCHECK_MSGVA(6<=outx && outx<=9,-1,"Fine delay adjust is only for outputs [6-9] not %d\n",outx);

	reg_offset=0xA0; //OUT6 Delay bypass
	reg_offset+=3*(outx-6); //OUTx Delay bypass
	ramp=((pdelay->ramp_cap & 0x7) << 3) | (pdelay->ramp_cur & 0x7);

	ad9516_write_reg(reg_offset+0, pdelay->bypass & 0x1);
	ad9516_write_reg(reg_offset+1, ramp & 0x3F );
	ad9516_write_reg(reg_offset+2, pdelay->fraction & 0x3F);

	//ad9516_write_reg(0x230, 1);
	//ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);
	//ad9516_write_reg(0x230, 0);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);

	return 0;

}

static void ad9516_sync_all_outputs(void)
{
	/* Get actual VCO value */
	uint8_t vco_back=ad9516_read_reg(0x1e0);

	/* Enable sync to all channels */
	ad9516_enable_sync(1,pll_out_allsync,sizeof(pll_out_allsync));

	/* VCO divider: static mode */
	ad9516_write_reg(0x1E0, 0x7);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x1);

	/* Sync the outputs when they're inactive to avoid +-1 cycle uncertainity */
	ad9516_write_reg(AD9516_REG_SYSTEM, AD9516_FLD_SYSTEM_BIT_SOFTSYNC);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);
	ad9516_write_reg(AD9516_REG_SYSTEM, 0);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 1);

	/* Set back to previous VCO value */
	ad9516_write_reg(0x1e0, vco_back);
	ad9516_write_reg(AD9516_REG_UPDATE_ALL, 0x1);
}

void ad9516_export_gpio() {

	char buf[NBUF];
	FILE * f;

	sprintf(buf,"%s/export",SYSFS_GPIO_BASEDIR);

	f = fopen(buf,"w");
	fprintf(f,SYSFS_GPIO_EMIO_AD9516);
	fclose(f);
}

void ad9516_unexport_gpio() {

	char buf[NBUF];
	FILE * f;

	sprintf(buf,"%s/unexport",SYSFS_GPIO_BASEDIR);

	f = fopen(buf,"w");
	fprintf(f,SYSFS_GPIO_EMIO_AD9516);
	fclose(f);
}

void ad9516_reset_n(int rst_n) {
	char buf[NBUF];
	FILE * f;

	sprintf(buf,"%s/gpio%s/direction",SYSFS_GPIO_BASEDIR,SYSFS_GPIO_EMIO_AD9516);

	f = fopen(buf,"w");
	fprintf(f,"out");
	fclose(f);

	sprintf(buf,"%s/gpio%s/value",SYSFS_GPIO_BASEDIR,SYSFS_GPIO_EMIO_AD9516);

	f = fopen(buf,"w");

	sprintf(buf,"%d",rst_n);

	fprintf(f,buf);
	fclose(f);
}


int ad9516_init(struct wrz_rgxf_handler* p_rgx)
{

	int ret;
	printf("Initializing %s...\n",pll_name);

	if(!f_xil) oc_spi_init();

	/* Use unidirectional SPI mode */
	ad9516_write_reg(0x000, 0x99);

	uint8_t reg3 = ad9516_read_reg(0x3);

	/* Check the presence of the chip */
	if (reg3 == 0xc3) 
	{
		pr_info("Detected %s version -4", pll_name);	
	}
	else if(reg3 == 0x41)
	{
		pr_info("Detected %s version -1", pll_name);
	}
	else
	{
		pr_error("Error: %s part ID(0x%02x) not found.\n",pll_name, reg3);
		return -1;
	}

	printf("Programming %s... \n",pll_name);
	if(p_rgx && p_rgx->len>0)
	{
		ad9516_load_regset((const struct ad9516_reg*)p_rgx->data, p_rgx->len, 1);
	}
	else
	{
		ad9516_load_regset(ad9516_config, ARRAY_SIZE(ad9516_config), 1);
	}

	printf("Waiting %s lock... \n",pll_name);
	ret = ad9516_wait_lock(7);
	if(ret)
	{
		pr_error("The %s could not be locked\n",pll_name);
		return ret;
	}

	printf("Syncing %s outputs... \n",pll_name);
	ad9516_sync_all_outputs();
	//ad9516_set_vco_divider(3);

	printf("%s correctly programmed\n",pll_name);

	return 0;
}

int lm32_rst()
{
	printf("Reseting LM32...\n");
	if(BASE_WRC_SYSCON)
	{
		//Disable LM32
		_fpga_writel((uint32_t)(BASE_WRC_SYSCON)+SYSC_REG_RSTR,FPGA_LM32_RESET_MASK | 0x10000000);
		//Enable LM32
		_fpga_writel((uint32_t)(BASE_WRC_SYSCON)+SYSC_REG_RSTR,FPGA_LM32_RESET_MASK | 0x00000000);
	}
	else
	{
		pr_warn("Could not find BASE_WRC_SYSCON in SDB\n");
		return WRZ_EXIT_SDB;
	}
	return 0;
}

/**
 * @brief  Reset the GTP using GPIO core at FPGA
 * @retval 0 if success or errno otherwhise.
 */
int gtp_reset()
{
	if(!BASE_WRC_GPIO_PORT)
	{
		pr_warn("Could not find GPIO_PORT at sdb\n");
		return EINVAL;
	}

	printf("Performing GTPs reset...");
	fflush(stdout);
	/*
		GPIO PORT MAP
		-------------------------------------------------
		constant c_GPIO_SFP1_LOS_TX_FAULT : integer := 0;
		constant c_GPIO_SFP1_DET          : integer := 1;
		constant c_GPIO_SFP0_LOS_TX_FAULT : integer := 2;
		constant c_GPIO_SFP0_DET          : integer := 3;
		constant c_GPIO_GTP_RESET         : integer := 4;
		constant c_GPIO_SW_RESET          : integer := 5;
	*/

	_fpga_writel((uint32_t)(BASE_WRC_GPIO_PORT)+0x4,0x10); // read GPIO PORT MAP
	sleep(1);
	_fpga_writel((uint32_t)(BASE_WRC_GPIO_PORT),0x10);
	printf("Done\n");

	return 0;
}


void help(const char* pgrname)
{
	printf("usage: %s [OPTIONS] [config_file]\n", pgrname);
	printf("where OPTIONS are:\n"
			"   -d <ps>   Delay in ps for CLK_TLL (override -c,-C,-f) \n"
			"   -c <0-7>  ramp of current\n"
			"   -C <0-7>  ramp of capacitor\n"
			"   -f <0-47> fraction of delay\n"
			"   -L Do NOT load configuration\n"
			"   -i <ch> invert by 90 deg the phase of latcher for specific channel\n"
			"   -I <ch> invert by  0 deg the phase of latcher for specific channel\n"
			"   -S <ID> Desactivate sync for WR outputs {1: len+ v1.x, 2: zen v2.x, 3: zen v3.x, 4: z16 v2.x}\n"
			"   -x Use Xilinx SPI core instead of OpenCore\n"
			"   -0 Use Xilinx SPI @ 0x81E00000\n"
			"   -1 Use Xilinx SPI @ 0x81E10000 (same as -x)\n"
			"   -2 Use Xilinx SPI @ 0x81E20000 (GM PLL in WR-ZEN v3)\n"
			"   -r Reset LM32 after programming AD9516\n"
			"   -g GPIO reset of the PLL\n"
			"   -h Show this little help message\n"
			"   -q quiet mode\n"
			"   -v verbose mode\n"
			"   -V very verbose\n"
			"\n");

	pr_debug("version: %s (%s); compiled at %s %s\n",
			__GIT_VER__, __GIT_USR__, __DATE__, __TIME__);

	exit(1);
}



int main(int argc, char ** argv) {
	int ret;
	int f_reset=0, ch_invert=0,f_nowrsync=0, f_loadcfg=1;
	char func;
//	uint32_t fdelay=0;
	struct wrz_rgxf_handler h_rgx = {0};
	static struct ad9516_delay clktll_del={0};
	clktll_del.bypass=1; //By default bypass the CLKTTL delay
	const char *pgrname=argv[0];

	snprintf(pll_name,sizeof(pll_name),"AD9516 PLL");


	wrz_msg_init(argc,argv);

	while(argc>1 && argv[1][0]=='-')
	{
		func=argv[1][1];
		switch(func)
		{
		case 'd': pr_warn("OPTIONS: -d Not implemented\n"); help(pgrname); break;
		case 'c':
			if(argc>2) {
				clktll_del.ramp_cur=atoideflim(argv[2],0,0,7);
				clktll_del.bypass=0;
				f_loadcfg=0;
				argc--;
				argv++;
			}
			break;
		case 'C':
			if(argc>2) {
				clktll_del.ramp_cap=atoideflim(argv[2],0,0,7);
				clktll_del.bypass=0;
				f_loadcfg=0;
				argc--;
				argv++;
			}
			break;
		case 'f':
			if(argc>2) {
				clktll_del.fraction=atoideflim(argv[2],0,0,47);
				clktll_del.bypass=0;
				f_loadcfg=0;
				argc--;
				argv++;
			}
			break;
		case 'r': f_reset=1; break;
		case 'g': f_gpiorst=1; break;
		case 'i':
		case 'I':
			if(argc>2) {
				ch_invert=atoideflim(argv[2],-1,0,9)+1;
				if(func=='I') ch_invert*=-1;
				argc--;
				argv++;
			}
			break;
		case 'S':
				if(argc>2) {
					f_nowrsync=atoideflim(argv[2],0,1,_PLL_SYNC_LAST);
					argc--;
					argv++;
				}; break;
		case 'L': f_loadcfg=0; break;
		case '0': BaseAddress=0; f_xil=3; break;
		case '1':
		case 'x': BaseAddress=0; f_xil=1; break;
		case '2': BaseAddress=0; f_xil=2; break;
		case 'h': help(pgrname); break;
		//parsed by wrz_msg_init()
		case 'v':
		case 'V':
		case 'q': break;
		//unknown opt
		default: pr_error("Unknown OPTIONS -%c\n",func); help(pgrname); break;
		}
		argc--;
		argv++;
	}

	//Open config file if present
	if(argc >1)
	{
		ret=strlen(argv[1]);
		if(strcmp(argv[1]+ret-4,".stp")!=0)
		{
			pr_err("File %s must have .stp extension\n",argv[1]);
			return WRZ_EXIT_CONF;
		}
		//wrz_rgxf_init(&h_rgx,argv[1],"r([0-9]*)[^x]*x([0-9a-fa-f]*)","dx");
		ret=wrz_rgxf_init(&h_rgx,argv[1],"\"([0-9A-Fa-f]*)\",[^,]*,\"([0-9A-Fa-f]*)\"","xx");
		if(ret) return WRZ_EXIT_CONF;
		wrz_rgxf_read(&h_rgx);
		for(ret=0;ret<h_rgx.len && wrz_msg_checklvl(LOG_INFO);ret++)
		{
			printf("#%02d: R%04x %02x\n",ret,wrz_rgxf_get_integer(&h_rgx,ret,0),wrz_rgxf_get_integer(&h_rgx,ret,1));
		}
	}

	if(f_gpiorst)
	{
		/* reset the PLL */
		ad9516_export_gpio();
		printf("Reseting the %s... \n",pll_name);
		ad9516_reset_n(0);
		sleep(1);
		ad9516_reset_n(1);
		sleep(1);
		printf("Reset the %s done.\n",pll_name);
	}

	//Using Xilinx driver
	if(f_xil) {
		uint8_t mmap_xil=0;
		snprintf(pll_name,sizeof(pll_name),"AD9516 PLL%d",(f_xil==3)?0:f_xil);
		switch(f_xil)
		{
			case 1: mmap_xil=WRZ_FPGA_MAP_DEVSPI_1;  break;
			case 2: mmap_xil=WRZ_FPGA_MAP_DEVSPI_2; break;
			default: mmap_xil=WRZ_FPGA_MAP_DEVSPI_0; break;
		}

		ret=wrz_fpga_mmap_init(mmap_xil);
		if(ret) return WRZ_EXIT_MMAP;

		if(f_loadcfg)
		{
			ad9516_init(&h_rgx);
		}

		if(clktll_del.bypass==0)
		{
			ad9516_finedel_calc(&clktll_del);
			ad9516_finedel_adjust(&clktll_del,9);
		}

		if(ch_invert) ad9516_toggle_phase(ch_invert>0,abs(ch_invert)-1);
		if(0< f_nowrsync && f_nowrsync < _PLL_SYNC_LAST)
		{
			ad9516_enable_sync(0,pll_synctabs[f_nowrsync].data,pll_synctabs[f_nowrsync].size);
		}

		if(f_reset) {
			wrz_fpga_munmap();
			ret=wrz_fpga_mmap_init(WRZ_FPGA_MAP_AUTO);
			if(ret) return WRZ_EXIT_MMAP;
			sdb_find_devices();
			pr_info("sleeping 3s...\n");
			sleep(3);
			gtp_reset();
		}
	}
	else
	{
		ret=wrz_fpga_mmap_init(WRZ_FPGA_MAP_AUTO);
		if(ret) return WRZ_EXIT_MMAP;
		sdb_find_devices();

		if(BASE_SPI_AD9516)
		{
			pr_debug("SPI device found @ %p\n",BASE_SPI_AD9516);

			if(clktll_del.bypass)
			{
				ad9516_init(&h_rgx);
				if(f_reset) {
					pr_info("sleeping 3s...\n");
					sleep(3);
					gtp_reset();
				}
			}
			else
			{
				ad9516_finedel_calc(&clktll_del);
				ad9516_finedel_adjust(&clktll_del,9);
			}

		}
		else
		{
			pr_err("Could not find BASE_SPI_AD9516 in SDB\n");
			sdb_print_devices();
			return WRZ_EXIT_SDB;
		}
	}

	if(f_gpiorst) ad9516_unexport_gpio();

	wrz_rgxf_close(&h_rgx);
	wrz_fpga_munmap();

	return WRZ_EXIT_OK;
}

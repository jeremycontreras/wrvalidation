/*
 * leak_test.c
 *
 * Simulate random memory leaks by allocating and using memory buffers at random
 * intervals.
 *
 * Copyright (C) 2019 Seven Solutions (www.sevensols.com)
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 *
 * Last updated: Feb 13th, 2019
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>

/* Macros and constant definitions*/

#define SEED 1
#define DEFAULT_PERIOD 1000000
#define DEFAULT_ALLOC 10000

enum error_code
{
	OK,
	ERR_MALLOC,
	ERR_PARAMS,
};

struct leak_params
{
	/* 1 if random period, 0 if not (constant mode). */
	int random;
	/*
	 * In random mode, minimum period in microseconds.
	 * In constant-mode, period in microseconds.
	 */
	int period_min;
	/* In random mode, maximum period in microseconds. */
	int period_max;
	/*
	 * In random mode, minimum allocation size in bytes.
	 * In constant-mode, allocation size in bytes.
	 */
	int alloc_min;
	/* In random mode, allocation size in bytes. */
	int alloc_max;
};

/* Saves the number of total bytes allocated so far */
unsigned long long total_bytes;
/* Saves the number of total allocations done so far */
unsigned int leaks;

char *usage =
	"\nleak_test\n\n"
	"Runs indefinitely creating periodic memory leaks.\n\n"
	"Usage:\n"
	"	./leak_test [OPTIONS]\n\n"
	"Options:\n"
	"  -r / -R	Repeatable/Full pseudorandom mode. Generate random leaks.\n"
	"		In 'repeatable' mode, it seeds the RNG with a known number\n"
	"		to generate a known pseudorandom pattern.\n"
	"		If none of this options is used, the leaks will have constant\n"
	"		size and frequency.\n"
	"  -p		Pause between leaks in us. In random mode, minimum pause in us.\n"
	"  -P		In random mode, maximum pause between leaks in us.\n"
	"  -s		Leak size in bytes. In random mode, minimum leak size.\n"
	"  -S		In random mode, maximum leak size.\n\n"
	"\nExamples:\n\n"
	"Generate constant leaks with default settings:\n\n"
	"	leak_test\n\n"
	"Generate random leaks with default settings:\n\n"
	"	leak_test -R\n\n"
	"Leak 1000 bytes every 0.5s:\n\n"
	"	leak_test -p 500000 -s 1000\n\n"
	"Leak 1000-10000 bytes every 0.5-1s:\n\n"
	"	leak_test -R -p 500000 -P 1000000 -s 1000 -S 10000\n";


void print_status(void)
{
	printf("Allocations: %u\n", leaks);
	printf("Bytes: %llu\n", total_bytes);
}

void sighandler(int signal)
{
	switch(signal)
	{
	case SIGUSR1:
		print_status();
		break;
	default:
		break;
	}
}

/*
 * Takes a set of parameters loaded by <load_parameters> and checks them.
 * The rules are:
 *   - If no random mode specified, then use the default values for the
 *     parameters that weren't specified (pause and allocation size).
 *   - If a random mode was specified and all range parameters are specified
 *     (min and max), then use them if they make sense (min < max). If no range
 *     parameters are defined use the defaults.
 *
 * Returns:
 *   0 if the parameters were well defined
 *   1 if we fell back to defaults
 *   -1 if there were incorrect parameters
 */
int sanitize_parameters(struct leak_params *p)
{
	if (p->random)
	{
		if (p->period_min > 0 && p->period_max > 0
			&& p->alloc_min > 0 && p->alloc_max > 0)
		{
			/* All parameters defined. Check ranges */
			if (p->period_max <= p->period_min
				&& p->alloc_max <= p->alloc_min)
			{
				printf("Wrong parameter ranges\n");
				return -1;
			}
		} else if (p->period_min <= 0
			&& p->period_max <= 0
			&& p->alloc_min <= 0
			&& p->alloc_max <= 0)
		{
			/* No parameters defined. Use defaults */
			p->period_min = DEFAULT_PERIOD;
			p->period_max = DEFAULT_PERIOD * 10;
			p->alloc_min = DEFAULT_ALLOC;
			p->alloc_max = DEFAULT_ALLOC * 10;
			printf("Using default period and allocation ranges.\n");
			return 1;
		} else
		{
			/* Some parameters defined. Error */
			printf("Incomplete parameter list for random mode\n");
			return -1;
		}
	} else
	{
		if (p->period_min <= 0 && p->alloc_min > 0)
		{
			/* Only size defined. Use default for period */
			p->period_min = DEFAULT_PERIOD;
			printf("Using default period.\n");
		}
		if (p->alloc_min <= 0 && p->period_min > 0)
		{
			/* Only period defined. Use default for size */
			p->alloc_min = DEFAULT_ALLOC;
			printf("Using default allocation size.\n");
		}
		if (p->period_min <= 0 && p->alloc_min <= 0)
		{
			/* Neither period nor size defined. Use defaults */
			p->period_min = DEFAULT_PERIOD;
			p->alloc_min = DEFAULT_ALLOC;
			printf("Using default period and allocation size.\n");
			return 1;
		}
	}
	return 0;
}

/*
 * Parses and loads command-line parameters into a struct fileopen_params passed
 * as a parameter.
 *
 * Parameters:
 *   argc and argv: passed from main
 *   p: struct leak_params in which to store the command-line parameters
 *
 * Returns:
 *   0 if success
 *   1 otherwise
 */
int load_parameters(int argc, char **argv, struct leak_params *p)
{
	int c;
	struct timespec ts;

	while ((c = getopt(argc, argv, "rRp:P:s:S:h")) != -1)
	{
		switch (c)
		{
		case 'r':
			/*
			 * Repeatable pseudorandom. Seed the RNG with a known
			 * value
			 */
			srandom(SEED);
			p->random = 1;
			break;
		case 'R':
			/*
			 * Full pseudorandom. Seed the RNG with the current time
			 */
			clock_gettime(CLOCK_REALTIME, &ts);
			srandom(ts.tv_nsec);
			p->random = 1;
			break;
		case 'p':
			p->period_min = strtol(optarg, NULL, 10);
			break;
		case 'P':
			p->period_max = strtol(optarg, NULL, 10);
			break;
		case 's':
			p->alloc_min = strtol(optarg, NULL, 10);
			break;
		case 'S':
			p->alloc_max = strtol(optarg, NULL, 10);
			break;
		case 'h':
			puts(usage);
			exit(1);
		case '?':
			return 1;
		default:
			printf("Unknown error parsing parameters\n");
			return 1;
		}
	}
	return 0;
}

/*
 * Allocates and write memory buffers without ever freeing them to simulate
 * memory leaks.
 *
 * In random mode, it pauses a random amount of time (in a defined range)
 * between allocations and the allocation size is also randomized every time.
 * In constant mode, both the pause between allocations and the allocation size
 * is fixed.
 *
 * Parameters:
 *   p: struct leak_params containing the pause and allocation parameters.
 *
 * Returns:
 *   ERR_MALLOC if it couldn't allocate memory
 *   (if nothing goes wrong it shouldn't return)
 */
int leak(struct leak_params *params)
{
	char *p;
	unsigned int us;
	unsigned int n;

	while (1)
	{
		if (params->random)
		{
			n = random() / (RAND_MAX / params->alloc_max)
				+ params->alloc_min;
		} else
		{
			n = params->alloc_min;
		}
		p = malloc(n);
		if (!p)
		{
			printf("Can't allocate memory: %s\n", strerror(errno));
			return ERR_MALLOC;
		}
		memset(p, 1, n);
		total_bytes += n;
		leaks++;
		if (params->random)
		{
			us = random() / (RAND_MAX / params->period_max)
				+ params->period_min;
		} else
		{
			us = params->period_min;
		}
		usleep(us);
	}

	return 0;
}

int main(int argc, char **argv)
{
	struct sigaction sa;
	struct leak_params lparams;

	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sighandler;
	sigaction(SIGUSR1, &sa, NULL);

	/*
	 * Catch signals and use <sighandler> to handle them.
	 * (Respond to SIGUSR1 by printing the current status).
	 */
	memset(&lparams, 0, sizeof(lparams));
	if (load_parameters(argc, argv, &lparams))
	{
		puts(usage);
		return ERR_PARAMS;
	}
	if (sanitize_parameters(&lparams) == -1)
	{
		puts(usage);
		return ERR_PARAMS;
	}

	printf("Leak test parameters:\n");
	if (lparams.random)
	{
		printf("Random leaks\n");
		printf("Leak size: %d - %d bytes\n",
			lparams.alloc_min, lparams.alloc_max);
		printf("Leak period: %d - %d us\n",
			lparams.period_min, lparams.period_max);
	} else
	{
		printf("Leak size: %d\n", lparams.alloc_min);
		printf("Leak period: %d\n", lparams.period_min);
	}

	return leak(&lparams);
}

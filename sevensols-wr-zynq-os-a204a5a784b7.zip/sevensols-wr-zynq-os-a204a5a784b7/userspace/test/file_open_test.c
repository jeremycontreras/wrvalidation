/*
 * file_open_test.c
 *
 * Opens files periodically at random intervals and keeps them open.
 *
 * Copyright (C) 2019 Seven Solutions (www.sevensols.com)
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 *
 * Last updated: Feb 13th, 2019
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

/* Macros and constant definitions*/

#define SEED 1
#define DEFAULT_PATH "/bug_suite_files"
#define FILE_PREFIX "bug_test"
#define MAX_PATH_LEN 256
#define DEFAULT_PERIOD 1000000

enum error_code
{
	OK,
	ERR_FOPEN,
	ERR_DIR,
	ERR_PARAMS,
};

struct fileopen_params
{
	/* 1 if random period, 0 if not (constant mode). */
	int random;
	/*
	 * In random mode, minimum period in microseconds.
	 * In constant-mode, period in microseconds.
	 */
	int period_min;
	/* In random mode, maximum period in microseconds. */
	int period_max;
	/* Output path. */
	char *dirpath;
};

/* Saves the number of files opened so far */
unsigned int files;

char *usage =
	"\nfile_open_test\n\n"
	"Runs indefinitely opening files periodically and keeping them open.\n\n"
	"Usage:\n"
	"	./file_open_test [OPTIONS]\n\n"
	"Options:\n"
	"  -r / -R	Repeatable/Full pseudorandom mode. Waits a random period between opens.\n"
	"		In 'repeatable' mode, it seeds the RNG with a known number\n"
	"		to generate a known pseudorandom pattern.\n"
	"		If none of this options is used, it will open files with\n"
	"		constant frequency.\n"
	"  -p		Pause between opens in us. In random mode, minimum pause in us.\n"
	"  -P		In random mode, maximum pause between opens in us.\n"
	"  -d		Output directory (default: /bug_suite_files).\n"
	"\nExamples:\n\n"
	"Open files at constant pace with default settings:\n\n"
	"	file_open_test\n\n"
	"Open files at random intervals with default settings:\n\n"
	"	leak_test -R\n\n"
	"Open files every 0.5-1s:\n\n"
	"	leak_test -R -p 500000 -P 1000000\n";


void print_status(void)
{
	printf("Files: %u\n", files);
}

void sighandler(int signal)
{
	switch(signal)
	{
	case SIGUSR1:
		print_status();
		break;
	default:
		break;
	}
}

/*
 * Takes a set of parameters loaded by <load_parameters> and checks them.
 * The rules are:
 *   - If no random mode specified, then use the specified pause value if it's
 *     valid. If it's not or if it's not specified, use the default one.
 *   - If a random mode was specified and all range parameters are specified
 *     (min and max), then use them if they make sense (min < max). If no range
 *     parameters are defined, use the defaults.
 *
 * Returns:
 *   0 if the parameters were well defined
 *   1 if we fell back to defaults
 *   -1 if there were incorrect parameters
 */
int sanitize_parameters(struct fileopen_params *p)
{
	if (p->random)
	{
		if (p->period_min > 0 && p->period_max > 0)
		{
			/* All parameters defined. Check ranges */
			if (p->period_max <= p->period_min)
			{
				printf("Wrong parameter ranges\n");
				return -1;
			}
		} else if (p->period_min <= 0 && p->period_max <= 0)
		{
			/* No parameters defined. Use defaults */
			p->period_min = DEFAULT_PERIOD;
			p->period_max = DEFAULT_PERIOD * 10;
			printf("Using default period range.\n");
			return 1;
		} else
		{
			/* Some parameters defined. Error */
			printf("Incomplete parameter list for random mode\n");
			return -1;
		}
	} else
	{
		if (p->period_min <= 0)
		{
			/* No period defined. Use defaults */
			p->period_min = DEFAULT_PERIOD;
			printf("Using default period.\n");
			return 1;
		}
	}

	return 0;
}

/*
 * Parses and loads command-line parameters into a struct fileopen_params passed
 * as a parameter.
 *
 * Parameters:
 *   argc and argv: passed from main
 *   p: struct fileopen_params in which to store the command-line parameters
 *
 * Returns:
 *   0 if success
 *   1 otherwise
 */
int load_parameters(int argc, char **argv, struct fileopen_params *p)
{
	int c;
	struct timespec ts;

	while ((c = getopt(argc, argv, "rRp:P:d:h")) != -1)
	{
		switch (c)
		{
		case 'r':
			/*
			 * Repeatable pseudorandom. Seed the RNG with a known
			 * value
			 */
			srandom(SEED);
			p->random = 1;
			break;
		case 'R':
			/*
			 * Full pseudorandom. Seed the RNG with the current time
			 */
			clock_gettime(CLOCK_REALTIME, &ts);
			srandom(ts.tv_nsec);
			p->random = 1;
			break;
		case 'p':
			p->period_min = strtol(optarg, NULL, 10);
			break;
		case 'P':
			p->period_max = strtol(optarg, NULL, 10);
			break;
		case 'd':
			free(p->dirpath);
			p->dirpath = strdup(optarg);
			break;
		case 'h':
			puts(usage);
			exit(1);
		case '?':
			return 1;
		default:
			printf("Unknown error parsing parameters\n");
			return 1;
		}
	}
	return 0;
}


/*
 * Creates files indefinitely and periodically into a directory specified in
 * <p> (struct fileopen_params), and leaves them open.
 * If the directory doesn't exist, it creates it.
 *
 * In random mode, it pauses a random amount of time (in a defined range)
 * between file creations. In constant mode, it waits for a constant amount of
 * time.
 *
 * Parameters:
 *   p: struct fileopen_params containing the pause parameters and dir name.
 *
 * Returns:
 *   ERR_DIR if it couldn't create or open the output dir.
 *   ERR_FOPEN if it couldn't open a file.
 *   (if nothing goes wrong it shouldn't return)
 */
int file_opener(struct fileopen_params *p)
{
	char filepath[MAX_PATH_LEN];
	FILE *fp;
	unsigned int us;
	DIR *dir = opendir(p->dirpath);

	/*
	 * Check output directory.
	 * If it exists, use it. If it doesn't, create it.
	 */
	if (dir)
	{
		closedir(dir);
	} else if (errno == ENOENT)
	{
		if (mkdir(p->dirpath, S_IRWXU))
		{
			printf("Error creating directory %s\n", p->dirpath);
			return ERR_DIR;
		}
	} else
	{
		printf("Can't open directory %s: %s\n", p->dirpath,
			strerror(errno));
		return ERR_DIR;
	}

	while (1)
	{
		snprintf(filepath, MAX_PATH_LEN, "%s/%s_%d", p->dirpath,
			FILE_PREFIX, files++);
		fp = fopen(filepath, "w+");
		if (!fp)
		{
			printf("Can't open file %s: %s\n", filepath,
				strerror(errno));
			return ERR_FOPEN;
		}
		if (p->random)
		{
			us = random() / (RAND_MAX / p->period_max)
				+ p->period_min;
		} else
		{
			us = p->period_min;
		}
		usleep(us);
	}

	return 0;
}

int main(int argc, char **argv)
{
	struct sigaction sa;
	struct fileopen_params fparams;

	/*
	 * Catch signals and use <sighandler> to handle them.
	 * (Respond to SIGUSR1 by printing the current status).
	 */
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sighandler;
	sigaction(SIGUSR1, &sa, NULL);

	memset(&fparams, 0, sizeof(fparams));
	fparams.dirpath = strdup(DEFAULT_PATH);
	if (load_parameters(argc, argv, &fparams))
	{
		puts(usage);
		return ERR_PARAMS;
	}
	if (sanitize_parameters(&fparams) == -1)
	{
		puts(usage);
		return ERR_PARAMS;
	}

	printf("Fileopen test parameters:\n");
	printf("Output directory: %s\n", fparams.dirpath);
	if (fparams.random)
	{
		printf("Random period\n");
		printf("Open period: %d - %d us\n",
			fparams.period_min, fparams.period_max);
	} else
	{
		printf("Open period: %d\n", fparams.period_min);
	}

	return file_opener(&fparams);
}

#!/bin/sh

# print_test.sh
#
# Prints random-length strings to different types of destinations at random
# intervals.
#
# For usage help and options, run it as
#
#         print_test.sh -h
#
# Author Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
# Copyright (c) 2019 Seven Solutions S.L. (www.sevensols.com)
#
# This file is part of wr-zynq-os
# You might use, distribute and modify this code and its resulting
# binary form under the terms of the LICENSE.txt provided within the
# module/project: wr-zynq-os.
#
# If you do not have received a copy of the LICENSE.txt along with
# this file please write to info@sevensols.com and consider that
# this file can not be copied and/or distributed in any forms.


#### Default parameters
out=""
# Minimum pause between prints (in milliseconds)
min_pause=500
# Maximum pause between prints (in milliseconds)
max_pause=10000
# Minimum string length
min_str=10
# Maximum string length
max_str=100

usage="
print_test.sh

Prints variable-length strings to different types of destinations periodically.

Usage:

	print_test.sh [OPTIONS]

Options:

  * Output options (use only one of them)

    -l			Send output to the system log
    -f <file>		Send output to <file>, truncating it
    -F <file>		Send output to <file>, appending to it
    -t <file>		Print to stdout and <file> using tee, truncating the file
    -T <file>		Print to stdout and <file> using tee, appending to the file

  * Timing and string options

    -p <ms>		Minimum pause between prints in milliseconds
    -P <ms>		Maximum pause between prints in milliseconds
    -s <length>	Minimum string length
    -S <length>	Maximum string length

  -h			Shows this help screen

Examples:

Print random-length strings to stdout at random intervals:

	print_test.sh

Print to the system log:

	print_test.sh -l

Append an 80-char string every second to file out.txt:

	print_test.sh -p 1000 -P 1000 -s 80 -S 80 -F out.txt
"

while getopts "hlf:F:t:T:p:P:s:S:" opt; do
	case "$opt" in
		h)
			echo "$usage"
			exit 0
			;;
		l)
			if [ -n "$out" ]; then
				echo "Use only one output command"
				exit 1
			fi
			out="| logger"
			;;
		f)
			if [ -n "$out" ]; then
				echo "Use only one output command"
				exit 1
			fi
			out=">$OPTARG"
			;;
		F)
			if [ -n "$out" ]; then
				echo "Use only one output command"
				exit 1
			fi
			out=">>$OPTARG"
			;;
		t)
			if [ -n "$out" ]; then
				echo "Use only one output command"
				exit 1
			fi
			out="| tee $OPTARG"
			;;
		T)
			if [ -n "$out" ]; then
				echo "Use only one output command"
				exit 1
			fi
			out="| tee -a $OPTARG"
			;;
		p)
			min_pause=$OPTARG
			;;
		P)
			max_pause=$OPTARG
			;;
		s)
			min_str=$OPTARG
			;;
		S)
			max_str=$OPTARG
			;;
	esac
done

while true; do
	# Get random time and length values in the defined ranges
	rand_ms=`awk -v min=$min_pause -v max=$max_pause 'BEGIN{srand(); print int(min + rand() * (max - min + 1))}'`
	rand_s=`echo "scale=3; $rand_ms / 1000" | bc`
	rand_str=`awk -v min=$min_str -v max=$max_str 'BEGIN{srand(); print int(min + rand() * (max - min + 1))}'`

	# Print and wait
	p1=$(printf '[Test string - %4d chars]' $rand_str)
	p2=$(printf '%*s' $rand_str | tr ' ' '.')
	eval echo "$p1$p2" $out
	sleep $rand_s
done

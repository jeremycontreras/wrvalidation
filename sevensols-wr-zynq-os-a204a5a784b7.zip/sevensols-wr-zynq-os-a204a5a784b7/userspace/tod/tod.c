
/**
 * @file tod.c
 *
 * @brief
 *
 * @author Fidel Rodríguez (fidel.rodriguez@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 27-Sep-2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting 
 * binary form under the terms of the LICENSE.txt provided within the 
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <time.h>
#include <sys/timex.h>
#include <string.h>
#include <termios.h> 
#include <fcntl.h>
#include <errno.h>
#include <libgpa.h>
#include <libgpa/i2c.h>
#include <libgpa/util.h>
#include <libgpa/gpio.h>
#include <libgpa/i2c/i2c_fan7470.h>
#include <libgpa/i2c/i2c_yh5151e.h>
#include <libgpa/i2c/i2c_oled1309.h>
#include <libgpa/eeprom.h>
#include <signal.h>

#define PROG_NAME        "tod_service"
#define GPA_MOD_NAME     "tod_service"
#define UART_SPEED       B57600
#define PID_SYSFS_DIR    "/sys/kernel/tod_pid/tod_pid"

#define CLOCKID CLOCK_REALTIME
#define SIGNAL_PPS 45
timer_t timerid;

int PPS_BALANCE=1;
/*
Default UART of the front TP panel
 */
char *uart_name0 = "/dev/ttyUL2";
char *uart_name1 = "/dev/ttyUL3";

int fd0=-1,fd1=-1; // global file descriptor to close at exit
int looping=1;
char *output;
int nlen;

void safe_exit(int sigid)
{
	pr_debug("NMEA_SHUTDOWN: %d\n",sigid);
	looping=0;
	return;
}

struct msg
{
	char satellite_availability[10];
	char rev[10];
	char julian_date[15];
	char date[15];
	char hours[15];
	char time_zone[10];
	char time_zone_offset[15];
	char leap_second[10];
	char latitude[20];
	char longitude[20];
	char altitude_sea[20];
	char alarm_sev[10];
	char alarm_src[10];
	char alarm_cause[10];
};

/* Function called from the kernel to send the information to the serial port */
void wake_up (int sig)
{
	if(fd0>=0) write(fd0,output,nlen);
	if(fd1>=0) write(fd1,output,nlen);
	PPS_BALANCE++;
	return;
}

void configure_uart(int uart_descriptor)
{
	struct termios tty;
	memset (&tty, 0, sizeof tty);

	/* Error Handling */
	if ( tcgetattr ( uart_descriptor, &tty ) != 0 )
		printf("Error getting handling\n");

	/* Save old tty parameters */

	/* Set Baud Rate */

	/*
	TODO: Change these params from libgpa...
	 */
	cfsetospeed (&tty, (speed_t)UART_SPEED);
	cfsetispeed (&tty, (speed_t)UART_SPEED);

	/* Setting other Port Stuff */
	tty.c_cflag     &=  ~PARENB;            // Make 8n1
	tty.c_cflag     &=  ~CSTOPB;
	tty.c_cflag     &=  ~CSIZE;
	tty.c_cflag     |=  CS8;

	tty.c_cflag     &=  ~CRTSCTS;           // no flow control
	tty.c_cc[VMIN]   =  1;                  // read doesn't block
	tty.c_cc[VTIME]  =  5;                  // 0.5 seconds read timeout
	tty.c_cflag     |=  CREAD | CLOCAL;     // turn on READ & ignore ctrl lines

	/* Make raw */
	cfmakeraw(&tty);

	/* Flush Port, then applies attributes */
	tcflush( uart_descriptor, TCIFLUSH );
	if ( tcsetattr ( uart_descriptor, TCSANOW, &tty ) != 0)
		pr_warn("Error flushing port\n");

}

int _00_satellite_availability(struct msg *message, struct gpa_mod* gnss_module)
{
	char result = '!';

	if(gnss_module)
	{
		// TODO: Define this...
		/*
		struct gpa_prm* gnss_param = gpa_mod_getprm_prefix(gnss_module,
				"nav","validTime");
		uint8_t is_valid = gpa_prm_get_u8(gnss_param);

		if(is_valid)
			result = '*';
		*/
	}

	snprintf(message->satellite_availability,
			sizeof(message->satellite_availability), "%c", result);
	return 0;
}

int _01_revision(struct msg *message)
{
	/* revision is modified by the programmers */
	snprintf(message->rev, sizeof(message->rev), "%s", "A");
	return 0;
}

int _02_julian_date(struct msg *message)
{
	/* Julian date is calculated with the values of the system time */

	unsigned UT = time(NULL);
	unsigned JD = (UT / 86400) + 40587;

	snprintf(message->julian_date, sizeof(message->julian_date), "%u", JD);

	return 0;
}

int _03_04_date(struct msg *message)
{
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	snprintf(message->date, sizeof(message->date),"%02d/%02d/%02d",
			(tm.tm_year+1900)%100,tm.tm_mon+1,tm.tm_mday);
	snprintf(message->hours, sizeof(message->hours),"%02d:%02d:%02d",
			tm.tm_hour, tm.tm_min, tm.tm_sec);

	return 0;
}


int _05_06_timezone(struct msg *message)
{
	time_t t = time(NULL);
	struct tm lt = {0};

	if(localtime_r(&t, &lt) == NULL)
		return 1;

	if(lt.tm_gmtoff > 0)
		snprintf(message->time_zone, sizeof(message->time_zone), "%s", "+");

	snprintf(message->time_zone_offset,sizeof(message->time_zone_offset),
			"%ld",lt.tm_gmtoff/3600);

	return 0;
}

int _07_leap_second(struct msg *message, struct gpa_mod* tmgr_module)
{
	int8_t leap_second = 37; // by default

	/* TODO: This will be done from the ktmgr... */

	snprintf(message->leap_second, sizeof(message->leap_second), "%d", leap_second);

	return 0;
}

int _08_09_10_latitude(struct msg *message, struct gpa_mod* gnss_module)
{
	int32_t lon=0,lat=0,alt=0;

	if(gnss_module)
	{
		/*
		 * TODO: define this...
		struct gpa_prm* gnss_param = gpa_mod_getprm_prefix(gnss_module,"nav","lon");
		lon = gpa_prm_get_i32(gnss_param);

		gnss_param = gpa_mod_getprm_prefix(gnss_module,"nav","lat");
		lat = gpa_prm_get_i32(gnss_param);

		gnss_param = gpa_mod_getprm_prefix(gnss_module,"nav","height");
		alt = gpa_prm_get_i32(gnss_param);
		*/
	}

	snprintf(message->latitude,sizeof(message->latitude),"%d",lon);
	snprintf(message->longitude,sizeof(message->longitude),"%d",lat);
	snprintf(message->altitude_sea,sizeof(message->altitude_sea),"%d",alt);

	return 0;
}

int _11_12_13_alarm(struct msg *message)
{
	/* @TODO: NOT IMPLEMENTED: Read from GPS libgpa */
	snprintf(message->alarm_sev,sizeof(message->alarm_sev),"%s","--");
	snprintf(message->alarm_src,sizeof(message->alarm_src),"%s","--");
	snprintf(message->alarm_cause,sizeof(message->alarm_cause),"%s","--");

	return 0;
}

void strcat_message(char* to, const char* from,const char* sep)
{
	strcat(to,from);
	strcat(to,sep);
	return; 
}

size_t generate_message(struct msg *message,char* output)
{
	output[0]='\0';
	const char * sep=".";

	strcat_message(output,message->satellite_availability,sep);
	strcat_message(output,message->rev,sep);
	strcat_message(output,message->julian_date,sep);
	strcat_message(output,message->date,sep);
	strcat_message(output,message->hours,sep);
	strcat_message(output,message->time_zone,"");
	strcat_message(output,message->time_zone_offset,sep);
	strcat_message(output,message->leap_second,sep);
	strcat_message(output,message->latitude,sep);
	strcat_message(output,message->longitude,sep);
	strcat_message(output,message->altitude_sea,sep);
	strcat_message(output,message->alarm_sev," ");
	strcat_message(output,message->alarm_src," ");
	strcat_message(output,message->alarm_cause,"\r\n");

	return strlen(output);
}

void help(const char* pgrname)
{
	printf("usage: %s [OPTIONS] [/dev/ttyXXX] [/dev/ttyYYY]\n\n", pgrname);
	printf( "/dev/ttyXXX corresponds to 1st UART (by default /dev/ttyUL2)\n"
			"/dev/ttyYYY corresponds to 2nd UART (by default /dev/ttyUL3)\n"
			"\n");
	printf("where OPTIONS are:\n\n"
			"  -a                             Auto detection mode\n"
			"  -h                             Show this little help message\n"
			"  -q                             Quiet mode\n"
			"  -v                             Verbose mode\n"
			"  -V                             Very verbose\n"
			"\n");


	pr_info("version: %s (%s); compiled at %s %s\n",
			__GIT_VER__, __GIT_USR__, __DATE__, __TIME__);
	pr_debug("libgpa:%s\n",gpa_lib_version('a'));

	exit(1);
}


int main(int argc,char **argv)
{
	int opt=0, flg_auto=0;
	struct msg message;
	struct timeval tv;
	time_t t_actual;

	/* Called when the user uses SIGTERM or Ctrl+C */
	signal(SIGINT, safe_exit);
	signal(SIGTERM, safe_exit);

	const char *pgrname=argv[0];
	gpa_msg_init(argc,argv);

	//Parse the specific arguments
	//Parse the specific arguments
	while ((opt = getopt(argc, argv, "avVqh?")) != -1)
	{
		pr_debug("%d: %d %c(%d) %s\n",argc,optind,'c',opt,optarg);
		switch ((char)opt)
		{
		case 'a': flg_auto=1; break; //parsed by wrz_msg_init()
		case 'v': break; //parsed by wrz_msg_init()
		case 'V': break; //parsed by wrz_msg_init()
		case 'q': break; //parsed by wrz_msg_init()
		case '?': help(pgrname); break;
		case 'h': help(pgrname); break;
		default:
			pr_error("find: illegal option %c (%x)\n", (char)opt,opt);
			help(pgrname);
			break;
		}
	}
	optind--;
	argc-=optind;
	argv+=optind;


	switch(argc)
	{
	case 3:
		uart_name1=argv[2];
		/* Fall thru */
	case 2:
		uart_name0=argv[1];
		if(argc==2) uart_name1=NULL; // Only by the 0
		pr_debug("uart0:%s uart1=%s\n",uart_name0,uart_name1);
		break;
	};

	/* Open de serial port */
	fd0 = open (uart_name0, O_RDWR | O_NOCTTY | O_SYNC);
	if (fd0>=0) configure_uart(fd0);
	else
	{
		if(errno==ENOENT && flg_auto)
			pr_info("%s: %s\n. ",uart_name0,gpa_strerror(errno));
		else
			pr_error("%s: %s\n. ",uart_name0,gpa_strerror(errno));
	}

	if(uart_name1)
	{
		fd1 = open (uart_name1, O_RDWR | O_NOCTTY | O_SYNC);
		if(fd1>=0) configure_uart(fd1);
		else {
			if(errno==ENOENT && flg_auto)
				pr_info("%s: %s\n. ",uart_name1,gpa_strerror(errno));
			else
				pr_error("%s: %s\n. ",uart_name1,gpa_strerror(errno));
		}
	}

	if(fd0 <0 && fd1 <0)
	{
		pr_error("%s: Failed opening serial interfaces (%s and %s) \n", PROG_NAME, uart_name0, uart_name1);
		exit(errno);
	}

	/* All is ok and its time to write our pid to the sysfs */

	pid_t my_pid = getpid();
	FILE *f = fopen(PID_SYSFS_DIR, "w");
	if(f==NULL)
	{
		pr_warn("%s: Error opening %s\n",PROG_NAME,PID_SYSFS_DIR);
		pr_warn("%s: using polling system instead...\n", PROG_NAME);
	}
	else
	{
		fprintf(f, "%d\n", my_pid);
		/* Set the signal subsystem */
		fclose(f);
		signal(SIGNAL_PPS, &wake_up);
		pr_info("%s: Detected timealign module running. ToD message will be aligned to the PPS. \n",PROG_NAME);
	}

	/* TODO: disabled by default */
	struct gpa_mod* gnss_module = NULL; //gpa_mod_create_user(gpa_mod_user2,
			//GPA_MOD_FLAG_MB_WRITE|GPA_MOD_FLAG_QUIET);
	struct gpa_mod* tmgr_module = NULL; //gpa_mod_create_user(gpa_mod_tmgrd,
			//GPA_MOD_FLAG_MB_WRITE|GPA_MOD_FLAG_QUIET);

	output = calloc(sizeof(struct msg)+30,1); //Just to be sure to have enough space

	do{
		_00_satellite_availability(&message, gnss_module);
		_01_revision(&message);
		_02_julian_date(&message);
		_03_04_date(&message);
		_05_06_timezone(&message);
		_07_leap_second(&message, tmgr_module);
		_08_09_10_latitude(&message, gnss_module);
		_11_12_13_alarm(&message);

		nlen= generate_message(&message,output);

		if(f==NULL) // Send if the connection with timealign failed
		{
			if(fd0>=0) write(fd0,output,nlen);
			if(fd1>=0) write(fd1,output,nlen);

			// And check if timealign is now available to connect
			f = fopen(PID_SYSFS_DIR, "w");
			if(f==NULL)
			{
				// We continue sending each second... not aligned
			}
			else
			{
				// Now exists, so write our PID
				// pr_warn("%s: TimeAlign module detected. Using the PPS interrupt as reference.\n", PROG_NAME);
				PPS_BALANCE=0;
				fprintf(f, "%d\n", my_pid);
				fclose(f);
				signal(SIGNAL_PPS, &wake_up);
			}
		}
		else
		{
			// PPS ALIGN is working and sending the msg via callback
			PPS_BALANCE--;
			if(abs(PPS_BALANCE)>3)
			{
				// Error detected, disable timealign
				//pr_warn("%s: PPS Reference lost. Using polling...\n", PROG_NAME);
				f=NULL;
			}
		}

		pr_debug("%s",output);

		gettimeofday(&tv, NULL);
		t_actual=tv.tv_sec;
		while(t_actual == tv.tv_sec)
		{
			usleep(100000);
			gettimeofday(&tv, NULL);
		}
//		sleep(1);
	} while(looping);

	free(output);

	char* last_message = "NMEASHUTDOWN";
	if(fd0>=0) write(fd0,last_message,sizeof(last_message));
	if(fd1>=0) write(fd1,last_message,sizeof(last_message));

	sleep(1);

	if(fd0>=0) close(fd0);
	if(fd1>=0) close(fd1);

	return 0;
}

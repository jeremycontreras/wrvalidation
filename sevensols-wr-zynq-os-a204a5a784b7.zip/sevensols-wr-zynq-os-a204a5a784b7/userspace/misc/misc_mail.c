/**
 * @file misc_mail.c
 *
 * @brief create mail resource
 *
 * @author Ignacio Marin Lopez (ignacio.marin@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 16-04-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <string.h>
#include <libgpa.h>
#include <libgpa/rsrc.h>
#include <libgpa/msg.h>
#include <libgpa/util.h>
#include "misc.h"

#define _MAX_SEND_TO_LENGTH 256

/**
 * @brief Create rsrc to config traps
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_mail_alerts(struct gpa_rsrc *parent, const char *key, const char *desc)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);

	//------------------------------------

	last_prm = gpa_prm_create_str(self, _MAIL_SEND_TO, "send_to", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, _MAX_SEND_TO_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "A list of alerts mail recipients separated by ;");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);


	last_prm = gpa_prm_create_bool(self, _MAIL__START_CLOSE_ENABLED, "start_shutdown", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 0);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling mail system init/shutdown");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _MAIL__PRMS_ALERTS_ENABLED, "prms_alerts", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 0);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling mail when parameters is alert state or return from alert state");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}
/**
 * @file misc.c
 *
 * @brief
 *
 * @author Fidel Rodriguez Lopez (fidel.rodriguez@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 13-11-2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <math.h>
/* libgpa includes */
#include <libgpa.h>
#include <libgpa/msg.h>
#include <libgpa/sysfs.h>

/* own includes */
#include "misc.h"
#include "misc_snmp.h"

struct gpa_rsrc_assoc rassoc []={
		{.oid=2000,.mp="./logging",.rp="./logging"},
		{.oid=2001,.mp="./monit",.opt=GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS,.xval=1},
		{.oid=2100,.mp="./lldp",.opt=GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS, .xval=1},
		{.oid=3000,.mp="./snmp", .opt=GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS,.xval=1}, //show_experts
		{.oid=3001,.mp="./snmp/info", .rp="./snmp_info"},
		{.oid=3002,.mp="./snmp/v1_v2",.rp="./snmpv2_config"},
		{.oid=3100,.mp="./snmp/v3"},
		{.oid=3110,.mp="./snmp/v3/userSNMP",.rp="./userSNMP"},
		{.oid=3210,.mp="./snmp/v3/adminSNMP",.rp="./adminSNMP"},
		{.oid=3310,.mp="./snmp/v3/secuserSNMP",.rp="./secuserSNMP"},
		{.oid=3410,.mp="./snmp/v3/secadminSNMP",.rp="./secadminSNMP"},
		{.oid=3800,.mp="./snmp/v3/change_password",.rp="./change_password"},
		{.oid=3900,.mp="./snmp/traps",.rp="./snmp_traps"},
		{.oid=4000,.mp="./mail",.rp="./mail"},

};

void help(const char *pgrname)
{
	printf("Misc daemon. \n");
	printf("Usage: %s \n", pgrname);
	printf("-------------------------\n");
	printf("version: %s (%s); compiled at %s %s\n", __GIT_VER__, __GIT_USR__, __DATE__, __TIME__);

	exit(1);
}

//--------------- RSYSLOG

enum misc_rsyslogd_protocol
{
	UDP,
	TCP,
	_N_RSYSLOG_PROTOCOL
};
const char *misc_rsyslogd_protocol_str[] = {
	[UDP] = "UDP",
	[TCP] = "TCP",
};

enum misc_rsyslogd_verbose
{
	DISABLE,
	ENABLE,
	_N_RSYSLOG_VERBOSE
};
const char *misc_rsyslogd_verbose_str[] = {
	[DISABLE] = "Disable",
	[ENABLE] = "Enable",
};

#define MISC_RSYSLOG_PORT_DEFAULT         514
#define MISC_RSYSLOG_PROTO_DEFAULT        UDP

//-------------------------------------



int main(int argc, char *argv[])
{
	const char *pgrname = argv[0];
	int opt, optind=1;
	gpa_msg_init(argc,argv);
	int ret = 0;
	/* Parsing process */
	while ((opt = getopt(argc, argv, "vVh?")) != -1)
	{
		optind++;
		switch (opt)
		{
			/* Standard options for libgpa modules */
			case 'v': //parsed by wrz_msg_init()
			case 'V': //parsed by wrz_msg_init()
			case 'q': break;
			case '?': help(pgrname); break;
			case 'h': help(pgrname); break;
			default:
				pr_error("find: illegal option %c (%x)\n", opt,opt);
				help(pgrname);
				break;
		}
	}
	optind--;
	argc-=optind;
	argv+=optind;

	struct gpa_mod* misc_module=NULL;
	struct gpa_rsrc* logging_rsrc=NULL;
	struct gpa_prm* last_prm=NULL;
	struct gpa_rsrc* last_rsrc=NULL;

	misc_module = gpa_mod_create_owner(gpa_mod_misc,
			"misc",GPA_MOD_FLAG_MB_WRITE,20);
	if(misc_module == NULL)
		exit(errno);
	gpa_mod_add_desc(misc_module,"Miscellaneous module (logging, debug...)");

	logging_rsrc = gpa_rsrc_create("logging", "Logging management",
			GPA_RSRC_TYPE_PRIVATE,GPA_RSRC_ENDIANESS_LITTLE);
	if(logging_rsrc)
		gpa_rsrc_append_child(misc_module->root_rsrc,logging_rsrc);


	/* LOGGER: SERVER IP */
	last_prm = gpa_prm_create_str(logging_rsrc,MISC_PRM_OID_LOGGING_IP,
			"server_ip",GPA_PRM_VTA_STRING,
			GPA_ACC_RL|GPA_ACC_INTERNAL,
			NULL,MISC_PRM_STR_LEN);
	GPA_RETCHECK_PTR(last_prm,errno);
	gpa_prm_set_desc(last_prm, "Logger server ip address");

	/* LOGGER: SERVER PORT */
	last_prm = gpa_prm_create_val(logging_rsrc,MISC_PRM_OID_LOGGING_PORT,
			"server_port",GPA_PRM_VTX_U16,
			GPA_ACC_RL|GPA_ACC_INTERNAL,{.u16=MISC_RSYSLOG_PORT_DEFAULT});
	GPA_RETCHECK_PTR(last_prm,errno);
	gpa_prm_set_desc(last_prm, "Logger server port");

	/* LOGGER: PROTOCOL */
	last_prm = gpa_prm_create_enum(logging_rsrc,MISC_PRM_OID_LOGGING_PROTO,
			"protocol",GPA_PRM_VTX_ENUM,
			GPA_ACC_RL|GPA_ACC_INTERNAL,NULL, _N_RSYSLOG_PROTOCOL,
			GPA_PRM_ENUM_OPT_INDEXED_DIRECT,MISC_RSYSLOG_PROTO_DEFAULT);
	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Logging (rsyslogd) protocol (UDP/TCP)");
		for(int i=0;i<_N_RSYSLOG_PROTOCOL;i++)
			gpa_prm_enum_add_entry(last_prm,i,misc_rsyslogd_protocol_str[i]);
	}

	/* LOGGER: VERBOSE ALL DEBUG*/
	last_prm = gpa_prm_create_enum(logging_rsrc,MISC_PRM_OID_VERBOSE,
			"verbose_all",GPA_PRM_VTX_ENUM,
			GPA_ACC_RWL|GPA_ACC_INTERNAL,NULL, _N_RSYSLOG_VERBOSE,
		       	GPA_PRM_ENUM_OPT_INDEXED_DIRECT,0);
	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Logging verbose level (debug) "
				"for all daemons and init scripts");
		for(int i=0;i<_N_RSYSLOG_VERBOSE;i++)
			gpa_prm_enum_add_entry(last_prm,i,misc_rsyslogd_verbose_str[i]);
	}

	/* LOGGER: DEBUG_MODE */
	last_prm = gpa_prm_create_bool(logging_rsrc,MISC_PRM_OID_LOGGING_AUTO_SAVE,
			"log_autosave",GPA_ACC_RL|GPA_ACC_INTERNAL|GPA_ACC_EXPERT,GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED,0);
	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Enabling autosave logs mode. When enabled log files save periodically and when "
			"a critical or warning event happen");

	}

	/* LOGGER: NFILEROTATE */
	last_prm = gpa_prm_create_uval(logging_rsrc,MISC_PRM_OID_LOGGING_NFILEROTATE,
			"log_n_rotate",GPA_PRM_VTX_U8,GPA_ACC_RL|GPA_ACC_INTERNAL|GPA_ACC_EXPERT, (union gpa_val) {.u8=5});

	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Number of files to autorotate when debug mode is enabled");
	}

	last_rsrc=misc_rsrc_snmp_info_config(misc_module->root_rsrc,"snmp_info", "snmp info configuration resource");
	if (!last_rsrc)
		pr_error ("Unable to create snmp info configuration resource\n");

	struct snmp_opts opts;
	opts.default_view=_SNMP_VIEW_BASIC;
	opts.default_mode=_SNMP_MODE_RO;
	last_rsrc=misc_rsrc_snmp_v2_config(misc_module->root_rsrc,"snmpv2_config", "snmp v2 configuration resource",opts);
	if (!last_rsrc)
		pr_error ("Unable to create snmp v2 configuration resource\n");

	opts.default_view=_SNMP_VIEW_EXTENDED;
	opts.default_mode=_SNMP_MODE_RO;
	opts.auth_protocol=_SNMP_AUTH_MD5;
	opts.priv_protocol=_SNMP_PRIV_DES;
	last_rsrc=misc_rsrc_snmp_v3_config(misc_module->root_rsrc,"userSNMP", "snmp v3 configuration userSNMP resource",opts);
	if (!last_rsrc)
		pr_error ("Unable to create snmp v3 configuration userSNMP resource\n");

	opts.default_view=_SNMP_VIEW_ALL;
	opts.default_mode=_SNMP_MODE_RW;
	opts.auth_protocol=_SNMP_AUTH_MD5;
	opts.priv_protocol=_SNMP_PRIV_DES;
	last_rsrc=misc_rsrc_snmp_v3_config(misc_module->root_rsrc,"adminSNMP", "snmp v3 configuration adminSNMP resource",opts);
	if (!last_rsrc)
		pr_error ("Unable to create snmp v3 configuration adminSNMP resource\n");

	opts.default_view=_SNMP_VIEW_EXTENDED;
	opts.default_mode=_SNMP_MODE_RO;
	opts.auth_protocol=_SNMP_AUTH_SHA;
	opts.priv_protocol=_SNMP_PRIV_AES;
	last_rsrc=misc_rsrc_snmp_v3_config(misc_module->root_rsrc,"secuserSNMP", "snmp v3 configuration userSNMP resource",opts);
	if (!last_rsrc)
		pr_error ("Unable to create snmp v3 configuration userSNMP resource\n");

	opts.default_view=_SNMP_VIEW_ALL;
	opts.default_mode=_SNMP_MODE_RW;
	opts.auth_protocol=_SNMP_AUTH_SHA;
	opts.priv_protocol=_SNMP_PRIV_AES;
	last_rsrc=misc_rsrc_snmp_v3_config(misc_module->root_rsrc,"secadminSNMP", "snmp v3 configuration adminSNMP resource",opts);
	if (!last_rsrc)
		pr_error ("Unable to create snmp v3 configuration adminSNMP resource\n");

	last_rsrc=misc_rsrc_snmp_v3_change_psswd(misc_module->root_rsrc,"change_password", "snmp v3 tool to change passwords");
	if (!last_rsrc)
		pr_error ("Unable to create snmp v3 tool to change passwords resource\n");

	last_rsrc=misc_rsrc_snmp_traps(misc_module->root_rsrc,"snmp_traps", "snmp traps configuration resource");
	if (!last_rsrc)
		pr_error ("Unable to create snmp trap configuration resource\n");

	last_rsrc=misc_rsrc_mail_alerts(misc_module->root_rsrc, "mail", "mail alerts");
	if (!last_rsrc)
		pr_error ("Unable to create mail configuration resource\n");


	ret = gpa_mod_add_rsrcs_assoc(misc_module,NULL, rassoc,GPA_ARRAY_SIZE(rassoc));
	if(ret != 0)
	{
		pr_err("Error adding resource to module: %s\n", misc_module->name);
		exit(errno);
	}

	/* LOGGER: DEBUG_MODE */
	last_prm = gpa_prm_create_bool(NULL,MISC_PRM_OID_MONIT_DISABLED,
			"monit_disabled",GPA_ACC_RL|GPA_ACC_INTERNAL|GPA_ACC_EXPERT,GPA_PRM_ENUM_OPT_BOOL_Y_N,0);

	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Disabling monit process");
		gpa_modir_path_addprm(misc_module, "monit", last_prm);

	}

	/* SNMP: SHOW EXPERTS */
	last_prm = gpa_prm_create_bool(NULL,_MISC_SNMP_SHOW_EXPERTS,
			"show_experts",GPA_ACC_RL|GPA_ACC_INTERNAL|GPA_ACC_EXPERT,GPA_PRM_ENUM_OPT_BOOL_Y_N,0);

	if(last_prm)
	{
		gpa_prm_set_desc(last_prm,"Show experts parameters in SNMP");
		gpa_modir_path_addprm(misc_module, "snmp", last_prm);
	}

	last_prm = gpa_prm_create_bool(NULL, LLDP_PRM_OID_ENABLED,
			"enable", GPA_ACC_RL|GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_Y_N, 1);

	if (last_prm) {
		gpa_modir_path_addprm(misc_module, "lldp", last_prm);
	}

	while (1)
	{
		gpa_mod_handle_mb(misc_module);
	}

	return GPA_EXIT_OK;
}

/**
 * @file misc_snmp.h
 *
 * @brief misc snmp headers
 *
 * @author Ignacio Marin Lopez (ignacio.marin@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 16-04-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#ifndef MISC_SNMP_SNMP_H_
#define MISC_SNMP_SNMP_H_
#include <libgpa.h>

enum
{
	_SNMP_INFO_LOCATION = 1,
	_SNMP_INFO_CONTACT,
};

#define _SNMP_INFO_MAX_LENGTH 128

struct gpa_rsrc *misc_rsrc_snmp_info_config(struct gpa_rsrc *parent, const char *key, const char *desc);

enum
{
	_SNMP_V2_COMMUNITY=1,
	_SNMP_V2_ACCESS_VIEW,
	_SNMP_V2_ACCESS_MODE,
	_SNMP_V2_SOURCE_MASK1,
	_SNMP_V2_SOURCE_MASK2,
	_SNMP_V2_SOURCE_MASK3,
	_SNMP_V2_SOURCE_MASK4,
	_SNMP_V2_SOURCE_MASK5,
};

#define _SNMP_V2_COMMUNITY_MAX_LENGTH 64
#define _SNMP_V2_DEFAULT_COMMUNITY "public"

enum
{
	_SNMP_MODE_RO = 0,
	_SNMP_MODE_RW,
};

enum
{
	_SNMP_VIEW_NONE = 0,
	_SNMP_VIEW_BASIC,
	_SNMP_VIEW_EXTENDED,
	_SNMP_VIEW_ALL,
};

struct snmp_opts
{
	uint16_t default_view; 
	uint16_t default_mode;
	uint16_t auth_protocol;
	uint16_t priv_protocol;
};

struct gpa_rsrc *misc_rsrc_snmp_v2_config(struct gpa_rsrc *parent, const char *key, const char *desc, struct snmp_opts opts);

enum
{
	_SNMP_V3_USER_NAME=1,
	_SNMP_V3_USER_ACCESS_VIEW,
	_SNMP_V3_USER_ACCESS_MODE,
	_SNMP_V3_USER_AUTH_PROTOCOL,
	_SNMP_V3_USER_PRIV_PROTOCOL,
};

enum
{
	_SNMP_AUTH_MD5 = 0,
	_SNMP_AUTH_SHA,
};

enum
{
	_SNMP_PRIV_DES = 0,
	_SNMP_PRIV_AES,
};

#define _SNMP_V3_USER_NAME_MAX_LENGTH 128
struct gpa_rsrc *misc_rsrc_snmp_v3_config(struct gpa_rsrc *parent, const char *key, const char *desc, struct snmp_opts opts);

enum
{
	_SNMP_V3_PSSWD_USER_NAME,
	_SNMP_V3_PSSWD_AUTH_PROTOCOL,
	_SNMP_V3_PSSWD_PRIV_PROTOCOL,
	_SNMP_V3_PSSWD_OLD_SECRETAUTH,
	_SNMP_V3_PSSWD_OLD_SECRETPRIV,
	_SNMP_V3_PSSWD_NEW_SECRETAUTH,
	_SNMP_V3_PSSWD_NEW_SECRETPRIV,
	_SNMP_V3_PSSWD_CHANGENOW,
};

struct gpa_rsrc *misc_rsrc_snmp_v3_change_psswd(struct gpa_rsrc *parent, const char *key, const char *desc);

/************************************************************/
/***************** TRAPS ************************************/
/************************************************************/

enum
{
	_SNMP_TRAP_COMMUNITY_NAME=1,
	_SNMP_TRAP_NMS_IP_1,
	_SNMP_TRAP_NMS_IP_2,
	_SNMP_TRAP_NMS_IP_3,
	_SNMP_TRAP_NMS_IP_4,
	_SNMP_TRAP_SYSTEM_INIT_SHUTDOWN_ENABLED,
	_SNMP_TRAP_MODULES_START_CLOSE_ENABLED,
	_SNMP_TRAP_PRMS_TRACKED_ENABLED,
	_SNMP_TRAP_PRMS_ALERTS_ENABLED
};

struct gpa_rsrc *misc_rsrc_snmp_traps(struct gpa_rsrc *parent, const char *key, const char *desc);

#define _MISC_SNMP_SHOW_EXPERTS 1

#endif //MISC_SNMP_SNMP_H_
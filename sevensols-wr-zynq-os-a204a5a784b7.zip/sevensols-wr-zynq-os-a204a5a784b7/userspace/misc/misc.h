/**
 * @file misc.h
 *
 * @brief This file contains the header for the misc submodule
 *
 * @author Fidel Rodriguez Lopez (fidel.rodriguez@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 10-09-2019
 * @copyright Copyright (c) 2019 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os (misc)
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os (misc).
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#define MISC_PRM_STR_LEN                   100
#define MISC_PRM_OID_LOGGING_IP            1
#define MISC_PRM_OID_LOGGING_PORT          2
#define MISC_PRM_OID_LOGGING_PROTO         3
#define MISC_PRM_OID_VERBOSE               4
#define MISC_PRM_OID_LOGGING_AUTO_SAVE     5
#define MISC_PRM_OID_LOGGING_NFILEROTATE   6

#define MISC_PRM_OID_MONIT_DISABLED        1
#define LLDP_PRM_OID_ENABLED               1

enum {
	_MAIL_SEND_TO=1,
	_MAIL__START_CLOSE_ENABLED=7,
	_MAIL__PRMS_ALERTS_ENABLED=9
};

struct gpa_rsrc *misc_rsrc_mail_alerts(struct gpa_rsrc *parent, const char *key, const char *desc);

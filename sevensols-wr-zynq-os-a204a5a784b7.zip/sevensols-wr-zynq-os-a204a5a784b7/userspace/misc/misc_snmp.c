/**
 * @file misc_snmp.c
 *
 * @brief create snmp rerources
 *
 * @author Ignacio Marin Lopez (ignacio.marin@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 16-04-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <string.h>
#include <libgpa.h>
#include <libgpa/rsrc.h>
#include <libgpa/msg.h>
#include <libgpa/util.h>
#include "misc_snmp.h"

#define _SNMP_PASSWD_LOG_FILE "/var/log/gpa_snmp_passwd.log"

/**
 * @brief Create snmp info rsrc
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_snmp_info_config(struct gpa_rsrc *parent, const char *key, const char *desc)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);

	//------------------------------------

	last_prm = gpa_prm_create_str(self, _SNMP_INFO_LOCATION, "location", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, _SNMP_INFO_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp sysLocation");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_INFO_CONTACT, "contact", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, _SNMP_INFO_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp sysContact");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}


/**
 * @brief Create snmp v2 config  rsrc
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param opts   community default options
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_snmp_v2_config(struct gpa_rsrc *parent, const char *key, const char *desc, struct snmp_opts opts)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);

	//------------------------------------

	last_prm = gpa_prm_create_str(self, _SNMP_V2_COMMUNITY, "community_name", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, _SNMP_V2_DEFAULT_COMMUNITY, _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v2 community name");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V2_ACCESS_VIEW, "access_view",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RL  | GPA_ACC_INTERNAL , NULL, 4, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.default_view);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 access view. None for disable v1/v2.");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_NONE, "none");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_BASIC, "basic");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_EXTENDED, "extended");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_ALL, "all");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V2_ACCESS_MODE, "access_mode",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, 2, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.default_mode);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 access mode. ro: read only; rw: read/write");
		gpa_prm_enum_add_entry(last_prm, _SNMP_MODE_RO, "ro");
		gpa_prm_enum_add_entry(last_prm, _SNMP_MODE_RW, "rw");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V2_SOURCE_MASK1, "source_mask_1", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 source mask 1 for filtering allowed hosts");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V2_SOURCE_MASK2, "source_mask_2", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 source mask 2 for filtering allowed hosts");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V2_SOURCE_MASK3, "source_mask_3", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 source mask 3 for filtering allowed hosts");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V2_SOURCE_MASK4, "source_mask_4", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 source mask 4 for filtering allowed hosts");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V2_SOURCE_MASK5, "source_mask_5", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL , "", _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v1/v2 source mask 5 for filtering allowed hosts");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}

/**
 * @brief Create snmp v3 config  rsrc
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @param opts   user default options
 * @note  user is created when you run /etc/init.d/snmpd and no persistent password file is found
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_snmp_v3_config(struct gpa_rsrc *parent, const char *key, const char *desc, struct snmp_opts opts)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);


	//------------------------------------

	last_prm = gpa_prm_create_str(self, _SNMP_V3_USER_NAME, "user_name", GPA_PRM_VTA_STRING, GPA_ACC_R | GPA_ACC_INTERNAL, (char *) key, strlen(key)+1);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 user name");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_USER_ACCESS_VIEW, "access_view",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, 4, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.default_view);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 access view.");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_NONE, "none");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_BASIC, "basic");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_EXTENDED, "extended");
		gpa_prm_enum_add_entry(last_prm, _SNMP_VIEW_ALL, "all");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_USER_ACCESS_MODE, "access_mode",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RL | GPA_ACC_INTERNAL, NULL, 2, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.default_mode);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 access mode. ro: read only; rw: read/write");
		gpa_prm_enum_add_entry(last_prm, _SNMP_MODE_RO, "ro");
		gpa_prm_enum_add_entry(last_prm, _SNMP_MODE_RW, "rw");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_USER_AUTH_PROTOCOL, "auth",
								   GPA_PRM_VTX_ENUM, GPA_ACC_R | GPA_ACC_INTERNAL, NULL, 3, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.auth_protocol);
	if (last_prm)
	{
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_MD5, "MD5");
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_SHA, "SHA");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_USER_PRIV_PROTOCOL, "priv",
								   GPA_PRM_VTX_ENUM, GPA_ACC_R | GPA_ACC_INTERNAL, NULL, 3, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, opts.priv_protocol);
	if (last_prm)
	{
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_MD5, "DES");
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_SHA, "AES");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}

/**
 * @brief sync function to change password
 * 
 * @param self A pointer to the rsrc
 * @param p    A pointer to the parameter
 * @param to_param  direction of sync
 * @return int32_t 0 if all was ok, otherwise an error
 */
static int32_t misc_rsrc_snmp_v3_change_psswd_sync(struct gpa_rsrc *self, struct gpa_prm *p, int to_param)
{
	if (gpa_prm_get_oid(p) == _SNMP_V3_PSSWD_CHANGENOW)
	{
		if (!to_param)
		{
			GPA_RETCHECK_MSG(strlen(gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETAUTH))) >= 8, -EFAULT, "Not enough length for new auth password, at least 8\n");
			GPA_RETCHECK_MSG(strlen(gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV))) >= 8, -EFAULT, "Not enough length for new priv password, at least 8\n");
			int ret = 0;
			char buff_auth[512];
			char buff_priv[512];
			char buff[1048];

			char authprotocol[10];
			char privprotocol[10];

			gpa_snprintf(authprotocol, sizeof(authprotocol), "%s", gpa_prm_val_tostr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_AUTH_PROTOCOL)));
			gpa_snprintf(privprotocol, sizeof(privprotocol), "%s", gpa_prm_val_tostr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_PRIV_PROTOCOL)));
			gpa_snprintf(buff_auth, sizeof(buff_auth), "snmpusm -v 3 -u %s -l authPriv -a %s -x %s -A %s -X %s localhost passwd -Ca %s %s",
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_USER_NAME)),
						authprotocol,
						privprotocol,
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETAUTH)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETAUTH)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_NEW_SECRETAUTH))),

			gpa_snprintf(buff_priv, sizeof(buff_priv), "snmpusm -v 3 -u %s -l authPriv -a %s -x %s -A %s -X %s localhost passwd -Cx %s %s &",
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_USER_NAME)),
						authprotocol,
						privprotocol,
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_NEW_SECRETAUTH)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV)),
						gpa_prm_getptr_str(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_NEW_SECRETPRIV))),

			gpa_snprintf (buff,sizeof(buff),"nohup sh -c \"(%s;%s)\" &> %s  &",buff_auth,buff_priv,_SNMP_PASSWD_LOG_FILE);
			ret = system(buff);
			GPA_RETCHECK_MSG(!ret, -EFAULT, "Unable to change priv password\n");

			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_USER_NAME), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_AUTH_PROTOCOL), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_PRIV_PROTOCOL), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETAUTH), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_NEW_SECRETAUTH), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_NEW_SECRETPRIV), "");
			gpa_prm_set_val_fromstr(gpa_rsrc_prm_find_oid(self, _SNMP_V3_PSSWD_CHANGENOW), "n");

			pr_info("Password successfully changed\n");
		}
		return 0;
	}

	return -ENOSYS;
}

/**
 * @brief Create change password rsrc
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_snmp_v3_change_psswd(struct gpa_rsrc *parent, const char *key, const char *desc)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);

	//Create our self structure
	self->prm_sync = misc_rsrc_snmp_v3_change_psswd_sync;

	//------------------------------------

	last_prm = gpa_prm_create_str(self, _SNMP_V3_PSSWD_USER_NAME, "user_name", GPA_PRM_VTA_STRING, GPA_ACC_RW | GPA_ACC_INTERNAL, "", _SNMP_V3_USER_NAME_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 user to change password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_PSSWD_AUTH_PROTOCOL, "auth",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RW | GPA_ACC_INTERNAL, NULL, 3, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, _SNMP_AUTH_MD5);
	if (last_prm)
	{
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_MD5, "MD5");
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_SHA, "SHA");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_enum(self, _SNMP_V3_PSSWD_PRIV_PROTOCOL, "priv",
								   GPA_PRM_VTX_ENUM, GPA_ACC_RW | GPA_ACC_INTERNAL, NULL, 3, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, _SNMP_PRIV_DES);
	if (last_prm)
	{
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_MD5, "DES");
		gpa_prm_enum_add_entry(last_prm, _SNMP_AUTH_SHA, "AES");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V3_PSSWD_OLD_SECRETAUTH, "old_auth_password", GPA_PRM_VTA_STRING, GPA_ACC_RW | GPA_ACC_INTERNAL, "", _SNMP_V3_USER_NAME_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 old auth password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V3_PSSWD_OLD_SECRETPRIV, "old_priv_password", GPA_PRM_VTA_STRING, GPA_ACC_RW | GPA_ACC_INTERNAL, "", _SNMP_V3_USER_NAME_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 old priv password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V3_PSSWD_NEW_SECRETAUTH, "new_auth_password", GPA_PRM_VTA_STRING, GPA_ACC_RW | GPA_ACC_INTERNAL, "", _SNMP_V3_USER_NAME_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 new auth password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_V3_PSSWD_NEW_SECRETPRIV, "new_priv_password", GPA_PRM_VTA_STRING, GPA_ACC_RW | GPA_ACC_INTERNAL, "", _SNMP_V3_USER_NAME_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "snmp v3 new priv password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _SNMP_V3_PSSWD_CHANGENOW, "changenow", GPA_ACC_RW, GPA_PRM_ENUM_OPT_BOOL_Y_N, 0);
	if (last_prm)
	{
		gpa_prm_set_refresh_rate(last_prm, GPA_PRM_OPT_RRATE_NONE);
		gpa_prm_set_desc(last_prm, "write 1(y) to change password");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);

	return self;
}

#define _MAX_IP_LENGTH 20

/**
 * @brief Create rsrc to config traps
 * 
 * @param parent parent rsrc
 * @param key    rsrc key
 * @param desc   rsrc desc
 * @return struct gpa_rsrc* A pointer to the created rsrc
 */
struct gpa_rsrc *misc_rsrc_snmp_traps(struct gpa_rsrc *parent, const char *key, const char *desc)
{
	struct gpa_prm *last_prm = NULL;
	struct gpa_rsrc *self = NULL;

	GPA_RETCHECK_PTRERRNO(key, -EFAULT);

	//Create the rsrc
	self = gpa_rsrc_create(key, desc, GPA_RSRC_TYPE_PRIVATE, GPA_RSRC_ENDIANESS_HERITED);
	GPA_RETCHECK_PTRERRNO(self, -EFAULT);

	//------------------------------------

	last_prm = gpa_prm_create_str(self, _SNMP_TRAP_COMMUNITY_NAME, "community_name", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, _SNMP_V2_DEFAULT_COMMUNITY, _SNMP_V2_COMMUNITY_MAX_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "We send traps using snmp v2 with this community name, it is not neccesary give access to this community in this device.");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	
	last_prm = gpa_prm_create_str(self, _SNMP_TRAP_NMS_IP_1, "NMS_IP_1", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _MAX_IP_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "NMS IP to send traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_TRAP_NMS_IP_2, "NMS_IP_2", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _MAX_IP_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "NMS IP to send traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_TRAP_NMS_IP_3, "NMS_IP_3", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _MAX_IP_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "NMS IP to send traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_str(self, _SNMP_TRAP_NMS_IP_4, "NMS_IP_4", GPA_PRM_VTA_STRING, GPA_ACC_RL | GPA_ACC_INTERNAL, "", _MAX_IP_LENGTH);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "NMS IP to send traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _SNMP_TRAP_SYSTEM_INIT_SHUTDOWN_ENABLED, "start_shutdown", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 1);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling system init/shutdown traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _SNMP_TRAP_MODULES_START_CLOSE_ENABLED, "modules_start_close", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 1);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling module start/close traps");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _SNMP_TRAP_PRMS_TRACKED_ENABLED, "prms_tracked", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 1);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling traps when tracked parameters change its value");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	last_prm = gpa_prm_create_bool(self, _SNMP_TRAP_PRMS_ALERTS_ENABLED, "prms_alerts", GPA_ACC_RL | GPA_ACC_INTERNAL, GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, 1);
	if (last_prm)
	{
		gpa_prm_set_desc(last_prm, "Enabling traps when parameters is alert state or return from alert state");
	}
	else
		pr_error("Could not create parameter for rsrc=%s\n", key);

	if (parent)
		gpa_rsrc_append_child(parent, self);
	return self;
}
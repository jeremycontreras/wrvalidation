# Common folder

Default folder to export all SNMP information by modules in .oid files.

#!/bin/sh

# Creates a named pipe and opens descriptor to it to keep it open
# (technically, to avoid the pipe sending an EOF after a process sends
# something through it).
# NOTE: When calling "start", run it as a background process

. /etc/init.d/wrz_functions

pid_file=/var/run/open_log_pipe.pid


start() {
	# Run only once
	if [ ! -e $pid_file ]; then
		echo "$$" > $pid_file
		mkfifo $LOG_PIPE
		exec 3>$LOG_PIPE
		while true; do sleep 600; done;
	fi
}

stop() {
	if [ -e $pid_file ]; then
		kill -9 `cat $pid_file`
		rm $LOG_PIPE
		rm $pid_file
	fi
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	*)
		echo "Usage: $0 {start & | stop}"
		exit 1
esac

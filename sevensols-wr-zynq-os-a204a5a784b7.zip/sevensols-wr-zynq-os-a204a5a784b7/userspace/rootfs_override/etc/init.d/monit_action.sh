#!/bin/sh

# Simple wrapper for monit to log and run the required actions depending on the
# severity of the event (CRITICAL / ERROR / WARNING)

OUTPUT_DIR=/root/debug

action_type=$1
reason=$2

case "$action_type" in
	warning)
		logger -p user.info "monit [WARNING] : <$2> failed too many times (see /var/log/monit.log)"
	;;
	error)
		logger -p user.info "monit [ERROR] : <$2> failed too many times (see /var/log/monit.log)"
	;;
	critical)
		# Run logging/housekeeping actions before rebooting
		logger -p user.info "monit [CRITICAL] : <$2> is unreliable. Rebooting . . ."
		mkdir -p $OUTPUT_DIR
		rm -fr $OUTPUT_DIR/*
		date_string=`date +%Y-%m-%d_%H.%M.%S`
		echo "$reason" > $OUTPUT_DIR/monit_restart_reason__$date_string
                monit status > $OUTPUT_DIR/monit_status__$date_string
		/wr/sbin/wrz_logdump -o $OUTPUT_DIR
		/sbin/reboot
	;;
	*)
		echo -e "Usage: $0 [warning|error|critical] <service>\n"
		exit 1
esac

exit $?

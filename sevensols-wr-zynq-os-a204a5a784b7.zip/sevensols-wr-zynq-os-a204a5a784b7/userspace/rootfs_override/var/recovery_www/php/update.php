<?php

/**
 * @file update.php
 *
 * @brief Actions to update files and flash the device
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

session_start();
$checkmd5fw = 1;

if (isset($_POST['action']) && !empty($_POST['action'])) {
	$action = $_POST['action'];
	switch ($action) {
	case 'upload':
		$imageType = $_POST['fileType'];
		upload($imageType);
		break;
	case 'flash':
		flash(false, false);
		break;
	case 'soft_force_flash':
		flash(true, false);
		break;
	case 'hard_force_flash':
		flash(false, true);
		break;
	}
}

/**
 * Upload a file to the server checking that is the correct file
 * anne@sevensols.com
 */
function upload($imageType) {
	exec("rm /var/www/uploads/*." . $imageType, $output, $retval);

	$_SESSION["target_dir"] = "/var/www/uploads/";
	$target_dir = $_SESSION["target_dir"];

	$_SESSION["upload_name"] = basename($_FILES["fileToUpload"]["name"]);
	$uploadname = $_SESSION["upload_name"];

	$_SESSION["target_file"] = $target_dir . $uploadname;
	$target_file = $_SESSION["target_file"];

	$imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

	// a flag to see if everything is ok
	$success = null;

	// Allow certain file formats
	if ($imageFileType != $imageType) {
		$output = ['error' => 'Sorry, only ' . $imageType . ' files are allowed. The file extension provided was: ' . $imageFileType];
	} elseif (!file_exists($target_dir)) {
		$output = ['error' => 'Directory does not exists.'];
	} // if everything is ok, try to upload file
	else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			$success = true;
		} else {
			$success = false;
		}

		// check and process based on successful status
		if ($success === true) {
			$output = [];
		} elseif ($success === false) {
			$output = ['error' => 'Error while uploading images. Contact the system administrator '];
		} else {
			$output = ['error' => 'No files were processed.'];
		}
	}

	echo json_encode($output);
}

/**
 * Flashes the server
 * anne@sevensols.com
 */
function flash($softFlash, $hardFlash) {
	flash_procedure($_SESSION["upload_name"], $_SESSION["target_file"], $softFlash, $hardFlash);
}

/**
 * Procedure that flashes the device and checks the md5. If all its correct, reboots the device
 * to complete the flashing
 *
 * @note: the original .tar file uploaded is renamed by javascript using only underscore (_).
 * wr-zynq-os-v2.1-RC1-20171128_binaries.tar > wr_zynq_os_v2.1_RC1_20171128_binaries.tar
 */
function flash_procedure($uploadfname, $uploadfile, $softFlash, $hardFlash) {
	$err_msg = "";
	$suc_msg = 'Upgrade procedure will take place after reboot...Please do not switch off the device during flashing procedure';
	if (file_exists($uploadfile)) {
		if ($softFlash == true) {
			exec("wrz_flashfw -f " . $uploadfile . " 2>&1", $output, $retval);
			$post_data = ['error' => "false", 'msg' => $suc_msg];
			echo json_encode($post_data);
		} elseif ($hardFlash == true) {
			exec("wrz_flashfw -F " . $uploadfile . " 2>&1", $output, $retval);
			$post_data = ['error' => "false", 'msg' => $suc_msg];
			echo json_encode($post_data);
		} else {
			//execute flashing tool
			exec("wrz_flashfw -d " . $uploadfile . " 2>&1", $output, $retval);
			switch ($retval) {
			case 0:
				//flash, no errors
				$post_data = ['error' => "false", 'msg' => $suc_msg];
				echo json_encode($post_data);
				exec("wrz_flashfw " . $uploadfile . " 2>&1", $output, $retval);
				break;
			case 1:
				$err_msg = "Firmware is not official.";
				break;
			case 2:
				$err_msg = "Hardware version is not compatible";
				break;
			case 3:
				$err_msg = "Device is not compatible.";
				break;
			case 4:
				$err_msg = "MDM5 Checksum is not valid. Update cancelled.";
				break;
			case 7:
				$err_msg = "File not found. Update cancelled.";
				break;
			}
		}
	} else {
		$err_msg = "No flashing file, did you upload a correct file?";
	}

	if (!empty($err_msg)) {
		$err_msg = "<span id=\"flash_error\"> ${err_msg} </span>\n";
		$post_data = ['error' => "true", 'msg' => $err_msg];
		echo json_encode($post_data);
	}
}

/**
 * Reboots the server after a certain time
 * anne@sevensols.com
 */
function reboot($timeout = 40) {
	echo '<div id="rebootmsg">
		<p align=center><img  style="width:5%" src="../img/loader.gif"></p>
		<br>
		<div id="rebooting" align=center>
		<p><font color="white">You will be rebooted in <span id="counter">' . $timeout . '</span> second(s).</font></p></div>
		</div>
		</div>
	<meta http-equiv="refresh" content="' . $timeout . ';url=../index.html">';
}

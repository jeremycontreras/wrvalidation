<?php

/**
 * @file functions.php
 *
 * @brief file with general functions
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

session_start();
$GLOBALS['tempFileWeb'] = "/tmp/tmpWeb"; //file to detect if device was rebooted or not
$GLOBALS['downFileDir'] = "/var/www/downloads/";
/**
 * Checks what kind of operation is going to be done
 * anne@sevensols.com
 */
if (!empty($_POST['action'])) {
	$action = $_POST['action'];
	switch ($action) {
		case 'getdashboardinfo':
			getDashboardInfo();
			break;
		case 'product':
			getNameProduct();
			break;
		case 'dumplog':
			dumpLog();
			break;
		case 'factory':
			restoreFactory();
			break;
		case 'checkUserReboot':
			checkUserReboot();
			break;
		case 'changesSavedButNotReboot';
			changesSavedButNotReboot();
			break;
		case 'exportConfig':
			exportConfig();
			break;
	}
}

/*
* Get dashboard info
*/
function getDashboardInfo()
{
	//create json objt info
	$info->hostname = "?";
	$info->ipDeviceETH0 = "?";
	$info->ipDeviceETH1 = "?";
	$info->softVersion = "?";
	$info->hardVersion = "?";
	$info->bootloaderVersion = "?";
	$info->serialNumber = "?";

	//hostname info
	$hostnameCommand = "hostname";
	exec($hostnameCommand, $outputHostname, $retval);
	if ($retval == 0) {
		$info->hostname = $outputHostname[0];
	}
	//ip info
	$output = [];
	$ipDeviceCommandETH0 = "/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'";
	exec($ipDeviceCommandETH0, $outputDeviceETH0, $retval);
	if ($retval == 0) {
		$info->ipDeviceETH0 = $outputDeviceETH0[0];
	}

	$ipDeviceCommandETH1 = "/sbin/ifconfig eth1 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'";
	exec($ipDeviceCommandETH1, $outputDeviceETH1, $retval);
	if ($retval == 0) {
		$info->ipDeviceETH1 = $outputDeviceETH1[0];
	}
	//software version
	$softVersionCommand = "cat /media/boot/current.tag";
	exec($softVersionCommand, $outputSoftV, $retval);
	if ($retval == 0) {
		$info->softVersion = $outputSoftV[0];
	}
	//hardware version

	$hardVersionCommand = "cat /proc/cmdline | grep -o '\hw_version=[^ ]*'";
	exec($hardVersionCommand, $outputHardV, $retval);
	if ($retval == 0) {
		$info->hardVersion = str_replace("hw_version=", "",$outputHardV[0]);
	}

	//bootloader version
	$bootloaderVersionCommand = "cat /proc/cmdline | grep -o '\ubv=[^ ]*'";
	exec($bootloaderVersionCommand, $outputBootloader, $retval);
	if ($retval == 0) {
		$info->bootloaderVersion = str_replace("ubv=", "",$outputBootloader[0]);
	}
	//serial number
	$serialNumberCommand = "cat /proc/cmdline | grep -o '\hw_sn=[^ ]*'";
	exec($serialNumberCommand, $outputSN, $retval);
	if ($retval == 0) {
		$info->serialNumber = str_replace("hw_sn=", "",$outputSN[0]);
	}

	//print info
	echo json_encode($info);
}

/*
* Gets product name
*/
function getNameProduct()
{
	//$line = shell_exec("gpa_json -m hald -l device export");
	$line = "Recovery";
	echo $line;
}

/*
* Gets LOG
*/
function dumpLog()
{
	exec("rm " . $GLOBALS['downFileDir'] . "wrz*.logdump");
	exec("wrz_logdump -o " . $GLOBALS['downFileDir'], $output, $retval);
	if ($retval == 0) {
		echo glob($GLOBALS['downFileDir'] . "wrz*.logdump")[0];
	} else {
		echo -1;
	}
}

/*
* Restore to factory deleting .config file
*/
function restoreFactory()
{
	$configFile = '/root/.config';

	if (file_exists($configFile)) {
		exec("/wr/sbin/wrz_config -F", $output, $retval);
		if($retval == 0){
			echo "success";
			exec("touch ".$configFile);
		}
	} else {
		echo "File does not exists";
	}
}

/*
* Returns true if device was not rebooted, false otherwise
*/
function checkUserReboot(){
	echo var_export(file_exists($GLOBALS['tempFileWeb']));
}

/*
* Creates a file for Saved "RL" value flags that disspears when restarted device
*/
function changesSavedButNotReboot(){
	shell_exec("echo 1 > ".$GLOBALS['tempFileWeb']);
}

/**
 * Exports the configuration file
 * anne@sevensols.com
 */
function exportConfig() {
	exec("wrz_loadconfig -e", $output, $retval);
	if ($retval == 0 || $retval == 1) {
		echo glob("/var/www/downloads/wrz_config*.config")[0];
	} else {
		echo $output[0];
	}
}

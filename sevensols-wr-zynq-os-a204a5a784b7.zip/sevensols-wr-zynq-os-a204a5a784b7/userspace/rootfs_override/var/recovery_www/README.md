# README #

**author** Anne M. (anne@sevensols.com)
**ingroup** PHP GPA
**date** 2020
**copyright** Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)

This project is part of PHP GPA
You might use, distribute and modify this code and its resulting 
binary form under the terms of the LICENSE.txt provided within the 
module/project: PHP GPA.
 
If you do not have received a copy of the LICENSE.txt along with
this file please write to info@sevensols.com and consider that
this file can not be copied and/or distributed in any forms.


This code is property of Seven Solutions, before distribution, copy or modify, write to info@sevensols.com

### Minimun Requisites ###

* Server with PHP
* Some fake JSON data
* Chrome

### How do I get set up? ###

Copy files to your /var/www/ server

### Files ###

This software has a backend developed in PHP that extracts the data from the embedded device and sends it to the froint end, and a frontend developed in JavaScript.

The backends extracts the data while the frontend draws the data.

The PHP files can be found under: /php

The Javascript under /js/pages

Each .html page is associated to a javascript that will dynamically draw the data, this is done so if new values are added, they will be automatically added to the page by only adding them to the backend.

Other /js/ files that can be found are files for general use and general globals to provide the correct work of the program. Special attention to functions.js, that follows a **Facade software pattern** where the center is this file. 

![alt text](https://upload.wikimedia.org/wikipedia/en/5/57/Example_of_Facade_design_pattern_in_UML.png "Facade software pattern")

### .min files ###

The web for recovery needs to be as small as possible. Before uploading new libraries, please check for the .min version ready for production websites.

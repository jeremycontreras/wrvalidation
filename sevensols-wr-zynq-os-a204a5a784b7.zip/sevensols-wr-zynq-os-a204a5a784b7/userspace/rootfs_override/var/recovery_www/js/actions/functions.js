/**
 * @file functions.js
 *
 * @brief Contains the global actions for the correct web data representation
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting 
 * binary form under the terms of the LICENSE.txt provided within the 
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

//globaldata
//default update interval
updateInterval = 4000;
//global value to save apply/save status, true nothing has changed or apply/save has been pressed
notapplysave = true;

$(document).ready(function () {
	//hide menu at the load
	$('#rightmenu').hide();
	//in errors if close is pressed, hide alert
	$('.menu li, #closeTopAlert').click(function () {
		$("#helper").hide();
		if ($(window).width() > 739) {
			$(".sidebar").css("top", "50px");
			$(".main").css("margin-top", "0%");
		} else {
			$(".sidebar").css("top", "0px");
			$(".main").css("margin-top", "0%");
		}
	});
}, true);

/**
 * General actions when a page is loaded
 * @param interval the interval to refresh and load the data from server
 * anne@sevensols.com
 */
function startingActions(interval = updateInterval) {
	updateContent(false);
	//creates interval refresh
	id = setInterval(updateContent, interval);
	//call to save data
	$('#saveChanges').click(function () {
		writeInformation("save");
	});
}

/**
 * Draws info
 * @param async to determine if the ajax call is async
 * anne@sevensols.com
 */
function updateContent() {
	try {
		drawContent(); //draw expertmode
	} catch (err) {
		console.log(err);
	}
}

/**
 * Draw values in active tab
 * anne@sevensols.com
 */
function drawValues(data) {}

/**
 * Create value tables for dashboard
 * anne@sevensols.com
 */
function updateInfo(infoId) {

}


/**
 * Reload page after a few seconds
 * @param seconds to wait before refresh page
 * anne@sevensols.com
 */
function reloadPage(seconds = 180000) {
	setTimeout(function () {
		location.reload(1);
	}, seconds);
}

/**
 * @file errors.js
 *
 * @brief Contains the management of the errors and definitions
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

allMessages = {
	"GPA_JSON_ERR_JFILE": {
		"value": "JSON file not found. <br>",
		"bit": 30,
		"type": "DEV"
	},
	"GPA_JSON_ERR_JFORMAT": {
		"value": "Incorrect JSON format received. <br>",
		"bit": 29,
		"type": "DEV"
	},
	"GPA_JSON_ERR_JVERSION": {
		"value": "Incorrect JSON version. <br>",
		"bit": 28,
		"type": "DEV"
	},
	"GPA_JSON_ERR_CONFILE": {
		"value": "Incorrect configuration file. <br>",
		"bit": 27,
		"type": "DEV"
	}
}

//shows or hides the error messages in console
debugLevel = true;


/**
 * Checks bit error
 * @param errPostGpa Error from post gpa_json
 * @param atribute Name of the attribute to show
 * @return an array with the error strings
 * anne@sevensols.com
 */
function checkInfoErrors(data) {

}

/**
 * Prints label at the top of the page with the different log
 * @param objectWithMessage information to show
 * @param levelError warning, succes, info...
 * anne@sevensols.com
 */
function showMessages(objectWithMessage, levelError) {
	if (objectWithMessage) {
		if (objectWithMessage.type == "USER") {
			var helperId = "helper";
			var textErrorId = "contentMsg";

			$("#" + helperId).removeClass("bg-teal bg-warning bg-danger");
			if (levelError == "success") { //success
				$("#" + helperId).addClass("bg-teal");
			} else if (levelError == "warning") { //warning
				$("#" + helperId).addClass("bg-warning");
			} else { //error
				$("#" + helperId).addClass("bg-danger");
			}
			$("#" + textErrorId).css("color", "white");
			$("#" + textErrorId).html(objectWithMessage.value);
			$("#" + helperId).show();

			if ($(window).width() > 739) {
				$(".sidebar").css("top", "87px");
				$(".main").css("margin-top", "2%");
			} else {
				$(".sidebar").css("top", "36px");
				$(".main").css("margin-top", "6%");
			}
		} else if (debugLevel == true) {
			console.log(objectWithMessage);
		}
	}
}

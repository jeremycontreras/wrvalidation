/**
 * @file elements.js
 *
 * @brief Contains a class to create elements quicker
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2020
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

class Element {

	constructor(elementType, className, idName) {
		if (!arguments.length) {
			this.autoLoad = false;
		} else if (arguments.length == 1)
			this.element = document.createElement(elementType);
		else if (arguments.length == 2) {
			this.element = document.createElement(elementType);
			this.element.className = className;
		} else if (arguments.length == 3) {
			this.element = document.createElement(elementType);
			this.element.className = className;
			this.element.id = idName;
		}
	}

	get Element() {
		return this.element;
	}

	setValue(valueElement) {
		this.element.value = valueElement;
	}

	setInnerHtml(htmlCode) {
		this.element.innerHTML = htmlCode;
	}

	setText(textValue) {
		this.element.textContent = textValue;
	}

	setAttributeElement(property, value) {
		this.element.setAttribute(property, value);
	}

	appendChildElement(elementToAppend) {
		try {
			this.element.appendChild(elementToAppend.element);
		} catch (error) {
			console.log("Error trying to append child to " + elementToAppend);
		}
	}
	appendTo(parentElement) {
		try {
			parentElement.element.append(this.element);
		} catch (error) {
			console.log("Error trying to append child to " + parentElement);
		}
	}

}

/**
 * @file menu.js
 *
 * @brief Actions of the left menu
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

var maindiv = ".maingpa";
var pageTabs = ["dashboard", "management"]

$(function () {
	$(maindiv).load("html/dashboard.html");
	$("#foot").load("html/footer.html");
	$("#tab-title").text($.trim($(".active").text()));

	getProductName();

	for (var i = 0; i < pageTabs.length; i++) {
		createMenuAction(pageTabs[i]);
	}
});

/**
 * AJAX get product Name
 * anne@sevensols.com
 */
function getProductName() {
	$.ajax({
		type: "POST",
		url: "php/functions.php",
		data: {
			action: "product",
		},
		success: function (result) {
			if ($.trim(result).length > 0) {
				var deviceName = "Board";
				deviceName = result;
				$("#title-top").text(deviceName);
			} else {
				showMessages(allMessages["ERROR_PRODUCT_NAME"], "error");
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			showMessages(thrownError);
		}
	});
}

/**
 * Changes and loads new pages
 * @param pageIdentifier name of id and page to change
 * anne@sevensols.com
 */
function createMenuAction(pageIdentifier) {
	$("#" + pageIdentifier).click(function () {
		$(".containerLoad").show();
		setTimeout(function () {
			$(".containerLoad").hide();
		}, 3000);
		$(maindiv).load("html/" + pageIdentifier + ".html");
		pageInstance = this;
		changeActive();
	});
}

/**
 * Actions to follow when a new page is loaded
 * anne@sevensols.com
 */
function changeActive() {
	$(".active").removeClass("active")
	$(pageInstance).addClass("active");
	$("#content").html("");
	$("#tab-title").text($.trim($(".active").text()));
	$('html, body').animate({
		scrollTop: 0
	}, 'slow');
	$("#helper").hide();

	modify = false;
	clearInterval(id);
}

/**
 * @file gpajson.js
 *
 * @brief Contains set of function to parse gpa json file in a robust way
 *
 * @author Benoit Rat. (benoit@sevensols.com)
 * @ingroup wr-zynq-os
 * @date 2018
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of wr-zynq-os
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: wr-zynq-os.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

/**
 * Set robustly a specific parameter attribute (from prmObj)
 * @param prmObj        The gpajson object that represent the prm
 * @param attr          The key of the attribute
 * @param subattr(opt)  The key of the sub attribute
 * @return Return the attribute as text of an empty text in case of error.
 */
function gpaPrmSetAttr(prmObj, attr, subattr, value) {
	try {
		prmObj[attr][subattr] = value;
	}
	catch (err) {
		showMessages(prmObj + "-" + err);
		return "";
	}
}

/**
 * Get robustly a specific parameter attribute (from prmObj)
 * @param prmObj        The gpajson object that represent the prm
 * @param attr          The key of the attribute
 * @param subattr(opt)  The key of the sub attribute
 * @return Return the attribute as text of an empty text in case of error.
 */
function gpaPrmGetAttr(prmObj, attr, subattr = undefined) {
	var ret;
	try {
		if (subattr == undefined)
			ret = prmObj[attr];
		else
			ret = prmObj[attr][subattr];
		if (ret == undefined)
			return "";
	}
	catch (err) {
		showMessages(prmObj + "-" + err);
		return "";
	}
	return ret;
}


/**
 * Get robustly a specific parameter attribute (from listObj)
 * @param listObj       The gpajson object that represent the list
 * @param keyprm        The key of the parameter
 * @param attr          The key of the attribute
 * @param subattr(opt)  The key of the sub attribute
 * @return Return the attribute as text of an empty text in case of error.
 */
function gpaListPrmGetAttr(listObj, keyprm, attr, subattr = undefined) {
	try {
		return gpaPrmGetAttr(listObj[keyprm], attr, subattr);
	}
	catch (err) {
		showMessages(keyprm + "-" + err);
		return "";
	}
}


/**
 * Get robustly a list (from listObj)
 * @param modObj        The gpajson object that represent the list
 * @param keylist       The key of the list
 * @return Return the attributes of the list.
 * anne@sevensols.com
 */
function gpaGetListAttr(modObj, keylist, subattr = undefined) {
	try {
		return modObj[keylist];
	}
	catch (err) {
		showMessages(keylist + "-" + err);
		return "";
	}
}

/**
 * Get robustly a specific parameter attribute (from modObj)
 *
 *
 * @param modObj        The gpajson object that represent the list
 * @param keylist       The key of the list
 * @param keyprm        The key of the parameter
 * @param attr          The key of the attribute
 * @param subattr(opt)  The key of the sub attribute
 * @return Return the attribute as text of an empty text in case of error.
 */
function gpaModPrmGetAttr(modObj, keylist, keyprm, attr, subattr = undefined) {
	try {
		return gpaListPrmGetAttr(modObj.list[keylist], keyprm, attr, subattr);
	}
	catch (err) {
		showMessages(attr + "-" + err);
		return "";
	}
}

/**
 * Get robustly a specific parameter attribute (from modObj) and its enum dic relation
 *
 *
 * @param modObj        The gpajson object that represent the list
 * @param keylist       The key of the list
 * @param keyprm        The key of the parameter
 * @param attr          The key of the attribute
 * @param subattr(opt)  The key of the sub attribute
 * @return Return the attribute as text of an empty text in case of error.
 */
function gpaModPrmGetAttrEnum(modObj, attr, subattr = undefined) {
	try {
		var enum_dic = gpaPrmGetAttr(modObj, "enum_dic");
		if (!enum_dic[gpaPrmGetAttr(modObj, attr)])
			return gpaPrmGetAttr(modObj, attr)
		return enum_dic[gpaPrmGetAttr(modObj, attr)];
	}
	catch (err) {
		showMessages(attr + "-" + err);
		return "";
	}
}

/**
 * Check the access of a specific parameter
 * @param prmObj        The gpajson object that represent the prm
 * @param accFlagArray  An array of multiple possibility
 *   - "R"      : Check only if read access
 *   - ["W","L"]: Check if write or load access
 *   - "WL"     : Check if write and load access

 * @return True if we find the specific access, false otherwise
 */
function gpaPrmAccIs(prmObj, accFlagArray) {
	var accPrmFlags = gpaPrmGetAttr(prmObj, "access");
	if (accPrmFlags == "") return false;
	if (accFlagArray instanceof Array == false) {
		var accFlagText = accFlagArray;
		accFlagArray = [accFlagText]; //Create an array with a simple text
	}
	for (var i = 0; i < accFlagArray.length; i++) {
		if (accFlagArray[i].indexOf(accPrmFlags) != -1)
			return true;
	}
	return false;
}


/**
 * Return the value of the parameter in a formatted text representation
 *
 * @note: this function has been specifically designed to process
 * The enumaration value, handle the precision, etc...
 *
 * @param prmObj        The gpajson object that represent the prm
 * @return the text value of a parameter or an empty string in case of error.
 */
function gpaPrmTextVal(prmObj) {
	var str = "";
	if (strMatch(gpaPrmGetAttr(prmObj, "vtype"), "enu")) {
		var vprm = gpaPrmGetAttr(prmObj, "value");
		vprm = getIndexedInt(vprm);

		if (strMatch("multibit", gpaPrmGetAttr(prmObj, "hattr", "class"))) {
			for (var [vstr, vid] of Object.entries(gpaPrmGetAttr(prmObj, "enum_dic"))) {
				if (vprm == 0) return vstr;
				if (vid > 0 && (vprm & (1 << (vid-1)))) {
					if(str === "") str=vstr;
					else str += ", " + vstr;
				}
			}
			return str;
		}
		else {
			for (var [vstr, vid] of Object.entries(gpaPrmGetAttr(prmObj, "enum_dic"))) {
				if (vprm == vid) {
					return vstr;
				}
			}
		}
	}
	else {
		try {
			var ndecimal = parseInt(prmObj["hattr"]["decimal"]);
			if(!isNaN(ndecimal)) {
				str = parseFloat(gpaPrmGetAttr(prmObj, "value")).toFixed(ndecimal);
				return str;
			}
		}
		catch(err)
		{
			//Do nothing
		}
		str = gpaPrmGetAttr(prmObj, "value");
	}
	return str;
}



/* GPA replacement */
/**

var attrVals = { hattr: "col", mode: "combobox" };
*/
function gpaModPrmAttrOverwrite(modObj, keylists, keyprms, attrVals) {
	try {
		for (var [listKey, listObj] of Object.entries(modObj.list)) {
			//Check if the list we are is matching the keylists patterns
			if (keylists.indexOf(listKey) == -1) continue;
			for (var [prmKey, prmObj] of Object.entries(listObj)) {
				if (keyprms.indexOf(prmKey) == -1) continue;
				for (var [attrKey, newVal] of Object.entries(attrVals)) {
					prmObj[attrKey] = newVal; //Creating or overwriting value
				}
			}
		}
	}
	catch (err) {
		showMessages(keyprams + "-" + err);
		return "";
	}
}

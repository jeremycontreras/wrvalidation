/**
 * @file dashboard.js
 *
 * @brief Contains the actions to draw on the web the dashboard
 *
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) ${2017} Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting 
 * binary form under the terms of the LICENSE.txt provided within the 
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */


$(document).ready(function () {
	getDashboardInfo();
	startingActions();
});

/**
 * Draws info
 * anne@sevensols.com
 */
function drawContent() {
	showMessages("dashboard.js");
	getDashboardInfo();
}

function getDashboardInfo() {
	$.ajax({
		type: 'POST',
		async: false,
		url: '../php/functions.php',
		data: {
			action: "getdashboardinfo",
		},
		dataType: 'json',
		cache: false,
		success: function (result) {
			console.log(result);
			for (element in result) {
				$("#" + element).text(result[element]);
			};
			$(".containerLoad").fadeOut();
		},
		error: function (xhr) {
			showMessages(xhr.responseText);
			$(".containerLoad").fadeOut();
		}
	});
}

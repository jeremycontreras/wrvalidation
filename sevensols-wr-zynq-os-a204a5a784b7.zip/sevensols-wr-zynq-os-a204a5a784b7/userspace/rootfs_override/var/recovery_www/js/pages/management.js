/**
 * @file management.js
 *
 * @brief Contains the actions to draw on the web the misc module
 * with time zone and ntp server information
 * 
 * @author Anne M. (anne@sevensols.com)
 * @ingroup PHP GPA
 * @date 2017
 * @copyright Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of PHP GPA
 * You might use, distribute and modify this code and its resulting 
 * binary form under the terms of the LICENSE.txt provided within the 
 * module/project: PHP GPA.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

modify = false;
gpahald = null;

$(document).ready(function () {

	startingActions();
	//options for input-file
	inputFirmware();
	//buttons actions
	rebootDevice();
	restoreDevice();
	dumpLog();
	flashDevice();
	exportConfiguration();

	$(".containerLoad").fadeOut();
});

/**
 * Sets to Filer input allowing several files updates
 * anne@sevensols.com
 */
function inputFirmware() {
	$('#filer_input').filer({
		showThumbs: true,
		addMore: false,
		allowDuplicates: false
	});
}

/**
 * Draws info
 * anne@sevensols.com
 */
function drawContent() {
	showMessages("management.js");
}

/**
 * Actions for button Reboot
 * anne@sevensols.com
 */
function rebootDevice() {
	//restart-reboot
	$("#restart").click(function () {
		showMessages(allMessages["SUCC_REBOOT_NOW"], "success");
		$("#msgAlert").html("The device is rebooting... Page will be reloaded in 60 seconds");
		$('#alertreboot').show();
		$('#rebooting').load('../php/reboot.php');
		reloadPage();
	});

}

/**
 * Actions for button Restore
 * anne@sevensols.com
 */
function restoreDevice() {
	$("#factory").click(function () {
		$.ajax({
			type: 'POST',
			async: false,
			url: "../php/functions.php",
			data: {
				action: "factory",
			},
			success: function (result) {
				if (result == "success") {
					showMessages(allMessages["SUCC_CONF_DELETED"], "success");
					$("#msgAlert").html("Restoring device... Page will be reloaded in 60 seconds");
					$('#alertreboot').show();
					$('#rebooting').load('../php/reboot.php');
					reloadPage();
				} else {
					showMessages(allMessages["ERROR_CONF_DELETED"], "error");
					showMessages(result);
				}
			},
			error: function (result) {
				showMessages(xhr.responseText);
				showMessages(allMessages["ERROR_REBOOTING"], "error");
			}
		});
	});
}

/**
 * Actions for button Dump Log
 * anne@sevensols.com
 */
function dumpLog() {
	var initMessages = function () {
		$('#alertreboot').show();
		$("#msgAlert").html("Preparing log files to download. Please wait, this could take a while.");
	}

	$("#dumplog").click(function () {
		$("#msgAlert").html("Preparing log files to download. Please wait, this could take a while.");
		$('#alertreboot').show();
		$.ajax({
			type: "POST",
			beforeSend: initMessages(),
			url: "../php/functions.php",
			data: {
				action: "dumplog",
			},
			success: function (result) {
				if ($.trim(result).length > 0 && result != -1) {
					result = result.replace("/var/www", '');
					var element = document.createElement('a');
					element.setAttribute('type', "hidden"); // make it hidden if needed
					element.setAttribute('href', encodeURIComponent(result));
					element.setAttribute('download', result.replace("/downloads/", ''));
					element.dispatchEvent(new MouseEvent('click', {
						bubbles: true,
						cancelable: true,
						view: window
					}));
					$('#alertreboot').hide();
				} else if (result == -1) {
					$('#alertreboot').hide();
					showMessages(allMessages["ERROR_LOG"], "error");
				} else {
					$('#alertreboot').hide();
					showMessages(allMessages["ERROR_LOG"], "error");
				}
			},
			error: function (xhr, ajaxOptions, thrownError) {
				showMessages(thrownError);
			}
		});
	});
}


/**
 * Actions to follow when the user:
 * Uploads a new flashing file to the device
 * Chooses to flash the decive
 * Actions for buttons hard or soft flash
 * anne@sevensols.com
 */
function flashDevice() {
	$("#updateUpload").fileinput({
		'theme': "explorer",
		uploadUrl: "../php/update.php",
		uploadExtraData: function (previewId, index) {
			var info = {
				action: 'upload',
				fileType: "tar"
			};
			return info;
		},
		uploadAsync: false,
		maxFileCount: 1,
		overwriteInitial: false,
		initialPreviewAsData: true,
	});

	$('#updateUpload').on('filebatchuploadsuccess', function () {
		$("#flashDevice").click();
	});

	$("#flashDevice").click(function () {
		$.ajax({
			type: 'POST',
			async: false,
			url: '../php/update.php',
			data: {
				action: 'flash'
			},
			cache: false,
			success: function (result) {
				result = JSON.parse(result);
				if (result.error == "true") {
					$('#flashNotice').removeClass("bg-info");
					$('#flashNotice').addClass("bg-warning");

					if (result.msg.indexOf("Firmware") > -1) {
						$('#softFlashNotice').show();
					} else if (result.msg.indexOf("Hardware") > -1 || result.msg.indexOf("Device") > -1) {
						$('#forceFlashNotice').show();
					} else {
						$('#softFlashNotice').hide();
						$('#forceFlashNotice').hide();
					}
				} else if (result.error == "false") {
					$('#flashNotice').removeClass("bg-warning");
					$('#flashNotice').addClass("bg-info");
					$('#forceFlashNotice').hide();
					$('#softFlashNotice').hide();
					$("#spinner").show();
					reloadPage();
				} else {
					showMessages(allMessages["ERROR_WHILE_FLASHING"], "error");
				}

				$('#flashNotice').fadeIn("slow");
				$("#flashStat").html(result.msg);

				//There are no errors, so I reboot
				if (result.error == "false") {
					$('#rebooting').load('php/reboot.php');
				}
			},
			error: function (result) {
				showMessages(xhr.responseText);
				showMessages(allMessages["ERROR_WHILE_UPDATING"], "error");
			}
		});
	});

	$("#softForceFlash").click(function () {
		$.ajax({
			type: 'POST',
			async: false,
			url: '../php/update.php',
			data: {
				action: 'soft_force_flash'
			},
			cache: false,
			success: function (result) {
				result = JSON.parse(result);
				$("#flashStat").html(result.msg);
				$("#spinner").show();
				$("#softFlashNotice").hide();
				reloadPage();
				$('#rebooting').load('php/reboot.php');
			},
			error: function (result) {
				showMessages(xhr.responseText);
				showMessages(allMessages["ERROR_WHILE_UPDATING"], "error");
			}
		});
	});

	$("#nosoftForceFlash").click(function () {
		$("#softFlashNotice").hide();
		$("#flashNotice").hide();
	});

	$("#hardForceFlash").click(function () {
		$.ajax({
			type: 'POST',
			async: false,
			url: '../php/update.php',
			data: {
				action: 'hard_force_flash'
			},
			cache: false,
			success: function (result) {
				if (confirm("Im sure I want to Flash")) {
					$("#flashStat").html(result.msg);
					$("#spinner").show();
					$("#forceFlashNotice").hide();
					reloadPage();
					$('#rebooting').load('php/reboot.php');
				} else {
					$("#softForceFlash").hide();
					$("#flashNotice").hide();
				}
			},
			error: function (result) {
				showMessages(xhr.responseText);
				showMessages(allMessages["ERROR_WHILE_UPDATING"], "error");
			}
		});
	});

	$("#nohardForceFlash").click(function () {
		$("#forceForceFlash").hide();
		$("#flashNotice").hide();
	});
}

/**
 * Actions to follow when the user uploads a new config file to the device and applies the changes
 * anne@sevensols.com
 */
function exportConfiguration() {
	$("#exportConfig").click(function () {
		$.ajax({
			type: 'POST',
			async: false,
			url: '../php/functions.php',
			data: {
				action: 'exportConfig'
			},
			cache: false,
			success: function (result) {
				if ($.trim(result).length > 0 && result.indexOf("wrz_config") != -1) {
					result = result.replace("/var/www", '');
					var element = document.createElement('a');
					element.setAttribute('type', "hidden"); // make it hidden if needed
					element.setAttribute('href', encodeURIComponent(result));
					element.setAttribute('download', result.replace("/downloads/", ''));
					element.dispatchEvent(new MouseEvent('click', {
						bubbles: true,
						cancelable: true,
						view: window
					}));
				} else {
					allMessages["ERROR_CONF_EXPORT"].value += result;
					showMessages(result, "error");
				}
			},
			error: function (result) {
				showMessages(result.responseText);
				showMessages(allMessages["ERROR_CONF_EXPORT"], "error");
			}
		});
	});
}

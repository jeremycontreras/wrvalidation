# README #

**author** Anne M. (anne@sevensols.com)
**ingroup** PHP GPA
**date** 2017
**copyright** Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)

This project is part of PHP GPA
You might use, distribute and modify this code and its resulting 
binary form under the terms of the LICENSE.txt provided within the 
module/project: PHP GPA.
 
If you do not have received a copy of the LICENSE.txt along with
this file please write to info@sevensols.com and consider that
this file can not be copied and/or distributed in any forms.


This code is property of Seven Solutions, before distribution, copy or modify, write to info@sevensols.com

Folder where RAD and downloads are saved

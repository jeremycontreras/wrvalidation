#!/bin/sh

# get7sinfo.sh
#
# Retrieves 7S custom metrics and pushes them to collectd using collectdctl.
# NOTE: collectdctl requires the unixsock plugin in collectd.

# Default step time is 30 seconds, unless specified as a command line parameter.
step=${1:-30}

host=$(hostname)

while true; do
	# /proc/meminfo monitoring
	meminfo_list="available sunreclaim unevictable"
	for item in $meminfo_list; do
		collectdctl putval $host/wr7s/mem_$item \
			N:`cat /proc/meminfo | grep -i "$item" | awk '{print $2}'`
	done

	# Zynq temperature
	raw=`cat /sys/devices/soc0/amba/f8007100.adc/iio\:device0/in_temp0_raw`
	offset=`cat /sys/devices/soc0/amba/f8007100.adc/iio\:device0/in_temp0_offset`
	scale=`cat /sys/devices/soc0/amba/f8007100.adc/iio\:device0/in_temp0_scale`
	collectdctl putval $host/wr7s/temperature \
		N:`echo "scale=2; ($raw + $offset) * $scale / 1000" | bc`

	# Available size in rootfs (only ram)
	collectdctl putval $host/wr7s/rootfs_free \
		N:`du -xc / | tail -1 | awk '{print $1}'`

	# servo/rtt
	collectdctl putval $host/wr7s/servo_rtt \
		N:`gpa_ctrl ppsi act/servo/mean_delay 2> /dev/null | sed 's/ *//'`

	sleep $step
done

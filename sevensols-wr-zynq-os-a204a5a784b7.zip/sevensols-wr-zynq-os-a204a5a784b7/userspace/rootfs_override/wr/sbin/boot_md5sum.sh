#!/bin/sh

# boot_md5sum.sh
#
# Reads the Xilinx Zynq BOOT.BIN file (passed as a parameter), extracts the
# component files from it and calculates their md5 hash.
# The file info is extracted from the BOOT.BIN header using bootinfo.
#
# If run without parameters, it dumps the binary file from the QSPI flash.


OUTDIR=/tmp/
FSBL_OUT=${OUTDIR}FSBL.bin
BIT_OUT=${OUTDIR}golden.bit
UBOOT_OUT=${OUTDIR}u-boot.bin


if [ -z "$1" ] ; then
	BOOT_BIN=${OUTDIR}boot.bin
	cat /dev/mtd0 > $BOOT_BIN
else
	BOOT_BIN=$1
fi


# Get file info from the binary image. See <bootinfo> code for details.
#
# NOTE: The files packed into the binary can have arbitrary names, but we need a
# certain pattern to match each one. Here we're assuming that the name of the
# FSBL file will contain "FSBL", the bitstream one will contain "bit" and the
# u-boot one will contain "boot".

INFO=`bootinfo $BOOT_BIN`

FSBL_NAME=`echo "$INFO" | grep FSBL | awk '{print $1}'`
FSBL_OFFSET=`echo "$INFO" | grep FSBL | awk '{print $3}'`
FSBL_SIZE=`echo "$INFO" | grep FSBL | awk '{print $4}'`

BIT_NAME=`echo "$INFO" | grep bit | awk '{print $1}'`
BIT_OFFSET=`echo "$INFO" | grep bit | awk '{print $3}'`
BIT_SIZE=`echo "$INFO" | grep bit | awk '{print $4}'`

UBOOT_NAME=`echo "$INFO" | grep boot | awk '{print $1}'`
UBOOT_OFFSET=`echo "$INFO" | grep boot | awk '{print $3}'`
UBOOT_SIZE=`echo "$INFO" | grep boot | awk '{print $4}'`



# Calculate FSBL md5sum
dd skip=$FSBL_OFFSET count=$FSBL_SIZE if=$BOOT_BIN of=$FSBL_OUT bs=1 >/dev/null 2>&1
md5sum $FSBL_OUT | sed "s|${OUTDIR}||"
rm $FSBL_OUT

# Calculate bitstream md5sum
dd skip=$BIT_OFFSET count=$BIT_SIZE if=$BOOT_BIN of=$BIT_OUT bs=1 >/dev/null 2>&1
md5sum $BIT_OUT | sed "s|${OUTDIR}||"
rm $BIT_OUT

# Calculate u-boot md5sum
dd skip=$UBOOT_OFFSET count=$UBOOT_SIZE if=$BOOT_BIN of=$UBOOT_OUT bs=1 >/dev/null 2>&1
md5sum $UBOOT_OUT | sed "s|${OUTDIR}||"
rm $UBOOT_OUT


if [ -z "$1" ] ; then
	rm $BOOT_BIN
fi

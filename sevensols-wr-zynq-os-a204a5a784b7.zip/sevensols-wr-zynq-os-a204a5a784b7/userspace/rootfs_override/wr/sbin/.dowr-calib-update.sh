#!/bin/sh

###########
# Calibration for DOWR
#
#Gateware info:
# GW ID      : 0x751e72d0
# GW VERSION : 3.0.86
# GW DATE    : 18/07/18 13:24

vuartx()
{
        /wr/bin/zen-vuart -c "$@"
}

echo "Previous calibration"
vuartx "sfp show"

echo ""
echo "Setting new calibration"
vuartx "sfp erase"
vuartx "sfp add AXGE-1254-0531 wr0 218309 206091 67216940"
vuartx "sfp add AXGE-3454-0531 wr0 218294 206108 -68210600"
vuartx "sfp add AXGE-1254-0531 wr1 218293 206071 67651666"
vuartx "sfp add AXGE-3454-0531 wr1 218379 206055 -67962185"
vuartx "sfp show"

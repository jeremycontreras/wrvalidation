#ifndef __COMMONDEFS_H__
#define __COMMONDEFS_H__

/*
 * commondefs.h
 *
 * Application-wide definitions.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Sep 5, 2019
 * Last updated: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

/* Maximum length for generic strings */
#define MAX_STR_LEN 100

/* Maximum number of ports */
#define MAX_PORTS 100

/* Maximum number of presets */
#define MAX_PRESETS 100

/* Timeouts */
#define TMO_GM_LOCK                     300
#define TMO_FR_EXPIRED                  10
#define NTP_SYNC_SECS_BETWEEN_RETRIES   5

#define NS_PER_SLEEP 500000000
#define N_SLEEPS_IN_ONE_SEC (1000000000 / NS_PER_SLEEP)
#define SECS_TO_RETRIES(x) (x * N_SLEEPS_IN_ONE_SEC)

#endif

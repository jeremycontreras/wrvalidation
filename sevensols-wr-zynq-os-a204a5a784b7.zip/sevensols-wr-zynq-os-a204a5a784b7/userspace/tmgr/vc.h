#ifndef __VC_H__
#define __VC_H__

/**
 * @file vc.c
 *
 * @brief Virtual Clock API
 *
 * @author Ricardo Canuelo (email: ricardo<DOT>canuelo<AT>sevensols<DOT>com)
 * @author Miguel Jimenez Lopez (email: miguel<DOT>jimenez<AT>sevensols<DOT>com)
 * @ingroup tmgr
 * @date Oct 11 2019
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of tmgr
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: tmgr.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

int vc_start(void);
int vc_run(void);
int vc_exit(void);

#endif

/*
 * clk_source.c
 *
 * Standalone fake clock source for testing purposes.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Jun 13, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

/*
 * Parameters:
 *
 * test_params/status
 *   - NOK: clock source is not working or disabled.
 *   - INITIALIZING: clock source is working but not ready yet.
 *   - OK: clock source is ready to be used.
 *
 * test_config/run
 *   boolean. A user can set it to start the test. When it's off it means the
 *   test is not running.
 *
 * test_config/init_time
 *   int. The number of seconds the clk source will stay in the INITIALIZING
 *   state.
 *
 * test_config/fail
 *   boolean. When set, it makes the test set the status to ERROR.
 */

#define DEFAULT_INIT_TIME 5

/* Struct to match an enum identifier with a string */
struct enum_str_match {
	int id;
	char *str;
};


/* Modirs */
static struct gpa_rsrc_assoc rassoc[] = {
	{.oid = 1, .mp = "./test_params",
	 .opt = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS, .xval = 1},
	{.oid = 2, .mp = "./test_config",
	 .opt = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS, .xval = 3},
};


/* Module parameters */
enum {
	PARAM_STATUS,
	PARAM_RUN,
	PARAM_INIT_TIME,
	PARAM_FAIL,
	N_PARAMS
};

/* State definition for the <status> parameter */
enum {
	STATUS_OFF,
	STATUS_INITIALIZING,
	STATUS_ERROR,
	STATUS_OK,
	N_STATUS_ENTRIES
};

/* Parameter array */
static struct gpa_prm *params[N_PARAMS];

/* id to string table for the <status> parameter  */
static struct enum_str_match status_def[N_STATUS_ENTRIES] = {
	{.id = STATUS_OFF,              .str = "OFF"},
        {.id = STATUS_INITIALIZING,     .str = "INITIALIZING"},
        {.id = STATUS_ERROR,            .str = "ERROR"},
        {.id = STATUS_OK,               .str = "OK"}
};

/* Module owner */
struct gpa_mod *clk_mod;



/*
 * run_test
 *
 * Starts the test sequence on the fake clock source.
 *
 * - Set status to INITIALIZING state
 * - Wait params[PARAM_INIT_TIME] seconds
 * - Set status to OK or ERROR state, depending on the contents of the <fail>
 *   parameter
 * - Restore params[PARAM_RUN] to OFF
 */
void run_test(void)
{
	struct timespec ts;

	ts.tv_sec = gpa_prm_get_u16(params[PARAM_INIT_TIME]);
	ts.tv_nsec = 0;

	/* Start of test */
	gpa_mod_prm_snd_u16(clk_mod, params[PARAM_STATUS], STATUS_INITIALIZING);
	nanosleep(&ts, 0);
	if (gpa_prm_get_u16(params[PARAM_FAIL]))
		gpa_mod_prm_snd_u16(clk_mod, params[PARAM_STATUS], STATUS_ERROR);
	else
	gpa_mod_prm_snd_u16(clk_mod, params[PARAM_STATUS], STATUS_OK);

	/* End of test */
	gpa_mod_prm_snd_u16(clk_mod, params[PARAM_RUN], 0);
}

int main(void)
{
	int i;

	/* Owner creation */
	clk_mod = gpa_mod_create_owner(gpa_mod_user1, "test_clocksource",
			GPA_MOD_FLAG_MB_WRITE, GPA_ARRAY_SIZE(rassoc));
	gpa_mod_add_rsrcs_assoc(clk_mod, 0, rassoc, GPA_ARRAY_SIZE(rassoc));

	/* Parameter creation */

	/* test_params/status */
	params[PARAM_STATUS] = gpa_prm_create_enum(0, 0, "status",
		GPA_PRM_VTX_ENUM, GPA_ACC_RW | GPA_ACC_INTERNAL, 0, 4,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, 0);
	for (i = 0; i < N_STATUS_ENTRIES; i++) {
		gpa_prm_enum_add_entry(params[PARAM_STATUS], status_def[i].id,
			status_def[i].str);
	}
	gpa_modir_path_addprm(clk_mod, "test_params", params[PARAM_STATUS]);

	/* test_config/run */
	params[PARAM_RUN] = gpa_prm_create_bool(0, 0, "run",
		GPA_ACC_RW | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_ON_OFF | GPA_PRM_ENUM_OPT_SEND_FROMSTR_FORCEVAL,
		0);
	gpa_modir_path_addprm(clk_mod, "test_config", params[PARAM_RUN]);

	/* test_config/init_time */
	params[PARAM_INIT_TIME] = gpa_prm_create_val(0, 1, "init_time",
		GPA_PRM_VTX_U16, GPA_ACC_RW | GPA_ACC_INTERNAL,
		{.u16 = DEFAULT_INIT_TIME});
	gpa_modir_path_addprm(clk_mod, "test_config", params[PARAM_INIT_TIME]);

	/* test_config/fail */
	params[PARAM_FAIL] = gpa_prm_create_bool(0, 2, "fail",
		GPA_ACC_RW | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_ON_OFF | GPA_PRM_ENUM_OPT_SEND_FROMSTR_FORCEVAL,
		0);
	gpa_modir_path_addprm(clk_mod, "test_config", params[PARAM_FAIL]);

	/* Event loop */
	while (1) {
		gpa_mod_handle_mb(clk_mod);
		if (gpa_prm_get_u16(params[PARAM_RUN])) {
			run_test();
		}
	}
	return 0;
}

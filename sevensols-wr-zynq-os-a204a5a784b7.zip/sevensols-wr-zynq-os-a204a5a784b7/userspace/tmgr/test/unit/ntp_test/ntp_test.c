#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "ntp.h"
#include "gpa_interface.h"

/*
 * ntp test
 *
 * Tests for the the ntp module API.
 */


/*
 * Initialize the ntp module. Test passes if the module can be initialized.
 */
int test0(void) {
	if (ntp_init(NTP_BUSYBOX)) {
		printf("Error initializing NTP module (BUSYBOX)\n");
		return 1;
	}

	/* Call ntp_init again. It should return 1 */
	if (!ntp_init(NTP_BUSYBOX)) {
		printf("Error re-initializing NTP module (BUSYBOX)\n");
		return 1;
	}

	return 0;
}

/*
 * Call ntp_get_offset with a null parameter. It should always fail.
 */
int test1(void)
{
	ntp_init(NTP_BUSYBOX);

	if (!ntp_server0_get_offset(0)) {
		printf("Error: ntp_get_offset(0) should have failed\n");
		return 1;
	}

	return 0;
}

/*
 * Get the offset from the configured NTP server. It should pass if the offset
 * could be correctly retrieved.
 *
 * In case of success it adds a 5 second delay after the query to try to honor
 * the server's limit restriction.
 */
int test2(void)
{
	float offset = 0.0f;

	ntp_init(NTP_BUSYBOX);

	if (ntp_server0_get_offset(&offset)) {
		printf("Error: ntp_get_offset\n");
		return 1;
	}
	if (offset == 0.0f) {
		printf("Error: offset read was 0\n");
		return 1;
	}
	sleep(5);
	printf("offset: %f\n", offset);

	return 0;
}

/*
 * Synchronize the system time to the NTP server. It should pass if the time
 * could be retrieved and set.
 *
 * In case of success it adds a 5 second delay after the query to try to honor
 * the server's limit restriction.
 */
int test3(void)
{
	ntp_init(NTP_BUSYBOX);

	if (ntp_server0_synchronize()) {
		printf("Error: ntp_synchronize\n");
		return 1;
	}

	sleep(5);
	return 0;
}


int (*test_array[])(void) = {
	test0,
	test1,
	test2,
	test3,
};


int main(int argc, char **argv)
{
	int test = 0;
	int all = 0;

	if (argc < 3) {
		printf("Usage:\n"
			"ntp_test <server> <test_id>\n"
			"To run all the tests use 'ntp_test all'\n\n");
		return 1;
	}

	/* Create tmgr gpa interface */
	if (!tmgr_create_mod_owner(1, 0, 0, 0, 0)) {
		printf("Error creating the tmgr libgpa interface. "
			"Maybe tmgrd is running?\n");
		return 1;
	}

	/* Set ntp server in the appropriate config parameter */
	if (set_ntp_server0_config_ip(argv[1])) {
		printf("Error: set_ntp_config_server\n");
		return 1;
	}

	if (strcmp(argv[2], "all") == 0) {
		all = 1;
	} else {
		test = strtol(argv[2], 0, 0);
	}

	if (all) {
		/* Run all the tests defined in test_array */
		int i;

		for (i = 0; i < sizeof(test_array) / sizeof(test_array[0]); i++) {
			if (test_array[i]()) {
				printf("Test %d FAILED\n", i);
				return 1;
			} else {
				printf("Test %d OK\n", i);
			}
		}
	} else {
		/* Run the selected test only */
		if (test >= sizeof(test_array) / sizeof(test_array[0])
			|| test < 0) {
			printf("Wrong test number\n");
			return 1;
		}
		if (test_array[test]()) {
			printf("Test %d FAILED\n", test);
			return 1;
		} else {
			printf("Test %d OK\n", test);
		}
	}

	return 0;
}

/*
 * ktmgr_test.c
 *
 * Unit test for the ktmgr module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 6, 2019
 * Last modified: Jun 13, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ktmgr.h"

/*
 * ktmgr test
 *
 * Tests the API of the ktmgr module.
 */

/*
 * Call ktmgr_get_attr and ktmgr_set_attr before initializing the module. Both
 * calls should fail.
 */
int test0(void) {
	long val = 0;

	if (!ktmgr_get_attr(0, &val) || !ktmgr_set_attr(0, val))
		return 1;

	return 0;
}


/*
 * Call ktmgr_init. It should fail if the ktmgr module is not loaded.
 */
int test1(void) {
	if (ktmgr_init()) {
		printf("Error initializing the ktmgr module\n");
		return 1;
	}
	return 0;
}


/*
 * Get the values of every attribute with ktmgr_get_attr. It should fail if the
 * ktmgr module is not loaded.
 */
int test2(void)
{
	int i;
	long val = 0;

	if (ktmgr_init()) {
		printf("Error initializing the ktmgr module\n");
		return 1;
	}

	for (i = 0; i < N_KTMGR_ATTRS; i++) {
		if (!ktmgr_get_attr(i, &val)) {
			printf("attr: %d, val: %ld\n", i, val);
		} else {
			printf("error: ktmgr_get_ktmgr_attr\n");
			return 1;
		}
	}

	return 0;
}


/*
 * Get a value from an undefined attribute id. It should fail.
 */
int test3(void)
{
	long val = 0;

	if (ktmgr_init()) {
		printf("Error initializing the ktmgr module\n");
		return 1;
	}

	if (!ktmgr_get_attr(-1, &val))
		return 1;
	if (!ktmgr_get_attr(N_KTMGR_ATTRS, &val))
		return 1;

	return 0;
}


/*
 * Set an incorrect value in an attribute with ktmgr_set_attr. It should fail.
 */
int test4(void)
{
	if (ktmgr_init()) {
		printf("Error initializing the ktmgr module\n");
		return 1;
	}

	if (!ktmgr_set_attr(KTMGR_CLK_CLASS, 256)) {
		return 1;
	}

	return 0;
}


/*
 * Set a value in an undefined attribute id. It should fail.
 */
int test5(void)
{
	if (ktmgr_init()) {
		printf("Error initializing the ktmgr module\n");
		return 1;
	}

	if (!ktmgr_set_attr(-1, 0)) {
		return 1;
	}
	if (!ktmgr_set_attr(N_KTMGR_ATTRS, 0))
		return 1;

	return 0;
}


int (*test_array[])(void) = {
	test0,
	test1,
	test2,
	test3,
	test4,
	test5,
};


int main(int argc, char **argv)
{
	int test = 0;
	int all = 0;

	if (argc < 2) {
		printf("Usage:\n"
			"ktmgr_test <test_id>\n"
			"To run all the tests use 'ktmgr_test all'\n\n");
		return 1;
	}

	if (strcmp(argv[1], "all") == 0) {
		all = 1;
	} else {
		test = strtol(argv[1], 0, 0);
	}

	if (all) {
		/* Run all the tests defined in test_array */
		int i;

		for (i = 0; i < sizeof(test_array) / sizeof(test_array[0]); i++) {
			if (test_array[i]()) {
				printf("Test %d FAILED\n", i);
				return 1;
			} else {
				printf("Test %d OK\n", i);
			}
		}
	} else {
		/* Run the selected test only */
		if (test >= sizeof(test_array) / sizeof(test_array[0])
			|| test < 0) {
			printf("Wrong test number\n");
			return 1;
		}
		if (test_array[test]()) {
			printf("Test %d FAILED\n", test);
			return 1;
		} else {
			printf("Test %d OK\n", test);
		}
	}

	return 0;
}

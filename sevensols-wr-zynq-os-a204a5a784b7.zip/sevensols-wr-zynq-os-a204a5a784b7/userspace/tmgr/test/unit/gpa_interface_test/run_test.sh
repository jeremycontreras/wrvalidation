#!/bin/sh

# gpa_interface_test.sh
#
# Launcher for the Time Manager gpa interface unit test
#
#
# Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
# copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
#
# Created: Jul 5, 2019
#
# This file is part of wr-zynq-os.
# You may use, distribute and modify this code under the
# terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
# If you haven't received a copy of LICENSE.txt along with
# this file please write to info@sevensols.com.

./gpa_interface_test 0 || exit 1
./gpa_interface_test 1 || exit 1
./gpa_interface_test 2 || exit 1
./gpa_interface_test 3 || exit 1
./gpa_interface_test 4 || exit 1
./gpa_interface_test 5 || exit 1
./gpa_interface_test 6 || exit 1

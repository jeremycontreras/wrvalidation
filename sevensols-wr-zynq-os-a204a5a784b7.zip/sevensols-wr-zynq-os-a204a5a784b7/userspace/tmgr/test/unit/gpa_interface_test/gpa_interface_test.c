/*
 * gpa_interface_test.c
 *
 * Unit test for the Time Manager gpa interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 10, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

#include "gpa_interface.h"

/*
 * gpa_interface test
 *
 * Tests the API of the libgpa parameter interface.
 */


/*
 * Create the tmgr gpa interface. Test passes if the interface can be created.
 */
int test0(void)
{
	if (!tmgr_create_mod_owner(0, 0, 0, 0, 0)) {
		printf("Error creating the tmgr libgpa interface\n");
		return 1;
	}

	return 0;
}

/*
 * Create the tmgr gpa interface in test mode. Test passes if the interface can
 * be created.
 */
int test1(void)
{
	if (!tmgr_create_mod_owner(1, 0, 0, 0, 0)) {
		printf("Error creating the tmgr libgpa interface\n");
		return 1;
	}

	return 0;
}


/*
 * Faulty call to a getter. Test passes if the call fails.
 */
int test2(void)
{
	/* Initialize the gpa interface first */
	test0();

	if (get_tmgr_info_uptime(0))
		return 0;

	return 1;
}

/*
 * Regular call to a getter. Test passes if the call works and the value is
 * correctly retrieved.
 */
int test3(void)
{
	enum vc_status status = 0;

	/* Initialize the gpa interface first */
	test0();

	if (get_vc_info_status(&status)) {
		printf("Error: get_vc_info_status\n");
		return 1;
	}
	if (status != VC_STATUS_DISABLED) {
		printf("Error: Got an unexpected VC status: %d (expected %d)\n",
			status, VC_STATUS_DISABLED);
		return 1;
	}

	return 0;
}

/*
 * Try to get a nonexistent parameter. Test passes if the getter function fails.
 */
int test4(void)
{
	int start = 0;

	/* Initialize the gpa interface first */
	test0();

	if (get_test_start(&start))
		return 0;

	return 1;
}

/*
 * Test getters and setters.
 */
int test5(void)
{
	const char *str;
	enum vc_status status;
	enum port_proto proto;
	enum port_mode mode;
	uint8_t num8;
	int num;

	/* Initialize the gpa interface first (including test mode) */
	test1();

	/* VC datetime */
	if (set_vc_info_datetime("1234")) {
		printf("Error: set_vc_info_datetime\n");
		return 1;
	}
	if (get_vc_info_datetime(&str)) {
		printf("Error: get_vc_info_datetime\n");
		return 1;
	}
	if (strcmp(str, "1234")) {
		printf("Error: Incorrect VC datetime: %s (expected '1234')\n",
			str);
		return 1;
	}

	/* VC status */
	if (set_vc_info_status(VC_STATUS_OK)) {
		printf("Error: set_vc_info_status\n");
		return 1;
	}
	if (get_vc_info_status(&status)) {
		printf("Error: get_vc_info_status\n");
		return 1;
	}
	if (status != VC_STATUS_OK) {
		printf("Error: Incorrect VC status: %d (expected %d)\n",
			status, VC_STATUS_OK);
		return 1;
	}

	/* VC activeref */
	if (set_vc_info_activeref("WR0")) {
		printf("Error: set_vc_info_activeref\n");
		return 1;
	}
	if (get_vc_info_activeref(&str)) {
		printf("Error: get_vc_info_activeref\n");
		return 1;
	}
	if (strcmp(str, "WR0")) {
		printf("Error: Incorrect VC activeref: %s (expected 'WR0')\n",
			str);
		return 1;
	}

	/* VC clock class */
	num8 = 0;
	if (set_vc_info_clock_class(1)) {
		printf("Error: set_vc_info_clock_class\n");
		return 1;
	}
	if (get_vc_info_clock_class(&num8)) {
		printf("Error: get_vc_info_clock_class\n");
		return 1;
	}
	if (num8 != 1) {
		printf("Error: Incorrect VC clock class: %d (expected %d)\n",
			num8, 1);
		return 1;
	}

	/* VC clock accuracy */
	num8 = 0;
	if (set_vc_info_clock_accuracy(3)) {
		printf("Error: set_vc_info_clock_accuracy\n");
		return 1;
	}
	if (get_vc_info_clock_accuracy(&num8)) {
		printf("Error: get_vc_info_clock_accuracy\n");
		return 1;
	}
	if (num8 != 3) {
		printf("Error: Incorrect VC clock accuracy: %d (expected %d)\n",
			num8, 3);
		return 1;
	}

	/* VC priority1 */
	num8 = 0;
	if (set_vc_info_priority1(1)) {
		printf("Error: set_vc_info_priority1\n");
		return 1;
	}
	if (get_vc_info_priority1(&num8)) {
		printf("Error: get_vc_info_priority1\n");
		return 1;
	}
	if (num8 != 1) {
		printf("Error: Incorrect VC priority1: %d (expected %d)\n",
			num8, 1);
		return 1;
	}

	/* VC priority2 */
	num8 = 0;
	if (set_vc_info_priority2(2)) {
		printf("Error: set_vc_info_priority2\n");
		return 1;
	}
	if (get_vc_info_priority2(&num8)) {
		printf("Error: get_vc_info_priority2\n");
		return 1;
	}
	if (num8 != 2) {
		printf("Error: Incorrect VC priority2: %d (expected %d)\n",
			num8, 2);
		return 1;
	}

	/* Port name */
	if (!get_port_name(10000, &str)) {
		printf("Error: get_port_name should fail for port 10000\n");
		return 1;
	}
	if (get_port_name(0, &str)) {
		printf("Error: get_port_name failed for port 0\n");
		return 1;
	}

	/* Port protocol */
	if (set_port_proto(0, PORT_PROTO_WR)) {
		printf("Error: set_port_proto\n");
		return 1;
	}
	if (get_port_proto(0, &proto)) {
		printf("Error: get_port_proto\n");
		return 1;
	}
	if (proto != PORT_PROTO_WR) {
		printf("Error: Incorrect port protocol: %d (expected %d)\n",
			proto, PORT_PROTO_WR);
		return 1;
	}

	/* Port mode */
	if (set_port_mode(0, PORT_MODE_SLAVE)) {
		printf("Error: set_port_mode\n");
		return 1;
	}
	if (get_port_mode(0, &mode)) {
		printf("Error: get_port_mode\n");
		return 1;
	}
	if (mode != PORT_MODE_SLAVE) {
		printf("Error: Incorrect port mode: %d (expected %d)\n",
			mode, PORT_MODE_SLAVE);
		return 1;
	}

	/* Config update */
	num = 0;
	if (set_tmgr_config_update(1)) {
		printf("Error: set_tmgr_config_update\n");
		return 1;
	}
	if (get_tmgr_config_update(&num)) {
		printf("Error: get_tmgr_config_update\n");
		return 1;
	}
	if (num != 1) {
		printf("Error: Incorrect Config update: %d (expected %d)\n",
			num, 1);
		return 1;
	}

	/* Config ntp srever */
	if (set_ntp_server0_config_ip("5678")) {
		printf("Error: set_ntp_server_config_ip\n");
		return 1;
	}
	if (get_ntp_server0_config_ip(&str)) {
		printf("Error: get_ntp_server_config_ip\n");
		return 1;
	}
	if (strcmp(str, "5678")) {
		printf("Error: Incorrect Config ntp server: %s "
			"(expected '5678')\n", str);
		return 1;
	}

	/* Test start */
	num = 0;
	if (set_test_start(1)) {
		printf("Error: get_so_config_enable\n");
		return 1;
	}
	if (get_test_start(&num)) {
		printf("Error: set_test_start\n");
		return 1;
	}
	if (num != 1) {
		printf("Error: Incorrect Test start: %d (expected %d)\n",
			num, 1);
		return 1;
	}

	return 0;
}


/* Auxiliary functions for test6 */

static void handler_loop_tasks(void)
{
	int update = 0;
	int ret;

	/* Read and apply configuration */
	ret = get_tmgr_config_update(&update);
	if (!ret && update) {
		load_config();
	}
}

void *loop(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = 50000000};

	tmgr_handler_loop(handler_loop_tasks, &ts);

	/* Never reached */
	return 0;
}


/*
 * Test a cached getter.
 *
 * Create the tmgr owner and run the tmgr handler loop in a separate
 * thread. Then, modify one of the cached parameters externally (using gpa_ctrl)
 * and check that the Time Manager will still see the old value until the
 * update_config flag is set.
 */
int test6(void)
{
	pthread_t thread;
	void *ret;
	long int num;
	char *val;
	char *aux;
	char str[100] = {0};
	char cmd[100] = {0};

	srandom(time(0));
	num = random();

	/* Initialize the gpa interface first (including test mode) */
	test1();

	pthread_create(&thread, 0, loop, 0);

	/* Read and save the initial value */
	get_ntp_server0_config_ip((const char **)&val);
	aux = strdup(val);

	/* Update the value externally */
	snprintf(cmd, sizeof(cmd), "gpa_ctrl tmgr config/ntp_server %ld", num);
	system(cmd);

	/* Read the value back. It shouldn't have changed yet */
	get_ntp_server0_config_ip((const char **)&val);
	if (strcmp(val, aux)) {
		printf("Cache bypass error\n");
		return 1;
	}
	free(aux);

	/* Set the update_config flag externally */
	system("gpa_ctrl tmgr config/update_config on");

	/* Read the value back. NOW we should see the value has changed */
	snprintf(str, sizeof(str), "%ld", num);

	get_ntp_server0_config_ip((const char **)&val);
	if (strcmp(val, str)) {
		printf("Error updating cached value\n");
		return 1;
	}

	tmgr_handler_stop();
	pthread_join(thread, &ret);

	return 0;

}


int (*test_array[])(void) = {
	test0,
	test1,
	test2,
	test3,
	test4,
	test5,
	test6,
};


int main(int argc, char **argv)
{
	int test = 0;
	char *start;
	char *end;

	if (argc < 2) {
		printf("Usage:\n"
			"gpa_interface_test <test_id>\n\n");
		return 1;
	}

	start = argv[1];
	end = 0;
	test = strtol(start, &end, 0);

	/* Run the selected test */
	if ((test == 0 && start == end)
		|| test < 0
		|| test >= sizeof(test_array) / sizeof(test_array[0])) {
		printf("Wrong test number\n");
		return 1;
	}
	if (test_array[test]()) {
		printf("Test %d FAILED\n", test);
		return 1;
	} else {
		printf("Test %d OK\n", test);
	}

	return 0;
}

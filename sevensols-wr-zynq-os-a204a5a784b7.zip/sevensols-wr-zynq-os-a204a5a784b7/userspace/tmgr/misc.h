#ifndef __MISC_H__
#define __MISC_H__

/*
 * misc.h
 *
 * Miscellaneous / unclassified functions for Time Manager.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Oct 11, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

/* Enable GM info refresher */
void enable_gm_refresh(int);

/*
 * Updates the info parameters of all the modules except for the Virtual Clock.
 */
void update_modules_info(void);

#endif

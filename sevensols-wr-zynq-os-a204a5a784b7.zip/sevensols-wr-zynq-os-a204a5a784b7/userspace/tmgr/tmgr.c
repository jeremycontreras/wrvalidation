/*
 * tmgr.c
 *
 * Time Manager main source file and entry point.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <libgpa.h>
#include <getopt.h>
#include <string.h>
#include <pthread.h>

/* Aplication header files and libraries */
#include "fsmlib.h"
#include "utils.h"
#include "gpa_interface.h"

/* Virtual Clock */
#include "vc.h"

/* GPA modules */
#include "hald.h"
#include "esmcd.h"
#include "ppsi.h"
#include "ptpd.h"
#include "testmod.h"

/* Other modules */
#include "ktmgr.h"
#include "ntp.h"
#include "wr_date.h"

#include "misc.h"


/*
 * TODO
 * ----
 *
 * - Complete a basic version of the handler_loop
 * - Documentation
 * - [DONE] Logging system -> use libgpa logging.
 * - Double-check parameter access (read / write).
 */

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define BANNER "tmgrd - Time Manager"
#define VERSION_MAJOR 0
#define VERSION_MINOR 20
#define FAILURE_PRESET 0

/************************************************************
 * Global variables                                         *
 ************************************************************/

int test_enabled;

/* Saves the timestamp at module startup */
struct timespec start_ts;

static int force_exit_in_failure = 0;


/************************************************************
 * Utility functions                                        *
 ************************************************************/

static void version(void)
{
	fprintf(stderr, "%s\n", BANNER);
	printf("%d.%d\n", VERSION_MAJOR, VERSION_MINOR);
}

static void help(void)
{
	fprintf(stderr, "%s (v%d.%d)\n", BANNER, VERSION_MAJOR, VERSION_MINOR);
	fprintf(stderr,
		"\nUsage:\n"
		"        tmgrd [options]\n\n"
		"  -t           Enable test features\n"
		"  -v           Enable error messages\n"
		"  -V           Enable debug messages\n"
		"  -q           Quiet mode\n"
		"  --version    Shows version info\n"
		"  --help       Shows this help message\n\n");
}

static void parse_cmdline(int argc, char *argv[])
{
	int c;
	struct option long_opts[] = {
		{"version", no_argument, 0, 0},
		{"help",    no_argument, 0, 0},
	};
	int opt = 0;

	while ((c = getopt_long(argc, argv, "tvVqh", long_opts, &opt)) != -1) {
		switch (c) {
		case 0:
			if (strcmp(long_opts[opt].name, "version") == 0) {
				/* Print version and exit */
				version();
				exit(0);
			}else if (strcmp(long_opts[opt].name, "help") == 0) {
				/* Show help message */
				help();
				exit(0);
			} else {
				fprintf(stderr, "[tmgrd] Unknown option: %s\n",
					long_opts[opt].name);
				exit(1);
			}
			break;
		case 't':
			/* Enable tests */
			test_enabled = 1;
			break;
		case 'h':
			/* Show help message */
			help();
			exit(0);
		/* libgpa takes care of these options */
		case 'v':
		case 'V':
		case 'q':
			break;
		case '?':
			help();
			fprintf(stderr, "[tmgrd] Unknown option %c\n", optopt);
			exit(1);
		default:
			fprintf(stderr, "[tmgrd] Error parsing "
				"command line options\n");
			exit(1);
		}
	}
}


/************************************************************
 * Top-level application logic                              *
 ************************************************************/

static void fail_critical(void)
{
	pr_error("Critical error in TMGR\n");
	tmgr_handler_stop();
	exit(1);
}

static int run_tmgr_in_failure(int force_exit)
{
	int ret = 1;

	if(!force_exit_in_failure) {
		pr_error("Wrong configuration detected in TMGR\n");
		pr_error("Applying default preset configuration and restart\n");
		set_tmgr_config_preset(FAILURE_PRESET);
		load_glb_preset(FAILURE_PRESET);
		ret = vc_start();
	}

	if(ret && force_exit)
		fail_critical();

	return ret;
}

/*
 * Tasks to run before entering the main event loop.
 *
 * Returns:
 *   1 if a critical task failed (ie. if it doesn't make sense for the
 *     Time Manager to continue).
 *   0 if the Time Manager is good to go.
 */
static int startup_tasks(void)
{
	uint32_t preset;

	/* 1 - Run current VC preset (GPA parameter one) */
	get_tmgr_config_preset(&preset);
	load_glb_preset(preset);

	/* 2 - Set the correct TAI in the kernel */
	if (fix_kernel_tai())
		return 1;
	if (set_fpga_time())
		return 1;

	/* 3 - Start the Virtual Clock */
	if(vc_start() && run_tmgr_in_failure(0))
		return 1;

	return 0;
}

static void handler_loop_tasks(void)
{
	struct timespec ts;
	int update = 0;
	int ret;

	/* Read and apply configuration */
	ret = get_tmgr_config_update(&update);
	if (!ret && update) {
		/* Exit VC engine */
		if(vc_exit())
			goto exit_failure;
		/* Load configuration */
		load_config();
		/* Start VC engine again */
		if(vc_start())
			goto start_failure;
		/* Clear config update flag */
		set_tmgr_config_update(0);
	}

	/* Run Virtual Clock */
	vc_run();

	/* Update the info parameters of all modules */
	update_modules_info();

	/* Update general info */
	clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
	set_tmgr_info_uptime(ts.tv_sec - start_ts.tv_sec);
	return;

start_failure:
	run_tmgr_in_failure(1);
	set_tmgr_config_update(0);
	return;

exit_failure:
	fail_critical();
}

static void *handler_vc_thread(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = 100000000};

	tmgr_handler_no_mb_loop(handler_loop_tasks, &ts);
	return NULL;
}

static int32_t release(struct gpa_rsrc *self)
{
	return 0;
}

#define PROG_NAME "tmgrd"

/************************************************************
 * Entry point                                              *
 ************************************************************/

int main(int argc, char *argv[])
{
	struct param_def *params_test = 0;
	struct timespec ts = {.tv_sec = 0, .tv_nsec = 100000000};
	pthread_t tmgr_vc_thread;
	void *tmgr_vc_thread_ret;

	/* Parse command line parameters */
	parse_cmdline(argc, argv);

	//daemonize(0);

	/* Get daemon startup time */
	clock_gettime(CLOCK_MONOTONIC_RAW, &start_ts);

	/**** GPA setup ****/
	argv[0]=PROG_NAME;
	gpa_msg_init(argc, argv);

	/* Initialize ports information (network interfaces) */
	if (initialize_ports_info()) {
		pr_error("Error scanning ports\n");
		return 1;
	}

	/**** Initialize user modules ****/

	/* Non-gpa modules */

	if (ktmgr_init()) {
		pr_warning("Error initializing the ktmgr module\n");
	}
	if (ntp_init(NTP_BUSYBOX)) {
		pr_warning("Error initializing the ntp module\n");
	}

	/* GPA-based modules */

	/* HALd GPA module */
	if(!hald_init()) {
		pr_warning("Error initializing the hald module\n");
	}

	/* ESMCd GPA module */
	if(!esmcd_init()) {
		pr_warning("Error initializing the esmcd module\n");
	}

	/* wPPSi GPA module */
	if(!ppsi_init()) {
		pr_warning("Error initializing the PPSi module\n");
	}

	/* PTPd GPA module */
	if(!ptpd_init()) {
		pr_warning("Error initializing the ptpd module\n");
	}

	/**** Create and publish gpa parameters ****/
	if (!tmgr_create_mod_owner(test_enabled, release, NULL, VERSION_MAJOR, VERSION_MINOR)) {
		pr_error("Error creating the tmgr libgpa interface\n");
		return 1;
	}

	/* Test clock source */
	/*
	 * Debug only. Try to initialize the test module. If it fails,
	 * disable the test mode.
	 */
	if (test_enabled) {
		params_test = testmod_init();
		if (!params_test)
			test_enabled = 0;
	}

	/**** Run startup tasks *****/
	if (startup_tasks()) {
		pr_error("Error initializing the Time Manager\n");
		return 1;
	}

	/**** Run event loop in a separate thread ****/
	pthread_create(&tmgr_vc_thread, 0, handler_vc_thread, 0);

	/**** Handle libgpa mailbox periodically ****/
	tmgr_handler_mb_only_loop(&ts);

	/**** Special case: main loop is finished by demand, wait for VC thread before exiting ****/
	pthread_join(tmgr_vc_thread, &tmgr_vc_thread_ret);
	/**** Close libgpa module (owner) ****/
	tmgr_close_mod_owner();

	return 0;
}

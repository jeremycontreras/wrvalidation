/*
 * misc.c
 *
 * Miscellaneous / unclassified functions for Time Manager.
 * Functions that don't deserve their own file will be put here.
 *
 * Of course, if a faimily of functions gets big enough it'll be better to move
 * them to their own module.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Oct 11, 2019
 * Last updated: Oct 14, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "misc.h"
#include "gpa_interface.h"
#include "hald.h"

static int gm_has_to_refresh = 0;

static void holdover_info_update(void)
{
	enum ho_state state;
	uint32_t state_time;
	uint32_t trig_time;
	enum ho_trig trig_origin;

	/* State */
	hald_get_softpll_ho_state(&state);
	set_ho_info_state(state);

	/* Time in holdover */
	hald_get_softpll_ho_trig_time(&trig_time);
	set_ho_info_time_holdover(trig_time);

	/* Trigger origin */
	hald_get_softpll_ho_trig_origin(&trig_origin);
	set_ho_info_trigger_origin(trig_origin);

	/* State time */
	hald_get_softpll_ho_state_time(&state_time);
	set_ho_info_state_time(state_time);

	/* Time learning */
	if (state == HO_LEARNING) {
		set_ho_info_time_learning(state_time);
	} else {
		set_ho_info_time_learning(0);
	}
}

static void gm_info_update(void)
{
	enum softpll_ext_fpanel detected;

	/* Detected inputs in fpanel */
	hald_get_softpll_ext_fpanel_detected(&detected);
	set_gm_info_detected(detected);
}

void enable_gm_refresh(int enable)
{
	gm_has_to_refresh = (enable) ? 1 : 0;
}

void update_modules_info(void)
{
	/* Update holdover info parameters */
	holdover_info_update();

	/* If GM is not in the timing source list, refresh some parameters */
	if(gm_has_to_refresh)
		gm_info_update();
}

/*
 * utils.h
 *
 * Utility functions for Time Manager.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Sep 6, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "commondefs.h"


#define DAEMONIZE_NO_CHDIR              1 << 0
#define DAEMONIZE_NO_CLOSE_FILES        1 << 1
#define DAEMONIZE_NO_REOPEN_STD_FDS     1 << 2
#define DAEMONIZE_NO_UMASK0             1 << 3

#define DAEMONIZE_MAX_CLOSE             8192

/* sysfs path containing the interface inodes */
#define SYSFS_PORT_PATH "/sys/class/net"


#define PORT_TYPE_ETH    1
#define PORT_TYPE_WR     (1 << 1)
#define PORT_TYPE_WR_ETH (PORT_TYPE_ETH | PORT_TYPE_WR)
#define PORT_TYPE_VALID  PORT_TYPE_WR_ETH




/*
 * find_ports
 *
 * Scans for available wr and eth ports and optionally saves their names in an
 * array passed as a parameter.
 *
 * NOTE: in case more than one port type is requested, the retrieval order in
 *       the names array will be WR ports first, then ETH ports. All ports of a
 *       concrete type will be saved in alphabetical order.
 *
 * Parameters:
 *   type:  A bitmask encoding the port types to scan for. See the PORT_TYPE
 *          macros in utils.h.
 *
 *   names: 0 if you don't want to save the port names. Otherwise, an array of
 *          strings that It must be already allocated and must have
 *          enough space (positions) to hold the names of all the available
 *          ports.
 *
 *   max_ports: Number of strings allocated in <names>.
 *
 * Returns:
 *   The number of ports found. 0 if it couldn't find any. -1 if error (names
 *   may still be modified in case of error).
 */
int find_ports(unsigned char type, char names[][MAX_STR_LEN], int max_ports);
int daemonize(int flags);

/*
 * gpa_access.h
 *
 * Centralized access to GPA parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 23, 2019
 * Last modified: Sep 6, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#ifndef __GPA_ACCESS_H__
#define __GPA_ACCESS_H__


#include <libgpa.h>


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/


/* Supported GPA datatypes */
enum gpa_datatype {
	GPA_TYPE_UINT8,
	GPA_TYPE_INT16,
	GPA_TYPE_UINT16,
	GPA_TYPE_INT32,
	GPA_TYPE_UINT32,
	GPA_TYPE_UINT64,
	GPA_TYPE_FLOAT32,
	GPA_TYPE_BOOL,
	GPA_TYPE_ENUM,
	GPA_TYPE_STRING,
};

/* Generic parameter data holder */
union param_data {
	uint8_t      u8;
	int16_t      i16;
	uint16_t     u16;
	uint32_t     u32;
	uint64_t     u64;
	int32_t      i32;
	float        f32;
	const char * str;
};

/* GPA parameter object */
struct gpa_param {
	/* The GPA parameter itself */
	struct gpa_prm *param;

	/* Its datatype */
	enum gpa_datatype type;

	/* 1 if the parameter is cached, 0 otherwise */
	int cached;

	/* 1 if the cache is initialized, 0 otherwise */
	int cache_initialized;

	/* Current cached value of the parameter */
	union param_data cached_data;

	/* Post-modification hook. 0 if none */
	void (*hook)(const void *data, const void *args);

	/* Additional (optional) argument for the hook */
	const void *hook_args;
};


/************************************************************
 * Public API                                               *
 ************************************************************/


/*
 * Enables caching for parameter <p>.
 *
 * Returns:
 *   0 If success
 *   1 otherwise
 */
int gpa_enable_cache(struct gpa_param *p);


/*
 * Sets <hook> as a function to run after <p> is modified internally by the tmgr
 * or externally by a user application (only for cached parameters, uncached
 * parameters are not aware of external changes).
 *
 * LibGPA implements a trigger mechanism to run functions upon certain events
 * such as parameter modifications, but it doesn't suit our needs because we
 * want to be able to update all cached parameters atomically (update_config
 * flag) and only then call their hooks. So this is a subset of that
 * mechanism tailored to the Time Manager parameters.
 *
 * Hooks are functions that take two (void *) arguments. The first one is the
 * new value of the associated parameter (passed as a pointer), the second one
 * is optional and is chosen by the user.
 *
 * Parameters:
 *   p: Associated parameter
 *   hook: the hook function
 *   args: will be passed as the second argument to <hook>
 *
 * Returns:
 *   0 If success
 *   1 otherwise
 */
int gpa_enable_hook(struct gpa_param *p, void (*hook)(const void *, const void *),
			const void *args);


/*
 * Updates the caches of all cached parameters.
 */
void gpa_update_caches(void);


/*
 * Gets the current value of parameter <p>.
 *
 * If the parameter is cached, it returns the cached value. If the cache is
 * dirty and it's time to update it (update_config flag), it refreshes the
 * cached value. If the new value is different than the cached one, it also runs
 * the post-modification hook of the parameter if it has one installed.
 *
 * Parameters:
 *   - p: the parameter to retrieve
 *   - d: a pointer to the place where to store the retrieved data. Its type
 *        must match the parameter datatype.
 *
 * Returns:
 *   0 If success
 *   1 otherwise
 */
int gpa_get_param(struct gpa_param *p, void *d);


/*
 * Sets the value of parameter <p>.
 *
 * Updates the cache if the parameter is cached. If the new value is different
 * than the current one, it calls the post-modification hook if the parameter
 * has one installed.
 *
 *
 *
 * Returns:
 *   0 If success
 *   1 otherwise
 */
int gpa_set_param(struct gpa_param *p, const void *d);

int32_t _gpa_mod_prm_snd_u8_poll(struct gpa_mod* mod, struct gpa_prm* prm,
				uint8_t val);
int32_t _gpa_mod_prm_snd_u16_poll(struct gpa_mod* mod, struct gpa_prm* prm,
				uint16_t val);
int32_t _gpa_mod_prm_snd_u32_poll(struct gpa_mod* mod, struct gpa_prm* prm,
				uint32_t val);
#endif

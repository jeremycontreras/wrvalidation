/*
 * test.c
 *
 * libGPA-based parameter interface for Time Manager. Test parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 11, 2019
 * Last modified: Aug 27, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"



/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum test_params {
	TEST_START,
	N_TEST_PARAMS
};

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* Test parameter array */
static struct gpa_param test_params[N_TEST_PARAMS];


/* Default parameter values */
static int dflt_test_start = 0;


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

/*
 * create_test_params
 *
 * Creates and publishes the test parameters and sets them to default values.
 */
int create_test_params(void)
{
	/* Start */
	test_params[TEST_START].param = gpa_prm_create_bool(
		0, TEST_START, "start", GPA_ACC_RW | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_ON_OFF, dflt_test_start);
	if (!test_params[TEST_START].param) {
		pr_error("Error creating %s/start\n",
			modir_array[TEST_MODIR].mp);
		return 1;
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[TEST_MODIR].mp,
		test_params[TEST_START].param)) {
		pr_error("Error adding start to %s\n",
			modir_array[TEST_MODIR].mp);
		return 1;
	}

	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/

int get_test_start(int *start)
{
	if (!start) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&test_params[TEST_START], start)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


/********** Setter functions **********/

int set_test_start(int start)
{
	if (gpa_set_param(&test_params[TEST_START], &start)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

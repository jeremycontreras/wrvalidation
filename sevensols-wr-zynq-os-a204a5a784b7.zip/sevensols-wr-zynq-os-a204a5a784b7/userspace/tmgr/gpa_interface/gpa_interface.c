/*
 * gpa_interface.c
 *
 * libGPA-based parameter interface for Time Manager.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <stdio.h>
#include <string.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/module.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"


/*
 * TECHNICAL DETAILS
 * =================
 * * About input parameters and how to do configuration changes:
 *
 * Ideally, the configuration parameters should be changed transactionally to
 * avoid nasty race conditions and incompatible parameter values. Unfortunately,
 * libgpa doesn't offer any way to do this, so I rolled my own transaction
 * mechanism based on a cache and a binary flag. It's shameful but for the
 * moment it'll do.
 *
 * Every input parameter should have a private cached copy, which is the one the
 * Time Manager will use internally. When a client changes a input parameter
 * the change is reflected only in the gpa-side but the Time Manager keeps using
 * the cached version. To update all the cached parameters the client must
 * notify the Time Manager that all the configuration changes are done by
 * setting the <config/update_config> flag.
 *
 * This is an improvement over regular parameter setting but note that it still
 * isn't thread safe.
 * The recommended way of managing this is by checking the update_config flag
 * and making the cache update in a single point in the control flow. Ideally,
 * there should be a housekeeping function that runs every once in a while (with
 * no thread contention) and takes care of this.
 */

/*
 * TODO
 * ----
 *
 * - Parameter docstrings
 * - Create a simpler mechanism to use and update cached values and to call
 *   post-update hooks only when necessary. Right now it's a mess.
 */



/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* Owner module id */
#define TMGR_OWNER_ID gpa_mod_tmgrd

/* Dynamic Modirs */
#define DEF_MAX_WR_IFACES 48
#define DEF_ETH_IFACES_OFFSET (DEF_MAX_WR_IFACES * PORTS_IFACE_REL_OID)

/* Maximum modir entries */
#define MAX_MODIR_ENTRIES 200


/************************************************************
 * External functions                                       *
 ************************************************************/

extern int create_tmgr_general_params(void);
extern int create_vc_params(void);
extern int create_gm_params(void);
extern int create_port_params(void);
extern int create_tsrc_info_params(void);
extern int create_ntp_params(void);
extern int create_holdover_params(void);
extern int create_gnss_params(void);
extern int create_switchover_params(void);
extern int create_test_params(void);

// FIXME: libGPA should provide this declaration!
extern struct gpa_mod* gpa_mod_create_owner_ver(enum gpa_mod_type id,char *name,
						uint8_t flags, uint8_t n_modirs,
						uint16_t ver_major, uint16_t ver_minor);

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* Owner module */
struct gpa_mod *tmgr_mod;

/* Control flag for the tmgr gpa loop */
static int tmgr_loop_stop;

/* Basic modir structure */
struct modir_def modir_array[] = {
	/* Config modir */
	[CONFIG_MODIR]                  = {.oid  = CFG_MODIR_OID,
					.mp   = CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* Virtual Clock modirs */
	[VCLOCK_MODIR]                  = {.oid  = VCLOCK_MODIR_OID,
					.mp   = VCLOCK_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_CONFIG_MODIR]           = {.oid  = VCLOCK_CFG_MODIR_OID,
					.mp   = VCLOCK_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_CONFIG_FOCA_MODIR]      = {.oid  = VCLOCK_CFG_FOCA_MODIR_OID,
					.mp   = VCLOCK_CFG_FOCA_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_INFO_MODIR]             = {.oid  = VCLOCK_INFO_MODIR_OID,
					.mp   = VCLOCK_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_INFO_INTEGRITY_MODIR]   = {.oid  = VCLOCK_INFO_INTEGRITY_MODIR_OID,
					.mp   = VCLOCK_INFO_INTEGRITY_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_INFO_Q_MODIR]           = {.oid  = VCLOCK_INFO_CLKQ_MODIR_OID,
					.mp   = VCLOCK_INFO_CLKQ_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[VCLOCK_INFO_TIMEPROP_MODIR]    = {.oid  = VCLOCK_INFO_TPROP_MODIR_OID,
					.mp   = VCLOCK_INFO_TPROP_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* Timing source modir */
	[TSRC_INFO_MODIR]               = {.oid  = TSRC_INFO_BASE_MODIR_OID,
					   .mp   = TSRC_INFO_BASE_MODIR_PATH,
					   .xval = MAX_MODIR_ENTRIES},

	/* Ports modir */
	[PORTS_MODIR]                   = {.oid  = PORTS_IFACE_BASE_MODIR_OID,
					.mp   = PORTS_IFACE_BASE_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* NTP modirs */
	[NTP_MODIR]                     = {.oid  = NTP_MODIR_OID,
					.mp   = NTP_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[NTP_CONFIG_MODIR]              = {.oid  = NTP_CFG_MODIR_OID,
					.mp   = NTP_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[NTP_INFO_MODIR]                = {.oid  = NTP_INFO_MODIR_OID,
					.mp   = NTP_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[NTP_PROVIDER_INFO_MODIR]       = {.oid  = NTP_INFO_PROVIDER_MODIR_OID,
					.mp   = NTP_INFO_PROVIDER_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[NTP_PROVIDER_CFG_MODIR]        = {.oid  = NTP_CFG_PROVIDER_MODIR_OID,
					.mp   = NTP_CFG_PROVIDER_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* GM modirs */
	[GM_MODIR]                      = {.oid  = GM_MODIR_OID,
					.mp   = GM_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[GM_CONFIG_MODIR]               = {.oid  = GM_CFG_MODIR_OID,
					.mp   = GM_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[GM_INFO_MODIR]                 = {.oid  = GM_INFO_MODIR_OID,
					.mp   = GM_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* GNSS modirs */
	[GNSS_MODIR]                    = {.oid  = GNSS_MODIR_OID,
					.mp   = GNSS_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[GNSS_CONFIG_MODIR]             = {.oid  = GNSS_CFG_MODIR_OID,
					.mp   = GNSS_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[GNSS_INFO_MODIR]               = {.oid  = GNSS_INFO_MODIR_OID,
					.mp   = GNSS_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* Holdover modirs */
	[HOLDOVER_MODIR]                = {.oid  = HO_MODIR_OID,
					.mp   = HO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[HOLDOVER_CONFIG_MODIR]         = {.oid  = HO_CFG_MODIR_OID,
					.mp   = HO_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[HOLDOVER_INFO_MODIR]           = {.oid  = HO_INFO_MODIR_OID,
					.mp   = HO_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* Misc modirs */
	[MISC_MODIR]                    = {.oid  = MISC_MODIR_OID,
					.mp   = MISC_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[MISC_CONFIG_MODIR]             = {.oid  = MISC_CFG_MODIR_OID,
					.mp   = MISC_CFG_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[MISC_INFO_MODIR]               = {.oid  = MISC_INFO_MODIR_OID,
					.mp   = MISC_INFO_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	[MISC_LEGACY_MODIR]             = {.oid  = MISC_LEGACY_MODIR_OID,
					.mp   = MISC_LEGACY_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},

	/* Test modir */
	[TEST_MODIR]                    = {.oid  = TEST_MODIR_OID,
					.mp   = TEST_MODIR_PATH,
					.xval = MAX_MODIR_ENTRIES},
};



/************************************************************
 * Private functions                                        *
 ************************************************************/

/* Print dynamic modir */
static void tmgr_print_rassoc(const struct gpa_rsrc_assoc *rassoc, int n_rassoc)
{
	int i;

	for(i = 0 ; i < n_rassoc ; i++) {
		pr_debug("modir[%d]:\n",i);
		pr_debug("\toid: %d\n",rassoc[i].oid);
		pr_debug("\tmp: %s\n",rassoc[i].mp);
		pr_debug("\topt: %x\n",rassoc[i].opt);
		pr_debug("\txval: %d\n",rassoc[i].xval);
		pr_debug("\n");
	}
}

/* Create NTP modirs */
static struct gpa_rsrc_assoc *tmgr_create_ntp_rassoc(int *n_rassoc)
{
	struct gpa_rsrc_assoc *rassoc_array = 0;
	struct gpa_rsrc_assoc *aux = 0;
	char *buf = 0;
	int modir = 0;
	int i;
	int oid, base_oid;
	int ntp_idx;

	rassoc_array = calloc(MAX_MODIRS, sizeof(struct gpa_rsrc_assoc));
	if(!rassoc_array)
		return 0;

	/* Main loop for NTP */
	for(i = 0 ; i < MAX_NTP_SERVERS ; i++) {
		ntp_idx = i+1;

		/* Base modir for NTP server */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, NTP_SERVER_MODIR_PATH, ntp_idx);
		base_oid = NTP_MODIR_OID + ntp_idx*NTP_SERVER_REL_OID;
		/* NOTE: Use previous value for base modir allowing to specify offset 0 for submodirs */
		oid = base_oid-1;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* cfg modir for NTP */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, NTP_SERVER_CFG_MODIR_PATH, ntp_idx);
		oid = base_oid + NTP_SERVER_CFG_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* info modir for NTP */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, NTP_SERVER_INFO_MODIR_PATH, ntp_idx);
		oid = base_oid + NTP_SERVER_INFO_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* cfg/auth modir for NTP */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, NTP_SERVER_CFG_AUTH_MODIR_PATH, ntp_idx);
		oid = base_oid + NTP_SERVER_CFG_AUTH_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;
	}

	aux = calloc(modir, sizeof(struct gpa_rsrc_assoc));
	memmove(aux, rassoc_array, modir * sizeof(struct gpa_rsrc_assoc));
	free(rassoc_array);

	*n_rassoc = modir;

	return aux;
}

/* Create tsrc_info modirs */
static struct gpa_rsrc_assoc *tmgr_create_tsrc_info_rassoc(int *n_rassoc)
{
	struct gpa_rsrc_assoc *rassoc_array = 0;
	struct gpa_rsrc_assoc *aux = 0;
	char *buf = 0;
	int modir = 0;
	int i;
	int oid, base_oid;
	int tsrc_idx;

	rassoc_array = calloc(MAX_MODIRS, sizeof(struct gpa_rsrc_assoc));
	if(!rassoc_array)
		return 0;

	/* Main loop for timing sources */
	for(i = 0 ; i < VC_PRIORITY_LENGTH ; i++) {
		tsrc_idx = i+1;

		/* Base modir for tsrc_info */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_MODIR_PATH, tsrc_idx);
		base_oid = TSRC_INFO_BASE_MODIR_OID + tsrc_idx*TSRC_INFO_REL_OID;
		oid = base_oid;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* clockQ modir for tsrc_info */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_MODIR_CLOCKQ_PATH, tsrc_idx);
		oid = base_oid + TSRC_INFO_CLOCKQ_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* time_properties modir for tsrc_info */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_MODIR_TPROP_PATH, tsrc_idx);
		oid = base_oid + TSRC_INFO_TPROP_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* stats modir for tsrc_info */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_MODIR_STATS_PATH, tsrc_idx);
		oid = base_oid + TSRC_INFO_STATS_REL_OID;

		rassoc_array[modir].oid = oid;
		rassoc_array[modir].mp = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;
	}

	aux = calloc(modir, sizeof(struct gpa_rsrc_assoc));
	memmove(aux, rassoc_array, modir * sizeof(struct gpa_rsrc_assoc));
	free(rassoc_array);

	*n_rassoc = modir;

	return aux;
}

/* Create ports modirs */
static struct gpa_rsrc_assoc *tmgr_create_port_rassoc(int nports, int *n_rassoc)
{
	struct gpa_rsrc_assoc *rassoc_array = 0;
	struct gpa_rsrc_assoc *aux = 0;
	int modir = 0;
	char *buf;
	char *pname;
	int neth = 0;
	int oid;
	int i;
	int eths_offset = DEF_ETH_IFACES_OFFSET;

	rassoc_array = calloc(MAX_MODIRS, sizeof(struct gpa_rsrc_assoc));
	if(!rassoc_array)
		return 0;

	/* Main loop for network interfaces */
	oid = PORTS_IFACE_OID;
	for(i = 0; i < nports; i++) {
		/* Reserve memory for interface modir entry */
		buf = calloc(MAX_STR_LEN, sizeof(char));

		/* Get the name of the current interface */
		get_port_iface_name(i, &pname);
		snprintf(buf, MAX_STR_LEN-1, PORTS_IFACE_MODIR_PATH, pname);

		/* If it is a ethX, put it at the end of the range (first wrX ones) */
		if (strstr(pname, "eth")) {
			oid = PORTS_IFACE_OID + eths_offset + (neth * PORTS_IFACE_REL_OID);
			neth++;
		} else { /* Otherwise, sum a specific offset for each interface */
			oid = PORTS_IFACE_OID + PORTS_IFACE_REL_OID * i;
		}

		/* ports/iface modir */
		rassoc_array[modir].oid  = oid;
		rassoc_array[modir].mp   = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* Add an offset from /ports/iface modir */
		oid += PORTS_CONFIG_REL_OID;

		/* Reserve memory for interface/config modir entry */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, PORTS_CONFIG_MODIR_PATH, pname);

		/* ports/iface/cfg modir */
		rassoc_array[modir].oid  = oid;
		rassoc_array[modir].mp   = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;

		/* Add an offset from /ports/iface/cfg modir */
		oid += PORTS_INFO_REL_OID;

		/* Reserve memory for interface/info modir entry */
		buf = calloc(MAX_STR_LEN, sizeof(char));
		snprintf(buf, MAX_STR_LEN-1, PORTS_INFO_MODIR_PATH, pname);

		/* ports/iface/info modir */
		rassoc_array[modir].oid  = oid;
		rassoc_array[modir].mp   = buf;
		rassoc_array[modir].opt  = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[modir].xval = MAX_MODIR_ENTRIES;
		modir++;
	}

	aux = calloc(modir, sizeof(struct gpa_rsrc_assoc));
	memmove(aux, rassoc_array, modir * sizeof(struct gpa_rsrc_assoc));
	free(rassoc_array);

	*n_rassoc = modir;

	return aux;
}


/* Create dynamic modir */
static struct gpa_rsrc_assoc *tmgr_create_rassoc(int test, int *n_rassoc)
{
	struct gpa_rsrc_assoc *rassoc_array = 0;
	struct gpa_rsrc_assoc *ports_rassoc_array = 0;
	struct gpa_rsrc_assoc *tsrc_info_rassoc_array = 0;
	struct gpa_rsrc_assoc *ntp_rassoc_array = 0;
	struct gpa_rsrc_assoc *aux = 0;
	int n_base_modirs = N_BASE_MODIRS;
	int i = 0;
	int nports;
	int ports_n_rassoc = 0;
	int tsrc_info_n_rassoc = 0;
	int ntp_n_rassoc = 0;

	if(!test)
		n_base_modirs--;

	/*
	 * Get the number of network interfaces (must be already scanned with
	 * <initialize_ports_info>.
	 */
	nports = get_nports();

	/* Reserve memory for gpa_rsrc_assoc */
	rassoc_array = calloc(MAX_MODIRS, sizeof(struct gpa_rsrc_assoc));
	if(!rassoc_array)
		return 0;

	for (i = 0; i < n_base_modirs; i++) {
		rassoc_array[i].oid = modir_array[i].oid;
		rassoc_array[i].mp = modir_array[i].mp;
		rassoc_array[i].opt = GPA_RSRC_ASSOC_OPT_FLAG_XVAL_FORCE_NPRMS;
		rassoc_array[i].xval = modir_array[i].xval;
	}

	/* Ports */
	ports_rassoc_array = tmgr_create_port_rassoc(nports, &ports_n_rassoc);
	memmove(&rassoc_array[i], ports_rassoc_array,
		ports_n_rassoc * sizeof(struct gpa_rsrc_assoc));
	i += ports_n_rassoc;
	free(ports_rassoc_array);

	/* tsrc_info */
	tsrc_info_rassoc_array = tmgr_create_tsrc_info_rassoc(&tsrc_info_n_rassoc);
	memmove(&rassoc_array[i], tsrc_info_rassoc_array,
		tsrc_info_n_rassoc * sizeof(struct gpa_rsrc_assoc));
	i += tsrc_info_n_rassoc;
	free(tsrc_info_rassoc_array);

	/* NTP */
	ntp_rassoc_array = tmgr_create_ntp_rassoc(&ntp_n_rassoc);
	memmove(&rassoc_array[i], ntp_rassoc_array,
		ntp_n_rassoc * sizeof(struct gpa_rsrc_assoc));
	i += ntp_n_rassoc;
	free(ntp_rassoc_array);

	aux = calloc(i, sizeof(struct gpa_rsrc_assoc));
	memmove(aux, rassoc_array, i * sizeof(struct gpa_rsrc_assoc));
	free(rassoc_array);

	*n_rassoc = i;
	return aux;
}



/************************************************************
 * Public API                                               *
 ************************************************************/

int gpa_common_find_oid(struct enum_oid_match *v, int nv, int enum_id)
{
	int ret = -1;
	int i;

	for(i = 0 ; i < nv ; i++) {
		if(v[i].enum_id == enum_id) {
			ret = v[i].oid;
			break;
		}
	}

	return ret;
}


struct gpa_mod *tmgr_create_mod_owner(int test_enabled,
				int32_t (*release)(struct gpa_rsrc *), void *priv,
				uint16_t v_maj, uint16_t v_min)
{
	int n_modirs;
	struct gpa_rsrc_assoc *rassoc;
	struct gpa_rsrc *fake_rsrc = NULL;
	enum pps_mode m;

	rassoc = tmgr_create_rassoc(test_enabled, &n_modirs);
	if(!rassoc)
		goto err_out2;

	/* Debug gpa_rsrc_assoc structure */
	tmgr_print_rassoc(rassoc, n_modirs);

	if (!tmgr_mod) {
		/* Create owner module and modir structure */
		tmgr_mod = gpa_mod_create_owner_ver(TMGR_OWNER_ID, "tmgrd",
						GPA_MOD_FLAG_MB_WRITE, n_modirs, v_maj, v_min);
		gpa_mod_add_rsrcs_assoc(tmgr_mod, 0,
			(const struct gpa_rsrc_assoc *)rassoc, n_modirs);

		// Create GPA fake resource for Time Manager
		fake_rsrc = gpa_rsrc_create("tmgr_rsc","Time Manager fake resource",
			GPA_RSRC_TYPE_PRIVATE,GPA_CELL_ENDIANNESS_TYPE_BIG);
		if(!fake_rsrc)
			goto err_out;

		fake_rsrc->priv = priv;
		fake_rsrc->on_release = release;

		gpa_rsrc_append_child(tmgr_mod->root_rsrc,fake_rsrc);

		/* Create and populate modir parameters */
		if (create_tmgr_general_params())
			goto err_out;
		if (create_vc_params())
			goto err_out;
		if (create_gm_params())
			goto err_out;
		if (create_port_params())
			goto err_out;
		if (create_tsrc_info_params())
			goto err_out;
		if (create_ntp_params())
			goto err_out;
		if (create_holdover_params())
			goto err_out;
		if(create_gnss_params())
			goto err_out;
		if (test_enabled) {
			if (create_test_params())
				goto err_out;
		}

		// Update params from dotconfig
		gpa_mod_init_prms(tmgr_mod);
		// Force to load configuration for parameters (cache update)
		load_config();
		// Init PPS mode
		get_tmgr_config_pps_mode(&m);
		init_tmgr_hald_pps_mode(m);
	}

	return tmgr_mod;
err_out:
	gpa_mod_close(tmgr_mod);
	tmgr_mod = NULL;
err_out2:
	return 0;
}

void tmgr_close_mod_owner(void)
{
	gpa_mod_close(tmgr_mod);
}

static void _tmgr_handler_loop(void (*f)(void), int mb_poll, struct timespec *ts)
{
	while (!tmgr_loop_stop) {
		if(mb_poll)
			gpa_mod_handle_mb(tmgr_mod);

		if (f)
			f();

		nanosleep(ts, 0);
	}
}

void tmgr_handler_loop(void (*f)(void), struct timespec *ts)
{
	_tmgr_handler_loop(f, 1, ts);
}

void tmgr_handler_mb_only_loop(struct timespec *ts)
{
	_tmgr_handler_loop(NULL, 1, ts);
}

void tmgr_handler_no_mb_loop(void (*f)(void), struct timespec *ts)
{
	_tmgr_handler_loop(f, 0, ts);
}

void load_config(void)
{
	/* Update cached parameters */
	gpa_update_caches();

	/*
	 * Interface configuration may have changed. Check if it's valid and
	 * correct it or consolidate it.
	 */
	check_port_config();
}

/********** Other functions **********/

/*
 * These functions are not mapped to a gpa parameter.
 */

void tmgr_handler_stop(void)
{
	tmgr_loop_stop = 1;
}


/* DEBUG ONLY */
void tmgr_print_mod_tree(void)
{
	gpa_mod_tree_print(tmgr_mod, gpa_modir_getobj_root(tmgr_mod));
}

/*
 * vc.c
 *
 * libGPA-based parameter interface for Time Manager. Virtual Clock parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 11, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <stdio.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>
#include <libgpa/util.h>
#include <libgpa/genmem.h>
#include <libgpa/prm_assoc.h>
#include <libgpa/ieee1588.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "vc_policy_foca.h"
#include "ktmgr.h"
#include "ppsi.h"
#include "vcs.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* General config */
#define VC_OID_POLICY            0

/* FOCA config */
#define VC_OID_FOCA_STRATEGY     0

/* General info */
#define VC_OID_STATUS            0
#define VC_OID_ACTIVEREF         1
#define VC_OID_MESSAGE           2
#define VC_OID_DATETIME          3
#define VC_OID_VCS_CODE          4
#define VC_OID_PASSIVE_STATUS    5

/* Integrity info */
#define VC_OID_INTEGRITY_LEAPS   0
#define VC_OID_INTEGRITY_TOD     1

#define GET_VC_OID(oid) VC_OID##_##oid
#define VC_PASSOC(oid, vtx, field) .p_oid = GET_VC_OID(oid), GPA_PASSOC_FIELD(GPA_PRM_VTX##_##vtx, field)
#define VC_RSRC_PATH "vc"
#define VC_RSRC_DESC "VC GPA resource"
#define VC_GMEM_RSRC_PATH "gmem"
#define VC_GMEM_RSRC_DESC "Generic memory resource for VC parameters"

#define PASSOC_CLKQ_FIELD(oid_suffix,field)				\
	.p_oid=GPA_OID_1588_CLOCK_Q##_##oid_suffix, .addr=offsetof(struct gpa_clkinf_passoc_data, field)
#define PASSOC_TPROP_FIELD(oid_suffix,field)				\
	.p_oid=GPA_OID_1588_CLOCK_TPROP##_##oid_suffix, .addr=offsetof(struct gpa_clkinf_passoc_data, field)

struct gpa_cfg_foca_passoc_data {
	int strategy;
};

struct gpa_cfg_passoc_data {
	int policy;
	struct gpa_cfg_foca_passoc_data foca;
};

struct gpa_info_integrity_passoc_data {
	enum vc_status leaps;
	enum vc_status tod;
};

struct gpa_info_passoc_data {
	uint32_t vcs_code;
	enum vc_status status;
	char active_reference[MAX_STR_LEN];
	char message[MAX_STR_LEN];
	char date_time[MAX_STR_LEN];
	enum vc_status passive_status;
	struct gpa_info_integrity_passoc_data integrity;
};

struct gpa_passoc_data {
	struct gpa_cfg_passoc_data cfg;
	struct gpa_info_passoc_data info;
	struct gpa_clkinf_passoc_data clkinf;
};

enum {
	VC_CFG_R_PRMS = 0,
	VC_CFG_FOCA_R_PRMS,
	VC_INFO_R_PRMS,
	VC_INFO_INTEGRITY_R_PRMS,
	VC_CLOCKQ_R_PRMS,
	VC_TPROP_R_PRMS,
	N_VC_RESOURCES,
};

#define _VC_PD(d)                     (&(d->pd))
#define _VC_PD_SIZE                   (sizeof(struct gpa_passoc_data))
#define _VC_PD_CFG(d)                 (&(d->pd.cfg))
#define _VC_PD_CFG_SIZE               (sizeof(struct gpa_cfg_passoc_data))
#define _VC_PD_CFG_FOCA(d)            (&(d->pd.cfg.foca))
#define _VC_PD_CFG_FOCA_SIZE          (sizeof(struct gpa_cfg_foca_passoc_data))
#define _VC_PD_INFO(d)                (&(d->pd.info))
#define _VC_PD_INFO_SIZE              (sizeof(struct gpa_info_passoc_data))
#define _VC_PD_INFO_INTEGRITY(d)      (&(d->pd.info.integrity))
#define _VC_PD_INFO_INTEGRITY_SIZE    (sizeof(struct gpa_info_integrity_passoc_data))
#define _VC_PD_CLKINF(d)              (&(d->pd.clkinf))
#define _VC_PD_CLKINF_SIZE            (sizeof(struct gpa_clkinf_passoc_data))
struct vc_gpa_data {
	/* Data structure for GPA passoc */
	struct gpa_passoc_data pd;

	/* Internal GPA resources */
	struct gpa_rsrc *vc;
	struct gpa_rsrc *gmem;
	struct gpa_rsrc *r_prms[N_VC_RESOURCES];
};


#define _GPA_RPRIV_TDEF struct vc_r_prms_priv
struct vc_r_prms_priv {
	void *addr;
	size_t sz;
};


/* Enum association structures */

struct gpa_passoc_xtra_enum enum_vc_status =
{
	.type = GPA_PASSOC_EXTRA_TYPE_ENUM,
	.enum_opt = GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
	.n_entries = N_VC_STATUS_ENTRIES,
	.entries =
	{
		[VC_STATUS_DISABLED] = "DISABLED",
		[VC_STATUS_OK] = "OK",
		[VC_STATUS_WARNING] = "WARNING",
		[VC_STATUS_ERROR] = "ERROR",
	}
};

struct gpa_passoc_xtra_enum enum_bool_yes_no =
{
	.type = GPA_PASSOC_EXTRA_TYPE_ENUM,
	.enum_opt = GPA_PRM_ENUM_OPT_BOOL | GPA_PRM_ENUM_OPT_BOOL_YES_NO,

};

static struct gpa_passoc_xtra_enum enum_vc_policy =
{
	.type = GPA_PASSOC_EXTRA_TYPE_ENUM,
	.enum_opt = GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
	.n_entries = N_VC_POLICY_CODES,
	.entries =
	{
		[VC_POLICY_CODE_DEFAULT] = "Default (FOCA)",
		[VC_POLICY_CODE_FOCA] = "FOCA",
	}
};

static struct gpa_passoc_xtra_enum enum_vc_pol_st_foca =
{
	.type = GPA_PASSOC_EXTRA_TYPE_ENUM,
	.enum_opt = GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
	.n_entries = N_VC_POL_FOCA_STRATEGIES,
	.entries =
	{
		[VC_POL_FOCA_ST_FO_STRICT] = "Fall-down",
		[VC_POL_FOCA_ST_FO_REEVALUATE] = "Re-evaluate",
	}
};

struct gpa_passoc_grp_cfg passoc_default_rr_none = {.ow_def.opt = GPA_PRM_OPT_RRATE_NONE};

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_cfg_passoc_data
static struct gpa_passoc_item itms_vc_cfg_passoc[] =
{
	{VC_PASSOC(POLICY, ENUM, policy), .ow_it.acc = GPA_ACC_RWL, .xdata = &enum_vc_policy, .desc = "VC policy that define how and when to transit between multiple timing source"},
};

#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_cfg_foca_passoc_data
static struct gpa_passoc_item itms_vc_cfg_foca_passoc[] =
{
	{VC_PASSOC(FOCA_STRATEGY, ENUM, strategy), .ow_it.acc = GPA_ACC_RWL | GPA_ACC_EXPERT, .xdata = &enum_vc_pol_st_foca, .desc = "Strategy configuration for FOCA policy"},
};


#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_info_passoc_data
static struct gpa_passoc_item itms_vc_info_passoc[] =
{
	{VC_PASSOC(STATUS, ENUM, status), .ow_it.acc = GPA_ACC_RT, .xdata = &enum_vc_status, .desc = "General Virtual Clock status"},
	{VC_PASSOC(ACTIVEREF, STR, active_reference), .ow_it.acc = GPA_ACC_R, .desc = "Current running VC timing source"},
	{VC_PASSOC(MESSAGE, STR, message), .ow_it.acc = GPA_ACC_R, .desc = "Status message"},
	{VC_PASSOC(DATETIME, STR, date_time), .ow_it.acc = GPA_ACC_R, .desc = "Current system time"},
	{VC_PASSOC(VCS_CODE, U32, vcs_code), .ow_it.acc = GPA_ACC_RT, .desc = "VCS code for current VC timing source"},
	{VC_PASSOC(PASSIVE_STATUS, ENUM, passive_status), .ow_it.acc = GPA_ACC_R | TMGR2_ACC, .xdata = &enum_vc_status, .desc = "VC passive status"},
};

#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_info_integrity_passoc_data
static struct gpa_passoc_item itms_vc_info_integrity_passoc[] =
{
	{VC_PASSOC(INTEGRITY_LEAPS, ENUM, leaps), .ow_it.acc = GPA_ACC_R | TMGR2_ACC, .xdata = &enum_vc_status, .desc = "VC leapseconds integrity flag"},
	{VC_PASSOC(INTEGRITY_TOD, ENUM, tod), .ow_it.acc = GPA_ACC_R | TMGR2_ACC, .xdata = &enum_vc_status, .desc = "VC ToD integrity flag"},
};

#undef GPA_PASSOC_CURRENT_STRUCT
static struct gpa_passoc_item itms_passoc_clkq[] =
{
	{PASSOC_CLKQ_FIELD(IDENTITY,     id), .desc = "Unique identity of PTP instance in the network"},
	{PASSOC_CLKQ_FIELD(PRIORITY1,    priority1), .desc = "Force BMCA decision using 1st priority (Lower values takes preference)"},
	{PASSOC_CLKQ_FIELD(PRIORITY2,    priority2), .desc = "Manually force BMCA to select clockID when quality is the same (Lower values takes preference)"},
	{PASSOC_CLKQ_FIELD(CLASS,        class), .desc = "The clockClass is one of the main attributtes that characterizes the timing instance"},
	{PASSOC_CLKQ_FIELD(ACCURACY,     accuracy), .desc = "It indicates the expected accuracy of the timing instance. It shall be conservatively estimated based on the time source"},
	{PASSOC_CLKQ_FIELD(OSLV,         variance), .desc = "Estimate of the variations of the Local Clock as measured by comparison to a suitable reference clock"},
	{PASSOC_CLKQ_FIELD(NHOPS,        n_hops), .desc = "Number of PTP communication paths traversed between this PTP instance to the Grandmaster PTP instance (aka stepsRemoved)"},
};

static struct gpa_passoc_item itms_passoc_tprop[] =
{
	{PASSOC_TPROP_FIELD(SOURCE,      time_source), .desc = "This information-only attribute indicates the immediate source of time used by the Grandmaster"},
	{PASSOC_TPROP_FIELD(UTCOFFSET,   utc_offset), .desc = "UTC-TAI offset (leap seconds) if under a PTP Timescale"},
	{PASSOC_TPROP_FIELD(TVALID,      time_valid), .desc = "True if the timescale is 'PTP traceable' to a primary reference"},
	{PASSOC_TPROP_FIELD(FVALID,      freq_valid), .desc = "True if the frequency determining the timescale is 'PTP traceable' to a primary reference"},
	{PASSOC_TPROP_FIELD(UTCOFFVALID, utc_offset_valid), .desc = "True if the current UTC offset is known to be valid (It will handle the next leap second jump)"},
	{PASSOC_TPROP_FIELD(TSCALE,      ptp_tscale), .desc = "True, if the timescale is PTP (TAI), otherwise it is ARB"},
	{PASSOC_TPROP_FIELD(LEAP59,      leap59), .desc = "When True, it indicate that the last minute of current UTC day contains 59 seconds"},
	{PASSOC_TPROP_FIELD(LEAP61,      leap61), .desc = "When True, it indicate that the last minute of current UTC day contains 61 seconds"},
};

/* GPA data for parameters */
static struct vc_gpa_data vc_gpa_data;

/************************************************************
 * Private functions                                        *
 ************************************************************/

static struct gpa_rsrc *_vc_get_gpa_rsrc(int grsrc)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_rsrc *r = NULL;

	if(grsrc < 0 || grsrc >= N_VC_RESOURCES) {
		pr_error("Invalid GPA resource index %d\n", grsrc);
		return NULL;
	}

	r = d->r_prms[grsrc];

	return r;
}

static int32_t _vc_release(struct gpa_rsrc *self)
{
	GPA_RETCHECK_PTR(self,-EFAULT);
	GPA_RSRC_PRIV_GET(self);
	gpa_free(priv);

	return 0;
}

static int32_t _vc_prmtransfer(struct gpa_rsrc* self, struct gpa_prm *p, int to_prm)
{
	int32_t ret = -ENOSYS;

	GPA_RSRC_PRIV_GET(self);

	/* Get offset inside structure (parameter) */
	int32_t p_addr = gpa_rsrc_prm_get_addr(self,p);
	/* Offset is equal to resource address (base of structure) + parameter offset */
	void * offset = priv->addr + p_addr;

	/* Finally, transfer value */
	ret=gpa_rsrc_transfer_prm(self, offset, p, to_prm);

	return ret;
}

static int32_t _vc_prmsync(struct gpa_rsrc* self, struct gpa_prm *p, int to_prm)
{
	int ret = -ENOSYS;
	GPA_RETCHECK_PTR(p,-EFAULT);
	GPA_RETCHECK_PTR(self,-EFAULT);
	GPA_RETCHECK_PTR(self->priv,-EFAULT);

	/* Special case (handled in setter function) */
	if (self == _vc_get_gpa_rsrc(VC_INFO_R_PRMS) && gpa_prm_get_oid(p) == GET_VC_OID(DATETIME))
		return 0;

	ret = _vc_prmtransfer(self, p, to_prm);

	return ret;
}

/*
 * Sets the appropriate WARNING or CRITICAL flags to the gm/info/tod_status
 * parameter.
 *
 * This function will be called by libgpa.
 */
int32_t vc_status_warning_check(const void *new_value, struct gpa_prm *p,
					uint8_t iwc)
{
	const union gpa_val *val = new_value;
	enum vc_status status = val->u16;

	if (iwc == GPA_PRM_RANGE_INPUT) {
		return (status >= 0 && status < N_VC_STATUS_ENTRIES);
	}

	switch (status) {
		/* WARNING cases */
	case VC_STATUS_DISABLED:
	case VC_STATUS_WARNING:
		if (iwc == GPA_PRM_RANGE_WARNING)
			return 1;
		break;
		/* CRITICAL cases */
	case VC_STATUS_ERROR:
		if (iwc == GPA_PRM_RANGE_CRITICAL)
			return 1;
		break;
	default:
		break;
	}

	return 0;
}

/* Declare an internal libGPA function to use it here */
int32_t _gpa_moddir_add_rsrc(struct gpa_mod *mod,struct gpa_modir * modir,const struct gpa_rsrc* rsrc, int lvl);
static int add_vc_prms_to_modirs()
{
	int i;
	char modir_path[MAX_STR_LEN];
	struct gpa_rsrc *r;
	struct gpa_modir *modir;
	struct {
		char *name;
		char *path;
	} aux[N_VC_RESOURCES] = {
		[VC_CFG_R_PRMS]            = {.name = "cfg", .path = VCLOCK_CFG_MODIR_PATH},
		[VC_CFG_FOCA_R_PRMS]       = {.name = "FOCA", .path = VCLOCK_CFG_FOCA_MODIR_PATH},
		[VC_INFO_R_PRMS]           = {.name = "info", .path = VCLOCK_INFO_MODIR_PATH},
		[VC_INFO_INTEGRITY_R_PRMS] = {.name = "integrity", .path = VCLOCK_INFO_INTEGRITY_MODIR_PATH},
		[VC_CLOCKQ_R_PRMS]         = {.name = "clockQ", .path = VCLOCK_INFO_CLKQ_MODIR_PATH},
		[VC_TPROP_R_PRMS]          = {.name = "time_properties", .path = VCLOCK_INFO_TPROP_MODIR_PATH},
	};

	for(i = 0 ; i < N_VC_RESOURCES ; i++) {
		snprintf(modir_path, MAX_STR_LEN-1, aux[i].path);
		modir = gpa_modir_getobj_path(tmgr_mod, modir_path);
		if(!modir)
			return 1;

		r = _vc_get_gpa_rsrc(i);
		if(!r)
			return 1;

		if(_gpa_moddir_add_rsrc(tmgr_mod, modir, r, 0)) {
			pr_error("Error associating VC %s parameters to %s\n",
				aux[i].name, modir_path);
			return 1;
		}
	}

	return 0;
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

void gpa_clkq_passoc_init(struct gpa_rsrc *r)
{
	int i;
	struct gpa_prm *prm = NULL;

	if(!r)
		return;

	for(i = 0 ; i < GPA_ARRAY_SIZE(itms_passoc_clkq) ; i++)
	{
		prm = gpa_rsrc_prm_find_oid(r, itms_passoc_clkq[i].p_oid);
		if(!prm) {
			pr_warn("Parameter OID=%d not found\n", itms_passoc_clkq[i].p_oid);
		} else {
			gpa_prm_set_desc(prm, itms_passoc_clkq[i].desc);
			gpa_prm_set_rsrc_addr(prm, itms_passoc_clkq[i].addr);
		}
	}
}

void gpa_tprop_passoc_init(struct gpa_rsrc *r)
{
	int i;
	struct gpa_prm *prm = NULL;

	if(!r)
		return;

	for(i = 0 ; i < GPA_ARRAY_SIZE(itms_passoc_tprop) ; i++)
	{
		prm = gpa_rsrc_prm_find_oid(r, itms_passoc_tprop[i].p_oid);
		if(!prm) {
			pr_warn("Parameter OID=%d not found\n", itms_passoc_tprop[i].p_oid);
		} else {
			gpa_prm_set_desc(prm, itms_passoc_tprop[i].desc);
			gpa_prm_set_rsrc_addr(prm, itms_passoc_tprop[i].addr);
		}
	}
}

/*
 * create_vc_params
 *
 * Creates and publishes the Virtual Clock parameters and sets them to default
 * values.
 */

int create_vc_params(void)
{
	struct vc_gpa_data *gdata = &vc_gpa_data;
	struct gpa_passoc_rsrc_cfg pcfg;
	struct gpa_rsrc *r;
	struct gpa_prm *param;
	uint8_t opt_flg = GPA_1588_CLK_OPT_TRACKED | GPA_1588_CLK_OPT_TSRC;
	char buf[MAX_STR_LEN];
	char * r_name[N_VC_RESOURCES] = {
		[VC_CFG_R_PRMS]            = "cfg_passoc",
		[VC_CFG_FOCA_R_PRMS]       = "cfg_foca_passoc",
		[VC_INFO_R_PRMS]           = "info_passoc",
		[VC_INFO_INTEGRITY_R_PRMS] = "info_integrity_passoc",
	};
	struct vc_r_prms_priv *priv;

	// Create GPA resource for VC
	snprintf(buf, MAX_STR_LEN-1, VC_RSRC_PATH);
	gdata->vc = gpa_rsrc_create(buf, VC_RSRC_DESC,
				GPA_RSRC_TYPE_PRIVATE,GPA_CELL_ENDIANNESS_TYPE_BIG);
	if(!gdata->vc)
		goto exit_create1;

	gpa_rsrc_append_child(tmgr_mod->root_rsrc, gdata->vc);

	/* Initialize gmem resource name for VC parameters */
	snprintf(buf, MAX_STR_LEN-1, VC_GMEM_RSRC_PATH);

	/* Create gmem resource for VC parameters */
	gdata->gmem = gpa_rsrc_genmem_create(gdata->vc, buf, _VC_PD(gdata),
					_VC_PD_SIZE, VC_GMEM_RSRC_DESC,
					NULL);
	if(!gdata->gmem)
		goto exit_create1;

	/* Fill passoc resource config */
	snprintf(buf, MAX_STR_LEN-1, r_name[VC_CFG_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _VC_PD_CFG(gdata);
	pcfg.size = _VC_PD_CFG_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_vc_cfg_passoc);
	pcfg.items = itms_vc_cfg_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[VC_CFG_R_PRMS] =gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[VC_CFG_R_PRMS];
	if(!r)
	        goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_CFG(gdata);
	priv->sz = _VC_PD_CFG_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	/* Search status param and assign custom check function */
	param = gpa_rsrc_prm_find_oid(r, GET_VC_OID(STATUS));
	gpa_prm_set_custom_check_range(param, vc_status_warning_check);

	/* Fill passoc resource FOCA config */
	snprintf(buf, MAX_STR_LEN-1, r_name[VC_CFG_FOCA_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _VC_PD_CFG_FOCA(gdata);
	pcfg.size = _VC_PD_CFG_FOCA_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_vc_cfg_foca_passoc);
	pcfg.items = itms_vc_cfg_foca_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[VC_CFG_FOCA_R_PRMS] = gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[VC_CFG_FOCA_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_CFG_FOCA(gdata);
	priv->sz = _VC_PD_CFG_FOCA_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	int st = VC_POL_FOCA_ST_FO_REEVALUATE;
	param = gpa_rsrc_prm_find_oid(r, GET_VC_OID(FOCA_STRATEGY));
	gpa_prm_set_val_fromptr(param, (void *) &st);

	/* Fill passoc resource info */
	snprintf(buf, MAX_STR_LEN-1, r_name[VC_INFO_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _VC_PD_INFO(gdata);
	pcfg.size = _VC_PD_INFO_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_vc_info_passoc);
	pcfg.items = itms_vc_info_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[VC_INFO_R_PRMS] = gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[VC_INFO_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_INFO(gdata);
	priv->sz = _VC_PD_INFO_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	/* Search passive_status param and assign custom check function */
	param = gpa_rsrc_prm_find_oid(r, GET_VC_OID(PASSIVE_STATUS));
	gpa_prm_set_custom_check_range(param, vc_status_warning_check);

	/* Fill passoc resource info integrity */
	snprintf(buf, MAX_STR_LEN-1, r_name[VC_INFO_INTEGRITY_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _VC_PD_INFO_INTEGRITY(gdata);
	pcfg.size = _VC_PD_INFO_INTEGRITY_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_vc_info_integrity_passoc);
	pcfg.items = itms_vc_info_integrity_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[VC_INFO_INTEGRITY_R_PRMS] = gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[VC_INFO_INTEGRITY_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_INFO_INTEGRITY(gdata);
	priv->sz = _VC_PD_INFO_INTEGRITY_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	/* Search integrity/leaps and integrity/tod params and assign custom check function */
	param = gpa_rsrc_prm_find_oid(r, GET_VC_OID(INTEGRITY_LEAPS));
	gpa_prm_set_custom_check_range(param, vc_status_warning_check);

	param = gpa_rsrc_prm_find_oid(r, GET_VC_OID(INTEGRITY_TOD));
	gpa_prm_set_custom_check_range(param, vc_status_warning_check);

	/* Create clockQ and time_properties (IEEE1588) GPA resources */
	gdata->r_prms[VC_CLOCKQ_R_PRMS] = gpa_rsrc_1588_clk_Q_create(gdata->gmem,opt_flg);
	r = gdata->r_prms[VC_CLOCKQ_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_CLKINF(gdata);
	priv->sz = _VC_PD_CLKINF_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	gpa_clkq_passoc_init(r);

	gdata->r_prms[VC_TPROP_R_PRMS] = gpa_rsrc_1588_clk_tprop_create(gdata->gmem,opt_flg);
	r = gdata->r_prms[VC_TPROP_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct vc_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct vc_r_prms_priv *) r->priv;
	priv->addr = _VC_PD_CLKINF(gdata);
	priv->sz = _VC_PD_CLKINF_SIZE;

	r->prm_sync = _vc_prmsync;
	r->on_release = _vc_release;

	gpa_tprop_passoc_init(r);

	return add_vc_prms_to_modirs();

exit_create1:
	if(gdata->vc)
		gpa_rsrc_release(gdata->vc);

	return 1;
}

/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/

int get_vc_cfg_policy(uint16_t *policy)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_cfg_passoc_data *c;

	if (!policy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CFG(d);
	*policy = c->policy;

	return 0;
}


int get_vc_cfg_foca_strategy(uint16_t *st)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_cfg_foca_passoc_data *c;

	if (!st) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CFG_FOCA(d);
	*st = c->strategy;

	return 0;
}

int get_vc_info_datetime(const char **datetime)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!datetime) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*datetime = &i->date_time[0];

	return 0;
}

int get_vc_info_vcs_code(uint32_t *code)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!code) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*code = i->vcs_code;

	return 0;
}

int get_vc_info_message(const char **msg)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!msg) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*msg = &i->message[0];

	return 0;
}

int get_vc_info_status(enum vc_status *status)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!status) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*status = i->status;

	return 0;
}

int get_vc_info_activeref(const char **ref)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!ref) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*ref = &i->active_reference[0];

	return 0;
}

int get_vc_info_clock_class(uint8_t *class)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CLKINF(d);
	*class = c->class;

	return 0;
}

int get_vc_info_clock_accuracy(uint8_t *accuracy)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CLKINF(d);
	*accuracy = c->accuracy;

	return 0;
}

int get_vc_info_priority1(uint8_t *priority1)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	if (!priority1) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CLKINF(d);
	*priority1 = c->priority1;

	return 0;
}

int get_vc_info_priority2(uint8_t *priority2)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	if (!priority2) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	c = _VC_PD_CLKINF(d);
	*priority2 = c->priority2;

	return 0;
}

int get_vc_info_passive_status(enum vc_status *ps)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!ps) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	*ps = i->passive_status;

	return 0;
}

int get_vc_info_integrity_leaps(enum vc_status *leaps)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_integrity_passoc_data *i;

	if (!leaps) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO_INTEGRITY(d);
	*leaps = i->leaps;

	return 0;
}

int get_vc_info_integrity_tod(enum vc_status *tod)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_integrity_passoc_data *i;

	if (!tod) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	i = _VC_PD_INFO_INTEGRITY(d);
	*tod = i->tod;

	return 0;
}

/********** Setter functions **********/


int set_vc_info_datetime(char *str)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;
	struct gpa_rsrc *r;
	struct gpa_prm *p;
	int32_t ret;

	if (!str) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	strncpy(&i->date_time[0], str, MAX_STR_LEN-1);

	/* Special case: TMGR main thread update it periodically */
	r = _vc_get_gpa_rsrc(VC_INFO_R_PRMS);
	if(!r) {
		pr_error("GPA resource not found\n");
		return 1;
	}

	p = gpa_rsrc_prm_find_oid(r, GET_VC_OID(DATETIME));
	if(!p) {
		pr_error("GPA parameter not found\n");
		return 1;
	}

	ret=_vc_prmtransfer(r, p, 1);
	if(ret)
		return 1;

	return 0;
}

int set_vc_info_vcs_code(uint32_t code)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	i = _VC_PD_INFO(d);
	i->vcs_code = code;

	return 0;
}

int set_vc_info_status(enum vc_status status)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (status < 0 || status >= N_VC_STATUS_ENTRIES) {
		pr_error("Invalid VC status %d\n", status);
		return 1;
	}

	i = _VC_PD_INFO(d);
	i->status = status;

	return 0;
}

int set_vc_info_message(char *msg)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!msg) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	strncpy(&i->message[0], msg, MAX_STR_LEN-1);

	return 0;
}


int set_vc_info_activeref(char *source)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (!source) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	i = _VC_PD_INFO(d);
	strncpy(&i->active_reference[0], source, MAX_STR_LEN-1);

	return 0;
}


int set_vc_info_clock_id(char *id)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	char buf[MAX_STR_LEN];
	char *pb = &(buf[0]);
	const char del[2] = ":";
	int i = 0;
	char *tok;
	uint8_t clockid[8] = {0};

	if (!id) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	/* Create a local copy */
	strncpy(pb, id, MAX_STR_LEN-1);

	/* Convert string representation into data pointer (u8) */
	tok = strtok(pb, del);
	while( tok != NULL ) {
		clockid[i] = (uint8_t) strtol(tok, NULL, 16);
		i++;
		tok = strtok(NULL, del);
	}

	/* Finally, copy it into memory */
	c = _VC_PD_CLKINF(d);
	memcpy(&c->id[0], &clockid[0], 8);

	return 0;
}

int set_vc_info_clock_class(uint8_t class)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->class = class;

	return 0;
}

int set_vc_info_clock_accuracy(uint8_t acc)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->accuracy = acc;

	return 0;
}

int set_vc_info_clock_variance(uint16_t var)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->variance = var;

	return 0;
}

int set_vc_info_priority1(uint8_t p)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->priority1 = p;

	return 0;
}

int set_vc_info_priority2(uint8_t p)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->priority2 = p;

	return 0;
}

int set_vc_info_utc_offset(int16_t offset)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->utc_offset = offset;

	return 0;
}

int set_vc_info_utc_offset_valid(int valid)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->utc_offset_valid = valid;

	return 0;
}

int set_vc_info_time_valid(int valid)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->time_valid = valid;

	return 0;
}

int set_vc_info_freq_valid(int valid)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->freq_valid = valid;

	return 0;
}

int set_vc_info_n_hops(uint16_t n_hops)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_clkinf_passoc_data *c;

	c = _VC_PD_CLKINF(d);
	c->n_hops = n_hops;

	return 0;
}

int set_vc_info_passive_status(enum vc_status ps)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *i;

	if (ps < 0 || ps >= N_VC_STATUS_ENTRIES) {
		pr_error("Invalid VC passive status %d\n", ps);
		return 1;
	}

	i = _VC_PD_INFO(d);
	i->passive_status = ps;

	return 0;
}

int set_vc_info_integrity_leaps(enum vc_status leaps)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_integrity_passoc_data *i;

	if (leaps < 0 || leaps >= N_VC_STATUS_ENTRIES) {
		pr_error("Invalid VC integrity leaps %d\n", leaps);
		return 1;
	}

	i = _VC_PD_INFO_INTEGRITY(d);
	i->leaps = leaps;

	return 0;
}

int set_vc_info_integrity_tod(enum vc_status tod)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_integrity_passoc_data *i;

	if (tod < 0 || tod >= N_VC_STATUS_ENTRIES) {
		pr_error("Invalid VC integrity tod %d\n", tod);
		return 1;
	}

	i = _VC_PD_INFO_INTEGRITY(d);
	i->tod = tod;

	return 0;
}

int32_t sync_vc_gpa_params(int to_prm)
{
	int32_t ret = -ENOSYS;
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_rsrc *r;
	int i;

	if (!d)
		return ret;

	for(i = 0 ; i < N_VC_RESOURCES ; i++) {
		r = _vc_get_gpa_rsrc(i);
		ret = gpa_rsrc_sync(r, to_prm);
		if(ret)
			break;
	}

	return ret;
}

int32_t reset_vc_data(void)
{
	struct vc_gpa_data *d = &vc_gpa_data;
	struct gpa_info_passoc_data *pinfo;
	unsigned int pinfo_size;
	struct gpa_clkinf_passoc_data *clkinfo;
	unsigned int clkinfo_size;
	int32_t ret = -ENOSYS;

	/* Clear Info parameters */
	pinfo = _VC_PD_INFO(d);
	pinfo_size = _VC_PD_INFO_SIZE;
	memset(pinfo, 0, pinfo_size);

	/* Clear Clock Info parameters */
	clkinfo = _VC_PD_CLKINF(d);
	clkinfo_size = _VC_PD_CLKINF_SIZE;
	memset(clkinfo, 0, clkinfo_size);

	ret = sync_vc_gpa_params(1);

	return ret;
}

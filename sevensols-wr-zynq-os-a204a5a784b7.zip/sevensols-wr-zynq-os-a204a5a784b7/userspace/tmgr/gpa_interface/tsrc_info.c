/*
 * tsrc_info.c
 *
 * libGPA-based parameter interface for Time Manager. Timing source parameters.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>
#include <libgpa/util.h>
#include <libgpa/genmem.h>
#include <libgpa/prm_assoc.h>
#include <libgpa/ieee1588.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "vc_policy_foca.h"
#include "ktmgr.h"
#include "ppsi.h"
#include "vcs.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* General */
#define TSRC_INFO_OID_NAME                 1
#define TSRC_INFO_OID_TYPE                 2
#define TSRC_INFO_OID_CODE                 3
#define TSRC_INFO_OID_STATUS               4
#define TSRC_INFO_OID_MESSAGE              5
#define TSRC_INFO_OID_IS_ACTIVE            6
#define TSRC_INFO_OID_PASSIVE_ONLY         7
#define TSRC_INFO_OID_N_CRITICAL_RECENT    10
#define TSRC_INFO_OID_N_CRITICAL_TOTAL     11
#define TSRC_INFO_OID_SRC_RANK             12

/* Developer reserved (set as UNLISTED) */
#define TSRC_INFO_OID_DEV_UPDATE          100

/* Stats */
#define TSRC_INFO_OID_STATS_MEAS_OFFSET    1

#define GET_TSRC_INFO_OID(oid) TSRC_INFO_OID##_##oid
#define TSRC_INFO_PASSOC(oid, vtx, field) .p_oid = GET_TSRC_INFO_OID(oid), GPA_PASSOC_FIELD(GPA_PRM_VTX##_##vtx, field)
#define TSRC_INFO_RSRC_PATH "tsrc_info%d"
#define TSRC_INFO_RSRC_DESC "Timing source info GPA resource"
#define TSRC_INFO_GMEM_RSRC_PATH "gmem"
#define TSRC_INFO_GMEM_RSRC_DESC "Generic memory resource for tsrc_info parameters"

/*
 * Internal structures for GPA parameters of timing source info
 */

struct gpa_stats_passoc_data {
	double meas_offset;
};

struct gpa_gen_passoc_data {
	char name[MAX_STR_LEN];
	enum tsrc_info_type type;
	uint32_t code;
	uint32_t src_rank;
	enum vc_status status;
	char message[MAX_STR_LEN];
	int is_active;
	int passive_only;
	uint32_t n_critical_recent;
	uint32_t n_critical_total;
	uint32_t update;
};

struct gpa_passoc_data {
	struct gpa_gen_passoc_data gen;
	struct gpa_stats_passoc_data stats;
	struct gpa_clkinf_passoc_data clkinf;
};

enum {
	TSRC_INFO_GEN_R_PRMS = 0,
	TSRC_INFO_STATS_R_PRMS,
	TSRC_INFO_CLOCKQ_R_PRMS,
	TSRC_INFO_TPROP_R_PRMS,
	N_TSRC_INFO_RESOURCES,
};

#define _TSRC_INFO_PD(d)                 (&(d->pd))
#define _TSRC_INFO_PD_SIZE               (sizeof(struct gpa_passoc_data))
#define _TSRC_INFO_PD_GEN(d)             (&(d->pd.gen))
#define _TSRC_INFO_PD_GEN_SIZE           (sizeof(struct gpa_gen_passoc_data))
#define _TSRC_INFO_PD_STATS(d)           (&(d->pd.stats))
#define _TSRC_INFO_PD_STATS_SIZE         (sizeof(struct gpa_stats_passoc_data))
#define _TSRC_INFO_PD_CLKINF(d)          (&(d->pd.clkinf))
#define _TSRC_INFO_PD_CLKINF_SIZE        (sizeof(struct gpa_clkinf_passoc_data))
struct tsrc_info_gpa_data {
	/* Data structure for GPA passoc */
	struct gpa_passoc_data pd;

	/* Internal GPA resources */
	struct gpa_rsrc *tsrc;
	struct gpa_rsrc *gmem;
	struct gpa_rsrc *r_prms[N_TSRC_INFO_RESOURCES];
};


#define _GPA_RPRIV_TDEF struct tsrc_info_r_prms_priv
struct tsrc_info_r_prms_priv {
	void *addr;
	size_t sz;

	unsigned int idx;
};

/* Enum association structures */

static struct gpa_passoc_xtra_enum enum_tsrc_info_gen_type =
{
	.type = GPA_PASSOC_EXTRA_TYPE_ENUM,
	.enum_opt = GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
	.n_entries = N_TSRC_INFO_TYPE,
	.entries =
	{
		[TSRC_INFO_TYPE_GM] = "GM",
		[TSRC_INFO_TYPE_GNSS] = "GNSS",
		[TSRC_INFO_TYPE_WR] = "WR",
		[TSRC_INFO_TYPE_PTP] = "PTP",
		[TSRC_INFO_TYPE_FR_HO] = "FR/HO",
	}
};

/* External definitions from vc.c */
extern struct gpa_passoc_xtra_enum enum_vc_status;
extern struct gpa_passoc_xtra_enum enum_bool_yes_no;
extern struct gpa_passoc_grp_cfg passoc_default_rr_none;

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_gen_passoc_data
static struct gpa_passoc_item itms_tsrc_info_gen_passoc[] =
{
	/* Public */
	{TSRC_INFO_PASSOC(NAME, STR, name), .ow_it.acc = GPA_ACC_RT, .desc = "Timing source name"},
	{TSRC_INFO_PASSOC(TYPE, ENUM, type), .ow_it.acc = GPA_ACC_RT, .xdata = &enum_tsrc_info_gen_type, .desc = "Timing source type"},
	{TSRC_INFO_PASSOC(CODE, U32, code), .ow_it.acc = GPA_ACC_RT, .desc = "Timing source VCS code"},
	{TSRC_INFO_PASSOC(STATUS, ENUM, status), .ow_it.acc = GPA_ACC_RT, .xdata = &enum_vc_status, .desc = "Timing source status"},
	{TSRC_INFO_PASSOC(MESSAGE, STR, message), .ow_it.acc = GPA_ACC_RT, .desc = "Timing source message"},
	{TSRC_INFO_PASSOC(IS_ACTIVE, ENUM, is_active), .ow_it.acc = GPA_ACC_RT, .xdata = &enum_bool_yes_no, .desc = "Timing source active flag"},
	{TSRC_INFO_PASSOC(PASSIVE_ONLY, ENUM, passive_only), .ow_it.acc = GPA_ACC_R | TMGR2_ACC, .xdata = &enum_bool_yes_no, .desc = "Timing source passive_only flag"},
	{TSRC_INFO_PASSOC(N_CRITICAL_RECENT, U32, n_critical_recent), .ow_it.acc = GPA_ACC_R | GPA_ACC_EXPERT, .desc = "Timing source recent critical error counter"},
	{TSRC_INFO_PASSOC(N_CRITICAL_TOTAL, U32, n_critical_total), .ow_it.acc = GPA_ACC_R | GPA_ACC_EXPERT, .desc = "Timing source total critical error counter"},
	{TSRC_INFO_PASSOC(SRC_RANK, U32, src_rank), .ow_it.acc = GPA_ACC_RT, .desc = "Timing source source rank"},
	/* Developer reserved */
	{TSRC_INFO_PASSOC(DEV_UPDATE, U32, update), .ow_it.acc = GPA_ACC_R | GPA_ACC_UNLISTED, .desc = "Timing source update counter"},
};

#undef GPA_PASSOC_CURRENT_STRUCT
#define GPA_PASSOC_CURRENT_STRUCT gpa_stats_passoc_data
static struct gpa_passoc_item itms_tsrc_info_stats_passoc[] =
{
	{TSRC_INFO_PASSOC(STATS_MEAS_OFFSET, F64, meas_offset), .ow_it.acc = GPA_ACC_R | TMGR2_ACC, .unit = "s", .desc = "Timing source measured offset"},
};

#undef GPA_PASSOC_CURRENT_STRUCT
extern int32_t vc_status_warning_check(const void *new_value, struct gpa_prm *p,
				uint8_t iwc);
extern void gpa_clkq_passoc_init(struct gpa_rsrc *r);
extern void gpa_tprop_passoc_init(struct gpa_rsrc *r);

/* GPA data for parameters */
static struct tsrc_info_gpa_data tsrc_info_gpa_data[VC_PRIORITY_LENGTH];
static unsigned int num_active_srcs = 0;

static struct tsrc_info_gpa_data *_tsrc_info_get_gpa_data(int tsrc)
{
	struct tsrc_info_gpa_data *d = NULL;

	if(tsrc < 0 || tsrc >= VC_PRIORITY_LENGTH) {
		pr_error("Invalid timing source index %d\n", tsrc);
		return NULL;
	}

	d = &(tsrc_info_gpa_data[tsrc]);

	return d;
}

static struct gpa_rsrc *_tsrc_info_get_gpa_rsrc(int tsrc, int grsrc)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_rsrc *r = NULL;

	if(!d)
		return NULL;

	if(grsrc < 0 || grsrc >= N_TSRC_INFO_RESOURCES) {
		pr_error("Invalid GPA resource index %d\n", grsrc);
		return NULL;
	}

	r = d->r_prms[grsrc];

	return r;
}

static int32_t _tsrc_info_release(struct gpa_rsrc *self)
{
	GPA_RETCHECK_PTR(self,-EFAULT);
	GPA_RSRC_PRIV_GET(self);
	gpa_free(priv);

	return 0;
}

static int32_t _tsrc_info_is_disabled(struct gpa_rsrc* self, struct gpa_prm *p)
{
	struct tsrc_info_r_prms_priv *priv;

	GPA_RETCHECK_PTR(self,-EFAULT);
	GPA_RETCHECK_PTR(self->priv,-EFAULT);

	priv = (struct tsrc_info_r_prms_priv *) self->priv;

	return (priv->idx >= num_active_srcs) ? 1 : 0;
}

static int32_t _tsrc_info_prmsync(struct gpa_rsrc* self, struct gpa_prm *p, int to_prm)
{
	int ret = -ENOSYS;
	GPA_RETCHECK_PTR(p,-EFAULT);
	GPA_RETCHECK_PTR(self,-EFAULT);
	GPA_RETCHECK_PTR(self->priv,-EFAULT);

	GPA_RSRC_PRIV_GET(self);

	/* Get offset inside structure (parameter) */
	int32_t p_addr = gpa_rsrc_prm_get_addr(self,p);
	/* Offset is equal to resource address (base of structure) + parameter offset */
	void * offset = priv->addr + p_addr;

	/* Finally, transfer value */
	ret=gpa_rsrc_transfer_prm(self, offset, p, to_prm);

	return ret;
}

/* Declare an internal libGPA function to use it here */
int32_t _gpa_moddir_add_rsrc(struct gpa_mod *mod,struct gpa_modir * modir,const struct gpa_rsrc* rsrc, int lvl);
static int add_tsrc_info_prms_to_modirs(int instance)
{
	int i;
	int idx = instance+1;
	char modir_path[MAX_STR_LEN];
	struct gpa_rsrc *r;
	struct gpa_modir *modir;
	struct {
		char *name;
		char *path;
	} aux[N_TSRC_INFO_RESOURCES] = {
		[TSRC_INFO_GEN_R_PRMS]    = {.name = "general", .path = TSRC_INFO_MODIR_PATH},
		[TSRC_INFO_STATS_R_PRMS]  = {.name = "stats", .path = TSRC_INFO_MODIR_STATS_PATH},
		[TSRC_INFO_CLOCKQ_R_PRMS] = {.name = "clockQ", .path = TSRC_INFO_MODIR_CLOCKQ_PATH},
		[TSRC_INFO_TPROP_R_PRMS]  = {.name = "time_properties", .path = TSRC_INFO_MODIR_TPROP_PATH},
	};

	for(i = 0 ; i < N_TSRC_INFO_RESOURCES ; i++) {
		snprintf(modir_path, MAX_STR_LEN-1, aux[i].path, idx);
		modir = gpa_modir_getobj_path(tmgr_mod, modir_path);
		if(!modir)
			return 1;

		r = _tsrc_info_get_gpa_rsrc(instance, i);
		if(!r)
			return 1;

		if(_gpa_moddir_add_rsrc(tmgr_mod, modir, r, 0)) {
			pr_error("Error associating tsrc_info %s parameters to %s\n",
				aux[i].name, modir_path);
			return 1;
		}
	}

	return 0;
}

static int create_tsrc_info_inst_params(int instance)
{
	struct tsrc_info_gpa_data *gdata;
	struct gpa_passoc_rsrc_cfg pcfg;
	struct gpa_rsrc *r;
	struct gpa_prm *param;
	int idx = instance+1;
	uint8_t opt_flg = GPA_1588_CLK_OPT_TRACKED | GPA_1588_CLK_OPT_TSRC;
	char buf[MAX_STR_LEN];
	char * r_name[N_TSRC_INFO_RESOURCES] = {
		[TSRC_INFO_GEN_R_PRMS]    = "gen_passoc",
		[TSRC_INFO_STATS_R_PRMS]  = "stats_passoc",
	};
	struct tsrc_info_r_prms_priv *priv;

	gdata = _tsrc_info_get_gpa_data(instance);
	if(!gdata)
		goto exit_create2;

	// Create GPA resource for timing source info
	snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_RSRC_PATH, idx);
	gdata->tsrc = gpa_rsrc_create(buf, TSRC_INFO_RSRC_DESC,
				GPA_RSRC_TYPE_PRIVATE,GPA_CELL_ENDIANNESS_TYPE_BIG);
	if(!gdata->tsrc)
		goto exit_create1;

	gpa_rsrc_append_child(tmgr_mod->root_rsrc, gdata->tsrc);

	/* Initialize gmem resource name for tsrc_info parameters */
	snprintf(buf, MAX_STR_LEN-1, TSRC_INFO_GMEM_RSRC_PATH);

	/* Create gmem resource for tsrc_info parameters */
	gdata->gmem = gpa_rsrc_genmem_create(gdata->tsrc, buf, _TSRC_INFO_PD(gdata),
					_TSRC_INFO_PD_SIZE, TSRC_INFO_GMEM_RSRC_DESC,
					NULL);
	if(!gdata->gmem)
		goto exit_create1;

	/* Fill passoc resource config */
	snprintf(buf, MAX_STR_LEN-1, r_name[TSRC_INFO_GEN_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _TSRC_INFO_PD_GEN(gdata);
	pcfg.size = _TSRC_INFO_PD_GEN_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_tsrc_info_gen_passoc);
	pcfg.items = itms_tsrc_info_gen_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[TSRC_INFO_GEN_R_PRMS] = gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[TSRC_INFO_GEN_R_PRMS];
	if(!r)
	        goto exit_create1;

	r->priv = calloc(1, sizeof(struct tsrc_info_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct tsrc_info_r_prms_priv *) r->priv;
	priv->addr = _TSRC_INFO_PD_GEN(gdata);
	priv->sz = _TSRC_INFO_PD_GEN_SIZE;
	priv->idx = instance;

	r->prm_sync = _tsrc_info_prmsync;
	r->is_disabled= _tsrc_info_is_disabled;
	r->on_release = _tsrc_info_release;

	/* Search status param and assign custom check function */
	param = gpa_rsrc_prm_find_oid(r, GET_TSRC_INFO_OID(STATUS));
	gpa_prm_set_custom_check_range(param, vc_status_warning_check);

	/* Fill passoc resource config */
	snprintf(buf, MAX_STR_LEN-1, r_name[TSRC_INFO_STATS_R_PRMS]);

	memset(&pcfg, 0, sizeof(pcfg));
	pcfg.ikey = &(buf[0]);
	pcfg.r_addr = _TSRC_INFO_PD_STATS(gdata);
	pcfg.size = _TSRC_INFO_PD_STATS_SIZE;
	pcfg.nitems = GPA_ARRAY_SIZE(itms_tsrc_info_stats_passoc);
	pcfg.items = itms_tsrc_info_stats_passoc;
	pcfg.gcfg = &passoc_default_rr_none;

	/* Create passoc resource for genmem */
	gdata->r_prms[TSRC_INFO_STATS_R_PRMS] = gpa_rsrc_passoc_create(gdata->gmem, &pcfg);
	r = gdata->r_prms[TSRC_INFO_STATS_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct tsrc_info_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct tsrc_info_r_prms_priv *) r->priv;
	priv->addr = _TSRC_INFO_PD_STATS(gdata);
	priv->sz = _TSRC_INFO_PD_STATS_SIZE;
	priv->idx = instance;

	r->prm_sync = _tsrc_info_prmsync;
	r->is_disabled= _tsrc_info_is_disabled;
	r->on_release = _tsrc_info_release;

	/* Create clockQ and time_properties (IEEE1588) GPA resources */
	gdata->r_prms[TSRC_INFO_CLOCKQ_R_PRMS] = gpa_rsrc_1588_clk_Q_create(gdata->gmem,opt_flg);
	r = gdata->r_prms[TSRC_INFO_CLOCKQ_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct tsrc_info_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct tsrc_info_r_prms_priv *) r->priv;
	priv->addr = _TSRC_INFO_PD_CLKINF(gdata);
	priv->sz = _TSRC_INFO_PD_CLKINF_SIZE;
	priv->idx = instance;

	r->prm_sync = _tsrc_info_prmsync;
	r->is_disabled= _tsrc_info_is_disabled;
	r->on_release = _tsrc_info_release;

	gpa_clkq_passoc_init(r);

	gdata->r_prms[TSRC_INFO_TPROP_R_PRMS] = gpa_rsrc_1588_clk_tprop_create(gdata->gmem,opt_flg);
	r = gdata->r_prms[TSRC_INFO_TPROP_R_PRMS];
	if(!r)
		goto exit_create1;

	r->priv = calloc(1, sizeof(struct tsrc_info_r_prms_priv));
	if(!r->priv)
		goto exit_create1;

	priv = (struct tsrc_info_r_prms_priv *) r->priv;
	priv->addr = _TSRC_INFO_PD_CLKINF(gdata);
	priv->sz = _TSRC_INFO_PD_CLKINF_SIZE;
	priv->idx = instance;

	r->prm_sync = _tsrc_info_prmsync;
	r->is_disabled= _tsrc_info_is_disabled;
	r->on_release = _tsrc_info_release;

	gpa_tprop_passoc_init(r);

	return add_tsrc_info_prms_to_modirs(instance);

exit_create1:
	if(gdata->tsrc)
		gpa_rsrc_release(gdata->tsrc);

exit_create2:
	return 1;
}

int create_tsrc_info_params(void)
{
	int i;
	int ret = 0;

	for(i = 0 ; i < VC_PRIORITY_LENGTH ; i++) {
		ret = create_tsrc_info_inst_params(i);
		if(ret) {
			pr_error("Error creating tsrc_info parameters for instance %d\n", i);
			break;
		}
	}

	return ret;
}

/********** Setter functions **********/

int set_tsrc_info_name(int tsrc, char *name)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	if (!name) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	g = _TSRC_INFO_PD_GEN(d);
	strncpy(&g->name[0], name, MAX_STR_LEN-1);

	return 0;
}

int set_tsrc_info_type(int tsrc, enum tsrc_info_type type)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	if (type < 0 || type >= N_TSRC_INFO_TYPE) {
		pr_error("Invalid type %d\n", type);
		return 1;
	}

	g = _TSRC_INFO_PD_GEN(d);
	g->type = type;

	return 0;
}

int set_tsrc_info_active_status(int tsrc, int ia)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	g = _TSRC_INFO_PD_GEN(d);
	g->is_active = ia;

	return 0;
}

int set_tsrc_info_vcs_code(int tsrc, uint32_t code)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	g = _TSRC_INFO_PD_GEN(d);
	g->code = code;

	return 0;
}

int set_tsrc_info_src_rank(int tsrc, uint32_t src_rank)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	g = _TSRC_INFO_PD_GEN(d);
	g->src_rank = src_rank;

	return 0;
}

int set_tsrc_info_status(int tsrc, enum vc_status status)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	if (status < 0 || status >= N_VC_STATUS_ENTRIES) {
		pr_error("Invalid status %d\n", status);
		return 1;
	}

	g = _TSRC_INFO_PD_GEN(d);
	g->status = status;

	return 0;
}

int set_tsrc_info_message(int tsrc, char *msg)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	if (!msg) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	g = _TSRC_INFO_PD_GEN(d);
	strncpy(&g->message[0], msg, MAX_STR_LEN-1);

	return 0;
}

int update_tsrc_info_counter(int tsrc)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_gen_passoc_data *g;

	if(!d)
		return 1;

	g = _TSRC_INFO_PD_GEN(d);
	g->update++;

	return 0;
}

int set_tsrc_info_clock_id(int tsrc, char *id)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	char buf[MAX_STR_LEN];
	char *pb = &(buf[0]);
	const char del[2] = ":";
	int i = 0;
	char *tok;
	uint8_t clockid[8] = {0};

	if(!d)
		return 1;

	if (!id) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	/* Create a local copy */
	strncpy(pb, id, MAX_STR_LEN-1);

	/* Convert string representation into data pointer (u8) */
	tok = strtok(pb, del);
	while( tok != NULL ) {
		clockid[i] = (uint8_t) strtol(tok, NULL, 16);
		i++;
		tok = strtok(NULL, del);
	}

	/* Finally, copy it into memory */
	c = _TSRC_INFO_PD_CLKINF(d);
	memcpy(&c->id[0], &clockid[0], 8);

	return 0;
}

int set_tsrc_info_clock_class(int tsrc, uint8_t class)
{

	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->class = class;

	return 0;
}

int set_tsrc_info_clock_accuracy(int tsrc, uint8_t acc)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->accuracy = acc;

	return 0;
}

int set_tsrc_info_clock_variance(int tsrc, uint16_t var)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->variance = var;

	return 0;
}

int set_tsrc_info_priority1(int tsrc, uint8_t prio)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->priority1 = prio;

	return 0;
}

int set_tsrc_info_priority2(int tsrc, uint8_t prio)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->priority2 = prio;

	return 0;
}

int set_tsrc_info_utc_offset(int tsrc, int16_t offset)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->utc_offset = offset;

	return 0;
}

int set_tsrc_info_utc_offset_valid(int tsrc, int valid)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->utc_offset_valid = valid;

	return 0;
}

int set_tsrc_info_time_valid(int tsrc, int valid)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->time_valid = valid;

	return 0;
}

int set_tsrc_info_freq_valid(int tsrc, int valid)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->freq_valid = valid;

	return 0;
}

int set_tsrc_info_n_hops(int tsrc, uint16_t n_hops)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_clkinf_passoc_data *c;

	if(!d)
		return 1;

	c = _TSRC_INFO_PD_CLKINF(d);
	c->n_hops = n_hops;

	return 0;
}

int32_t sync_tsrc_info_gpa_params(int tsrc)
{
	int32_t ret = -ENOSYS;
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_rsrc *r;
	int i;

	if (!d)
		return ret;

	for(i = 0 ; i < N_TSRC_INFO_RESOURCES ; i++) {
		/* Sync from memory to GPA parameters */
		r = _tsrc_info_get_gpa_rsrc(tsrc, i);
		ret = gpa_rsrc_sync(r, 1);
		if(ret)
			break;
	}

	return ret;
}

int set_tsrc_info_num_active_srcs(unsigned int n)
{
	if (n > VC_PRIORITY_LENGTH)
		return 1;

	num_active_srcs = n;

	return 0;
}

int32_t reset_tsrc_info_data(int tsrc)
{
	struct tsrc_info_gpa_data *d = _tsrc_info_get_gpa_data(tsrc);
	struct gpa_passoc_data *p;
	unsigned int sp;
	int32_t ret = -ENOSYS;

	if(!d)
		return ret;

	p = _TSRC_INFO_PD(d);
	sp = _TSRC_INFO_PD_SIZE;

	memset(p, 0, sp);
	ret = sync_tsrc_info_gpa_params(tsrc);

	return ret;
}

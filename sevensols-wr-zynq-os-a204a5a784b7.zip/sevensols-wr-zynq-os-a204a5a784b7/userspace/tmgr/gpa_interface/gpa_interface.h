#ifndef __GPA_INTERFACE_H__
#define __GPA_INTERFACE_H__

/*
 * gpa_interface.h
 *
 * libGPA-based parameter interface for Time Manager.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>

#include "hald.h"
#include "preset.h"

/*
 * HOW TO USE THIS
 * ===============
 *
 * This API is meant to abstract most of the libgpa-related cruft for the Time
 * Manager logic, replacing it with still ugly (but simpler) cruft.
 *
 * For each read/write parameter there's a getter and a setter function named
 * <get_modir_parameter> and <set_modir_parameter> respectively. Some parameters
 * are not supposed to be modified, so the have a getter function only.
 *
 * The parameters can be grossly classified (from an interface perspective) in
 * two groups: Input and output parameters.
 *
 * - Input parameters are used by the Time Manager clients (the web interface,
 *     for instance) to communicate to the Time Manager, for example, by setting
 *     an option or changing a configuration parameter. Everything under
 *     <config> as well as the writable port parameters are examples of input
 *     parameters.
 *
 * - Output parameters are the way the Time Manager has to publish information
 *     to the clients. These parameters are read-only from outside. Everything
 *     under <info> and <virtualclock> is an output parameter.
 *
 * Any parameter can be read at any time. Additionally, the input parameters can
 * be modified by any client. Just keep in mind that in order to apply the
 * changes done to the input parameters you have to set the
 * <config/update_config> flag to notify the Time Manager about the config
 * change and let it apply the changes in a safe way (this is further explained
 * in gpa_interface.c -> TECHNICAL DETAILS).
 */


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/*
 * Maximum allowed time offset difference between system and NTP reference
 * server.
 *
 * TODO: Set this as a configurable libgpa parameter?
 */
#define NTP_DRIFT_THRESHOLD             1.0f

enum pps_mode {
	PPS_MODE_TMGR_ALWAYS_ON,
	PPS_MODE_TMGR_ONLY_LOCKED,
	PPS_MODE_TMGR_LEGACY,
	N_PPS_MODES,
};

/* Virtual clock STATUS states */
enum vc_status {
	VC_STATUS_DISABLED,
	VC_STATUS_OK,
	VC_STATUS_WARNING,
	VC_STATUS_ERROR,
	N_VC_STATUS_ENTRIES,
};

enum port_proto {
	PORT_PROTO_DISABLED,
	PORT_PROTO_WR,
	PORT_PROTO_PTP,
	N_PORT_PROTOS,
};

enum port_mode {
	PORT_MODE_MASTER,
	PORT_MODE_SLAVE,
	PORT_MODE_AUTO,
	N_PORT_MODES,
};

enum port_status {
	PORT_STATUS_SLAVE,
	PORT_STATUS_MASTER,
	PORT_STATUS_PASSIVE,
	PORT_STATUS_DISABLED,
	N_PORT_STATUS
};

enum tsrc_info_type {
	TSRC_INFO_TYPE_GM,
	TSRC_INFO_TYPE_GNSS,
	TSRC_INFO_TYPE_WR,
	TSRC_INFO_TYPE_PTP,
	TSRC_INFO_TYPE_FR_HO,
	N_TSRC_INFO_TYPE
};

enum ntp_status {
	NTP_STATUS_NONE,
	NTP_STATUS_OK,
	NTP_STATUS_NOT_SYNC,
	NTP_STATUS_STOP_REPLY,

	N_NTP_STATUS
};

enum ntp_stratum_mode {
	NTP_STRATUM_MODE_AUTO,
	NTP_STRATUM_MODE_MANUAL,

	N_NTP_STRATUM_MODE
};

enum ntp_stratum {
	NTP_STRATUM_1 = 1,
	NTP_STRATUM_2 = 2,
	NTP_STRATUM_3 = 3,
	NTP_STRATUM_3E = 4,
	NTP_STRATUM_4 = 5,
	NTP_STRATUM_4E = 6,
	NTP_STRATUM_15 = 15,
	NTP_STRATUM_UNDEFINED = 16,

	N_NTP_STRATUM = 8
};

enum gm_time_source {
	GM_TIME_SOURCE_UNDEF = _GPA_1588_SRC_UNDEF,
	GM_TIME_SOURCE_ATOMIC_CLOCK = GPA_1588_SRC_ATOMIC_CLOCK,
	GM_TIME_SOURCE_GNSS = GPA_1588_SRC_GNSS,
	GM_TIME_SOURCE_PTP = GPA_1588_SRC_PTP,
	GM_TIME_SOURCE_OTHER = GPA_1588_SRC_OTHER,

	N_GM_TIME_SOURCES = 5
};

enum gm_pps_mandatory {
	GM_PPS_MANDATORY_YES,
	GM_PPS_MANDATORY_NO,
	GM_PPS_MANDATORY_STARTUP_ONLY,

	N_GM_PPS_MANDATORY
};

enum holdover_force_trigger {
	HO_FORCE_TRIGGER_STOP,
	HO_FORCE_TRIGGER_START,
	HO_FORCE_TRIGGER_NONE,

	N_HO_FORCE_TRIGGER
};


struct modir_def {
	uint16_t oid;
	char *mp;
	uint8_t xval;
};


/************************************************************
 * External declarations                                    *
 ************************************************************/

extern struct modir_def modir_array[];


/************************************************************
 * Public API                                               *
 ************************************************************/

/*
 * tmgr_create_mod_owner
 *
 * Create the tmgr owner module, including modirs and parameters set to their
 * default values.
 *
 * Parameters:
 *   - test_enabled: 1 to enable the automated test functionality (creates an
 *                     additional modir)
 *                   0 to disable it.
 *   - release: Release function for GPA resource.
 *   - priv: Private information for release.
 *   - v_maj, v_min: Major and Minor version.
 *
 * Returns a pointer to the singleton struct gpa_mod representing the module.
 */
struct gpa_mod *tmgr_create_mod_owner(int test_enabled,
				int32_t (*release)(struct gpa_rsrc *), void *priv,
				uint16_t v_maj, uint16_t v_min);
void tmgr_close_mod_owner(void);

/*
 * tmgr_handler_loop
 *
 * Runs the application event loop. Takes care of checking the module mailbox
 * and abstract the required runtime libgpa requirements.
 *
 * Parameters:
 *   - f: A function to be called at every iteration (no parameters).
 *   - ts: Loop period.
 */
void tmgr_handler_loop(void (*f)(void), struct timespec *ts);

/*
 * tmgr_handler_mb_only_loop
 *
 * Check the module mailbox and abstract the required runtime libgpa requirements.
 *
 * Parameters:
 *   - ts: Loop period.
 */
void tmgr_handler_mb_only_loop(struct timespec *ts);

/*
 * tmgr_handler_no_mb_loop
 *
 * Runs the application event loop without handling libgpa mailbox.
 *
 * Parameters:
 *   - f: A function to be called at every iteration (no parameters).
 *   - ts: Loop period.
 */
void tmgr_handler_no_mb_loop(void (*f)(void), struct timespec *ts);





void init_tmgr_hald_pps_mode(enum pps_mode m);

/********** Getter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */


/* General Time Manager parameters */
int get_tmgr_config_pps_mode(uint32_t *);
int get_tmgr_info_uptime(uint64_t *);
int get_tmgr_config_update(int *);
int get_tmgr_config_preset(uint32_t *);


/* Virtual clock parameters */
int get_vc_cfg_policy(uint16_t *);
int get_vc_cfg_foca_strategy(uint16_t *);
int get_vc_info_datetime(const char **);
int get_vc_info_vcs_code(uint32_t *);
int get_vc_info_message(const char **);
int get_vc_info_status(enum vc_status *);
int get_vc_info_activeref(const char **);
int get_vc_info_clock_class(uint8_t *);
int get_vc_info_clock_accuracy(uint8_t *);
int get_vc_info_clock_variance(uint16_t *);
int get_vc_info_priority1(uint8_t *);
int get_vc_info_priority2(uint8_t *);
int get_vc_info_passive_status(enum vc_status *);
int get_vc_info_integrity_leaps(enum vc_status *);
int get_vc_info_integrity_tod(enum vc_status *);


/* GrandMaster mode parameters */
int get_gm_info_align_state(enum softpll_align_state *);
int get_gm_info_detected(enum softpll_ext_fpanel *);
int get_gm_info_pps_delta(int32_t *);
int get_gm_config_align_pps(int *);
int get_gm_config_offset(int32_t *);
int get_gm_config_force_clock_class(uint8_t *);
int get_gm_config_clock_accuracy(uint8_t *);
int get_gm_config_time_source(enum gm_time_source *);
int get_gm_config_priority1(uint8_t *);
int get_gm_config_priority2(uint8_t *);
int get_gm_config_pps_mandatory(enum gm_pps_mandatory *);
int get_gm_config_src_rank(uint32_t *);

/* GNSS mode parameters */
int get_gnss_info_align_state(enum softpll_align_state *);
int get_gnss_info_detected(enum softpll_ext_fpanel *);
int get_gnss_config_offset(int32_t *);
int get_gnss_config_priority1(uint8_t *);
int get_gnss_config_priority2(uint8_t *);
int get_gnss_config_src_rank(uint32_t *);


/* Port functions */

/*
 * Validates and corrects (if necessary) the new port configuration. It uses the
 * <port_config_is_valid> function to check if the port configuration is correct
 * for each port.
 *
 * If a configuration change in one of the ports is not valid, it's reverted to
 * its previous state. If it's ok, the current_port_mode value for that port is
 * updated.
 *
 * Note that if there are more than one conflicting interfaces in the
 * configuration, the first one (in interface discovery order) will prevail.
 */
void check_port_config(void);

/*
 * Port parameters.
 * First parameter is the port number.
 */
int get_port_name(unsigned int p, const char **name);
int get_port_proto(unsigned int p, enum port_proto *proto);
int get_port_mode(unsigned int p, enum port_mode *mode);
int get_port_src_rank(unsigned int p, uint32_t *rank);
int get_port_status(unsigned int p, enum port_status *status);
int get_port_profile(unsigned int p, const char **profile);
int get_port_rank(unsigned int p, uint32_t *rank);
int get_port_refresh_all(void);


/* NTP parameters */
#define get_ntp_server0_config_ip(ip) get_ntp_server_config_ip(0,ip)
int get_ntp_server_config_ip(int, const char **);
int get_ntp_config_provider_enabled(int *);
int get_ntp_config_refresh_rate(uint32_t *);
int get_ntp_config_retries(uint32_t *);
#define get_ntp_server0_info_offset(offset) get_ntp_server_info_offset(0, offset)
int get_ntp_server_info_offset(int, float *);


/* Holdover parameters */
int get_ho_config_force_trigger(enum holdover_force_trigger *);
int get_ho_config_src_rank(uint32_t *);
int get_ho_config_force_fr(int *);
int get_ho_info_time_learning(uint32_t *);
int get_ho_info_time_holdover(uint32_t *);
int get_ho_info_state(enum ho_state *);
int get_ho_info_trigger_origin(enum ho_trig *);
int get_ho_info_state_time(uint32_t *);
/*
int get_ho_info_expired(uint32_t *);
*/


/* Switchover parameters */
int get_so_config_enable(int *);


/* Test parameters */
int get_test_start(int *);



/********** Setter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   value to store
 *
 * Return:
 *   0: success
 *   1: error
 */

/* General Time Manager parameters */
int set_tmgr_info_uptime(uint64_t);
int set_tmgr_config_update(int);
int set_tmgr_config_preset(uint32_t);
int set_tmgr_autoload_preset(int);


/* Virtual clock parameters */
int set_vc_info_datetime(char *);
int set_vc_info_vcs_code(uint32_t);
int set_vc_info_status(enum vc_status);
int set_vc_info_message(char *);
int set_vc_info_activeref(char *);
int set_vc_info_clock_id(char *);
int set_vc_info_clock_class(uint8_t);
int set_vc_info_clock_accuracy(uint8_t);
int set_vc_info_clock_variance(uint16_t);
int set_vc_info_priority1(uint8_t);
int set_vc_info_priority2(uint8_t);
int set_vc_info_utc_offset(int16_t);
int set_vc_info_utc_offset_valid(int);
int set_vc_info_time_valid(int);
int set_vc_info_freq_valid(int);
int set_vc_info_n_hops(uint16_t);
int set_vc_info_passive_status(enum vc_status);
int set_vc_info_integrity_leaps(enum vc_status);
int set_vc_info_integrity_tod(enum vc_status);
int32_t sync_vc_gpa_params(int to_prm);
int32_t reset_vc_data(void);

/* Timing source parameters */
int set_tsrc_info_name(int, char *);
int set_tsrc_info_type(int, enum tsrc_info_type);
int set_tsrc_info_active_status(int, int);
int set_tsrc_info_vcs_code(int, uint32_t);
int set_tsrc_info_src_rank(int, uint32_t);
int set_tsrc_info_status(int, enum vc_status);
int set_tsrc_info_message(int, char *);
int update_tsrc_info_counter(int);
int set_tsrc_info_clock_id(int, char *);
int set_tsrc_info_clock_class(int, uint8_t);
int set_tsrc_info_clock_accuracy(int, uint8_t);
int set_tsrc_info_clock_variance(int, uint16_t);
int set_tsrc_info_priority1(int, uint8_t);
int set_tsrc_info_priority2(int, uint8_t);
int set_tsrc_info_utc_offset(int, int16_t);
int set_tsrc_info_utc_offset_valid(int, int);
int set_tsrc_info_time_valid(int, int);
int set_tsrc_info_freq_valid(int, int);
int set_tsrc_info_n_hops(int, uint16_t);
int32_t sync_tsrc_info_gpa_params(int);
int set_tsrc_info_num_active_srcs(unsigned int);
int32_t reset_tsrc_info_data(int tsrc);

/* GrandMaster mode parameters */
int set_gm_info_align_state(enum softpll_align_state);
int set_gm_info_detected(enum softpll_ext_fpanel);
int set_gm_info_pps_delta(int32_t);
int set_gm_info_message(char *);
int set_gm_info_leapsec_file_exp_date(char *);
int update_gm_info_leapsec_file_exp_date(void);
int set_gm_info_leapsec_file_valid(int);
int set_gm_config_align_pps(int);
int set_gm_config_offset(int32_t);
int set_gm_config_clock_class(uint8_t);
int set_gm_config_clock_accuracy(uint32_t);
int set_gm_config_priority1(uint8_t);
int set_gm_config_priority2(uint8_t);
int set_gm_config_src_rank(uint32_t);
void reset_gm_info(void);

/* GNSS mode parameters */
int set_gnss_info_align_state(enum softpll_align_state);
int set_gnss_info_detected(enum softpll_ext_fpanel);
int set_gnss_info_status(char *);
int set_gnss_config_priority1(uint8_t);
int set_gnss_config_priority2(uint8_t);
int set_gnss_config_src_rank(uint32_t);


/*
 * Port parameters.
 * First parameter is the port number.
 */
int set_port_src_rank(unsigned int p, uint32_t rank);
int set_port_proto(unsigned int p, enum port_proto proto);
int set_port_mode(unsigned int p, enum port_mode mode);
int set_port_status(unsigned int p, enum port_status status);
int set_port_profile(unsigned int p, char *profile);
int set_port_rank(unsigned int p, uint32_t rank);


/* NTP parameters */
#define set_ntp_server0_config_ip(ip) set_ntp_server_config_ip(0,ip)
int set_ntp_server_config_ip(int, char *);
int set_ntp_config_provider_enabled(int);
int set_ntp_config_refresh_rate(uint32_t);
int set_ntp_config_retries(uint32_t);
#define set_ntp_server0_info_offset(offset) set_ntp_server_info_offset(0,offset)
int set_ntp_server_info_offset(int, float);
#define set_ntp_server0_info_server_status(status) set_ntp_server_info_server_status(0, status)
int set_ntp_server_info_server_status(int, enum ntp_status);
void reset_ntp_info(void);


/* Holdover parameters */
int set_ho_config_force_trigger(enum holdover_force_trigger);
int set_ho_config_src_rank(uint32_t);
int set_ho_info_time_learning(uint32_t);
int set_ho_info_time_holdover(uint32_t);
int set_ho_info_state(enum ho_state);
int set_ho_info_trigger_origin(enum ho_trig);
int set_ho_info_state_time(uint32_t);
/*
int set_ho_info_expired(uint32_t);
*/


/* Switchover parameters */
int set_so_config_enable(int);


/* Test parameters */
int set_test_start(int);



/********** Other functions **********/

/*
 * These functions are not mapped to a gpa parameter.
 */

/*
 * get_nports
 *
 * Returns the number of ports found and configured.
 */
int get_nports(void);

/*
 * Get the interface name for a specific port
 *
 * Returns 0 if everything is OK and an error code otherwise.
 */
int get_port_iface_name(unsigned int p,char **name);

/*
 * Initialize ports info
 *
 * Returns 0 if everything is OK and an error code otherwise.
 */
int initialize_ports_info(void);

/*
 * Updates all the cached parameters by calling their getter functions and then
 * clears the update flag.
 */
void load_config(void);

/*
 * Stops the Time Manager handler loop
 */
void tmgr_handler_stop(void);

/* DEBUG ONLY */
void tmgr_print_mod_tree(void);

#endif

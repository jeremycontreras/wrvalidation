#ifndef __GPA_COMMON_H__
#define __GPA_COMMON_H__

/*
 * gpa_common.h
 *
 * libGPA-based parameter interface for Time Manager. Common definitions
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 11, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdint.h>

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* Maximum number of modirs */
#define MAX_MODIRS 400

/* Length of VC priority list */
#define VC_PRIORITY_LENGTH 5

/* Max number of NTP servers */
#define MAX_NTP_SERVERS 1

/* Mark as unlisted/expert parameters for TMGR2 */
#if _DDEBUG
#define TMGR2_ACC GPA_ACC_EXPERT
#else
#define TMGR2_ACC GPA_ACC_UNLISTED
#endif

/* TMGR general cfg modir */
#define CFG_MODIR_OID                       1100
#define CFG_MODIR_PATH                      "./cfg"

/* Virtual Clock modirs */
#define VCLOCK_MODIR_OID                    1200
#define VCLOCK_MODIR_PATH                   "./vclock"
#define VCLOCK_CFG_MODIR_OID                1210
#define VCLOCK_CFG_MODIR_PATH               VCLOCK_MODIR_PATH "/cfg"
#define VCLOCK_CFG_FOCA_MODIR_OID           1211
#define VCLOCK_CFG_FOCA_MODIR_PATH          VCLOCK_CFG_MODIR_PATH "/foca"
#define VCLOCK_INFO_MODIR_OID               1220
#define VCLOCK_INFO_MODIR_PATH              VCLOCK_MODIR_PATH "/info"
#define VCLOCK_INFO_INTEGRITY_MODIR_OID     1250
#define VCLOCK_INFO_INTEGRITY_MODIR_PATH    VCLOCK_INFO_MODIR_PATH "/integrity"
#define VCLOCK_INFO_CLKQ_MODIR_OID          1230
#define VCLOCK_INFO_CLKQ_MODIR_PATH         VCLOCK_INFO_MODIR_PATH "/Q"
#define VCLOCK_INFO_TPROP_MODIR_OID         1240
#define VCLOCK_INFO_TPROP_MODIR_PATH        VCLOCK_INFO_MODIR_PATH "/time_properties"

/* TSRC modirs */
#define TSRC_INFO_BASE_MODIR_OID            1300
#define TSRC_INFO_BASE_MODIR_PATH           "./tsrc_info"
#define TSRC_INFO_REL_OID                   10
#define TSRC_INFO_CLOCKQ_REL_OID            1
#define TSRC_INFO_TPROP_REL_OID             2
#define TSRC_INFO_STATS_REL_OID             3
#define TSRC_INFO_MODIR_PATH                TSRC_INFO_BASE_MODIR_PATH "/%d"
#define TSRC_INFO_MODIR_CLOCKQ_PATH         TSRC_INFO_MODIR_PATH "/Q"
#define TSRC_INFO_MODIR_TPROP_PATH          TSRC_INFO_MODIR_PATH "/time_properties"
#define TSRC_INFO_MODIR_STATS_PATH          TSRC_INFO_MODIR_PATH "/stats"

/* Port modirs */
#define PORTS_IFACE_BASE_MODIR_OID          1900 /* Special value for main (net) modir */
#define PORTS_IFACE_BASE_MODIR_PATH         "./net"
#define PORTS_IFACE_OID                     2000
#define PORTS_IFACE_REL_OID                 100
#define PORTS_CONFIG_REL_OID                10
#define PORTS_INFO_REL_OID                  10
#define PORTS_IFACE_MODIR_PATH              PORTS_IFACE_BASE_MODIR_PATH "/%s"
#define PORTS_CONFIG_MODIR_PATH             PORTS_IFACE_MODIR_PATH "/cfg"
#define PORTS_INFO_MODIR_PATH               PORTS_IFACE_MODIR_PATH "/info"

/* NTP modirs */
#define NTP_MODIR_OID                       7000
#define NTP_MODIR_PATH                      "./ntp"
#define NTP_CFG_MODIR_OID                   7001
#define NTP_CFG_MODIR_PATH                  NTP_MODIR_PATH "/cfg"
#define NTP_INFO_MODIR_OID                  7002
#define NTP_INFO_MODIR_PATH                 NTP_MODIR_PATH "/info"
#define NTP_CFG_PROVIDER_MODIR_OID          7005
#define NTP_CFG_PROVIDER_MODIR_PATH         NTP_CFG_MODIR_PATH "/provider"
#define NTP_INFO_PROVIDER_MODIR_OID         7006
#define NTP_INFO_PROVIDER_MODIR_PATH        NTP_INFO_MODIR_PATH "/provider"
#define NTP_SERVER_REL_OID                  10
#define NTP_SERVER_CFG_REL_OID              0
#define NTP_SERVER_CFG_AUTH_REL_OID         1
#define NTP_SERVER_INFO_REL_OID             5
#define NTP_SERVER_MODIR_PATH               NTP_MODIR_PATH "/%d"
#define NTP_SERVER_CFG_MODIR_PATH           NTP_SERVER_MODIR_PATH "/cfg"
#define NTP_SERVER_CFG_AUTH_MODIR_PATH      NTP_SERVER_CFG_MODIR_PATH "/auth"
#define NTP_SERVER_INFO_MODIR_PATH          NTP_SERVER_MODIR_PATH "/info"

/* GM modirs */
#define GM_MODIR_OID                        7100
#define GM_MODIR_PATH                       "./gm"
#define GM_CFG_MODIR_OID                    7110
#define GM_CFG_MODIR_PATH                   GM_MODIR_PATH "/cfg"
#define GM_INFO_MODIR_OID                   7120
#define GM_INFO_MODIR_PATH                  GM_MODIR_PATH "/info"

/* GNSS modirs */
#define GNSS_MODIR_OID                      7300
#define GNSS_MODIR_PATH                     "./gnss"
#define GNSS_CFG_MODIR_OID                  7310
#define GNSS_CFG_MODIR_PATH                 GNSS_MODIR_PATH "/cfg"
#define GNSS_INFO_MODIR_OID                 7320
#define GNSS_INFO_MODIR_PATH                GNSS_MODIR_PATH "/info"

/* Holdover modirs */
#define HO_MODIR_OID                        7200
#define HO_MODIR_PATH                       "./holdover"
#define HO_CFG_MODIR_OID                    7210
#define HO_CFG_MODIR_PATH                   HO_MODIR_PATH "/cfg"
#define HO_INFO_MODIR_OID                   7220
#define HO_INFO_MODIR_PATH                  HO_MODIR_PATH "/info"

/* Misc modirs */
#define MISC_MODIR_OID                      8000
#define MISC_MODIR_PATH                     "./misc"
#define MISC_CFG_MODIR_OID                  8010
#define MISC_CFG_MODIR_PATH                 MISC_MODIR_PATH "/cfg"
#define MISC_INFO_MODIR_OID                 8020
#define MISC_INFO_MODIR_PATH                MISC_MODIR_PATH "/info"
#define MISC_LEGACY_MODIR_OID               8030
#define MISC_LEGACY_MODIR_PATH              MISC_MODIR_PATH "/legacy"


/* Test modir */
#define TEST_MODIR_OID                      9000
#define TEST_MODIR_PATH                     "./test"

/*
 * modir IDs
 */

enum modir_id {
	CONFIG_MODIR,
	VCLOCK_MODIR,
	VCLOCK_CONFIG_MODIR,
	VCLOCK_CONFIG_FOCA_MODIR,
	VCLOCK_INFO_MODIR,
	VCLOCK_INFO_INTEGRITY_MODIR,
	VCLOCK_INFO_Q_MODIR,
	VCLOCK_INFO_TIMEPROP_MODIR,
	TSRC_INFO_MODIR,
	PORTS_MODIR,
	NTP_MODIR,
	NTP_CONFIG_MODIR,
	NTP_INFO_MODIR,
	NTP_PROVIDER_CFG_MODIR,
	NTP_PROVIDER_INFO_MODIR,
	GM_MODIR,
	GM_CONFIG_MODIR,
	GM_INFO_MODIR,
	GNSS_MODIR,
	GNSS_CONFIG_MODIR,
	GNSS_INFO_MODIR,
	HOLDOVER_MODIR,
	HOLDOVER_CONFIG_MODIR,
	HOLDOVER_INFO_MODIR,
	MISC_MODIR,
	MISC_CONFIG_MODIR,
	MISC_INFO_MODIR,
	MISC_LEGACY_MODIR,
	TEST_MODIR,
	N_BASE_MODIRS,
};

/* Struct for clockQ and tprop GPA resources (passoc) */
struct gpa_clkinf_passoc_data {
	/* ClockQ */
	uint8_t id[8];
	uint8_t class;
	uint8_t accuracy;
	uint16_t variance;
	uint8_t priority1;
	uint8_t priority2;
	uint16_t n_hops;

	/* TimeProperties */
	uint8_t time_source;
	int16_t utc_offset;
	int utc_offset_valid;
	int time_valid;
	int freq_valid;
	int ptp_tscale;
	int leap59;
	int leap61;
};

/* Struct to match an enum identifier with a string */
struct enum_str_match {
	int id;
	char *str;
};

/* Struct to translate enum ID into OID */
struct enum_oid_match {
	int enum_id;
	int oid;
};

/* Search function for the enum_oid_match array */
extern int gpa_common_find_oid(struct enum_oid_match *v, int nv, int enum_id);

/* Owner module (defined in gpa_interface.c) */
extern struct gpa_mod *tmgr_mod;


#endif

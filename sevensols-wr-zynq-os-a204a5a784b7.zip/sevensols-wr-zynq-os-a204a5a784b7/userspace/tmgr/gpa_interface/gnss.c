/*
 * gnss.c
 *
 * libGPA-based parameter interface for Time Manager. GNSS timing source
 * parameters.
 *
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "leapsec.h"
#include "ktmgr.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum gnss_params {
	GNSS_INFO_STATUS,
	GNSS_INFO_ALIGN_STATE,
	GNSS_INFO_DETECTED,

	GNSS_CFG_OFFSET,
	GNSS_CFG_PRIORITY1,
	GNSS_CFG_PRIORITY2,
	GNSS_CFG_SRC_RANK,

	N_GNSS_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* GNSS timing source params for the <gnss> modir */
static struct gpa_param gnss_params[N_GNSS_PARAMS];

/* enum to string tables */
static struct enum_str_match gnss_info_external_state[N_SOFTPLL_ALIGN_STATES] = {
	{.id = SOFTPLL_ALIGN_STATE_EXT_OFF,               .str = "EXT_OFF"},
	{.id = SOFTPLL_ALIGN_STATE_START,                 .str = "START"},
	{.id = SOFTPLL_ALIGN_STATE_INIT_CSYNC,            .str = "INIT_CSYNC"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_CSYNC,            .str = "WAIT_CSYNC"},
	{.id = SOFTPLL_ALIGN_STATE_START_ALIGNMENT,       .str = "START_ALIGNMENT"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_SAMPLE,           .str = "WAIT_SAMPLE"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_DELAY,      .str = "COMPENSATE_DELAY"},
	{.id = SOFTPLL_ALIGN_STATE_LOCKED,                .str = "LOCKED"},
	{.id = SOFTPLL_ALIGN_STATE_START_MAIN,            .str = "START_MAIN"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_CLKIN,            .str = "WAIT_CLKIN"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_PLOCK,            .str = "WAIT_PLOCK"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_1,            .str = "RESERVED1"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_2,            .str = "RESERVED2"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_3,            .str = "RESERVED3"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_4,            .str = "RESERVED4"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_COARSE, .str = "COMPENSATE_PPS_COARSE"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_FINE,   .str = "COMPENSATE_PPS_FINE"},
};

static struct enum_str_match gnss_info_detected[N_SOFTPLL_EXT_FPANEL] = {
	{.id = SOFTPLL_EXT_DETECTED_NONE,       .str = "None"},
	{.id = SOFTPLL_EXT_DETECTED_PPS,        .str = "PPS (only)"},
	{.id = SOFTPLL_EXT_DETECTED_CLK,        .str = "CLK (only)"},
	{.id = SOFTPLL_EXT_DETECTED_PPSCLK,     .str = "PPS & CLK"},
};

/* oid translator */
static struct enum_oid_match gnss_enum_oid_translator[N_GNSS_PARAMS] = {
	/* gnss/info */
	{.enum_id = GNSS_INFO_STATUS,           .oid = 0},
	{.enum_id = GNSS_INFO_ALIGN_STATE,      .oid = 1},
	{.enum_id = GNSS_INFO_DETECTED,         .oid = 2},

	/* gnss/config */
	{.enum_id = GNSS_CFG_SRC_RANK,          .oid = 0},
	{.enum_id = GNSS_CFG_OFFSET,            .oid = 1},
	{.enum_id = GNSS_CFG_PRIORITY1,         .oid = 5},
	{.enum_id = GNSS_CFG_PRIORITY2,         .oid = 6},
};

/* Default parameter values */

static int dflt_gnss_info_align_state                     = 0;
static enum softpll_ext_fpanel dflt_gnss_info_detected    = SOFTPLL_EXT_DETECTED_NONE;
static char *dflt_gnss_info_status                        = "Unknown";

static int dflt_gnss_cfg_offset                           = 0;
static uint8_t dflt_gnss_cfg_priority1                    = 128;
static uint8_t dflt_gnss_cfg_priority2                    = 128;
static uint32_t dflt_gnss_cfg_src_rank                    = 0;


/************************************************************
 * Private functions                                        *
 ************************************************************/

void hook_gnss_gm_offset(const void *data, const void *args)
{
	int32_t offset = *((int32_t*)data);

	hald_set_softpll_ext_user_offset(offset);
}


void hook_gnss_priority1(const void *data, const void *args)
{
	uint8_t priority = *((uint8_t*)data);

	ktmgr_set_attr(KTMGR_PRIORITY1, priority);
}

void hook_gnss_priority2(const void *data, const void *args)
{
	uint8_t priority = *((uint8_t*)data);

	ktmgr_set_attr(KTMGR_PRIORITY2, priority);
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

/*
 * create_gnss_params
 *
 * Creates and publishes the GNSS timing source parameters and sets them to
 * default values.
 */
int create_gnss_params(void)
{
	int i;
	int oid;
	struct enum_oid_match *v_oid = gnss_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(gnss_enum_oid_translator);


	/**** Info parameters ****/

	/* GNSS Status */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_INFO_STATUS);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_INFO_STATUS].param = gpa_prm_create_str(
		0, oid, "status", GPA_PRM_VTA_STRING,
		GPA_ACC_RT | GPA_ACC_INTERNAL | TMGR2_ACC, dflt_gnss_info_status, MAX_STR_LEN);
	if (!gnss_params[GNSS_INFO_STATUS].param) {
		pr_error("Error creating %s/status\n",
			modir_array[GNSS_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_INFO_STATUS].param,
		"GNSS module status info");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_INFO_MODIR].mp,
		gnss_params[GNSS_INFO_STATUS].param)) {
		pr_error("Error adding status to %s\n",
			modir_array[GNSS_INFO_STATUS].mp);
		return 1;
	}
	gnss_params[GNSS_INFO_STATUS].type = GPA_TYPE_STRING;


	/* GNSS Align State */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_INFO_ALIGN_STATE);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_INFO_ALIGN_STATE].param = gpa_prm_create_enum(
		0, oid, "align_state", GPA_PRM_VTX_ENUM,
		GPA_ACC_R | GPA_ACC_INTERNAL | TMGR2_ACC, 0, N_SOFTPLL_ALIGN_STATES,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_gnss_info_align_state);
	if (!gnss_params[GNSS_INFO_ALIGN_STATE].param) {
		pr_error("Error creating %s/align_state\n",
			modir_array[GNSS_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_INFO_ALIGN_STATE].param,
		"(Read from hald) softPLL alignment state");
	for (i = 0; i < N_SOFTPLL_ALIGN_STATES; i++) {
		gpa_prm_enum_add_entry(gnss_params[GNSS_INFO_ALIGN_STATE].param,
			gnss_info_external_state[i].id,
			gnss_info_external_state[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_INFO_MODIR].mp,
		gnss_params[GNSS_INFO_ALIGN_STATE].param)) {
		pr_error("Error adding align_state to %s\n",
			modir_array[GNSS_INFO_MODIR].mp);
		return 1;
	}
	gnss_params[GNSS_INFO_ALIGN_STATE].type = GPA_TYPE_ENUM;


	/* GNSS Detected */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_INFO_DETECTED);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_INFO_DETECTED].param = gpa_prm_create_enum(0, oid,
		"detected", GPA_PRM_VTX_ENUM,
		GPA_ACC_RT | GPA_ACC_INTERNAL | TMGR2_ACC, 0, N_SOFTPLL_EXT_FPANEL,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_gnss_info_detected);
	if (!gnss_params[GNSS_INFO_DETECTED].param) {
		pr_error("Error creating %s/detected\n",
			modir_array[GNSS_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_INFO_DETECTED].param,
		"(Read from hald) detected external reference inputs");
	for (i = 0; i < N_SOFTPLL_EXT_FPANEL; i++) {
		gpa_prm_enum_add_entry(gnss_params[GNSS_INFO_DETECTED].param,
			gnss_info_detected[i].id,
			gnss_info_detected[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_INFO_MODIR].mp,
		gnss_params[GNSS_INFO_DETECTED].param)) {
		pr_error("Error adding detected to %s\n",
			modir_array[GNSS_INFO_MODIR].mp);
		return 1;
	}
	gnss_params[GNSS_INFO_DETECTED].type = GPA_TYPE_ENUM;


	/**** Config parameters ****/

	/* GNSS src rank */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_CFG_SRC_RANK);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_CFG_SRC_RANK].param = gpa_prm_create_val(
		0, oid, "src_rank", GPA_PRM_VTX_U32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL | TMGR2_ACC,
		{.u32 = dflt_gnss_cfg_src_rank});
	if (!gnss_params[GNSS_CFG_SRC_RANK].param) {
		pr_error("Error creating %s/src_rank\n",
			modir_array[GNSS_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_CFG_SRC_RANK].param,
			"GNSS priority");
	if (gpa_modir_path_addprm(tmgr_mod,  modir_array[GNSS_CONFIG_MODIR].mp,
					gnss_params[GNSS_CFG_SRC_RANK].param)) {
		pr_error("Error adding src_rank to %s\n",
			modir_array[GNSS_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gnss_params[GNSS_CFG_SRC_RANK].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("src_rank is not configured. "
			"Using default value: %d\n",
			dflt_gnss_cfg_src_rank);
	}
	gnss_params[GNSS_CFG_SRC_RANK].type = GPA_TYPE_UINT32;
	gpa_enable_cache(&gnss_params[GNSS_CFG_SRC_RANK]);

	/* GNSS Offset */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_CFG_OFFSET);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_CFG_OFFSET].param = gpa_prm_create_val(
		0, oid, "gm_offset", GPA_PRM_VTX_I32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL | TMGR2_ACC, {.i32 = dflt_gnss_cfg_offset});
	if (!gnss_params[GNSS_CFG_OFFSET].param) {
		pr_error("Error creating %s/gm_offset\n",
			modir_array[GNSS_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_CONFIG_MODIR].mp,
		gnss_params[GNSS_CFG_OFFSET].param)) {
		pr_error("Error adding gm_offset to %s\n",
			modir_array[GNSS_CFG_OFFSET].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gnss_params[GNSS_CFG_OFFSET].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("gm_offset is not configured. "
			"Using default value: %d\n", dflt_gnss_cfg_offset);
	}
	gnss_params[GNSS_CFG_OFFSET].type = GPA_TYPE_INT32;
	gpa_enable_cache(&gnss_params[GNSS_CFG_OFFSET]);
	gpa_enable_hook(&gnss_params[GNSS_CFG_OFFSET], hook_gnss_gm_offset, 0);


	/* GNSS Priority1 */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_CFG_PRIORITY1);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_CFG_PRIORITY1].param = gpa_prm_create_val(
		0, oid, "priority1", GPA_PRM_VTX_U8,
		GPA_ACC_RWL | GPA_ACC_INTERNAL | TMGR2_ACC, {.u8 = dflt_gnss_cfg_priority1});
	if (!gnss_params[GNSS_CFG_PRIORITY1].param) {
		pr_error("Error creating %s/priority1\n",
			modir_array[GNSS_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_CFG_PRIORITY1].param,
		"PTP priority1 value for GNSS mode");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_CONFIG_MODIR].mp,
		gnss_params[GNSS_CFG_PRIORITY1].param)) {
		pr_error("Error adding priority1 to %s\n",
			modir_array[GNSS_CFG_PRIORITY1].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gnss_params[GNSS_CFG_PRIORITY1].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("priority1 is not configured. "
			"Using default value: %d\n", dflt_gnss_cfg_priority1);
	}
	gnss_params[GNSS_CFG_PRIORITY1].type = GPA_TYPE_UINT8;
	gpa_enable_cache(&gnss_params[GNSS_CFG_PRIORITY1]);
	gpa_enable_hook(&gnss_params[GNSS_CFG_PRIORITY1], hook_gnss_priority1, 0);


	/* GNSS Priority2 */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GNSS_CFG_PRIORITY2);
	if(oid < 0)
		return 1;

	gnss_params[GNSS_CFG_PRIORITY2].param = gpa_prm_create_val(
		0, oid, "priority2", GPA_PRM_VTX_U8,
		GPA_ACC_RWL | GPA_ACC_INTERNAL | TMGR2_ACC, {.u8 = dflt_gnss_cfg_priority2});
	if (!gnss_params[GNSS_CFG_PRIORITY2].param) {
		pr_error("Error creating %s/priority2\n",
			modir_array[GNSS_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gnss_params[GNSS_CFG_PRIORITY2].param,
		"PTP priority2 value for GNSS mode");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GNSS_CONFIG_MODIR].mp,
		gnss_params[GNSS_CFG_PRIORITY2].param)) {
		pr_error("Error adding priority2 to %s\n",
			modir_array[GNSS_CFG_PRIORITY2].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gnss_params[GNSS_CFG_PRIORITY2].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("priority2 is not configured. "
			"Using default value: %d\n", dflt_gnss_cfg_priority2);
	}
	gnss_params[GNSS_CFG_PRIORITY2].type = GPA_TYPE_UINT8;
	gpa_enable_cache(&gnss_params[GNSS_CFG_PRIORITY2]);
	gpa_enable_hook(&gnss_params[GNSS_CFG_PRIORITY2], hook_gnss_priority2, 0);

	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/

int get_gnss_info_align_state(enum softpll_align_state *align_state)
{
	if (!align_state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_INFO_ALIGN_STATE], align_state)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gnss_info_detected(enum softpll_ext_fpanel *detected)
{
	if (!detected) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_INFO_DETECTED], detected)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gnss_config_offset(int32_t *offset)
{
	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_CFG_OFFSET], offset)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gnss_config_priority1(uint8_t *priority1)
{
	if (!priority1) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_CFG_PRIORITY1], priority1)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gnss_config_priority2(uint8_t *priority2)
{
	if (!priority2) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_CFG_PRIORITY2], priority2)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gnss_config_src_rank(uint32_t *rank)
{
	if(!rank) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gnss_params[GNSS_CFG_SRC_RANK], rank)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

/********** Setter functions **********/


int set_gnss_info_align_state(enum softpll_align_state align_state)
{
	if (align_state < 0 || align_state >= N_SOFTPLL_ALIGN_STATES) {
		pr_error("Invalid align state %d\n", align_state);
		return 1;
	}

	if (gpa_set_param(&gnss_params[GNSS_INFO_ALIGN_STATE], &align_state)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_info_detected(enum softpll_ext_fpanel detected)
{
	if (detected < 0 || detected >= N_SOFTPLL_EXT_FPANEL) {
		pr_error("Invalid GNSS detected value %d\n", detected);
		return 1;
	}

	if (gpa_set_param(&gnss_params[GNSS_INFO_DETECTED], &detected)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_info_status(char *status)
{
	if (gpa_set_param(&gnss_params[GNSS_INFO_STATUS], status)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_config_offset(int32_t offset)
{
	if (gpa_set_param(&gnss_params[GNSS_CFG_OFFSET], &offset)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_config_priority1(uint8_t priority1)
{
	if (gpa_set_param(&gnss_params[GNSS_CFG_PRIORITY1], &priority1)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_config_priority2(uint8_t priority2)
{
	if (gpa_set_param(&gnss_params[GNSS_CFG_PRIORITY2], &priority2)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gnss_config_src_rank(uint32_t rank)
{
	if (gpa_set_param(&gnss_params[GNSS_CFG_SRC_RANK], &rank)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

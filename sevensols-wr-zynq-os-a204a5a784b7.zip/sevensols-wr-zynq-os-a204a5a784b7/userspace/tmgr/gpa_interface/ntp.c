/*
 * ntp.c
 *
 * libGPA-based parameter interface for Time Manager. NTP parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 27, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum ntp_params {
	NTP_CFG_REFRESH_RATE,
	NTP_CFG_RETRIES,
	NTP_CFG_PROVIDER_ENABLED,
	NTP_CFG_PROVIDER_STRATUM_MODE,
	NTP_CFG_PROVIDER_STRATUM_MANUAL,

	N_NTP_PARAMS
};

enum ntp_server_params {
	NTP_SERVER_CFG_IP,
	NTP_SERVER_INFO_OFFSET,
	NTP_SERVER_INFO_SERVER_STATUS,
	NTP_SERVER_INFO_STRATUM,
	NTP_SERVER_INFO_DELAY,
	NTP_SERVER_INFO_JITTER,

	N_NTP_SERVER_PARAMS
};

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* NTP parameter arrays */
static struct gpa_param ntp_params[N_NTP_PARAMS];
static struct gpa_param ntp_server_params[MAX_NTP_SERVERS][N_NTP_SERVER_PARAMS];

/* enum to string tables */
static struct enum_str_match ntp_info_server_status_def[N_NTP_STATUS] = {
	{.id = NTP_STATUS_NONE,                 .str = "Disabled"},
	{.id = NTP_STATUS_OK,                   .str = "OK"},
	{.id = NTP_STATUS_NOT_SYNC,             .str = "NTP sync error"},
	{.id = NTP_STATUS_STOP_REPLY,           .str = "NTP stopped replying"},
};

static struct enum_str_match ntp_stratum_mode_def[N_NTP_STRATUM_MODE] = {
	{.id = NTP_STRATUM_MODE_AUTO,           .str = "Auto"},
	{.id = NTP_STRATUM_MODE_MANUAL,         .str = "Manual"},
};

static struct enum_str_match ntp_stratum_def[N_NTP_STRATUM] = {
	{.id = NTP_STRATUM_1,                   .str = "Stratum 1"},
	{.id = NTP_STRATUM_2,                   .str = "Stratum 2"},
	{.id = NTP_STRATUM_3,                   .str = "Stratum 3"},
	{.id = NTP_STRATUM_3E,                  .str = "Stratum 3E"},
	{.id = NTP_STRATUM_4,                   .str = "Stratum 4"},
	{.id = NTP_STRATUM_4E,                  .str = "Stratum 4E"},
	{.id = NTP_STRATUM_15,                  .str = "Stratum 15"},
	{.id = NTP_STRATUM_UNDEFINED,           .str = "Undefined"},
};

/* oid translator */
static struct enum_oid_match ntp_enum_oid_translator[N_NTP_PARAMS] = {
	/* config */
	{.enum_id = NTP_CFG_REFRESH_RATE,       .oid = 2},
	{.enum_id = NTP_CFG_RETRIES,            .oid = 3},
	/* config/provider */
	{.enum_id = NTP_CFG_PROVIDER_ENABLED,        .oid = 1},
	{.enum_id = NTP_CFG_PROVIDER_STRATUM_MODE,   .oid = 2},
	{.enum_id = NTP_CFG_PROVIDER_STRATUM_MANUAL, .oid = 3},
};

static struct enum_oid_match ntp_server_enum_oid_translator[N_NTP_SERVER_PARAMS] = {
	/* config */
	{.enum_id = NTP_SERVER_CFG_IP,                      .oid = 0},
	/* info */
	{.enum_id = NTP_SERVER_INFO_OFFSET,                 .oid = 0},
	{.enum_id = NTP_SERVER_INFO_SERVER_STATUS,          .oid = 1},
	{.enum_id = NTP_SERVER_INFO_STRATUM,                .oid = 2},
	{.enum_id = NTP_SERVER_INFO_DELAY,                  .oid = 5},
	{.enum_id = NTP_SERVER_INFO_JITTER,                 .oid = 6},
};

/* Default parameter values */
static uint32_t dflt_cfg_ntp_refresh_rate                    = 30;
static uint32_t dflt_cfg_ntp_retries                         = 5;
static enum ntp_stratum_mode dflt_ntp_provider_stratum_mode  = NTP_STRATUM_MODE_AUTO;
static enum ntp_stratum dflt_ntp_provider_stratum_manual     = NTP_STRATUM_2;

static char *dflt_cfg_ntp_server_ip                     = "";
static float dflt_info_ntp_server_offset                = 0.0;
static enum ntp_status dflt_info_ntp_server_status      = NTP_STATUS_NONE;
static enum ntp_stratum dflt_info_ntp_server_stratum    = NTP_STRATUM_UNDEFINED;
static float dflt_info_ntp_server_delay                 = 0.0;
static float dflt_info_ntp_server_jitter                = 0.0;

/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Sets the appropriate WARNING or CRITICAL flags to the ntp/info/server_status
 * parameter.
 *
 * This function will be called by libgpa.
 */
int32_t ntp_status_warning_check(const void *new_value, struct gpa_prm *p,
					uint8_t iwc)
{
	const union gpa_val *val = new_value;
	enum ntp_status status = val->u16;

	if (iwc == GPA_PRM_RANGE_INPUT) {
		return (status >= 0 && status < N_NTP_STATUS);
	}

	switch (status) {
		/* WARNING cases */
	case NTP_STATUS_STOP_REPLY:
		if (iwc == GPA_PRM_RANGE_WARNING)
			return 1;
		break;
		/* CRITICAL cases */
	case NTP_STATUS_NOT_SYNC:
		if (iwc == GPA_PRM_RANGE_CRITICAL)
			return 1;
		break;
	default:
		break;
	}

	return 0;
}

int32_t ntp_offset_warning_check(const void *new_value, struct gpa_prm *p,
					uint8_t iwc)
{
	const union gpa_val *val = new_value;
	float offset = val->f32;

	if (iwc == GPA_PRM_RANGE_INPUT)
		return 1;

	if (iwc == GPA_PRM_RANGE_WARNING && (offset >= NTP_DRIFT_THRESHOLD
					|| offset <= -NTP_DRIFT_THRESHOLD))
		return 1;

	return 0;
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

int create_ntp_server_params(int server)
{
	int oid;
	int inst_idx = server+1;
	struct enum_oid_match *v_oid = ntp_server_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(ntp_server_enum_oid_translator);
	char modir_name[MAX_STR_LEN];
	char param_name[MAX_STR_LEN];
	int i;

	/* ntp/N/cfg modir */
	snprintf(modir_name, MAX_STR_LEN-1, NTP_SERVER_CFG_MODIR_PATH, inst_idx);

	/* NTP server */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "ipv4_server", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_CFG_IP);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_CFG_IP].param = gpa_prm_create_str(
		0, oid, param_name, GPA_PRM_VTA_STRING,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,
		dflt_cfg_ntp_server_ip, MAX_STR_LEN);
	if (!ntp_server_params[server][NTP_SERVER_CFG_IP].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_CFG_IP].param,
		"IP or URL of the reference NTP server");
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
		ntp_server_params[server][NTP_SERVER_CFG_IP].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_server_params[server][NTP_SERVER_CFG_IP].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("%s is not configured. "
			"Using default value: %s\n", param_name, dflt_cfg_ntp_server_ip);
	}
	ntp_server_params[server][NTP_SERVER_CFG_IP].type = GPA_TYPE_STRING;
	gpa_enable_cache(&ntp_server_params[server][NTP_SERVER_CFG_IP]);

	/**** Info parameters ****/
	snprintf(modir_name, MAX_STR_LEN-1, NTP_SERVER_INFO_MODIR_PATH, inst_idx);

	/* NTP offset */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "offset", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_INFO_OFFSET);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param = gpa_prm_create_val(0, oid,
			param_name, GPA_PRM_VTX_F32, GPA_ACC_R |
			GPA_ACC_INTERNAL, {.f32 = dflt_info_ntp_server_offset});

	if (!ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param,
		"Time offset between the device and the NTP reference server (in seconds)");
	gpa_prm_set_unit(ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param, "s");
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
		ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	ntp_server_params[server][NTP_SERVER_INFO_OFFSET].type = GPA_TYPE_FLOAT32;
	gpa_prm_set_custom_check_range(ntp_server_params[server][NTP_SERVER_INFO_OFFSET].param,
		ntp_offset_warning_check);


	/* NTP server status */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "server_status", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_INFO_SERVER_STATUS);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param = gpa_prm_create_enum(0, oid,
		param_name, GPA_PRM_VTX_ENUM,
		GPA_ACC_RT | GPA_ACC_INTERNAL, 0, N_NTP_STATUS,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_info_ntp_server_status);
	if (!ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param,
		"NTP server status. Warns if the NTP server can't be reached");
	for (i = 0; i < N_NTP_STATUS; i++) {
		gpa_prm_enum_add_entry(ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param,
			ntp_info_server_status_def[i].id,
			ntp_info_server_status_def[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
		ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].type = GPA_TYPE_ENUM;
	gpa_prm_set_custom_check_range(ntp_server_params[server][NTP_SERVER_INFO_SERVER_STATUS].param,
		ntp_status_warning_check);

	/* NTP stratum */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "stratum", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_INFO_STRATUM);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_INFO_STRATUM].param = gpa_prm_create_enum(0, oid,
		param_name, GPA_PRM_VTX_ENUM, GPA_ACC_R | GPA_ACC_INTERNAL, 0,
		N_NTP_STRATUM, GPA_PRM_ENUM_OPT_NONE, dflt_info_ntp_server_stratum);
	if (!ntp_server_params[server][NTP_SERVER_INFO_STRATUM].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_INFO_STRATUM].param,
		"Stratum announced by the corresponding NTP server");
	for (i = 0; i < N_NTP_STRATUM; i++) {
		gpa_prm_enum_add_entry(ntp_server_params[server][NTP_SERVER_INFO_STRATUM].param,
			ntp_stratum_def[i].id,
			ntp_stratum_def[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
		ntp_server_params[server][NTP_SERVER_INFO_STRATUM].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	ntp_server_params[server][NTP_SERVER_INFO_STRATUM].type = GPA_TYPE_ENUM;

	/* NTP delay */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "delay", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_INFO_DELAY);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_INFO_DELAY].param = gpa_prm_create_val(0, oid,
			param_name, GPA_PRM_VTX_F32, GPA_ACC_R |
			GPA_ACC_INTERNAL | TMGR2_ACC, {.f32 = dflt_info_ntp_server_delay});

	if (!ntp_server_params[server][NTP_SERVER_INFO_DELAY].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_INFO_DELAY].param,
		"NTP server delay");
	gpa_prm_set_unit(ntp_server_params[server][NTP_SERVER_INFO_DELAY].param, "s");
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
		ntp_server_params[server][NTP_SERVER_INFO_DELAY].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	ntp_server_params[server][NTP_SERVER_INFO_DELAY].type = GPA_TYPE_FLOAT32;

	/* NTP jitter */
	memset(param_name, 0, MAX_STR_LEN);
	strncpy(param_name, "jitter", MAX_STR_LEN-1);

	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_SERVER_INFO_JITTER);
	if(oid < 0)
		return 1;

	ntp_server_params[server][NTP_SERVER_INFO_JITTER].param = gpa_prm_create_val(0, oid,
			param_name, GPA_PRM_VTX_F32, GPA_ACC_R |
			GPA_ACC_INTERNAL | TMGR2_ACC, {.f32 = dflt_info_ntp_server_jitter});

	if (!ntp_server_params[server][NTP_SERVER_INFO_JITTER].param) {
		pr_error("Error creating %s/%s\n",
			modir_name, param_name);
		return 1;
	}
	gpa_prm_set_desc(ntp_server_params[server][NTP_SERVER_INFO_JITTER].param,
		"NTP server jitter");
	gpa_prm_set_unit(ntp_server_params[server][NTP_SERVER_INFO_JITTER].param, "s");
	if (gpa_modir_path_addprm(tmgr_mod, modir_name,
					ntp_server_params[server][NTP_SERVER_INFO_JITTER].param)) {
		pr_error("Error adding %s to %s\n",
			param_name, modir_name);
		return 1;
	}
	ntp_server_params[server][NTP_SERVER_INFO_JITTER].type = GPA_TYPE_FLOAT32;

	return 0;
}

int create_ntp_params(void)
{
	int oid;
	int i;
	int ret;
	struct enum_oid_match *v_oid = ntp_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(ntp_enum_oid_translator);

	/**** Config parameters ****/

	/* NTP refresh rate */
	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_CFG_REFRESH_RATE);
	if(oid < 0)
		return 1;

	ntp_params[NTP_CFG_REFRESH_RATE].param = gpa_prm_create_val(
		0, oid, "refresh_rate", GPA_PRM_VTX_U32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,
		{.u32 = dflt_cfg_ntp_refresh_rate});
	if (!ntp_params[NTP_CFG_REFRESH_RATE].param) {
		pr_error("Error creating %s/refresh_rate\n",
			modir_array[NTP_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ntp_params[NTP_CFG_REFRESH_RATE].param,
		"Time lapse between NTP server queries (in seconds)");
	gpa_prm_set_unit(ntp_params[NTP_CFG_REFRESH_RATE].param, "s");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[NTP_CONFIG_MODIR].mp,
		ntp_params[NTP_CFG_REFRESH_RATE].param)) {
		pr_error("Error adding refresh_rate to %s\n",
			modir_array[NTP_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_params[NTP_CFG_REFRESH_RATE].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("refresh_rate is not configured. "
			"Using default value: %d\n", dflt_cfg_ntp_refresh_rate);
	}
	ntp_params[NTP_CFG_REFRESH_RATE].type = GPA_TYPE_UINT32;
	gpa_enable_cache(&ntp_params[NTP_CFG_REFRESH_RATE]);

	/* NTP retries */
	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_CFG_RETRIES);
	if(oid < 0)
		return 1;

	ntp_params[NTP_CFG_RETRIES].param = gpa_prm_create_val(
		0, oid, "retries", GPA_PRM_VTX_U32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,
		{.u32 = dflt_cfg_ntp_retries});
	if (!ntp_params[NTP_CFG_RETRIES].param) {
		pr_error("Error creating %s/retries\n",
			modir_array[NTP_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ntp_params[NTP_CFG_RETRIES].param,
		"Number of retries for NTP server queries");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[NTP_CONFIG_MODIR].mp,
		ntp_params[NTP_CFG_RETRIES].param)) {
		pr_error("Error adding retries to %s\n",
			modir_array[NTP_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_params[NTP_CFG_RETRIES].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("retries is not configured. "
			"Using default value: %d\n", dflt_cfg_ntp_retries);
	}
	ntp_params[NTP_CFG_RETRIES].type = GPA_TYPE_UINT32;
	gpa_enable_cache(&ntp_params[NTP_CFG_RETRIES]);

	/* NTP provider enabled */
	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_CFG_PROVIDER_ENABLED);
		if(oid < 0)
			return 1;

	ntp_params[NTP_CFG_PROVIDER_ENABLED].param = gpa_prm_create_bool(
		0, oid, "enabled", GPA_ACC_RL | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_YES_NO, 0);
	if (!ntp_params[NTP_CFG_PROVIDER_ENABLED].param) {
		pr_error("Error creating %s/enabled\n",
			modir_array[NTP_PROVIDER_CFG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ntp_params[NTP_CFG_PROVIDER_ENABLED].param,
		"If 'Yes' the device will act as an NTP server on its management"
		" to distribute its own Time of Day to other devices.");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[NTP_PROVIDER_CFG_MODIR].mp,
		ntp_params[NTP_CFG_PROVIDER_ENABLED].param)) {
		pr_error("Error adding provider_enabled to %s\n",
			modir_array[NTP_PROVIDER_CFG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_params[NTP_CFG_PROVIDER_ENABLED].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("provider/enabled is not configured. "
			"Define it in .config file\n");
	}
	ntp_params[NTP_CFG_PROVIDER_ENABLED].type = GPA_TYPE_BOOL;
	gpa_enable_cache(&ntp_params[NTP_CFG_PROVIDER_ENABLED]);

	/* NTP provider stratum mode */
	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_CFG_PROVIDER_STRATUM_MODE);
	if(oid < 0)
		return 1;

	ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param = gpa_prm_create_enum(0, oid,
		"stratum_mode", GPA_PRM_VTX_ENUM, GPA_ACC_RL | GPA_ACC_INTERNAL, 0,
		N_NTP_STRATUM_MODE, GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_ntp_provider_stratum_mode);
	if (!ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param) {
		pr_error("Error creating %s/%s\n",
			modir_array[NTP_PROVIDER_CFG_MODIR].mp, "stratum_mode");
		return 1;
	}
	gpa_prm_set_desc(ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param,
		"Mode to provide the NTP stratum. If Manual it will directly set the value from"
		" 'Manual Stratum', otherwise it will take into account the virtual clock quality"
		" (timing source, clock accuracy, etc) to modify this value.");
	for (i = 0; i < N_NTP_STRATUM_MODE; i++) {
		gpa_prm_enum_add_entry(ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param,
			ntp_stratum_mode_def[i].id,
			ntp_stratum_mode_def[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[NTP_PROVIDER_CFG_MODIR].mp,
		ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param)) {
		pr_error("Error adding %s to %s\n",
			"stratum_mode", modir_array[NTP_PROVIDER_CFG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("stratum_mode is not configured. "
			"Define it in .config file\n");
	}
	ntp_params[NTP_CFG_PROVIDER_STRATUM_MODE].type = GPA_TYPE_ENUM;

	/* NTP provider stratum (manual) */
	oid = gpa_common_find_oid(v_oid, n_v_oid, NTP_CFG_PROVIDER_STRATUM_MANUAL);
	if(oid < 0)
		return 1;

	ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param = gpa_prm_create_enum(0, oid,
		"stratum_manual", GPA_PRM_VTX_ENUM, GPA_ACC_RL | GPA_ACC_INTERNAL, 0,
		N_NTP_STRATUM, GPA_PRM_ENUM_OPT_NONE, dflt_ntp_provider_stratum_manual);
	if (!ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param) {
		pr_error("Error creating %s/%s\n",
			modir_array[NTP_PROVIDER_CFG_MODIR].mp, "stratum_manual");
		return 1;
	}
	gpa_prm_set_desc(ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param,
		"NTP provider stratum manual configuration");
	for (i = 0; i < N_NTP_STRATUM; i++) {
		gpa_prm_enum_add_entry(ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param,
			ntp_stratum_def[i].id,
			ntp_stratum_def[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[NTP_PROVIDER_CFG_MODIR].mp,
		ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param)) {
		pr_error("Error adding %s to %s\n",
			"stratum_manual", modir_array[NTP_PROVIDER_CFG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("stratum_manual is not configured. "
			"Define it in .config file\n");
	}
	ntp_params[NTP_CFG_PROVIDER_STRATUM_MANUAL].type = GPA_TYPE_ENUM;

	/* Finally, create NTP server parameters */
	for(i = 0 ; i < MAX_NTP_SERVERS ; i++) {
		ret = create_ntp_server_params(i);
		if(ret)
			break;
	}

	return ret;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/

int get_ntp_server_config_ip(int n, const char **server)
{
	if (!server) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(n < 0 || n >= MAX_NTP_SERVERS) {
		pr_error("NTP server %d does not exist\n", n);
		return 1;
	}

	if (gpa_get_param(&ntp_server_params[n][NTP_SERVER_CFG_IP], server)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ntp_config_provider_enabled(int *enabled)
{
	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ntp_params[NTP_CFG_PROVIDER_ENABLED], enabled)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ntp_config_refresh_rate(uint32_t *rate)
{
	if (!rate) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ntp_params[NTP_CFG_REFRESH_RATE], rate)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ntp_config_retries(uint32_t *retries)
{
	if (!retries) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ntp_params[NTP_CFG_RETRIES], retries)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ntp_server_info_offset(int n, float *offset)
{
	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(n < 0 || n >= MAX_NTP_SERVERS) {
		pr_error("NTP server %d does not exist\n", n);
		return 1;
	}

	if (gpa_get_param(&ntp_server_params[n][NTP_SERVER_INFO_OFFSET], offset)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}


/********** Setter functions **********/


int set_ntp_server_config_ip(int n, char *server)
{
	if (!server) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	if(n < 0 || n >= MAX_NTP_SERVERS) {
		pr_error("NTP server %d does not exist\n", n);
		return 1;
	}

	if (gpa_set_param(&ntp_server_params[n][NTP_SERVER_CFG_IP], server)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ntp_config_provider_enabled(int enable)
{
	if (gpa_set_param(&ntp_params[NTP_CFG_PROVIDER_ENABLED], &enable)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ntp_config_refresh_rate(uint32_t rate)
{
	if (gpa_set_param(&ntp_params[NTP_CFG_REFRESH_RATE], &rate)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ntp_config_retries(uint32_t retries)
{
	if (gpa_set_param(&ntp_params[NTP_CFG_RETRIES], &retries)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ntp_server_info_offset(int n, float offset)
{
	if(n < 0 || n >= MAX_NTP_SERVERS) {
		pr_error("NTP server %d does not exist\n", n);
		return 1;
	}

	if (gpa_set_param(&ntp_server_params[n][NTP_SERVER_INFO_OFFSET], &offset)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ntp_server_info_server_status(int n, enum ntp_status status)
{
	if (status < 0 || status >= N_NTP_STATUS) {
		pr_error("Invalid NTP server status %d\n", status);
		return 1;
	}

	if(n < 0 || n >= MAX_NTP_SERVERS) {
		pr_error("NTP server %d does not exist\n", n);
		return 1;
	}

	if (gpa_set_param(&ntp_server_params[n][NTP_SERVER_INFO_SERVER_STATUS], &status)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

void reset_ntp_info(void)
{
	int i;

	for(i = 0 ; i < MAX_NTP_SERVERS ; i++) {
		set_ntp_server_info_server_status(i, NTP_STATUS_NONE);
	}
}

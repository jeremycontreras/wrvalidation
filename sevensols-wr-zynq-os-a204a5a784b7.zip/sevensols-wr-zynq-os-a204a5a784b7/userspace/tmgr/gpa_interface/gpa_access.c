/*
 * gpa_access.c
 *
 * Centralized access to GPA parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 23, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <libgpa.h>

#include "commondefs.h"
#include "gpa_access.h"
#include "gpa_interface.h"
#include "gpa_common.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* A node of a singly-linked list of caches */
struct cache_list {
	struct gpa_param *param;
	struct cache_list *next;
};

/************************************************************
 * External references                                      *
 ************************************************************/

extern struct gpa_mod *tmgr_mod;

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* A list of all the caches in use so far */
static struct cache_list *cached_params;

/* A dummy cache for internal copies and comparison operations */
static union param_data dummy_cache;
static char dummy_string[MAX_STR_LEN];


/************************************************************
 * Private functions                                        *
 ************************************************************/


/*
 * Returns a deep copy of the cache of parameter <p> for comparison purposes.
 *
 * NOTE: The copy it returns is the internal dummy_cache. This function is neither
 * thread-safe nor reentrant. Don't modify the returned structure.
 *
 * Returns a pointer to the cache copy.
 */
static union param_data *gpa_copy_cache(struct gpa_param *p)
{
	if (p->type == GPA_TYPE_STRING) {
		memset(dummy_string, 0, MAX_STR_LEN);
		if (p->cached_data.str)
			strncpy(dummy_string, p->cached_data.str, MAX_STR_LEN-1);
		dummy_cache.str = dummy_string;
	} else {
		dummy_cache = p->cached_data;
	}

	return &dummy_cache;
}


/*
 * Gets the current value of GPA parameter <p> and saves it into <d> according
 * to its type.
 *
 * Parameters:
 *   - p: a pointer to the parameter to query
 *   - d: a pointer to a union param_data variable to store the result
 *
 * Returns:
 *   0 if success
 *   1 otherwise
 */
static int gpa_generic_get(struct gpa_param *p, union param_data *d)
{
	union param_data data;

	errno = 0;
	switch (p->type) {
	case (GPA_TYPE_UINT8):
		data.u8 = gpa_prm_get_u8(p->param);
		break;
	case (GPA_TYPE_INT16):
		data.i16 = gpa_prm_get_i16(p->param);
		break;
	case (GPA_TYPE_UINT16):
		data.u16 = gpa_prm_get_u16(p->param);
		break;
	case (GPA_TYPE_INT32):
		data.i32 = gpa_prm_get_i32(p->param);
		break;
	case (GPA_TYPE_UINT32):
		data.u32 = gpa_prm_get_u32(p->param);
		break;
	case (GPA_TYPE_UINT64):
		data.u64 = gpa_prm_get_u64(p->param);
		break;
	case (GPA_TYPE_FLOAT32):
		data.f32 = gpa_prm_get_f32(p->param);
		break;
	case (GPA_TYPE_BOOL):
		data.i32 = gpa_prm_get_bool(p->param);
		break;
	case (GPA_TYPE_ENUM):
		data.u32 = gpa_prm_get_enum_val(p->param);
		break;
	case (GPA_TYPE_STRING):
		data.str = gpa_prm_get_str(p->param);
		break;
	}
	if (errno) {
		return 1;
	}

	*d = data;

	return 0;
}


/*
 * Updates the cache of parameter <p>, ie. it reads the GPA parameter and saves
 * the new value in the cache of <p>.
 *
 * Returns:
 *   0 if success
 *   1 otherwise
 */
static int gpa_update_cache(struct gpa_param *p)
{
	union param_data data;

	if (gpa_generic_get(p, &data)) {
		return 1;
	}
	/*
	 * Cached string parameters must save a copy of the
	 * original string. This allocates a string buffer that
	 * must be free'd at some point.
	 */
	if (p->type == GPA_TYPE_STRING) {
		if (p->cached_data.str)
			free((void *)(p->cached_data.str));
		p->cached_data.str = strdup(data.str);
	} else {
		p->cached_data = data;
	}
	p->cache_initialized = 1;

	return 0;
}


/*
 * Compares the contents of <d1> and <d2> depending on <type>.
 *
 * Returns:
 *   1 if they're equal
 *   0 if they're different
 */
static int gpa_compare_param_data(union param_data *d1, union param_data *d2,
				enum gpa_datatype type)
{
	switch (type) {
	case (GPA_TYPE_UINT8):
		return (d1->u8 == d2->u8);
	case (GPA_TYPE_INT16):
		return (d1->i16 == d2->i16);
	case (GPA_TYPE_UINT16):
		return (d1->u16 == d2->u16);
	case (GPA_TYPE_BOOL):
	case (GPA_TYPE_INT32):
		return (d1->i32 == d2->i32);
	case (GPA_TYPE_UINT32):
	case (GPA_TYPE_ENUM):
		return (d1->u32 == d2->u32);
	case (GPA_TYPE_UINT64):
		return (d1->u64 == d2->u64);
	case (GPA_TYPE_FLOAT32):
		return (d1->f32 == d2->f32);
	case (GPA_TYPE_STRING):
		if (!d1->str && !d2->str)
			return 1;
		if (d1->str && d2->str && (strcmp(d1->str, d2->str) == 0))
			return 1;
		else
			return 0;
	};

	return 0;
}


/*
 * Gets the current value of parameter <p>.
 *
 * If the parameter is cached, it returns the cached value. If the cache is
 * dirty and it's time to update it, it refreshes the cached value. If the new
 * value is different than the cached one, it also runs the post-modification
 * hook of the parameter if it has one installed.
 *
 * The cache is considered dirty if the update_config flag is set or if the
 * <force_cache_update> argument is != 0.
 *
 * Parameters:
 *   - p: the parameter to retrieve
 *   - d: a pointer to the place where to store the retrieved data. Its type
 *        must match the parameter datatype.
 *   - force_cache_update: != 0 to force a cache refresh for this parameter.
 *
 * Returns:
 *   0 If success
 *   1 otherwise
 */
static int _gpa_get_param(struct gpa_param *p, void *d, int force_cache_update)
{
	union param_data data;
	union param_data *pdata;
	int update = 0;
	int run_hook = 0;
	int ret;

	if (!p || !p->param)
		return 1;

	if (p->cached) {
		/*
		 * Cached parameter. If the update flag is ON or the cache is
		 * empty, refresh the cached value.
		 */
		union param_data *current_cache = gpa_copy_cache(p);

		ret = get_tmgr_config_update(&update);
		if ((!ret && update)
			|| !p->cache_initialized
			|| force_cache_update) {
			/*
			 * Update the cached data, run the post-modification
			 * hook if the value has changed.
			 */
			if (gpa_update_cache(p))
				return 1;
			if (!gpa_compare_param_data(current_cache,
					&p->cached_data, p->type)) {
				run_hook = 1;
			}
		}
		pdata = &p->cached_data;
	} else {
		/* Uncached parameter */
		if (gpa_generic_get(p, &data)) {
			return 1;
		}
		pdata = &data;
	}

	switch (p->type) {
	case (GPA_TYPE_UINT8):
		*((int8_t*)d) = pdata->u8;
		break;
	case (GPA_TYPE_INT16):
		*((int16_t*)d) = pdata->i16;
		break;
	case (GPA_TYPE_UINT16):
		*((uint16_t*)d) = pdata->u16;
		break;
	case (GPA_TYPE_BOOL):
	case (GPA_TYPE_INT32):
		*((int32_t*)d) = pdata->i32;
		break;
	case (GPA_TYPE_UINT32):
	case (GPA_TYPE_ENUM):
		*((uint32_t*)d) = pdata->u32;
		break;
	case (GPA_TYPE_UINT64):
		*((uint64_t*)d) = pdata->u64;
		break;
	case (GPA_TYPE_FLOAT32):
		*((float*)d) = pdata->f32;
		break;
	case (GPA_TYPE_STRING):
		*((char**)d) = (char *)(pdata->str);
		break;
	};

	if (p->hook && run_hook)
		p->hook(d, p->hook_args);

	return 0;
}

/************************************************************
 * Public API                                               *
 ************************************************************/


int gpa_enable_hook(struct gpa_param *p, void (*hook)(const void *, const void*),
			const void *args)
{
	if (!p || !p->param)
		return 1;

	p->hook = hook;
	p->hook_args = args;
	return 0;

}

int gpa_enable_cache(struct gpa_param *p)
{
	struct cache_list *new_elem;

	if (!p || !p->param)
		return 1;

	p->cached = 1;

	new_elem = calloc(1, sizeof(struct cache_list));
	new_elem->param = p;
	if (!cached_params) {
		cached_params = new_elem;
	} else {
		struct cache_list *c = cached_params;
		while (c->next)
			c = c->next;
		c->next = new_elem;
	}

	return 0;
}


int gpa_get_param(struct gpa_param *p, void *d)
{
	return _gpa_get_param(p, d, 0);
}


int gpa_set_param(struct gpa_param *p, const void *d)
{
	int ret = 0;
	char *state;
	union param_data newval;
	union param_data current_val;
	union param_data *pcurrent_val;
	int change = 0;

	/* 1 - Get the current value */

	if (p->cached) {
		pcurrent_val = &p->cached_data;
	} else {
		if (gpa_generic_get(p, &current_val)) {
			return 1;
		}
		pcurrent_val = &current_val;
	}

	/* 2 - If the new value is different, update the GPA parameter */

	switch (p->type) {
	case (GPA_TYPE_UINT8):
		newval.u8 = *((uint8_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_u8(tmgr_mod, p->param, newval.u8);
			change = 1;
		}
		break;
	case (GPA_TYPE_INT16):
		newval.i16 = *((int16_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_i16(tmgr_mod, p->param, newval.i16);
			change = 1;
		}
		break;
	case (GPA_TYPE_UINT16):
		newval.u16 = *((uint16_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_u16(tmgr_mod, p->param, newval.u16);
			change = 1;
		}
		break;
	case (GPA_TYPE_INT32):
		newval.i32 = *((int32_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_i32(tmgr_mod, p->param, newval.i32);
			change = 1;
		}
		break;
	case (GPA_TYPE_BOOL):
		newval.i32 = *((int32_t*)d);
		if (newval.i32)
			state = "1";
		else
			state = "0";
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_fromstr(tmgr_mod, p->param, state);
			change = 1;
		}
		break;
	case (GPA_TYPE_UINT32):
		newval.u32 = *((uint32_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_u32(tmgr_mod, p->param, newval.u32);
			change = 1;
		}
		break;
	case (GPA_TYPE_UINT64):
		newval.u64 = *((uint64_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_u64(tmgr_mod, p->param, newval.u64);
			change = 1;
		}
		break;
	case (GPA_TYPE_FLOAT32):
		newval.f32 = *((float*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_f32(tmgr_mod, p->param, newval.f32);
			change = 1;
		}
		break;
	case (GPA_TYPE_ENUM):
		newval.u32 = *((uint32_t*)d);
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_enum(tmgr_mod, p->param, newval.u32);
			change = 1;
		}
		break;
	case (GPA_TYPE_STRING):
		newval.str = (char *)d;
		if (!gpa_compare_param_data(pcurrent_val, &newval, p->type)) {
			ret = gpa_mod_prm_snd_fromstr(tmgr_mod, p->param, newval.str);
			change = 1;
		}
		break;
	};

	/* 3 - Update the cache if necessary */

	if (p->cached && change) {
		p->cache_initialized = 1;
		p->cached_data = newval;
	}

	/* 4 - Call post-modification hook if necessary */

	if (p->hook && change) {
		p->hook(d, p->hook_args);
	}

	return ret;
}

void gpa_update_caches(void)
{
	struct cache_list *c = cached_params;
	int dummy;

	while (c) {
		_gpa_get_param(c->param, &dummy, 1);
		c = c->next;
	}
}

#define MAX_RETRIES 5
#define _GPA_POLL_INTERVAL_NS 10000000 //10ms
/**
 * @brief  snd_u8_poll HACK: temporal snd wrapper function to avoid problems with
 *         minipc communication. This will be solved in the libgpa/minipc subsystem.
 * @note   This function would be equivalent to the gpa_mod_prm_snd_u8 when it is fixed!!
 * @param  mod: module pointer
 * @param  prm: parameter pointer
 * @param  val: value to be set
 * @retval 0 if success or 1 if fails
 */
int32_t _gpa_mod_prm_snd_u8_poll(struct gpa_mod* mod, struct gpa_prm* prm,
			uint8_t val)
{
	struct timespec ts = {.tv_sec = 1, .tv_nsec = 0};
	struct timespec ts_poll = {.tv_sec = 0, .tv_nsec = _GPA_POLL_INTERVAL_NS};
	int r = MAX_RETRIES;
	int new_val;

	while(r--)
	{
		gpa_mod_prm_snd_u8(mod,prm,val);
		/* previous call could end as timeout, but we'll check */
		nanosleep(&ts_poll, 0);
		new_val = gpa_prm_get_u8(prm);
		if(new_val==val)
			break; // value is set correctly
		pr_verbose("value was not set, retrying...(%d/%d)\n",
			MAX_RETRIES-r,
			MAX_RETRIES);
		nanosleep(&ts, 0);
	}

	return r?0:1;
}

/**
 * @brief  snd_u16_poll HACK: temporal snd wrapper function to avoid problems with
 *         minipc communication. This will be solved in the libgpa/minipc subsystem.
 * @note   This function would be equivalent to the gpa_mod_prm_snd_u16 when it is fixed!!
 * @param  mod: module pointer
 * @param  prm: parameter pointer
 * @param  val: value to be set
 * @retval 0 if success or 1 if fails
 */
int32_t _gpa_mod_prm_snd_u16_poll(struct gpa_mod* mod, struct gpa_prm* prm,
			uint16_t val)
{
	struct timespec ts = {.tv_sec = 1, .tv_nsec = 0};
	struct timespec ts_poll = {.tv_sec = 0, .tv_nsec = _GPA_POLL_INTERVAL_NS};
	int r = MAX_RETRIES;
	int new_val;

	while(r--)
	{
		gpa_mod_prm_snd_u16(mod,prm,val);
		/* previous call could end as timeout, but we'll check */
		nanosleep(&ts_poll, 0);
		new_val = gpa_prm_get_u16(prm);
		if(new_val==val)
			break; // value is set correctly
		pr_verbose("value was not set, retrying...(%d/%d)\n",
			MAX_RETRIES-r,
			MAX_RETRIES);
		nanosleep(&ts, 0);
	}

	return r?0:1;
}

/**
 * @brief  snd_u32_poll HACK: temporal snd wrapper function to avoid problems with
 *         minipc communication. This will be solved in the libgpa/minipc subsystem.
 * @note   This function would be equivalent to the gpa_mod_prm_snd_u32 when it is fixed!!
 * @param  mod: module pointer
 * @param  prm: parameter pointer
 * @param  val: value to be set
 * @retval 0 if success or 1 if fails
 */
int32_t _gpa_mod_prm_snd_u32_poll(struct gpa_mod* mod, struct gpa_prm* prm,
			uint32_t val)
{
	struct timespec ts = {.tv_sec = 1, .tv_nsec = 0};
	struct timespec ts_poll = {.tv_sec = 0, .tv_nsec = _GPA_POLL_INTERVAL_NS};
	int r = MAX_RETRIES;
	int new_val;

	while(r--)
	{
		gpa_mod_prm_snd_u32(mod,prm,val);
		/* previous call could end as timeout, but we'll check */
		nanosleep(&ts_poll, 0);
		new_val = gpa_prm_get_u32(prm);
		if(new_val==val)
			break; // value is set correctly
		pr_verbose("value was not set, retrying...(%d/%d)\n",
			MAX_RETRIES-r,
			MAX_RETRIES);
		nanosleep(&ts, 0);
	}

	return r?0:1;
}



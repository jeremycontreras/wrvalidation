/*
 * ports.c
 *
 * libGPA-based parameter interface for Time Manager. Port parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 11, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "ppsi.h"
#include "utils.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* Port parameters */
enum port_params_enum {
	PORT_CFG_SRC_RANK,
	PORT_CFG_PROTO,
	PORT_CFG_MODE,

	PORT_INFO_NAME,
	PORT_INFO_STATUS,
	PORT_INFO_PROFILE,
	PORT_INFO_RANK,

	N_PORT_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* Number of ports */
static int n_ports;

/* Port names */
static char port_names[MAX_PORTS][MAX_STR_LEN];

/*
 * Array to save the current port mode for each mode.
 * This is needed to compare port configuration changes to the previous port
 * configuration status.
 */
static enum port_mode current_port_mode[MAX_PORTS];

static int initialized;

/* Port params for the <ports> modir */
static struct gpa_param port_params[MAX_PORTS][N_PORT_PARAMS];


/* enum to string tables */

static struct enum_str_match port_proto_def[N_PORT_PROTOS] = {
	{.id = PORT_PROTO_DISABLED,     .str = "DISABLED"},
	{.id = PORT_PROTO_WR,           .str = "WR"},
	{.id = PORT_PROTO_PTP,          .str = "PTP"},
};

static struct enum_str_match port_mode_def[N_PORT_MODES] = {
	{.id = PORT_MODE_MASTER,        .str = "MASTER"},
	{.id = PORT_MODE_SLAVE,         .str = "SLAVE"},
	{.id = PORT_MODE_AUTO,          .str = "AUTO"},
};

static struct enum_str_match port_status_def[N_PORT_STATUS] = {
	{.id = PORT_STATUS_SLAVE,       .str = "SLAVE"},
	{.id = PORT_STATUS_MASTER,      .str = "MASTER"},
	{.id = PORT_STATUS_PASSIVE,     .str = "PASSIVE"},
	{.id = PORT_STATUS_DISABLED,    .str = "DISABLED"},
};

/* oid translator */
static struct enum_oid_match ports_enum_oid_translator[N_PORT_PARAMS] = {
	/* config */
	{.enum_id = PORT_CFG_SRC_RANK,  .oid = 0},
	{.enum_id = PORT_CFG_PROTO,     .oid = 1},
	{.enum_id = PORT_CFG_MODE,      .oid = 2},

	/* info */
	{.enum_id = PORT_INFO_NAME,     .oid = 0},
	{.enum_id = PORT_INFO_STATUS,   .oid = 1},
};

/* Default parameter values */
static uint32_t dflt_port_src_rank      = 0;
static int dflt_port_proto              = PORT_PROTO_DISABLED;
static int dflt_port_mode               = PORT_MODE_AUTO;
static int dflt_port_status             = PORT_STATUS_DISABLED;


/************************************************************
 * Private functions                                        *
 ************************************************************/


/*
 * Checks if the configuration change for <port> (setting its <mode>) is
 * compatible with the new configuration or not.
 *
 * Returns:
 *   1 if the configuration is valid
 *   0 otherwise
 */
static int port_config_is_valid(int port, enum port_mode mode)
{
	/* TODO: Anything to check here? */
	return 1;
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

/*
 * create_port_params
 *
 * Creates and publishes the port parameters.
 */
int create_port_params(void)
{
	int i;
	int j;
	int oid;
	struct enum_oid_match *v_oid = ports_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(ports_enum_oid_translator);

	if (find_ports(PORT_TYPE_WR, port_names, MAX_PORTS) <= 0)
		return 1;

	for (i = 0; i < n_ports; i++)
	{
		char modir_name[MAX_STR_LEN] = {0};
		char param_name[MAX_STR_LEN] = {0};

		/**** Config parameters ****/

		/* Create config modir name */
		snprintf(modir_name, MAX_STR_LEN-1, PORTS_CONFIG_MODIR_PATH,
			port_names[i]);


		/* Port src rank */
		strncpy(param_name, "src_rank", MAX_STR_LEN-1);
		oid = gpa_common_find_oid(v_oid, n_v_oid, PORT_CFG_SRC_RANK);
		if(oid < 0)
			return 1;

		port_params[i][PORT_CFG_SRC_RANK].param = gpa_prm_create_val(
			0, oid, param_name, GPA_PRM_VTX_U32,
			GPA_ACC_RWL | GPA_ACC_INTERNAL,
			{.u32 = dflt_port_src_rank});
		if (!port_params[i][PORT_CFG_SRC_RANK].param) {
			pr_error("Error creating %s/%s\n",
				modir_name, param_name);
			return 1;
		}
		gpa_prm_set_desc(port_params[i][PORT_CFG_SRC_RANK].param,
		"Rank of the port to be selected as an active time source by the Virtual Clock policy. If 0 this port will never be active.");
		if (gpa_modir_path_addprm(tmgr_mod,  modir_name,
			port_params[i][PORT_CFG_SRC_RANK].param)) {
			pr_error("Error adding src_rank to %s\n",
				modir_name);
			return 1;
		}
		port_params[i][PORT_CFG_SRC_RANK].type = GPA_TYPE_UINT32;
		gpa_enable_cache(&port_params[i][PORT_CFG_SRC_RANK]);


		/* Port protocol */
		memset(param_name, 0, MAX_STR_LEN);
		strncpy(param_name, "proto", MAX_STR_LEN-1);
		oid = gpa_common_find_oid(v_oid, n_v_oid, PORT_CFG_PROTO);
		if(oid < 0)
			return 1;

		port_params[i][PORT_CFG_PROTO].param = gpa_prm_create_enum(
			0, oid, param_name,
			GPA_PRM_VTX_ENUM, GPA_ACC_RWL | GPA_ACC_INTERNAL, 0,
			N_PORT_PROTOS, GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
			dflt_port_proto);
		if (!port_params[i][PORT_CFG_PROTO].param) {
			pr_error("Error creating %s/%s\n", modir_name,
				param_name);
			return 1;
		}
		for (j = 0; j < N_PORT_PROTOS; j++) {
			gpa_prm_enum_add_entry(port_params[i][PORT_CFG_PROTO].param,
				port_proto_def[j].id, port_proto_def[j].str);
		}
		gpa_prm_set_desc(port_params[i][PORT_CFG_PROTO].param,
		"Timing protocol used by this port (network interface). PTP and WR can not work simultaneously on the same port.");
		if (gpa_modir_path_addprm(tmgr_mod, modir_name,
			port_params[i][PORT_CFG_PROTO].param)) {
			pr_error("Error adding proto to %s\n",
				modir_name);
			return 1;
		}
		port_params[i][PORT_CFG_PROTO].type = GPA_TYPE_ENUM;
		gpa_enable_cache(&port_params[i][PORT_CFG_PROTO]);


		/* Port mode */
		memset(param_name, 0, MAX_STR_LEN);
		strncpy(param_name, "mode", MAX_STR_LEN-1);
		oid = gpa_common_find_oid(v_oid, n_v_oid, PORT_CFG_MODE);
		if(oid < 0)
			return 1;

		port_params[i][PORT_CFG_MODE].param = gpa_prm_create_enum(
			0, oid, param_name,
			GPA_PRM_VTX_ENUM, GPA_ACC_RWL | GPA_ACC_INTERNAL, 0,
			N_PORT_MODES, GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
			dflt_port_mode);
		if (!port_params[i][PORT_CFG_MODE].param) {
			pr_error("Error creating %s/%s\n", modir_name, param_name);
			return 1;
		}
		for (j = 0; j < N_PORT_MODES; j++) {
			gpa_prm_enum_add_entry(port_params[i][PORT_CFG_MODE].param,
				port_mode_def[j].id, port_mode_def[j].str);
		}
		gpa_prm_set_desc(port_params[i][PORT_CFG_MODE].param,
				"Configures the mode of the port in PPSi/PTPd. If src_rank > 0, SLAVE or AUTO mode must be configured.");
		if (gpa_modir_path_addprm(tmgr_mod, modir_name,
			port_params[i][PORT_CFG_MODE].param)) {
			pr_error("Error adding mode to %s\n",
				modir_name);
			return 1;
		}
		port_params[i][PORT_CFG_MODE].type = GPA_TYPE_ENUM;
		gpa_enable_cache(&port_params[i][PORT_CFG_MODE]);
		current_port_mode[i] = dflt_port_mode;



		/**** Info parameters ****/

		/* Create info modir name */
		memset(modir_name, 0, MAX_STR_LEN);
		snprintf(modir_name, MAX_STR_LEN-1, PORTS_INFO_MODIR_PATH,
			port_names[i]);


		/* Port name */
		memset(param_name, 0, MAX_STR_LEN);
		strncpy(param_name, "ifname", MAX_STR_LEN-1);
		oid = gpa_common_find_oid(v_oid, n_v_oid, PORT_INFO_NAME);
		if(oid < 0)
			return 1;

		port_params[i][PORT_INFO_NAME].param = gpa_prm_create_str(
			0, oid, param_name, GPA_PRM_VTA_STRING,
			GPA_ACC_R | GPA_ACC_INTERNAL, port_names[i],
			MAX_STR_LEN);
		if (!port_params[i][PORT_INFO_NAME].param) {
			pr_error("Error creating %s/%s\n", modir_name,
				param_name);
			return 1;
		}
		gpa_prm_set_desc(port_params[i][PORT_INFO_NAME].param,
				"Port name (Network interface name)");
		if (gpa_modir_path_addprm(tmgr_mod, modir_name,
			port_params[i][PORT_INFO_NAME].param)) {
			pr_error("Error adding name to %s\n",
				modir_name);
			return 1;
		}
		port_params[i][PORT_INFO_NAME].type = GPA_TYPE_STRING;


		/* Port status */
		memset(param_name, 0, MAX_STR_LEN);
		strncpy(param_name, "status", MAX_STR_LEN-1);
		oid = gpa_common_find_oid(v_oid, n_v_oid, PORT_INFO_STATUS);
		if(oid < 0)
			return 1;

		port_params[i][PORT_INFO_STATUS].param = gpa_prm_create_enum(
			0, oid, param_name,
			GPA_PRM_VTX_ENUM, GPA_ACC_RT | GPA_ACC_INTERNAL, 0,
			N_PORT_STATUS, GPA_PRM_ENUM_OPT_INDEXED_DIRECT,
			dflt_port_status);
		if (!port_params[i][PORT_INFO_STATUS].param) {
			pr_error("Error creating %s/%s\n", modir_name, param_name);
			return 1;
		}
		for (j = 0; j < N_PORT_STATUS; j++) {
			gpa_prm_enum_add_entry(port_params[i][PORT_INFO_STATUS].param,
				port_status_def[j].id, port_status_def[j].str);
		}
		gpa_prm_set_desc(port_params[i][PORT_INFO_STATUS].param,
				"Port status");
		if (gpa_modir_path_addprm(tmgr_mod, modir_name,
			port_params[i][PORT_INFO_STATUS].param)) {
			pr_error("Error adding status to %s\n",
				modir_name);
			return 1;
		}
		port_params[i][PORT_INFO_STATUS].type = GPA_TYPE_ENUM;
	}

	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/

void check_port_config(void)
{
	int i;

	for (i = 0; i < n_ports; i++)
	{
		enum port_mode mode;
		char *port_name = 0;

		get_port_mode(i, &mode);
		get_port_iface_name(i, &port_name);

		/* Check if the configuration change is valid */
		if (port_config_is_valid(i, mode)) {
			/* Consolidate the configuration change if it's valid */
			current_port_mode[i] = mode;
		} else {
			pr_warning("Wrong port configuration. "
				"Error setting port %s mode (%s)\n", port_name,
				port_mode_def[mode].str);
			set_port_mode(i, current_port_mode[i]);
		}
	}
}

/********** Getter functions **********/

int get_port_name(unsigned int p, const char **name)
{
	if (!name) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_INFO_NAME], name)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_src_rank(unsigned int p, uint32_t *rank)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_CFG_SRC_RANK], rank)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_proto(unsigned int p, enum port_proto *proto)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_CFG_PROTO], proto)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_mode(unsigned int p, enum port_mode *mode)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_CFG_MODE], mode)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_status(unsigned int p, enum port_status *status)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_INFO_STATUS], status)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_profile(unsigned int p, const char **profile)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_INFO_PROFILE], profile)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_port_rank(unsigned int p, uint32_t *rank)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_get_param(&port_params[p][PORT_INFO_RANK], rank)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

/********** Setter functions **********/


int set_port_src_rank(unsigned int p, uint32_t rank)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_CFG_SRC_RANK], &rank)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}


int set_port_proto(unsigned int p, enum port_proto proto)
{
	char *port_name;

	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}
	if (proto < 0 || proto >= N_PORT_PROTOS) {
		pr_error("Invalid port protocol %d\n", proto);
		return 1;
	}
	get_port_iface_name(p, &port_name);
	if (strstr(port_name, "eth") && proto == PORT_PROTO_WR) {
		pr_error("Copper port %s can't use protocol WR\n",
			port_name);
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_CFG_PROTO], &proto)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}


int set_port_mode(unsigned int p, enum port_mode mode)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}
	if (mode < 0 || mode >= N_PORT_MODES) {
		pr_error("Invalid port mode %d\n", mode);
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_CFG_MODE], &mode)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;

}


int set_port_status(unsigned int p, enum port_status status)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}
	if (status < 0 || status >= N_PORT_STATUS) {
		pr_error("Invalid port status %d\n", status);
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_INFO_STATUS], &status)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;

}


int set_port_profile(unsigned int p, char *profile)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}
	if (!profile) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_INFO_PROFILE], profile)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}


int set_port_rank(unsigned int p, uint32_t rank)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}
	if (!rank) {
		pr_error("Argument is a NULL pointer\n");
		return 1;
	}

	if (gpa_set_param(&port_params[p][PORT_INFO_RANK], &rank)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}


/********** Other functions **********/

/*
 * These functions are not mapped to a gpa parameter.
 */

int get_nports(void)
{
	return n_ports;
}

int get_port_iface_name(unsigned int p, char **name)
{
	if (p > n_ports) {
		pr_error("Invalid port number: %d\n", p);
		return 1;
	}

	*name = port_names[p];

	return 0;
}

int initialize_ports_info(void)
{
	int n;

	if (initialized)
		return n_ports;

	n = find_ports(PORT_TYPE_WR, port_names, MAX_PORTS);

	if (n <= 0)
		return 1;

	n_ports = n;
	initialized = 1;

	return 0;
}

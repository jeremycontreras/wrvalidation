/*
 * tmgr_general.c
 *
 * libGPA-based parameter interface for Time Manager. General tmgr parameters.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 21, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "preset.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum tmgr_params {
	/* Config parameters */
	TMGR_CFG_UPDATE,
	TMGR_CFG_PRESET,

	/* misc parameters */
	TMGR_MISC_INFO_UPTIME,
	TMGR_MISC_CFG_TIMEZONE,
	TMGR_MISC_CFG_PPS_MODE,
	TMGR_MISC_LEGACY_DAYTIME,
	TMGR_MISC_LEGACY_TIME,

	N_TMGR_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* enum to string translation tables */
static struct enum_str_match pps_mode_enum[N_PPS_MODES] = {
	{.id = PPS_MODE_TMGR_ALWAYS_ON,    .str = "Always ON"},
	{.id = PPS_MODE_TMGR_ONLY_LOCKED,  .str = "Only Locked"},
	{.id = PPS_MODE_TMGR_LEGACY,       .str = "Legacy"},
};

static struct gpa_param tmgr_params[N_TMGR_PARAMS];

/* Default parameter values */
static uint64_t dflt_info_uptime        = 0;
/*
 * dflt_cfg_preset selects the preset number as indexed in the <gbl_presets> array
 * below in preset.c
 * This may not match the preset identifier.
 */
static int dflt_cfg_preset              = 0;
static int dflt_cfg_update              = 0;
static char *dflt_cfg_timezone          = "Europe/Madrid";
static enum pps_mode dflt_cfg_pps_mode  = PPS_MODE_TMGR_ONLY_LOCKED;
static int dflt_legacy_daytimep         = 0;
static int dflt_legacy_timep            = 0;

/* OIDs */
static struct enum_oid_match tmgr_oid_translator[N_TMGR_PARAMS] = {
	/* misc/info */
	{.enum_id = TMGR_MISC_INFO_UPTIME,    .oid = 0},

	/* misc/config */
	{.enum_id = TMGR_MISC_CFG_TIMEZONE,   .oid = 0},
	{.enum_id = TMGR_MISC_CFG_PPS_MODE,   .oid = 1},

	/* misc/legacy */
	{.enum_id = TMGR_MISC_LEGACY_DAYTIME, .oid = 0},
	{.enum_id = TMGR_MISC_LEGACY_TIME,    .oid = 1},

	/* config */
	{.enum_id = TMGR_CFG_UPDATE,          .oid = 0},
	{.enum_id = TMGR_CFG_PRESET,          .oid = 1},
};


/************************************************************
 * Private functions                                        *
 ************************************************************/

#define set_pps_mode init_tmgr_hald_pps_mode
static void hook_pps_mode(const void *data, const void *args)
{
	enum pps_mode m = *((enum pps_mode *)data);
	set_pps_mode(m);
}
#undef set_pps_mode

static void hook_preset(const void *data, const void *args)
{
	int preset = *((int*)data);
	load_glb_preset(preset);
}

/************************************************************
 * Module-specific functions                                *
 ************************************************************/

/*
 * create_tmgr_params
 *
 * Creates and publishes the general tmgr parameters and sets them to default
 * values.
 */
int create_tmgr_general_params(void)
{
	int oid;
	struct enum_oid_match *v_oid = tmgr_oid_translator;
	int n_v_oid = ARRAY_SIZE(tmgr_oid_translator);
	struct preset_name *presets;
	int num_presets, max_presets;
	unsigned int last_preset;
	int i;

	/* Uptime: in MISC_INFO_MODIR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_MISC_INFO_UPTIME);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_MISC_INFO_UPTIME].param = gpa_prm_create_val(
		0, oid, "uptime", GPA_PRM_VTX_U64,
		GPA_ACC_R | GPA_ACC_INTERNAL, {.u64 = dflt_info_uptime});
	if (!tmgr_params[TMGR_MISC_INFO_UPTIME].param) {
		pr_error("Error creating %s/uptime\n",
			modir_array[MISC_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_MISC_INFO_UPTIME].param,
		"Time Manager uptime in seconds");
	gpa_prm_set_unit(tmgr_params[TMGR_MISC_INFO_UPTIME].param,
		"s");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[MISC_INFO_MODIR].mp,
		tmgr_params[TMGR_MISC_INFO_UPTIME].param)) {
		pr_error("Error adding uptime to %s\n",
			modir_array[MISC_INFO_MODIR].mp);
		return 1;
	}
	tmgr_params[TMGR_MISC_INFO_UPTIME].type = GPA_TYPE_UINT64;


	/* Timezone: in MISC_CONFIG_MODIR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_MISC_CFG_TIMEZONE);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_MISC_CFG_TIMEZONE].param = gpa_prm_create_str(
		0, oid, "timezone", GPA_PRM_VTA_STRING,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, dflt_cfg_timezone, MAX_STR_LEN);
	if (!tmgr_params[TMGR_MISC_CFG_TIMEZONE].param) {
		pr_error("Error creating %s/timezone\n",
			modir_array[MISC_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_MISC_CFG_TIMEZONE].param,
		"Time Zone information");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[MISC_CONFIG_MODIR].mp,
		tmgr_params[TMGR_MISC_CFG_TIMEZONE].param)) {
		pr_error("Error adding timezone to %s\n",
			modir_array[MISC_INFO_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, tmgr_params[TMGR_MISC_CFG_TIMEZONE].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("timezone is not configured. "
			"Using default value: %s\n", dflt_cfg_timezone);
	}
	tmgr_params[TMGR_MISC_CFG_TIMEZONE].type = GPA_TYPE_STRING;

	/* pps_mode: in MISC_CONFIG_MODIR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_MISC_CFG_PPS_MODE);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_MISC_CFG_PPS_MODE].param = gpa_prm_create_enum(
		0, oid, "pps_mode", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, 0, N_PPS_MODES,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_cfg_pps_mode);
	if (!tmgr_params[TMGR_MISC_CFG_PPS_MODE].param) {
		pr_error("Error creating %s/pps_mode\n",
			modir_array[MISC_CONFIG_MODIR].mp);
		return 1;
	}

	gpa_prm_set_desc(tmgr_params[TMGR_MISC_CFG_PPS_MODE].param,
			"PPS mode configuration");
	for (i = 0; i < N_PPS_MODES; i++) {
		gpa_prm_enum_add_entry(tmgr_params[TMGR_MISC_CFG_PPS_MODE].param,
					pps_mode_enum[i].id, pps_mode_enum[i].str);
	}

	if (gpa_modir_path_addprm(tmgr_mod,
					modir_array[MISC_CONFIG_MODIR].mp,
					tmgr_params[TMGR_MISC_CFG_PPS_MODE].param)) {
		pr_error("Error adding pps_mode to %s\n",
			modir_array[MISC_INFO_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, tmgr_params[TMGR_MISC_CFG_PPS_MODE].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("pps_mode is not configured. "
			"Using default value: %d\n", dflt_cfg_pps_mode);
	}
	tmgr_params[TMGR_MISC_CFG_PPS_MODE].type = GPA_TYPE_ENUM;
	gpa_enable_cache(&tmgr_params[TMGR_MISC_CFG_PPS_MODE]);
	gpa_enable_hook(&tmgr_params[TMGR_MISC_CFG_PPS_MODE], hook_pps_mode, 0);

	/* daytime_protocol: in MISC_LEGACY_MODIR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_MISC_LEGACY_DAYTIME);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_MISC_LEGACY_DAYTIME].param = gpa_prm_create_bool(
		0, oid, "daytime_protocol", GPA_ACC_RL | GPA_ACC_INTERNAL | GPA_ACC_EXPERT,
		GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, dflt_legacy_daytimep);
	if (!tmgr_params[TMGR_MISC_LEGACY_DAYTIME].param) {
		pr_error("Error creating %s/daytime_protocol\n",
			modir_array[MISC_LEGACY_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_MISC_LEGACY_DAYTIME].param,
			"Protocol that provides readable daytime using UDP or TCP packets according to RFC867");
	if (gpa_modir_path_addprm(tmgr_mod,
					modir_array[MISC_LEGACY_MODIR].mp,
					tmgr_params[TMGR_MISC_LEGACY_DAYTIME].param)) {
		pr_error("Error adding daytime_protocol to %s\n",
			modir_array[MISC_LEGACY_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, tmgr_params[TMGR_MISC_LEGACY_DAYTIME].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("daytime_protocol is not configured. "
			"Using default value: %d\n", dflt_legacy_daytimep);
	}

	tmgr_params[TMGR_MISC_LEGACY_DAYTIME].type = GPA_TYPE_BOOL;

	/* time_protocol: in MISC_LEGACY_MODIR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_MISC_LEGACY_TIME);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_MISC_LEGACY_TIME].param = gpa_prm_create_bool(
		0, oid, "time_protocol", GPA_ACC_RL | GPA_ACC_INTERNAL | GPA_ACC_EXPERT,
		GPA_PRM_ENUM_OPT_BOOL_ENABLED_DISABLED, dflt_legacy_timep);
	if (!tmgr_params[TMGR_MISC_LEGACY_TIME].param) {
		pr_error("Error creating %s/time_protocol\n",
			modir_array[MISC_LEGACY_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_MISC_LEGACY_TIME].param,
			"Protocol that provides machine readable date and time (32 bits) using UDP or TCP packets according to RFC868");
	if (gpa_modir_path_addprm(tmgr_mod,
					modir_array[MISC_LEGACY_MODIR].mp,
					tmgr_params[TMGR_MISC_LEGACY_TIME].param)) {
		pr_error("Error adding time_protocol to %s\n",
			modir_array[MISC_LEGACY_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, tmgr_params[TMGR_MISC_LEGACY_TIME].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("time_protocol is not configured. "
			"Using default value: %d\n", dflt_legacy_timep);
	}

	tmgr_params[TMGR_MISC_LEGACY_TIME].type = GPA_TYPE_BOOL;

	/* Update flag */
	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_CFG_UPDATE);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_CFG_UPDATE].param = gpa_prm_create_bool(
		0, oid, "update_config", GPA_ACC_RW | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_ON_OFF, dflt_cfg_update);
	if (!tmgr_params[TMGR_CFG_UPDATE].param) {
		pr_error("Error creating %s/update_config\n",
			modir_array[CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_CFG_UPDATE].param,
		"Commits (applies) the current parameter values");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[CONFIG_MODIR].mp,
		tmgr_params[TMGR_CFG_UPDATE].param)) {
		pr_error("Error adding update_config to %s\n",
			modir_array[CONFIG_MODIR].mp);
		return 1;
	}
	tmgr_params[TMGR_CFG_UPDATE].type = GPA_TYPE_BOOL;


	/* Preset */
	/*
	 * Scan available presets and populate the parameter enum.
	 */
	num_presets = get_available_glb_presets(&last_preset);
	if (num_presets < 0) {
		pr_error("Error scanning presets\n");
		return 1;
	}
	max_presets = last_preset+1;
	presets = get_glb_presets();

	oid = gpa_common_find_oid(v_oid, n_v_oid, TMGR_CFG_PRESET);
	if(oid < 0)
		return 1;

	tmgr_params[TMGR_CFG_PRESET].param = gpa_prm_create_enum(
		0, oid, "preset", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, 0, num_presets,
		GPA_PRM_ENUM_OPT_NONE, dflt_cfg_preset);
	if (!tmgr_params[TMGR_CFG_PRESET].param) {
		pr_error("Error creating %s/preset\n",
			modir_array[CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(tmgr_params[TMGR_CFG_PRESET].param,
		"VC preset number to use");
	for (i = 0; i < max_presets; i++) {
		if(presets[i].used)
			gpa_prm_enum_add_entry(tmgr_params[TMGR_CFG_PRESET].param,
					i, presets[i].name);
	}
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[CONFIG_MODIR].mp,
		tmgr_params[TMGR_CFG_PRESET].param)) {
		pr_error("Error adding preset to %s\n",
			modir_array[CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, tmgr_params[TMGR_CFG_PRESET].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("preset is not configured. "
			"Using default value: %d\n", dflt_cfg_preset);
	}
	tmgr_params[TMGR_CFG_PRESET].type = GPA_TYPE_ENUM;
	gpa_enable_cache(&tmgr_params[TMGR_CFG_PRESET]);
	gpa_enable_hook(&tmgr_params[TMGR_CFG_PRESET], hook_preset, 0);

	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/

/********** Getter functions **********/

void init_tmgr_hald_pps_mode(enum pps_mode m)
{
	switch(m) {
	case PPS_MODE_TMGR_ALWAYS_ON:
		hald_set_pps_mode_state_tmgr(1);
		hald_set_pps_mode_controller(PPS_MODE_CONTROLLER_TMGR);
		break;
	case PPS_MODE_TMGR_ONLY_LOCKED:
	case PPS_MODE_TMGR_LEGACY:
        default:
		hald_set_pps_mode_state_tmgr(0);
		hald_set_pps_mode_controller(PPS_MODE_CONTROLLER_TMGR);
		break;
	};
}

int get_tmgr_config_pps_mode(uint32_t *mode)
{
	if (!mode) {
		pr_warning("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&tmgr_params[TMGR_MISC_CFG_PPS_MODE], mode)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_tmgr_info_uptime(uint64_t *uptime)
{
	if (!uptime) {
		pr_warning("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&tmgr_params[TMGR_MISC_INFO_UPTIME], uptime)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_tmgr_config_update(int *update)
{
	if (!update) {
		pr_warning("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&tmgr_params[TMGR_CFG_UPDATE], update)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_tmgr_config_preset(uint32_t *preset)
{
	if (!preset) {
		pr_warning("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&tmgr_params[TMGR_CFG_PRESET], preset)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


/********** Setter functions **********/


int set_tmgr_info_uptime(uint64_t uptime)
{
	if (gpa_set_param(&tmgr_params[TMGR_MISC_INFO_UPTIME], &uptime)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_tmgr_config_update(int update)
{
	if (gpa_set_param(&tmgr_params[TMGR_CFG_UPDATE], &update)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_tmgr_config_preset(uint32_t preset)
{
	if (gpa_set_param(&tmgr_params[TMGR_CFG_PRESET], &preset)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_tmgr_autoload_preset(int enable)
{
	void (*func)(const void *, const void*) = (enable) ? hook_preset : NULL;

	return gpa_enable_hook(&tmgr_params[TMGR_CFG_PRESET], func, 0);
}

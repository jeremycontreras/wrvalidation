/*
 * gm.c
 *
 * libGPA-based parameter interface for Time Manager. GrandMaster mode
 * parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 26, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "leapsec.h"
#include "ktmgr.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum gm_params {
	GM_INFO_MESSAGE,
	GM_INFO_ALIGN_STATE,
	GM_INFO_DETECTED,
	GM_INFO_PPS_DELTA,
	GM_INFO_LEAPSEC_FILE_EXP_DATE,
	GM_INFO_LEAPSEC_FILE_VALID,

	GM_CFG_ALIGN_PPS,
	GM_CFG_OFFSET,
	GM_CFG_FORCE_CLOCK_CLASS,
	GM_CFG_CLOCK_ACCURACY,
	GM_CFG_TIME_SOURCE,
	GM_CFG_PRIORITY1,
	GM_CFG_PRIORITY2,
	GM_CFG_PPS_MANDATORY,
	GM_CFG_SRC_RANK,

	N_GM_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* GrandMaster mode params for the <gm> modir */
static struct gpa_param gm_params[N_GM_PARAMS];

/* enum to string tables */
static struct enum_str_match gm_info_external_state[N_SOFTPLL_ALIGN_STATES] = {
	{.id = SOFTPLL_ALIGN_STATE_EXT_OFF,               .str = "EXT_OFF"},
	{.id = SOFTPLL_ALIGN_STATE_START,                 .str = "START"},
	{.id = SOFTPLL_ALIGN_STATE_INIT_CSYNC,            .str = "INIT_CSYNC"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_CSYNC,            .str = "WAIT_CSYNC"},
	{.id = SOFTPLL_ALIGN_STATE_START_ALIGNMENT,       .str = "START_ALIGNMENT"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_SAMPLE,           .str = "WAIT_SAMPLE"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_DELAY,      .str = "COMPENSATE_DELAY"},
	{.id = SOFTPLL_ALIGN_STATE_LOCKED,                .str = "LOCKED"},
	{.id = SOFTPLL_ALIGN_STATE_START_MAIN,            .str = "START_MAIN"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_CLKIN,            .str = "WAIT_CLKIN"},
	{.id = SOFTPLL_ALIGN_STATE_WAIT_PLOCK,            .str = "WAIT_PLOCK"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_1,            .str = "RESERVED1"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_2,            .str = "RESERVED2"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_3,            .str = "RESERVED3"},
	{.id = SOFTPLL_ALIGN_STATE_RESERVED_4,            .str = "RESERVED4"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_COARSE, .str = "COMPENSATE_PPS_COARSE"},
	{.id = SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_FINE,   .str = "COMPENSATE_PPS_FINE"},
};

static struct enum_str_match gm_info_detected[N_SOFTPLL_EXT_FPANEL] = {
	{.id = SOFTPLL_EXT_DETECTED_NONE,       .str = "None"},
	{.id = SOFTPLL_EXT_DETECTED_PPS,        .str = "PPS (only)"},
	{.id = SOFTPLL_EXT_DETECTED_CLK,        .str = "CLK (only)"},
	{.id = SOFTPLL_EXT_DETECTED_PPSCLK,     .str = "PPS & CLK"},
};

static struct enum_str_match gm_config_time_src[N_GM_TIME_SOURCES] = {
	{.id = GM_TIME_SOURCE_UNDEF,            .str = "UNDEFINED"},
	{.id = GM_TIME_SOURCE_ATOMIC_CLOCK,     .str = "ATOMIC_CLOCK"},
	{.id = GM_TIME_SOURCE_GNSS,             .str = "GNSS"},
	{.id = GM_TIME_SOURCE_PTP,              .str = "PTP"},
	{.id = GM_TIME_SOURCE_OTHER,            .str = "OTHER"},
};

static struct enum_str_match gm_config_pps_mandatory[N_GM_PPS_MANDATORY] = {
	{.id = GM_PPS_MANDATORY_YES,            .str = "YES"},
	{.id = GM_PPS_MANDATORY_NO,             .str = "NO"},
	{.id = GM_PPS_MANDATORY_STARTUP_ONLY,   .str = "STARTUP_ONLY"},
};

/* oid translator */
static struct enum_oid_match gm_enum_oid_translator[N_GM_PARAMS] = {
	/* gm/info */
	{.enum_id = GM_INFO_MESSAGE,                    .oid = 0},
	{.enum_id = GM_INFO_ALIGN_STATE,                .oid = 1},
	{.enum_id = GM_INFO_DETECTED,                   .oid = 2},
	{.enum_id = GM_INFO_PPS_DELTA,                  .oid = 3},
	{.enum_id = GM_INFO_LEAPSEC_FILE_EXP_DATE,      .oid = 4},
	{.enum_id = GM_INFO_LEAPSEC_FILE_VALID,         .oid = 5},

	/* gm/config */
	{.enum_id = GM_CFG_SRC_RANK,            .oid = 0},
	{.enum_id = GM_CFG_OFFSET,              .oid = 1},
	{.enum_id = GM_CFG_ALIGN_PPS,           .oid = 2},
	{.enum_id = GM_CFG_CLOCK_ACCURACY,      .oid = 3},
	{.enum_id = GM_CFG_TIME_SOURCE,         .oid = 4},
	{.enum_id = GM_CFG_PRIORITY1,           .oid = 5},
	{.enum_id = GM_CFG_PRIORITY2,           .oid = 6},
	{.enum_id = GM_CFG_PPS_MANDATORY,       .oid = 7},
	{.enum_id = GM_CFG_FORCE_CLOCK_CLASS,   .oid = 10},
};

/* Default parameter values */

static int dflt_gm_info_align_state                     = 0;
static enum softpll_ext_fpanel dflt_gm_info_detected    = SOFTPLL_EXT_DETECTED_NONE;
static int32_t dflt_gm_info_pps_delta                   = 0;
static char *dflt_gm_info_message                        = "Unknown";
static char *dflt_gm_info_leapsec_exp_date              = "";
static int dflt_gm_info_leapsec_valid                   = 1;

static int dflt_gm_cfg_align_pps                        = 0;
static int dflt_gm_cfg_offset                           = 0;
static uint8_t dflt_gm_cfg_clk_class                    = 0;
static uint8_t dflt_gm_cfg_clk_accuracy                 = GPA_1588_DEF_CLOCK_ACCURACY;
static enum gm_time_source dlft_gm_cfg_time_source      = GM_TIME_SOURCE_OTHER;
static uint8_t dflt_gm_cfg_priority1                    = 128;
static uint8_t dflt_gm_cfg_priority2                    = 128;
static enum gm_pps_mandatory dflt_gm_cfg_pps_mandatory  = GM_PPS_MANDATORY_YES;
static uint32_t dflt_gm_cfg_src_rank                    = 0;


/************************************************************
 * Private functions                                        *
 ************************************************************/

/* TODO: Remove this function and use a public one from libGPA */
static const char *_gm_clock_accuracy_desc(uint8_t value)
{
	switch(value)
	{
	case GPA_1588_ACU_1_PS:   return "<= 1 ps";
	case GPA_1588_ACU_2_5_PS: return "<= 2.5 ps";
	case GPA_1588_ACU_10_PS:  return "<= 10 ps";
	case GPA_1588_ACU_25_PS:  return "<= 25 ps";
	case GPA_1588_ACU_100_PS: return "<= 100 ps";
	case GPA_1588_ACU_250_PS: return "<= 250 ps";
	case GPA_1588_ACU_1_NS:   return "<= 1 ns";
	case GPA_1588_ACU_2_5_NS: return "<= 2.5 ns";
	case GPA_1588_ACU_10_NS:  return "<= 10 ns";
	case GPA_1588_ACU_25_NS:  return "<= 25 ns";
	case GPA_1588_ACU_100_NS: return "<= 100 ns";
	case GPA_1588_ACU_250_NS: return "<= 250 ns";
	case GPA_1588_ACU_1_US:   return "<= 1 us";
	case GPA_1588_ACU_2_5_US: return "<= 2.5 us";
	case GPA_1588_ACU_10_US:  return "<= 10 us";
	case GPA_1588_ACU_25_US:  return "<= 25 us";
	case GPA_1588_ACU_100_US: return "<= 100 us";
	case GPA_1588_ACU_250_US: return "<= 250 us";
	case GPA_1588_ACU_1_MS:   return "<= 1 ms";
	case GPA_1588_ACU_2_5_MS: return "<= 2.5 ms";
	case GPA_1588_ACU_10_MS:  return "<= 10 ms";
	case GPA_1588_ACU_25_MS:  return "<= 25 ms";
	case GPA_1588_ACU_100_MS: return "<= 100 ms";
	case GPA_1588_ACU_250_MS: return "<= 250 ms";
	case GPA_1588_ACU_1_S:    return "<= 1s";
	case GPA_1588_ACU_10_S:   return "<= 10s";
	case GPA_1588_ACU_GT_10_S:return "> 10s";
	case GPA_1588_ACU_UNKNOWN:return "Unknown";
	default: return NULL;
	}
}

/*
 * Sets the appropriate WARNING or CRITICAL flags to the
 * gm/info/leapsec_file_valid parameter.
 *
 * This function will be called by libgpa.
 */
int32_t leapsec_status_warning_check(const void *new_value, struct gpa_prm *p,
					uint8_t iwc)
{
	const union gpa_val *val = new_value;
	int valid = val->u16;

	if (iwc == GPA_PRM_RANGE_INPUT)
		return 1;

	if (valid == 0 && iwc == GPA_PRM_RANGE_CRITICAL)
		return 1;

	return 0;
}


void hook_align_pps(const void *data, const void *args)
{
	int align = *((int*)data);

	hald_set_softpll_ext_align_pps(align);
}

void hook_gm_offset(const void *data, const void *args)
{
	int32_t offset = *((int32_t*)data);

	hald_set_softpll_ext_user_offset(offset);
}

void hook_clock_accuracy(const void *data, const void *args)
{
	uint8_t accuracy = *((uint8_t*)data);

	ktmgr_set_attr(KTMGR_CLK_ACCURACY, accuracy);
}

void hook_time_source(const void *data, const void *args)
{
	enum gm_time_source src = *((enum gm_time_source*)data);

	ktmgr_set_attr(KTMGR_TIMESOURCE, src);
}

void hook_priority1(const void *data, const void *args)
{
	uint8_t priority = *((uint8_t*)data);

	ktmgr_set_attr(KTMGR_PRIORITY1, priority);
}

void hook_priority2(const void *data, const void *args)
{
	uint8_t priority = *((uint8_t*)data);

	ktmgr_set_attr(KTMGR_PRIORITY2, priority);
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

/*
 * create_gm_params
 *
 * Creates and publishes the GrandMaster mode parameters and sets them to
 * default values.
 */
int create_gm_params(void)
{
	int i;
	int oid;
	struct enum_oid_match *v_oid = gm_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(gm_enum_oid_translator);


	/**** Info parameters ****/

	/* GM Message */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_MESSAGE);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_MESSAGE].param = gpa_prm_create_str(
		0, oid, "message", GPA_PRM_VTA_STRING,
		GPA_ACC_RT | GPA_ACC_INTERNAL, dflt_gm_info_message, MAX_STR_LEN);
	if (!gm_params[GM_INFO_MESSAGE].param) {
		pr_error("Error creating %s/message\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_MESSAGE].param,
		"User friendly message that resume the current state of the"
		" GM timing source");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_MESSAGE].param)) {
		pr_error("Error adding message to %s\n",
			modir_array[GM_INFO_MESSAGE].mp);
		return 1;
	}
	gm_params[GM_INFO_MESSAGE].type = GPA_TYPE_STRING;


	/* GM Align State */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_ALIGN_STATE);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_ALIGN_STATE].param = gpa_prm_create_enum(
		0, oid, "align_state", GPA_PRM_VTX_ENUM,
		GPA_ACC_R | GPA_ACC_INTERNAL | GPA_ACC_EXPERT, 0, N_SOFTPLL_ALIGN_STATES,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_gm_info_align_state);
	if (!gm_params[GM_INFO_ALIGN_STATE].param) {
		pr_error("Error creating %s/align_state\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_ALIGN_STATE].param,
		"(Read from hald) softPLL alignment state");
	for (i = 0; i < N_SOFTPLL_ALIGN_STATES; i++) {
		gpa_prm_enum_add_entry(gm_params[GM_INFO_ALIGN_STATE].param,
			gm_info_external_state[i].id,
			gm_info_external_state[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_ALIGN_STATE].param)) {
		pr_error("Error adding align_state to %s\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gm_params[GM_INFO_ALIGN_STATE].type = GPA_TYPE_ENUM;


	/* GM Detected */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_DETECTED);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_DETECTED].param = gpa_prm_create_enum(0, oid,
		"detected", GPA_PRM_VTX_ENUM,
		GPA_ACC_RT | GPA_ACC_INTERNAL, 0, N_SOFTPLL_EXT_FPANEL,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_gm_info_detected);
	if (!gm_params[GM_INFO_DETECTED].param) {
		pr_error("Error creating %s/detected\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_DETECTED].param,
		"Report the detection of external reference inputs from the front panel.");
	for (i = 0; i < N_SOFTPLL_EXT_FPANEL; i++) {
		gpa_prm_enum_add_entry(gm_params[GM_INFO_DETECTED].param,
			gm_info_detected[i].id,
			gm_info_detected[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_DETECTED].param)) {
		pr_error("Error adding detected to %s\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gm_params[GM_INFO_DETECTED].type = GPA_TYPE_ENUM;


	/* GM PPS delta */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_PPS_DELTA);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_PPS_DELTA].param = gpa_prm_create_val(0, oid,
		"pps_delta", GPA_PRM_VTX_I32, GPA_ACC_R |
		GPA_ACC_INTERNAL | GPA_ACC_UNLISTED,
		{.i32 = dflt_gm_info_pps_delta});
	if (!gm_params[GM_INFO_PPS_DELTA].param) {
		pr_error("Error creating %s/pps_delta\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_PPS_DELTA].param,
		"(Read from hald) delay between external reference PPS and "
		"generated PPS (ps)");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_PPS_DELTA].param)) {
		pr_error("Error adding pps_delta to %s\n",
			modir_array[GM_INFO_PPS_DELTA].mp);
		return 1;
	}
	gm_params[GM_INFO_PPS_DELTA].type = GPA_TYPE_INT32;


	/* Leap-second file expiration date */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_LEAPSEC_FILE_EXP_DATE);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].param = gpa_prm_create_str(
		0, oid, "leapsec_file_exp_date", GPA_PRM_VTA_STRING,
		GPA_ACC_R | GPA_ACC_INTERNAL, dflt_gm_info_leapsec_exp_date,
		MAX_STR_LEN);
	if (!gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].param) {
		pr_error("Error creating %s/leapsec_file_exp_date\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].param,
		"Expiration date of the leap seconds files (YYYY-MM-DD)");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].param)) {
		pr_error("Error adding leapsec_file_exp_date to %s\n",
			modir_array[GM_INFO_LEAPSEC_FILE_EXP_DATE].mp);
		return 1;
	}
	gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].type = GPA_TYPE_STRING;


	/* Leap-second file validity */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_INFO_LEAPSEC_FILE_VALID);
	if(oid < 0)
		return 1;

	gm_params[GM_INFO_LEAPSEC_FILE_VALID].param = gpa_prm_create_bool(
		0, oid, "leapsec_file_valid", GPA_ACC_R | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_YES_NO, dflt_gm_info_leapsec_valid);
	if (!gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE].param) {
		pr_error("Error creating %s/leapsec_file_valid\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_INFO_LEAPSEC_FILE_VALID].param,
		"YES if the leap seconds file is valid. NO if it's expired or missing");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_INFO_MODIR].mp,
		gm_params[GM_INFO_LEAPSEC_FILE_VALID].param)) {
		pr_error("Error adding leapsec_file_valid to %s\n",
			modir_array[GM_INFO_LEAPSEC_FILE_VALID].mp);
		return 1;
	}
	gm_params[GM_INFO_LEAPSEC_FILE_VALID].type = GPA_TYPE_BOOL;
	gpa_prm_set_custom_check_range(
		gm_params[GM_INFO_LEAPSEC_FILE_VALID].param,
		leapsec_status_warning_check);


	/**** Config parameters ****/


	/* GM src rank */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_SRC_RANK);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_SRC_RANK].param = gpa_prm_create_val(
		0, oid, "src_rank", GPA_PRM_VTX_U32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,
		{.u32 = dflt_gm_cfg_src_rank});
	if (!gm_params[GM_CFG_SRC_RANK].param) {
		pr_error("Error creating %s/src_rank\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_SRC_RANK].param,
			"GM priority");
	if (gpa_modir_path_addprm(tmgr_mod,  modir_array[GM_CONFIG_MODIR].mp,
					gm_params[GM_CFG_SRC_RANK].param)) {
		pr_error("Error adding src_rank to %s\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_SRC_RANK].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("src_rank is not configured. "
			"Using default value: %d\n",
			dflt_gm_cfg_src_rank);
	}
	gm_params[GM_CFG_SRC_RANK].type = GPA_TYPE_UINT32;
	gpa_enable_cache(&gm_params[GM_CFG_SRC_RANK]);


	/* GM Offset */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_OFFSET);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_OFFSET].param = gpa_prm_create_val(
		0, oid, "gm_offset", GPA_PRM_VTX_I32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, {.i32 = dflt_gm_cfg_offset});
	if (!gm_params[GM_CFG_OFFSET].param) {
		pr_error("Error creating %s/gm_offset\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_OFFSET].param,
			"Offset to compensate user cable delay");
	gpa_prm_set_unit(gm_params[GM_CFG_OFFSET].param, "ps");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
					gm_params[GM_CFG_OFFSET].param)) {
		pr_error("Error adding gm_offset to %s\n",
			modir_array[GM_CFG_OFFSET].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_OFFSET].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("gm_offset is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_offset);
	}
	gm_params[GM_CFG_OFFSET].type = GPA_TYPE_INT32;
	gpa_enable_cache(&gm_params[GM_CFG_OFFSET]);
	gpa_enable_hook(&gm_params[GM_CFG_OFFSET], hook_gm_offset, 0);


	/* GM align PPS */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_ALIGN_PPS);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_ALIGN_PPS].param = gpa_prm_create_bool(
		0, oid, "align_pps", GPA_ACC_RWL | GPA_ACC_INTERNAL,
		GPA_PRM_ENUM_OPT_BOOL_ON_OFF, dflt_gm_cfg_align_pps);
	if (!gm_params[GM_CFG_ALIGN_PPS].param) {
		pr_error("Error creating %s/align_pps\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_ALIGN_PPS].param,
		"Enable this to align the PPS input to the PPS output during the locking procedure."
		" It should be enabled when using a GNSS receiver as external reference as PPS might"
		" be shifted from 10MHz after each GNSS relock.");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_ALIGN_PPS].param)) {
		pr_error("Error adding align_pps to %s\n",
			modir_array[GM_CFG_ALIGN_PPS].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_ALIGN_PPS].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("align_pps is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_align_pps);
	}
	gm_params[GM_CFG_ALIGN_PPS].type = GPA_TYPE_BOOL;
	gpa_enable_cache(&gm_params[GM_CFG_ALIGN_PPS]);
	gpa_enable_hook(&gm_params[GM_CFG_ALIGN_PPS], hook_align_pps, 0);

	/* GM Force clock class */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_FORCE_CLOCK_CLASS);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_FORCE_CLOCK_CLASS].param = gpa_prm_create_val(
		0, oid, "force_clock_class", GPA_PRM_VTX_U8,
		GPA_ACC_RWL | GPA_ACC_INTERNAL | GPA_ACC_EXPERT,
		{.u8 = dflt_gm_cfg_clk_class});
	if (!gm_params[GM_CFG_FORCE_CLOCK_CLASS].param) {
		pr_error("Error creating %s/force_clock_class\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_FORCE_CLOCK_CLASS].param,
		"Clock class to use for GrandMaster mode");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_FORCE_CLOCK_CLASS].param)) {
		pr_error("Error adding force_clock_class to %s\n",
			modir_array[GM_CFG_FORCE_CLOCK_CLASS].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_FORCE_CLOCK_CLASS].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("force_clock_class is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_clk_class);
	}
	gm_params[GM_CFG_FORCE_CLOCK_CLASS].type = GPA_TYPE_UINT8;
	gpa_enable_cache(&gm_params[GM_CFG_FORCE_CLOCK_CLASS]);


	/* GM Clock accuracy */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_CLOCK_ACCURACY);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_CLOCK_ACCURACY].param = gpa_prm_create_enum(
		0, oid,"clock_accuracy", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,	NULL,_GPA_1588_ACU_N_ENTRIES,
		GPA_PRM_ENUM_OPT_NONE, dflt_gm_cfg_clk_accuracy);
	if (!gm_params[GM_CFG_CLOCK_ACCURACY].param) {
		pr_error("Error creating %s/clock_accuracy\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_CLOCK_ACCURACY].param,
		"It announces the expected accuracy provided by the external reference."
		" It shall be conservatively estimated based on the type of the timing source"
		" (e.g., Atomic clock <= 1ns, GNSS receiver <= 50ns)");

	struct gpa_prm *last_prm = gm_params[GM_CFG_CLOCK_ACCURACY].param;
	gpa_prm_enum_add_entry(last_prm, _GPA_1588_ACU_UNDEF, "Undefined");
	for(uint8_t v=GPA_1588_ACU_1_PS; v<GPA_1588_ACU_GT_10_S;v++)
		gpa_prm_enum_add_entry(last_prm, v, _gm_clock_accuracy_desc(v));
	gpa_prm_enum_add_entry(last_prm, GPA_1588_ACU_UNKNOWN, _gm_clock_accuracy_desc(GPA_1588_ACU_UNKNOWN));
	struct gpa_range r={.min.u8=GPA_1588_ACU_1_PS,.max.u8=GPA_1588_ACU_UNKNOWN};
	gpa_prm_set_range_input(last_prm,r);

	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_CLOCK_ACCURACY].param)) {
		pr_error("Error adding clock_accuracy to %s\n",
			modir_array[GM_CFG_CLOCK_ACCURACY].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_CLOCK_ACCURACY].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("clock_accuracy is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_clk_accuracy);
	}

	gm_params[GM_CFG_CLOCK_ACCURACY].type = GPA_TYPE_ENUM;
	gpa_enable_cache(&gm_params[GM_CFG_CLOCK_ACCURACY]);
	gpa_enable_hook(&gm_params[GM_CFG_CLOCK_ACCURACY], hook_clock_accuracy, 0);


	/* Time source */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_TIME_SOURCE);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_TIME_SOURCE].param = gpa_prm_create_enum(0, oid,
		"time_source", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, 0, N_GM_TIME_SOURCES,
		GPA_PRM_ENUM_OPT_NONE, dlft_gm_cfg_time_source);
	if (!gm_params[GM_CFG_TIME_SOURCE].param) {
		pr_error("Error creating %s/time_source\n",
			modir_array[GM_INFO_MODIR].mp);
		return 1;
	}
	for (i = 0; i < N_GM_TIME_SOURCES; i++) {
		gpa_prm_enum_add_entry(gm_params[GM_CFG_TIME_SOURCE].param,
			gm_config_time_src[i].id,
			gm_config_time_src[i].str);
	}
	gpa_prm_set_desc(gm_params[GM_CFG_TIME_SOURCE].param,
			"Type of the timing source announced by GM. It should correspond"
			" to the type of external reference that provides 10MHz/PPS to the"
			" front-panel of the device. (This field is informative and not used for"
			" decision making)");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_TIME_SOURCE].param)) {
		pr_error("Error adding time_source to %s\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gm_params[GM_CFG_TIME_SOURCE].type = GPA_TYPE_ENUM;
	gpa_enable_cache(&gm_params[GM_CFG_TIME_SOURCE]);
	gpa_enable_hook(&gm_params[GM_CFG_TIME_SOURCE], hook_time_source, 0);



	/* GM Priority1 */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_PRIORITY1);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_PRIORITY1].param = gpa_prm_create_val(
		0, oid, "priority1", GPA_PRM_VTX_U8,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, {.u8 = dflt_gm_cfg_priority1});
	if (!gm_params[GM_CFG_PRIORITY1].param) {
		pr_error("Error creating %s/priority1\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_PRIORITY1].param,
		"PTP priority1 announced when the GM is active. It is mainly used by"
		" BMCA to force the best-clock selection using 1st priority (Lower values take precedence)");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_PRIORITY1].param)) {
		pr_error("Error adding priority1 to %s\n",
			modir_array[GM_CFG_PRIORITY1].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_PRIORITY1].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("priority1 is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_priority1);
	}
	gm_params[GM_CFG_PRIORITY1].type = GPA_TYPE_UINT8;
	gpa_enable_cache(&gm_params[GM_CFG_PRIORITY1]);
	gpa_enable_hook(&gm_params[GM_CFG_PRIORITY1], hook_priority1, 0);


	/* GM Priority2 */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_PRIORITY2);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_PRIORITY2].param = gpa_prm_create_val(
		0, oid, "priority2", GPA_PRM_VTX_U8,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, {.u8 = dflt_gm_cfg_priority2});
	if (!gm_params[GM_CFG_PRIORITY2].param) {
		pr_error("Error creating %s/priority2\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_PRIORITY2].param,
		"PTP priority2 announced when the GM is active. It is mainly used by"
		" BMCA to force the choice between two references when their clock"
		" qualities are the same (Lower values take precedence)");
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_PRIORITY2].param)) {
		pr_error("Error adding priority2 to %s\n",
			modir_array[GM_CFG_PRIORITY2].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_PRIORITY2].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("priority2 is not configured. "
			"Using default value: %d\n", dflt_gm_cfg_priority2);
	}
	gm_params[GM_CFG_PRIORITY2].type = GPA_TYPE_UINT8;
	gpa_enable_cache(&gm_params[GM_CFG_PRIORITY2]);
	gpa_enable_hook(&gm_params[GM_CFG_PRIORITY2], hook_priority2, 0);


	/* PPS mandatory */
	oid = gpa_common_find_oid(v_oid, n_v_oid, GM_CFG_PPS_MANDATORY);
	if(oid < 0)
		return 1;

	gm_params[GM_CFG_PPS_MANDATORY].param = gpa_prm_create_enum(0, oid,
		"pps_mandatory", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWL | GPA_ACC_INTERNAL, 0, N_GM_PPS_MANDATORY,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_gm_cfg_pps_mandatory);
	if (!gm_params[GM_CFG_PPS_MANDATORY].param) {
		pr_error("Error creating %s/pps_mandatory\n",
			modir_array[GM_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(gm_params[GM_CFG_PPS_MANDATORY].param,
		"Controls whether a PPS input signal is needed at startup or to stay active for the GM source.");
	for (i = 0; i < N_GM_PPS_MANDATORY; i++) {
		gpa_prm_enum_add_entry(gm_params[GM_CFG_PPS_MANDATORY].param,
			gm_config_pps_mandatory[i].id,
			gm_config_pps_mandatory[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod, modir_array[GM_CONFIG_MODIR].mp,
		gm_params[GM_CFG_PPS_MANDATORY].param)) {
		pr_error("Error adding pps_mandatory to %s\n",
			modir_array[GM_CFG_PPS_MANDATORY].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, gm_params[GM_CFG_PPS_MANDATORY].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("pps_mandatory is not configured. "
			"Using default value: %d\n",
			dflt_gm_cfg_pps_mandatory);
	}
	gm_params[GM_CFG_PPS_MANDATORY].type = GPA_TYPE_ENUM;
	gpa_enable_cache(&gm_params[GM_CFG_PPS_MANDATORY]);

	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/

int get_gm_info_align_state(enum softpll_align_state *align_state)
{
	if (!align_state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_INFO_ALIGN_STATE], align_state)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_info_detected(enum softpll_ext_fpanel *detected)
{
	if (!detected) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_INFO_DETECTED], detected)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_info_pps_delta(int32_t *delta)
{
	if (!delta) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_INFO_PPS_DELTA], delta)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_align_pps(int *enabled)
{
	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_ALIGN_PPS], enabled)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_offset(int32_t *offset)
{
	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_OFFSET], offset)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_force_clock_class(uint8_t *class)
{
	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_FORCE_CLOCK_CLASS], class)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_clock_accuracy(uint8_t *accuracy)
{
	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_CLOCK_ACCURACY], accuracy)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_gm_config_time_source(enum gm_time_source *src)
{
	if (!src) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_TIME_SOURCE], src)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_gm_config_priority1(uint8_t *priority1)
{
	if (!priority1) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_PRIORITY1], priority1)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_priority2(uint8_t *priority2)
{
	if (!priority2) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_PRIORITY2], priority2)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_gm_config_pps_mandatory(enum gm_pps_mandatory *val)
{
	if (!val) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_PPS_MANDATORY], val)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}


int get_gm_config_src_rank(uint32_t *rank)
{
	if(!rank) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&gm_params[GM_CFG_SRC_RANK], rank)) {
		pr_warning("Error getting parameter\n");
		return 1;
	}

	return 0;
}

/********** Setter functions **********/


int set_gm_info_align_state(enum softpll_align_state align_state)
{
	if (align_state < 0 || align_state >= N_SOFTPLL_ALIGN_STATES) {
		pr_error("Invalid align state %d\n", align_state);
		return 1;
	}

	if (gpa_set_param(&gm_params[GM_INFO_ALIGN_STATE], &align_state)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_info_detected(enum softpll_ext_fpanel detected)
{
	if (detected < 0 || detected >= N_SOFTPLL_EXT_FPANEL) {
		pr_error("Invalid GM detected value %d\n", detected);
		return 1;
	}

	if (gpa_set_param(&gm_params[GM_INFO_DETECTED], &detected)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_info_pps_delta(int32_t delta)
{
	if (gpa_set_param(&gm_params[GM_INFO_PPS_DELTA], &delta)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_info_message(char *message)
{
	if (gpa_set_param(&gm_params[GM_INFO_MESSAGE], message)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_info_leapsec_file_exp_date(char *date)
{
	if (gpa_set_param(&gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE], date)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_info_leapsec_file_valid(int valid)
{
	if (gpa_set_param(&gm_params[GM_INFO_LEAPSEC_FILE_VALID], &valid)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int update_gm_info_leapsec_file_exp_date(void)
{
	time_t exp_date = leapsec_get_expiration_date();
	char str[MAX_STR_LEN] = {0};
	int ret = 0;
	struct tm exp_tm = {0};

	if (exp_date < 0) {
		strncpy(str, "Leap-second file error", MAX_STR_LEN-1);
		ret = 1;
	} else {
		if (!gmtime_r(&exp_date, &exp_tm)) {
			pr_warning("gmtime_r error\n");
			strncpy(str, "Leap-second file error", MAX_STR_LEN-1);
			ret = 1;
		} else {
			snprintf(str, MAX_STR_LEN-1, "%d-%02d-%02d %02d:%02d:%02d",
				exp_tm.tm_year + 1900, exp_tm.tm_mon + 1,
				exp_tm.tm_mday, exp_tm.tm_hour,
				exp_tm.tm_min, exp_tm.tm_sec);
		}
	}

	if (gpa_set_param(&gm_params[GM_INFO_LEAPSEC_FILE_EXP_DATE], str)) {
		pr_warning("Error setting parameter\n");
		ret = 1;
	}

	return ret;
}

int set_gm_config_align_pps(int enable)
{
	if (gpa_set_param(&gm_params[GM_CFG_ALIGN_PPS], &enable)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_offset(int32_t offset)
{
	if (gpa_set_param(&gm_params[GM_CFG_OFFSET], &offset)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_force_clock_class(uint8_t class)
{
	if (gpa_set_param(&gm_params[GM_CFG_FORCE_CLOCK_CLASS], &class)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_clock_accuracy(uint32_t accuracy)
{
	if (gpa_set_param(&gm_params[GM_CFG_CLOCK_ACCURACY], &accuracy)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_priority1(uint8_t priority1)
{
	if (gpa_set_param(&gm_params[GM_CFG_PRIORITY1], &priority1)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_priority2(uint8_t priority2)
{
	if (gpa_set_param(&gm_params[GM_CFG_PRIORITY2], &priority2)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_gm_config_src_rank(uint32_t rank)
{
	if (gpa_set_param(&gm_params[GM_CFG_SRC_RANK], &rank)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

void reset_gm_info(void)
{
	enum leapsec_exp_status leapsec_exp;
	int leaps_valid;

	// General GM info
	set_gm_info_detected(SOFTPLL_EXT_DETECTED_NONE);
	set_gm_info_align_state(SOFTPLL_ALIGN_STATE_EXT_OFF);
	set_gm_info_message("Uninitialized");

	// Leap seconds
	update_gm_info_leapsec_file_exp_date();
	leapsec_exp = leapsec_check_expiration_date();
	leaps_valid = (leapsec_exp == LEAPSEC_EXP_EXPIRED
		|| leapsec_exp == LEAPSEC_EXP_ERROR) ? 0 : 1;
	set_gm_info_leapsec_file_valid(leaps_valid);
}

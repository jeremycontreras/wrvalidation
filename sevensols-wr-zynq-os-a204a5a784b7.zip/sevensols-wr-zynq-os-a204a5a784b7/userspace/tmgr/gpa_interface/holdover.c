/*
 * holdover.c
 *
 * libGPA-based parameter interface for Time Manager. Holdover parameters.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Aug 27, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <libgpa.h>
#include <libgpa_owner.h>
#include <libgpa/rsrc.h>

#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum ho_params {
	HO_CFG_SRC_RANK,
	HO_CFG_TIME_TO_EXPIRED,
	HO_CFG_FORCE_TRIGGER,
	HO_CFG_FORCE_FR,

	HO_INFO_TIME_LEARNING,
	HO_INFO_TIME_HOLDOVER,
	HO_INFO_STATE,
	HO_INFO_TRIGGER_ORIGIN,
	HO_INFO_STATE_TIME,
	/*
	 * TODO: What should we put in this one? Is this necessary?
	 *
	HO_INFO_EXPIRED,
	*/

	N_HO_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/* Holdover parameter array */
static struct gpa_param ho_params[N_HO_PARAMS];

/* oid translator */
static struct enum_oid_match ho_enum_oid_translator[N_HO_PARAMS] = {
	/* config */
	{.enum_id = HO_CFG_SRC_RANK,            .oid = 0},
	{.enum_id = HO_CFG_TIME_TO_EXPIRED,     .oid = 1},
	{.enum_id = HO_CFG_FORCE_TRIGGER,       .oid = 2},
	{.enum_id = HO_CFG_FORCE_FR,            .oid = 3},

	/* info */
	{.enum_id = HO_INFO_TIME_LEARNING,      .oid = 0},
	{.enum_id = HO_INFO_TIME_HOLDOVER,      .oid = 1},
	{.enum_id = HO_INFO_STATE,              .oid = 2},
	{.enum_id = HO_INFO_TRIGGER_ORIGIN,     .oid = 3},
	{.enum_id = HO_INFO_STATE_TIME,         .oid = 4},
	/*
	{.enum_id = HO_INFO_EXPIRED,            .oid = 5},
	*/
};

/* enum to string tables */

static struct enum_str_match ho_force_trigger[N_HO_FORCE_TRIGGER] = {
	{.id = HO_FORCE_TRIGGER_STOP,   .str = "STOP"},
	{.id = HO_FORCE_TRIGGER_START,  .str = "START"},
	{.id = HO_FORCE_TRIGGER_NONE,   .str = "NONE"},
};

static struct enum_str_match ho_trigger[N_HO_TRIGGERS] = {
	{.id = HO_TRIGGER_NONE,         .str = "NONE"},
	{.id = HO_TRIGGER_MANUAL,       .str = "MANUAL"},
	{.id = HO_TRIGGER_PPS_DRIFT,    .str = "PPS_DRIFT"},
	{.id = HO_TRIGGER_NO_DATA,      .str = "NO_DATA"},
	{.id = HO_TRIGGER_TRACK_LOST,   .str = "TRACK_LOST"},
	{.id = HO_TRIGGER_RESERVED5,    .str = "RESERVED5"},
	{.id = HO_TRIGGER_RESERVED6,    .str = "RESERVED6"},
	{.id = HO_TRIGGER_RESERVED7,    .str = "RESERVED7"},
	{.id = HO_TRIGGER_LINKDOWN,     .str = "LINKDOWN"},
	{.id = HO_TRIGGER_EXTCLK_DOWN,  .str = "EXTCLK_DOWN"},
	{.id = HO_TRIGGER_EXTPPS_DOWN,  .str = "EXTPPS_DOWN"},
	{.id = HO_TRIGGER_CLK_DRIFT,    .str = "CLK_DRIFT"},
};

static struct enum_str_match info_ho_state[N_HO_STATES] = {
	{.id = HO_UNAVAILABLE,  .str = "UNAVAILABLE"},
	{.id = HO_DISABLED,     .str = "DISABLED"},
	{.id = HO_LOCKING,      .str = "LOCKING"},
	{.id = HO_LEARNING,     .str = "LEARNING"},
	{.id = HO_READY,        .str = "READY"},
	{.id = HO_ACTIVATED,    .str = "ACTIVATED"},
	{.id = HO_EXPIRED,      .str = "EXPIRED"},
};


/* Default parameter values */
static uint32_t dflt_cfg_ho_src_rank            = 0;
static uint32_t dflt_cfg_ho_time_to_expired     = 79800;
static int dflt_cfg_ho_force_trig               = HO_FORCE_TRIGGER_NONE;
static int dflt_cfg_ho_force_fr                 = 0;
static int dflt_info_ho_state                   = 0;
static int dflt_ho_trigger                      = 0;
static uint32_t dflt_info_ho_state_time         = 0;
static uint32_t dflt_info_ho_time_learning      = 0;
static uint32_t dflt_info_ho_time_holdover      = 0;
/*
static int dflt_info_ho_expired                 = 0;
*/


/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Sets the appropriate WARNING or CRITICAL flags to the holdover/config/state
 * parameter.
 *
 * This function will be called by libgpa.
 */
int32_t ho_state_warning_check(const void *new_value, struct gpa_prm *p,
				uint8_t iwc)
{
	const union gpa_val *val = new_value;
	enum ho_state state = val->u16;

	if (iwc == GPA_PRM_RANGE_INPUT) {
		return (state >= 0 && state < N_HO_STATES);
	}

	switch (state) {
		/* OK cases */
	case HO_UNAVAILABLE:
	case HO_DISABLED:
	case HO_READY:
		break;
		/* WARNING cases */
	case HO_LOCKING:
	case HO_LEARNING:
	case HO_ACTIVATED:
		if (iwc == GPA_PRM_RANGE_WARNING)
			return 1;
		break;
		/* CRITICAL cases */
	case HO_EXPIRED:
		if (iwc == GPA_PRM_RANGE_CRITICAL)
			return 1;
		break;

	case N_HO_STATES:
	default:
		break;
	}

	return 0;
}


/************************************************************
 * Module-specific functions                                *
 ************************************************************/

int create_holdover_params(void)
{
	int oid;
	struct enum_oid_match *v_oid = ho_enum_oid_translator;
	int n_v_oid = ARRAY_SIZE(ho_enum_oid_translator);
	int i;

	/**** Config parameters ****/

	/* HO src rank */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_CFG_SRC_RANK);
	if(oid < 0)
		return 1;

	ho_params[HO_CFG_SRC_RANK].param = gpa_prm_create_val(
		0, oid, "src_rank", GPA_PRM_VTX_U32,
		GPA_ACC_RWL | GPA_ACC_INTERNAL,
		{.u32 = dflt_cfg_ho_src_rank});
	if (!ho_params[HO_CFG_SRC_RANK].param) {
		pr_error("Error creating %s/src_rank\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_CFG_SRC_RANK].param,
			"Holdover priority");
	if (gpa_modir_path_addprm(tmgr_mod,  modir_array[HOLDOVER_CONFIG_MODIR].mp,
					ho_params[HO_CFG_SRC_RANK].param)) {
		pr_error("Error adding src_rank to %s\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ho_params[HO_CFG_SRC_RANK].param,
				DEFAULT_CONFIG_FILE)) {
		pr_warning("src_rank is not configured. "
			"Using default value: %d\n",
			dflt_cfg_ho_src_rank);
	}
	ho_params[HO_CFG_SRC_RANK].type = GPA_TYPE_UINT32;
	gpa_enable_cache(&ho_params[HO_CFG_SRC_RANK]);


	/* Holdover Time to expired */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_CFG_TIME_TO_EXPIRED);
	if(oid < 0)
		return 1;

	ho_params[HO_CFG_TIME_TO_EXPIRED].param = gpa_prm_create_val(0, oid,
		"time_to_expired", GPA_PRM_VTX_U32, GPA_ACC_RWL |
		GPA_ACC_INTERNAL, {.u32 = dflt_cfg_ho_time_to_expired});

	if (!ho_params[HO_CFG_TIME_TO_EXPIRED].param) {
		pr_error("Error creating %s/time_to_expired\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_CFG_TIME_TO_EXPIRED].param,
			"Time the holdover to expired (in seconds)");
	gpa_prm_set_unit(ho_params[HO_CFG_TIME_TO_EXPIRED].param,
			"s");
	if (gpa_modir_path_addprm(tmgr_mod,
					modir_array[HOLDOVER_CONFIG_MODIR].mp,
					ho_params[HO_CFG_TIME_TO_EXPIRED].param)) {
		pr_error("Error adding time_to_expired to %s\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	ho_params[HO_CFG_TIME_TO_EXPIRED].type = GPA_TYPE_UINT32;


	/* Holdover force trigger */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_CFG_FORCE_TRIGGER);
	if(oid < 0)
		return 1;

	ho_params[HO_CFG_FORCE_TRIGGER].param = gpa_prm_create_enum(
		0, oid, "force_trigger", GPA_PRM_VTX_ENUM,
		GPA_ACC_RWT | GPA_ACC_INTERNAL, 0, N_HO_FORCE_TRIGGER,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_cfg_ho_force_trig);
	if (!ho_params[HO_CFG_FORCE_TRIGGER].param) {
		pr_error("Error creating %s/force_trigger\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_CFG_FORCE_TRIGGER].param,
			"Set to START to set the holdover external triggers to MANUAL. Set to STOP to stop activated holdover.");
	for (i = 0; i < N_HO_FORCE_TRIGGER; i++) {
		gpa_prm_enum_add_entry(ho_params[HO_CFG_FORCE_TRIGGER].param,
				ho_force_trigger[i].id, ho_force_trigger[i].str);
	}
	if (gpa_modir_path_addprm(tmgr_mod,
	        modir_array[HOLDOVER_CONFIG_MODIR].mp,
		ho_params[HO_CFG_FORCE_TRIGGER].param)) {
		pr_error("Error adding force_trigger to %s\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	ho_params[HO_CFG_FORCE_TRIGGER].type = GPA_TYPE_ENUM;


	/* Holdover force FR */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_CFG_FORCE_FR);
	if(oid < 0)
		return 1;

	ho_params[HO_CFG_FORCE_FR].param = gpa_prm_create_bool(
		0, oid, "force_freerunning", GPA_ACC_RWLT | GPA_ACC_INTERNAL
		| GPA_ACC_EXPERT, GPA_PRM_ENUM_OPT_BOOL_ON_OFF,
		dflt_cfg_ho_force_fr);
	if (!ho_params[HO_CFG_FORCE_FR].param) {
		pr_error("Error creating %s/force_freerunning\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_CFG_FORCE_FR].param,
		"Set to <on> to disable the holdover mechanism");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_CONFIG_MODIR].mp,
		ho_params[HO_CFG_FORCE_FR].param)) {
		pr_error("Error adding force_freerunning to %s\n",
			modir_array[HOLDOVER_CONFIG_MODIR].mp);
		return 1;
	}
	if (gpa_mod_prm_load(tmgr_mod, ho_params[HO_CFG_FORCE_FR].param,
		DEFAULT_CONFIG_FILE)) {
		pr_warning("force_freerunning is not configured. "
			"Using default value: %d\n", dflt_cfg_ho_force_fr);
	}
	ho_params[HO_CFG_FORCE_FR].type = GPA_TYPE_BOOL;
	gpa_enable_cache(&ho_params[HO_CFG_FORCE_FR]);


	/**** Info parameters ****/


	/* Holdover Time learning */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_TIME_LEARNING);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_TIME_LEARNING].param = gpa_prm_create_val(0, oid,
		"time_learning", GPA_PRM_VTX_U32, GPA_ACC_R |
		GPA_ACC_INTERNAL, {.u32 = dflt_info_ho_time_learning});

	if (!ho_params[HO_INFO_TIME_LEARNING].param) {
		pr_error("Error creating %s/time_learning\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_INFO_TIME_LEARNING].param,
		"Time the holdover has been in LEARNING state (in seconds)");
	gpa_prm_set_unit(ho_params[HO_INFO_TIME_LEARNING].param,
		"s");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_TIME_LEARNING].param)) {
		pr_error("Error adding time_learning to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_TIME_LEARNING].type = GPA_TYPE_UINT32;


	/* Holdover Time in Holdover */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_TIME_HOLDOVER);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_TIME_HOLDOVER].param = gpa_prm_create_val(0, oid,
		"time_holdover", GPA_PRM_VTX_U32, GPA_ACC_R |
		GPA_ACC_INTERNAL, {.u32 = dflt_info_ho_time_holdover});

	if (!ho_params[HO_INFO_TIME_HOLDOVER].param) {
		pr_error("Error creating %s/time_holdover\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_INFO_TIME_HOLDOVER].param,
		"Seconds elapsed since holdover activation");
	gpa_prm_set_unit(ho_params[HO_INFO_TIME_HOLDOVER].param,
		"s");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_TIME_HOLDOVER].param)) {
		pr_error("Error adding time_holdover to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_TIME_HOLDOVER].type = GPA_TYPE_UINT32;


	/* Holdover State of Holdover */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_STATE);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_STATE].param = gpa_prm_create_enum(
		0, oid, "state", GPA_PRM_VTX_ENUM,
		GPA_ACC_RT | GPA_ACC_INTERNAL, 0, N_HO_STATES,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_info_ho_state);
	if (!ho_params[HO_INFO_STATE].param) {
		pr_error("Error creating %s/state\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	for (i = 0; i < N_HO_STATES; i++) {
		gpa_prm_enum_add_entry(ho_params[HO_INFO_STATE].param,
			info_ho_state[i].id, info_ho_state[i].str);
	}
	gpa_prm_set_desc(ho_params[HO_INFO_STATE].param,
		"Holdover state");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_STATE].param)) {
		pr_error("Error adding state to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_STATE].type = GPA_TYPE_ENUM;
	gpa_prm_set_custom_check_range(ho_params[HO_INFO_STATE].param,
		ho_state_warning_check);


	/* Holdover Trigger origin */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_TRIGGER_ORIGIN);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_TRIGGER_ORIGIN].param = gpa_prm_create_enum(
		0, oid, "trigger_origin", GPA_PRM_VTX_ENUM,
		GPA_ACC_RT | GPA_ACC_INTERNAL, 0, N_HO_TRIGGERS,
		GPA_PRM_ENUM_OPT_INDEXED_DIRECT, dflt_ho_trigger);
	if (!ho_params[HO_INFO_TRIGGER_ORIGIN].param) {
		pr_error("Error creating %s/trigger_origin\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	for (i = 0; i < N_HO_TRIGGERS ; i++) {
		gpa_prm_enum_add_entry(ho_params[HO_INFO_TRIGGER_ORIGIN].param,
			ho_trigger[i].id, ho_trigger[i].str);
	}
	gpa_prm_set_desc(ho_params[HO_INFO_TRIGGER_ORIGIN].param,
		"Trigger origin of last one launched");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_TRIGGER_ORIGIN].param)) {
		pr_error("Error adding trigger_origin to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_TRIGGER_ORIGIN].type = GPA_TYPE_ENUM;


	/* Holdover State time */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_STATE_TIME);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_STATE_TIME].param = gpa_prm_create_val(0, oid,
		"state_time", GPA_PRM_VTX_U32, GPA_ACC_R |
		GPA_ACC_INTERNAL | GPA_ACC_EXPERT, {.u32 = dflt_info_ho_state_time});

	if (!ho_params[HO_INFO_STATE_TIME].param) {
		pr_error("Error creating %s/state_time\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	gpa_prm_set_desc(ho_params[HO_INFO_STATE_TIME].param,
		"Seconds spent in current holdover state");
	gpa_prm_set_unit(ho_params[HO_INFO_STATE_TIME].param,
		"s");
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_STATE_TIME].param)) {
		pr_error("Error adding state_time to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_STATE_TIME].type = GPA_TYPE_UINT32;


#if 0
	/* Holdover expired */
	oid = gpa_common_find_oid(v_oid, n_v_oid, HO_INFO_EXPIRED);
	if(oid < 0)
		return 1;

	ho_params[HO_INFO_EXPIRED].param = gpa_prm_create_val(
		0, oid, "expired", GPA_PRM_VTX_U32,
		GPA_ACC_R | GPA_ACC_INTERNAL, {.u32 = dflt_info_ho_expired});
	if (!ho_params[HO_INFO_EXPIRED].param) {
		pr_error("Error creating %s/expired\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	if (gpa_modir_path_addprm(tmgr_mod,
		modir_array[HOLDOVER_INFO_MODIR].mp,
		ho_params[HO_INFO_EXPIRED].param)) {
		pr_error("Error adding expired to %s\n",
			modir_array[HOLDOVER_INFO_MODIR].mp);
		return 1;
	}
	ho_params[HO_INFO_EXPIRED].type = GPA_TYPE_UINT32;
#endif


	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


/********** Getter functions **********/


int get_ho_config_force_trigger(enum holdover_force_trigger *force)
{
	if (!force) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_CFG_FORCE_TRIGGER], force)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_config_src_rank(uint32_t *rank)
{
	if(!rank) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_CFG_SRC_RANK], rank)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_config_force_fr(int *enabled)
{
	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_CFG_FORCE_FR], enabled)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_info_time_learning(uint32_t *time)
{
	if (!time) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_TIME_LEARNING], time)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_info_time_holdover(uint32_t *time)
{
	if (!time) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_TIME_HOLDOVER], time)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_info_state(enum ho_state *ho_state)
{
	if (!ho_state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_STATE], ho_state)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_info_trigger_origin(enum ho_trig *trigger)
{
	if (!trigger) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_TRIGGER_ORIGIN], trigger)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int get_ho_info_state_time(uint32_t *time)
{
	if (!time) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_STATE_TIME], time)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

/*
int get_ho_info_expired(uint32_t *expired)
{
	if (!expired) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (gpa_get_param(&ho_params[HO_INFO_EXPIRED], expired)) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}
*/


/********** Setter functions **********/


int set_ho_config_force_trigger(enum holdover_force_trigger force)
{
	if (force < 0 || force >= N_HO_FORCE_TRIGGER) {
		pr_error("Invalid force_trigger %d\n", force);
		return 1;
	}

	if (gpa_set_param(&ho_params[HO_CFG_FORCE_TRIGGER], &force)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_config_src_rank(uint32_t rank)
{
	if (gpa_set_param(&ho_params[HO_CFG_SRC_RANK], &rank)) {
		pr_warning("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_info_time_learning(uint32_t time)
{
	if (gpa_set_param(&ho_params[HO_INFO_TIME_LEARNING], &time)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_info_time_holdover(uint32_t time)
{
	if (gpa_set_param(&ho_params[HO_INFO_TIME_HOLDOVER], &time)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_info_state(enum ho_state ho_state)
{
	if (ho_state < 0 || ho_state >= N_HO_STATES) {
		pr_error("Invalid holdover state %d\n", ho_state);
		return 1;
	}
	if (gpa_set_param(&ho_params[HO_INFO_STATE], &ho_state)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_info_trigger_origin(enum ho_trig trigger)
{
	if (trigger < 0 || trigger >= N_HO_TRIGGERS) {
		pr_error("Invalid trigger %d\n", trigger);
		return 1;
	}
	if (gpa_set_param(&ho_params[HO_INFO_TRIGGER_ORIGIN], &trigger)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

int set_ho_info_state_time(uint32_t time)
{
	if (gpa_set_param(&ho_params[HO_INFO_STATE_TIME], &time)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}

/*
int set_ho_info_expired(uint32_t expired)
{
	if (gpa_set_param(&ho_params[HO_INFO_EXPIRED], &expired)) {
		pr_error("Error setting parameter\n");
		return 1;
	}

	return 0;
}
*/

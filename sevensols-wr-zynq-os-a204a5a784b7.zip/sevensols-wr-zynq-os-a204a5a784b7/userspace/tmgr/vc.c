/**
 * @file vc.c
 *
 * @brief Virtual Clock logic and API implementation
 *
 * @author Ricardo Canuelo (email: ricardo<DOT>canuelo<AT>sevensols<DOT>com)
 * @author Miguel Jimenez Lopez (email: miguel<DOT>jimenez<AT>sevensols<DOT>com)
 * @ingroup tmgr
 * @date Aug 19 2019
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of tmgr
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: tmgr.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "commondefs.h"
#include "misc.h"
#include "gpa_interface.h"
#include "gpa_common.h"
#include "ktmgr.h"
#include "ppsi.h"
#include "ptpd.h"
#include "esmcd.h"

#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "vc_policy.h"
#include "vc.h"

/*
 * External function declarations.
 * Include the declarations for all the concrete clock source implementations
 * here.
 */

extern int create_iface_fsm(struct vc_timing_src *);
extern int free_iface_fsm(struct vc_timing_src *);

extern int create_gm_fsm(struct vc_timing_src *);
extern int free_gm_fsm(struct vc_timing_src *);

extern int create_fr_ho_fsm(struct vc_timing_src *);
extern int free_fr_ho_fsm(struct vc_timing_src *);

extern int create_gnss_fsm(struct vc_timing_src *);
extern int free_gnss_fsm(struct vc_timing_src *);

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/* TODO: Use a proper standard value for this */
#define DFL_HO_FR_TSRC_PRIO UINT16_MAX
#define DFL_HO_FR_FORCED_TSRC_PRIO 1
#define GM_ID 0
#define FR_HO_ID 1
#define GET_IFACE_ID(i) (i+2)

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/** Current VC policy */
static struct vc_policy *current_policy;

/** VC Timing source array for possible references */
static struct vc_timing_src vc_tsrc_list[VC_PRIORITY_LENGTH];
/** Number of VC Timing source in the global array */
static int n_vc_tsrc_list = 0;

/* Selected and current VC timing source */
static struct vc_timing_src *current_src;
static struct vc_timing_src *selected_src;

/************************************************************
 * Private functions                                        *
 ************************************************************/

/**
 * @brief Update datetime
 */
static void update_datetime(void)
{
	time_t tv;
	struct tm curr_time;
	char buffer[MAX_STR_LEN] = {0};
	char tz[MAX_STR_LEN] = {0};

	/* System time */
	time(&tv);
	localtime_r(&tv, &curr_time);
	strftime(tz, MAX_STR_LEN-1, "%Z", &curr_time);
	snprintf(buffer, MAX_STR_LEN - 1, "%04d-%02d-%02d %02d:%02d:%02d %s",
		curr_time.tm_year + 1900, curr_time.tm_mon + 1,
		curr_time.tm_mday, curr_time.tm_hour, curr_time.tm_min,
		curr_time.tm_sec, tz);
	set_vc_info_datetime(buffer);
}

/**
 * @brief Compute the number of selected sources checking src_rank info
 * @return Number of selected sources
*/
static int vc_tsrc_list_get_selected_sources(void)
{
	int n_sources = 1; /* FR/HO is always present */
	int nports = get_nports();
	int i;
	uint32_t rank;
	enum port_mode pm;

	/* Add all interfaces Slave/Auto with src_rank > 0 */
	for(i = 0 ; i < nports ; i++) {
		get_port_mode(i, &pm);
		get_port_src_rank(i, &rank);

		if ((pm == PORT_MODE_AUTO || pm == PORT_MODE_SLAVE) && rank > 0) {
			n_sources++;
		}
	}

	get_gm_config_src_rank(&rank);
	if(rank != 0)
		n_sources++;

	return n_sources;
}

/**
 * @brief Initialize timing source structures for network ports
 *
 * It fills timing source structures using network ports settings specified
 * by the user (from direct configuration or using preset files)
 *
 * @param[inout] current Pointer to first timing source struture to fill
 * @return 0 if success and an error code otherwise
 * @retval EINVAL Timing source pointer is NULL
 *
*/
static int vc_tsrc_list_ports_init(struct vc_timing_src **current)
{
	int nports = get_nports();
	int i;
	uint32_t rank;
	const char *pn;
	enum port_mode pm;
	enum port_proto pp;

	if(!current || !(*current))
		return -EINVAL;

	for(i = 0 ; i < nports ; i++) {
		get_port_mode(i, &pm);
		get_port_src_rank(i, &rank);
		get_port_proto(i, &pp);

		/* NOTE: Add only Slave/Auto interfaces that are references ones */
		if ((pm == PORT_MODE_AUTO || pm == PORT_MODE_SLAVE) && (pp != PORT_PROTO_DISABLED) && rank > 0) {

			/* Get interface configuration */
			get_port_name(i, &pn);

			/* Common data for timing resource */
			(*current)->fsm = NULL;
			(*current)->fsm_ext = NULL;
			(*current)->vc_info.status = VC_STATUS_DISABLED;
			(*current)->type = VC_TSRC_TYPE_IFACE;
			snprintf((*current)->name, MAX_STR_LEN-1, "%s", pn);
			(*current)->id = (uint32_t)GET_IFACE_ID(i);
			(*current)->prio = rank;
			vc_tsrc_set_run_status((*current), VC_TSRC_RUN_STATUS_NULL);
			vc_tsrc_deactivate((*current));
			vc_tsrc_clear_stop_fsm((*current));
			(*current)->build = create_iface_fsm;
			(*current)->free = free_iface_fsm;

			/* Private data for interface resource */
			(*current)->priv.iface.name = pn;
			(*current)->priv.iface.mode = pm;
			(*current)->priv.iface.proto = pp;
			(*current)->priv.iface.port_idx = i;

			/* Pass to the next element */
			(*current)++;
			n_vc_tsrc_list++;
		}
	}

	return 0;
}

/**
 * @brief Initialize timing source structures for GM
 *
 * It fills timing source structures using GM settings specified
 * by the user (from direct configuration or using preset files)
 *
 * @param[inout] current Pointer to first timing source struture to fill
 * @return 0 if success and an error code otherwise
 * @retval EINVAL Timing source pointer is NULL
 *
 */
static int vc_tsrc_list_gm_init(struct vc_timing_src **current)
{
	uint32_t rank;

	if(!current || !(*current))
		return -EINVAL;

	get_gm_config_src_rank(&rank);
	if(rank != 0) {
		/* Common data for timing resource */
		(*current)->fsm = NULL;
		(*current)->fsm_ext = NULL;
		(*current)->vc_info.status = VC_STATUS_DISABLED;
		(*current)->type = VC_TSRC_TYPE_GM;
		strncpy((*current)->name, "Grandmaster", MAX_STR_LEN-1);
		(*current)->id = GM_ID;
		(*current)->prio = rank;
		vc_tsrc_set_run_status((*current), VC_TSRC_RUN_STATUS_NULL);
		vc_tsrc_deactivate((*current));
		vc_tsrc_clear_stop_fsm((*current));
		(*current)->build = create_gm_fsm;
		(*current)->free = free_gm_fsm;

		/* Pass to the next element */
		(*current)++;
		n_vc_tsrc_list++;
	}

	/* Enable GM refresher if GM is not included in the timing source list */
	enable_gm_refresh((rank == 0) ? 1 : 0);

	return 0;
}

/**
 * @brief Initialize timing source structure for FR/HO
 *
 * It fills timing source structures using FR/HO settings specified
 * by the user (from direct configuration or using preset files)
 *
 * @param[inout] current Pointer to first timing source struture to fill
 * @return 0 if success and an error code otherwise
 * @retval EINVAL Timing source pointer is NULL
 *
 */
static int vc_tsrc_list_fr_ho_init(struct vc_timing_src **current)
{
	uint32_t rank, user_rank;
	enum ho_state hos;
	int ho_force_fr;

	if(!current || !(*current))
		return -EINVAL;

	/* TODO: Is there any condition not to add FR/HO to the list using
	   src_rank? */
	get_ho_config_src_rank(&rank);
	user_rank = rank;
	if(rank == 0)
		rank = DFL_HO_FR_TSRC_PRIO;

	(*current)->priv.fr_ho.mode = VC_TSRC_FR_HO_MODE_FAILED;

	/* If there is no other timing source, put rank as DFL_HO_FR_FORCED_TSRC_PRIO to force Manual FR/HO if user has not configure anything*/
	if(n_vc_tsrc_list == 0) {
		if(user_rank == 0)
			rank = DFL_HO_FR_FORCED_TSRC_PRIO;
		(*current)->priv.fr_ho.mode = VC_TSRC_FR_HO_MODE_MANUAL;
	}

	/* Common data for timing resource */
	(*current)->fsm = NULL;
	(*current)->fsm_ext = NULL;
	(*current)->vc_info.status = VC_STATUS_DISABLED;
	(*current)->type = VC_TSRC_TYPE_FR_HO;

	hald_get_softpll_ho_state(&hos);
	get_ho_config_force_fr(&ho_force_fr);
	/* TODO: Check with Emilio if this is the proper condition */
	if(hos == HO_UNAVAILABLE || ho_force_fr) {
		strncpy((*current)->name, "Free-running", MAX_STR_LEN-1);
		// Disable HO (it is not here!)
		hald_set_softpll_ho_run(0);
	} else {
		strncpy((*current)->name, "Holdover", MAX_STR_LEN-1);
		// Enable HO (only for learning)
		hald_set_softpll_ho_run(1);
	}

	(*current)->id = FR_HO_ID;
	(*current)->prio = rank;
	vc_tsrc_set_run_status((*current), VC_TSRC_RUN_STATUS_NULL);
	vc_tsrc_deactivate((*current));
	vc_tsrc_clear_stop_fsm((*current));
	(*current)->build = create_fr_ho_fsm;
	(*current)->free = free_fr_ho_fsm;

	/* Pass to the next element */
	(*current)++;
	n_vc_tsrc_list++;

	return 0;
}

/**
 * @brief Restart timing daemons (PPSi & PTP)
 *
 * It checks port configuration and restart timing daemons if necessary.
 * This step is specially required for those ports configured as masters.
 * In addition to this, the ports configured as slave/auto are initially set
 * as passive (or disabled) in order not to start synchronization.
 *
 * @warning PTPd does not provide a passive mode, maybe it could be required
 *          in a future version.
 *
 */
static void vc_timing_daemons_restart(void)
{
	int nports = get_nports();
	int i;
	char product[MAX_STR_LEN] = {0};
	int is_z16 = 0;
	int is_ethX = 0;
	int synce_enabled;
	enum port_mode pm;
	enum port_proto pp;
	const char *pn;
	enum ppsi_port_mode ppsi_pms[N_PORT_MODES] = {
		[PORT_MODE_MASTER] = PPSI_PORT_MODE_MASTER,
		[PORT_MODE_SLAVE] = PPSI_PORT_MODE_PASSIVE,
		[PORT_MODE_AUTO] = PPSI_PORT_MODE_PASSIVE
	};
	enum ptpd_port_mode ptpd_pms[N_PORT_MODES] = {
		[PORT_MODE_MASTER] = PTPD_PORT_MODE_MASTER,
		// Passive is missed for PTPd?
		[PORT_MODE_SLAVE] = PTPD_PORT_MODE_DISABLED,
		[PORT_MODE_AUTO] = PTPD_PORT_MODE_DISABLED
	};
	enum port_status port_s_ppsi[N_PORT_MODES] = {
		[PORT_MODE_MASTER] = PORT_STATUS_MASTER,
		[PORT_MODE_SLAVE] = PORT_STATUS_PASSIVE,
		[PORT_MODE_AUTO] = PORT_STATUS_PASSIVE,
	};
	enum port_status port_s_ptpd[N_PORT_MODES] = {
		[PORT_MODE_MASTER] = PORT_STATUS_MASTER,
		[PORT_MODE_SLAVE] = PORT_STATUS_DISABLED,
		[PORT_MODE_AUTO] = PORT_STATUS_DISABLED,
	};

	if(hald_get_ver_product(product, MAX_STR_LEN)) {
		pr_error("Product info could not be retrieved from HALd\n");
		return;
	} else {
		if(!strncmp(product, "Z16", MAX_STR_LEN-1))
			is_z16 = 1;
		else
			is_z16 = 0;
	}

	for(i = 0 ; i < nports ; i++) {
		get_port_mode(i, &pm);
		get_port_proto(i, &pp);
		get_port_name(i, &pn);

		is_ethX = (strstr(pn, "eth") ? 1 : 0);

		if (is_z16 && is_ethX) {
			pr_warning("ethX ports can not be configured to use PTP or WR in Z16 device\n");
			set_port_status(i, PORT_PROTO_DISABLED);
			continue;
		}

		if(is_ethX && pp == PORT_PROTO_WR) {
			pr_warning("ethX ports can not be configured to use WR\n");
			pp = PORT_PROTO_DISABLED;
		}

		switch(pp) {
		case PORT_PROTO_WR:
			/* First, set this port to be used by PPSi */
			if(!is_ethX)
				ppsi_set_port_mode(pn, ppsi_pms[pm]);
			/* Mark this port as DISABLED for PTPd */
			ptpd_set_port_mode(pn, PTPD_PORT_MODE_DISABLED);
			break;
		case PORT_PROTO_PTP:
			/* First, set this port to be used by PTPd */
			ptpd_set_port_mode(pn, ptpd_pms[pm]);
			/* Mark this port as DISABLED for PPSi */
			if(!is_ethX)
				ppsi_set_port_mode(pn, PPSI_PORT_MODE_DISABLED);

			/* Check SyncE for Masters ports */
			ptpd_get_port_enable_synce(pn, &synce_enabled);
			if(pm == PORT_MODE_MASTER && synce_enabled) {
				// Enable KTMGR Auto mode in ESMCd (put SSM code in reserved value)
				esmcd_set_port_cfg_provider_ssm(pn, ESMCD_PORT_SSM_RSVD0);
				// Enable ESMCd provider
				esmcd_set_port_cfg_provider_enable(pn, 1);
			}
			break;
		case PORT_PROTO_DISABLED:
			/* Disable for PTPd and PPSi */
			ptpd_set_port_mode(pn, PTPD_PORT_MODE_DISABLED);

			if(!is_ethX)
				ppsi_set_port_mode(pn, PPSI_PORT_MODE_DISABLED);
			break;
		default:
			continue;
		}

		/* Set port status depending on port mode and port proto configuration */
		set_port_status(i, (pp == PORT_PROTO_DISABLED) ? PORT_STATUS_DISABLED
				: (pp == PORT_PROTO_WR) ? port_s_ppsi[pm] : port_s_ptpd[pm]);

		/* Update wproc for PTPd port */
		ptpd_set_run_stop(pn, 1);
	}

	/* Finally, re-start PPSi daemon */
	ppsi_set_cfg_timing_mode(PPSI_TM_FR);
	ppsi_set_cfg_ext_port_config(1);
	ppsi_set_run_stop(1);
}

/**
 * @brief Init Virtual Clock policy
 *
 * It gets Virtual Clock policy from GPA parameters or use the default one
 * otherwise. Then, the policy is initialized and its strategy is changed if
 * a specify value has set on GPA parameter.
 *
 * @note Policy initialization process implies timing source thread creation
 *
 */
static int vc_tsrc_list_policy_init(void)
{
	uint16_t policy, strategy;

	/* Init policy */
	if(get_vc_cfg_policy(&policy))
		policy = VC_POLICY_CODE_FOCA;

	current_policy = vc_policy_get(policy);
	vc_policy_init(current_policy, &vc_tsrc_list[0], n_vc_tsrc_list);

	/* Configure strategy for the policy */
	switch(policy) {
	case VC_POLICY_CODE_FOCA:
	case VC_POLICY_CODE_DEFAULT:
	default:
		if(get_vc_cfg_foca_strategy(&strategy))
			vc_policy_change_strategy(current_policy,
						(uint32_t) strategy);
		break;
	}

	return 0;
}

/**
 * @brief Init global timing source list for Virtual Clock
 *
 * It initializes the global timing source list and fill its information
 * depending on user configuration (from direct configuration or preset files)
 *
 * @return 0 if success and an error code otherwise
 * @retval EINVAL Number of selected sources is greater than the number of allowed references
 * @retval EFAULT Some timing source initialization has failed
 *
 */
static int vc_tsrc_list_init(void)
{
	struct vc_timing_src *current;
	int ns;

	// Clean list
	memset((void *) &(vc_tsrc_list[0]), 0, sizeof(vc_tsrc_list));
	n_vc_tsrc_list = 0;

	ns = vc_tsrc_list_get_selected_sources();
	if(ns > VC_PRIORITY_LENGTH) {
		pr_error("Number of selected sources (%d) is greater than maximum references allowed (%d) \n", ns, VC_PRIORITY_LENGTH);
		return -EINVAL;
	}

	// Get the first empty element
	current = &(vc_tsrc_list[0]);
	// Initialize timing source related to ports
	if(vc_tsrc_list_ports_init(&current))
		return -EFAULT;
	// Initialize GM timing source
	if(vc_tsrc_list_gm_init(&current))
		return -EFAULT;
	// Initialize FR/HO timing source
	if(vc_tsrc_list_fr_ho_init(&current))
		return -EFAULT;

	// Re-start timing daemons if necessary
	vc_timing_daemons_restart();

	// Init policy and start timing source threads
	vc_tsrc_list_policy_init();

	/* Init source pointers */
	current_src = NULL;
	selected_src = NULL;

	/* Print priority list inside policy */
	//vc_policy_print_tsrc_list(current_policy);

	set_tsrc_info_num_active_srcs(n_vc_tsrc_list);

	return 0;
}

/**
 * @brief Free global timing source list for Virtual Clock
 *
 * It frees timing resources of global list and exits from the current policy.
 *
 * @note Policy exit process wait for the completion of timing source threads
 *       and also frees their resources.
 *
 * @return Always 0 (For future versions, error codes could be returned)
 *
 */
static int vc_tsrc_list_free(void)
{
	/* Exit from policy and free timing source list */
	vc_policy_exit(current_policy);

	/* Hide tsrc_info for a while */
	set_tsrc_info_num_active_srcs(0);

	/* Clean timing source list for VC algorithm */
	memset((void *) &(vc_tsrc_list[0]), 0, sizeof(vc_tsrc_list));
	n_vc_tsrc_list = 0;

	return 0;
}

/**
 * @brief Send acknowledgment to timing source threads
 *
 * The long story: timing source threads stops its execution in its
 * IDLE state when a CRITICAL condition occurs. In order to notify this
 * event to the main thread of TMGR, they set a checkpoint flag inside
 * vc_timing_src structure. They have to wait in IDLE state until this
 * flag is clear again. Consequently, main thread of TMGR should send
 * ACK periodically to timing source threads to unblock them.
 *
 */
static void vc_send_ack(void)
{
	int i;
	struct vc_timing_src *s;

	/* For each timing source in the global list */
	for(i = 0 ; i < n_vc_tsrc_list ; i++) {
		s = &(vc_tsrc_list[i]);
		/* If checkpoint flag has been enabled */
		if(vc_tsrc_checkp_fsm_is_enabled(s)) {
			/* Clear it (ack) */
			vc_tsrc_clear_checkp_fsm(s);
		}
	}
}

/**
 * @brief Reset values for Virtual Clock information
 */
static void vc_reset_data(void)
{
	int i;

	/* Reset NTP & GM info */
	reset_ntp_info();
	reset_gm_info();

	/* Reset data for VC info */
	reset_vc_data();

	/* Clean GPA parameters for tsrc_info list */
	for(i = 0 ; i < VC_PRIORITY_LENGTH ; i++) {
		reset_tsrc_info_data(i);
	}
}

/**
 * @brief Select the next timing source for Virtual Clock
 *
 * @return NULL if no timing source can be selected and a timing source pointer otherwise
 */
static struct vc_timing_src * vc_select(void)
{
	struct vc_timing_src *s;
	enum holdover_force_trigger ft;
	enum ho_state hos;

	/*  Check state of HO and user force trigger */
	get_ho_config_force_trigger(&ft);
	hald_get_softpll_ho_state(&hos);

	/* User has issue a HO trigger and it has been activated */
	if(ft == HO_FORCE_TRIGGER_START && hos == HO_ACTIVATED) {
		set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);
		s = vc_policy_force_select(current_policy, FR_HO_ID);
	} else {
		s = vc_policy_select(current_policy);
	}

	return s;
}

/************************************************************
 * Public API                                               *
 ************************************************************/

/**
 * @brief Start Virtual Clock engine
 *
 * It initializes Virtual Clock resources and reset its data
 *
 * @return Always 0 (For future versions, error codes could be returned)
 *
 */
int vc_start(void)
{
	int ret;

	/* 1 - Configure ktmgr to update PPSi */
	ktmgr_set_attr(KTMGR_TM_LOCKSTATE, 1);
	/* 2 - Init timing source list */
	ret = vc_tsrc_list_init();
	/* 3 - Reset data */
	vc_reset_data();

	return ret;
}

/**
 * @brief Run Virtual Clock engine
 *
 * It runs main functions of Virtual Clock engine.
 *     - Select timing source using policy
 *     - Change from one timing source to another (if required)
 *     - Send ACK to timing source threads
 *     - Update datetime
 *
 * @note It should be periodically called in the main loop of TMGR
 *
 * @return Always 0 (For future versions, error codes could be returned)
 *
 */
int vc_run(void)
{
	static int msg_no_sources;
	static int msg_wait_stop;

	/* 1 - Choose clock source using current VC policy */
	selected_src = vc_select();
	if(!selected_src) {
		if (!msg_no_sources) {
			msg_no_sources = 1;
			pr_verbose("No available clock sources "
				"for Virtual Clock\n");
		}
	}

	/* 2 - Deactivate current clock source if it's running and activate the
	 *     new clock source.
	 *
	 *     We have two possible scenarios here:
	 *
	 *         a) There's no source running currently or the current source has failed
	 *            and the VC has selected another one (see step 1 above). In this
	 *            case we have to deactivate the current running source not-active)
	 *            and activate the new selected source.
	 *
	 *         b) There's a Virtual Clock source already running but the user has
	 *            decided to switch to another source manually. We have to notify
	 *            the current running source and wait for it to stop. Once it has
	 *            stopped we can activate the new selected source.
	 *
	 *      Note that <vc_tsrc_deactivate> will notify the source passed as a
	 *      parameter but will only return successfully when the source has
	 *      stopped. This is meant to be called repeatedly until the current
	 *      source stops properly.
	 */

	if (selected_src != current_src) {
		if (!vc_tsrc_deactivate(current_src)) {
			pr_verbose("Old src: %s -> New src: %s \n",
				(current_src) ? current_src->name : "None",
				(selected_src) ? selected_src->name : "None");
			current_src = selected_src;

			/* Activate the new one */
			vc_tsrc_activate(current_src);
			msg_no_sources = 0;
			msg_wait_stop = 0;
		} else {
			if (!msg_wait_stop) {
				msg_wait_stop = 1;
				pr_verbose("Waiting for current "
					"source to stop\n");
			}
		}
	}

	/* 3 - Ack timing source threads after enabling/disabling sources */
	vc_send_ack();

	/* 4 - Update datetime */
	update_datetime();

	return 0;
}

/**
 * @brief Stop Virtual Clock engine
 *
 * It frees Virtual Clock resources
 *
 * @return Always 0 (For future versions, error codes could be returned)
 *
 */
int vc_exit(void)
{
	int ret;

	/* 1 - Free timing source list */
	ret = vc_tsrc_list_free();
	/* 2 - Configure ktmgr not to update PPSi */
	ktmgr_set_attr(KTMGR_TM_LOCKSTATE, 0);

	return ret;
}

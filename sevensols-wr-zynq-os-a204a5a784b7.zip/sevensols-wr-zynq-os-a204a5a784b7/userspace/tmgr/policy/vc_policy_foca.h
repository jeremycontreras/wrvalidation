#ifndef __VC_POLICY_FOCA_H__
#define __VC_POLICY_FOCA_H__

/*
 * vc_policy_foca.h
 *
 * Header file for FailOver Clock Algoritm (FOCA) policy
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "vc_policy.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

enum vc_policy_foca_strategy {
	/* Strict FO: it does not come back until it fails in the last timing source */
	VC_POL_FOCA_ST_FO_STRICT = 0,
	/* Best FO: when it fails, select the best available timing source */
	VC_POL_FOCA_ST_FO_REEVALUATE,

	N_VC_POL_FOCA_STRATEGIES,
};

/************************************************************
 * Public API                                               *
 ************************************************************/

struct vc_policy *vc_policy_get_foca(void);

#endif /* __VC_POLICY_FOCA_H__ */

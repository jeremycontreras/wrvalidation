#ifndef __VC_POLICY_H__
#define __VC_POLICY_H__

/*
 * vc_policy.h
 *
 * General API for controlling Virtual Clock (VC) policy to select sources.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdint.h>

#include "vc_timing_src.h"

enum vc_policy_code {
	VC_POLICY_CODE_DEFAULT = 0,
	VC_POLICY_CODE_FOCA,
	N_VC_POLICY_CODES,
};

struct vc_strategy {
	/* Strategy name */
	char *name;

	/* Strategy ID */
	uint32_t id;
};

struct vc_policy {
	/* Policy name */
	char *name;

	/* Policy ID */
	uint32_t id;

	/* Policy strategy */
	struct vc_strategy *strategy;

	/* VC Timing source list */
	struct vc_timing_src **tsrc_list;
	int n_tsrc_list;

	/* Current timing source */
	struct vc_timing_src *tsrc_current;
	int tsrc_current_idx;

	/* API for VC policy */
	int (*init)(struct vc_policy *);
	struct vc_timing_src *(*select)(struct vc_policy *);
	struct vc_timing_src *(*force_select)(struct vc_policy *, uint32_t);
	int (*change_strategy)(struct vc_policy *, uint32_t);
	int (*exit)(struct vc_policy *);
};

/************************************************************
 * Public API                                               *
 ************************************************************/

/* Generic functions (vc_policy.c) */
void vc_policy_tsrc_sort(struct vc_timing_src **, int, int (*)(const void *, const void *));
void vc_policy_sort(struct vc_timing_src **, int);
void vc_policy_print_tsrc_list(struct vc_policy *);
int vc_policy_init(struct vc_policy *, struct vc_timing_src *, int);
struct vc_timing_src *vc_policy_select(struct vc_policy *);
struct vc_timing_src *vc_policy_force_select(struct vc_policy *, uint32_t);
int vc_policy_change_strategy(struct vc_policy *, uint32_t);
int vc_policy_exit(struct vc_policy *);
struct vc_policy *vc_policy_get(enum vc_policy_code);

#endif /* __VC_POLICY_H__ */

/*
 * vc_policy_foca.c
 *
 * Source code for FailOver Clock Algoritm (FOCA) policy
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "vc_policy_foca.h"

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

// Forward declaration to include them in vc_policy static structure
static int vc_pol_foca_init(struct vc_policy *p);
static struct vc_timing_src *vc_pol_foca_select(struct vc_policy *p);
static struct vc_timing_src *vc_pol_foca_force_select(struct vc_policy *p, uint32_t src_id);
static int vc_pol_foca_change_strategy(struct vc_policy *p, uint32_t id);
static int vc_pol_foca_exit(struct vc_policy *p);

static struct vc_strategy vc_st_foca_defs[N_VC_POL_FOCA_STRATEGIES] =
{
	[VC_POL_FOCA_ST_FO_STRICT] = {.name = "Strict Failover", .id = VC_POL_FOCA_ST_FO_STRICT},
	[VC_POL_FOCA_ST_FO_REEVALUATE] = {.name = "Failover with re-evaluation", .id = VC_POL_FOCA_ST_FO_REEVALUATE},
};

static struct vc_policy vc_pol_foca_def =
{
	.name = "FOCA",
	.id = VC_POLICY_CODE_FOCA,
	.strategy = &(vc_st_foca_defs[VC_POL_FOCA_ST_FO_REEVALUATE]), /* REEVALUATE by default */
	.init = vc_pol_foca_init,
	.select = vc_pol_foca_select,
	.force_select = vc_pol_foca_force_select,
	.change_strategy = vc_pol_foca_change_strategy,
	.exit = vc_pol_foca_exit,
};

/************************************************************
 * Private functions                                        *
 ************************************************************/

static int vc_pol_foca_init(struct vc_policy *p)
{
	int ret = 1;

	if(!p)
		return ret;

	// Init internal data
	p->tsrc_current = NULL;
	p->tsrc_current_idx = -1;

	// Default policy is with re-evaluation
	p->strategy = &(vc_st_foca_defs[VC_POL_FOCA_ST_FO_REEVALUATE]);

	// Sort VC timing source by priority
	vc_policy_sort(p->tsrc_list, p->n_tsrc_list);

	ret = 0;

	return ret;
}

static struct vc_timing_src *vc_pol_foca_select(struct vc_policy *p)
{
	struct vc_timing_src *selected = NULL;
	int selected_idx = -1;
	struct vc_timing_src *current = NULL;
	int current_idx = -1;
	signed char current_prio0 = -1;
	signed char prio0;
	int tsrc_is_ready = 0;
	int i;

	if(!p)
		return selected;

	/* 1. Start with current timing source (or NULL if None is selected) */
	current = p->tsrc_current;
	current_idx = p->tsrc_current_idx;

	/* 2. Check if a new selection should be performed */
	/* Here there are two cases:
	 * - Current timing source failure
	 * - Current timing source is Ok but priority0 has been set (not -1). Then, a priority comparison should be performed */
	if(current) {
		if(!vc_tsrc_is_critical(current)) {
			selected = current;
			selected_idx = current_idx;
			current_prio0 = vc_tsrc_get_prio0(current);

			if(current_prio0 == -1)
				return selected;
		}
	}

	/* 3. Select a new timing sorce from the list */

	/* Depending on the strategy, the complete list is considered or only the rest of elements in the FO chain */
	if(p->strategy->id == VC_POL_FOCA_ST_FO_REEVALUATE || p->tsrc_current_idx == -1) {
		i = 0;
	}
	else {
		i = p->tsrc_current_idx+1;
		if(i == p->n_tsrc_list)
			i = 0;
	}

	/* NOTE: It is supposed that list is ordered by priority, so do not check this field */
	for(; i < p->n_tsrc_list ; i++) {
		current = p->tsrc_list[i];
		tsrc_is_ready = (!vc_tsrc_is_critical(current) && vc_tsrc_is_runnable(current));
		if(current_prio0 == -1) {
			if(tsrc_is_ready) {
				selected = current;
				selected_idx = i;
				break;
			}
		} else {
			prio0 = vc_tsrc_get_prio0(current);
			if(tsrc_is_ready && (prio0 != -1 && current_prio0 > prio0)) {
				selected = current;
				selected_idx = i;
				break;
			}
		}
	}

	/* 4. Update current fields in policy */
	if (selected_idx != -1) {
		p->tsrc_current = selected;
		p->tsrc_current_idx = selected_idx;
	} else {
		p->tsrc_current = NULL;
		p->tsrc_current_idx = -1;
	}

	return selected;
}

static struct vc_timing_src * vc_pol_foca_force_select(struct vc_policy *p, uint32_t src_id)
{
	struct vc_timing_src *s = NULL;
	int i;
	int found = -1;

	if(!p)
		return s;

	for(i = 0 ; i < p->n_tsrc_list ; i++) {
		if(p->tsrc_list[i]->id == src_id) {
			found = i;
			break;
		}
	}

	if(found == -1)
		return s;
	else {
		p->tsrc_current = p->tsrc_list[found];
		p->tsrc_current_idx = found;
	}

	return p->tsrc_current;
}

static int vc_pol_foca_change_strategy(struct vc_policy *p, uint32_t id)
{
	int ret = 1;
	int i;
	int found = 0;
	struct vc_strategy *st;

	if(!p)
		return ret;

	for(i = 0 ; i < N_VC_POL_FOCA_STRATEGIES ; i++) {
		st = &(vc_st_foca_defs[i]);
		if(st->id == id) {
			found = 1;
			break;
		}
	}

	if(found) {
		ret = 0;
		p->strategy = st;
	}

	return ret;
}

static int vc_pol_foca_exit(struct vc_policy *p)
{
	int ret = 0;

	/* TODO: Something to do here? */

	return ret;
}

/************************************************************
 * Public API                                               *
 ************************************************************/

struct vc_policy *vc_policy_get_foca(void)
{
	return &vc_pol_foca_def;
}


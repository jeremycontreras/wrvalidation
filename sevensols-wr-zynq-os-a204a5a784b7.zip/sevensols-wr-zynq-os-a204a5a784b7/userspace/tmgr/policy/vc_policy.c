/*
 * vc_policy.c
 *
 * General API for controlling Virtual Clock (VC) policy to select sources.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <stdint.h>

#include "gpa_interface.h"
#include "gpa_common.h"
#include "vc_policy.h"

/* External functions to get policies */
/* FOCA: vc_policy_foca.c */
extern struct vc_policy *vc_policy_get_foca(void);

static int vc_policy_tsrc_dfl_sortf(const void *a, const void *b)
{
	const struct vc_timing_src **src1 = (const struct vc_timing_src **) a;
	const struct vc_timing_src **src2 = (const struct vc_timing_src **) b;
	const struct vc_timing_src *s1 = *src1;
	const struct vc_timing_src *s2 = *src2;

	return (s1->prio-s2->prio);
}

void vc_policy_tsrc_sort(struct vc_timing_src **list, int n_list, int (*sortf)(const void *a, const void *b))
{
	int i;
	struct vc_timing_src *c;

	qsort(list, n_list, sizeof(struct vc_timing_src *), sortf);

	/* Set source index after sorting the list */
	for(i = 0 ; i < n_list ; i++) {
		c = list[i];
		vc_tsrc_set_src_idx(c, i);
	}
}

void vc_policy_sort(struct vc_timing_src **list, int n_list)
{
	vc_policy_tsrc_sort(list, n_list, vc_policy_tsrc_dfl_sortf);
}

void vc_policy_print_tsrc_list(struct vc_policy *p)
{
	int i;
	int n_list;
	struct vc_timing_src *s;

	if(!p)
		return;

	n_list = p->n_tsrc_list;

	for(i = 0 ; i < n_list ; i++) {
		s = p->tsrc_list[i];
		printf("List[%d]: \n", i);
		printf("\t-name: %s \n", s->name);
		printf("\t-prio: %d \n", s->prio);
		printf("\t-src_idx: %d \n", vc_tsrc_get_src_idx(s));
		printf("\n");
	}
}

int vc_policy_init(struct vc_policy *p, struct vc_timing_src *list, int n_list)
{
	int ret = 1;
	int i;
	struct vc_timing_src *src;

	if(!p)
		return ret;

	/* 1. First create Timing source internal list */
	p->tsrc_list = calloc(n_list, sizeof(struct vc_timing_src *));

	for(i = 0 ; i < n_list ; i++) {
		p->tsrc_list[i] = &list[i];
	}

	p->n_tsrc_list = n_list;

	/* 2. Build all VC Timing sources */
	for(i = 0 ; i < n_list ; i++) {
		src = &(list[i]);
		vc_tsrc_init(src);
		vc_tsrc_run(src);
	}

	/* 3. Call specific policy init if any */
	if(p->init)
		ret = p->init(p);

	return ret;
}

struct vc_timing_src *vc_policy_select(struct vc_policy *p)
{
	struct vc_timing_src *ret = NULL;

	if(!p || !p->select)
		return ret;

	ret = p->select(p);

	return ret;
}

struct vc_timing_src *vc_policy_force_select(struct vc_policy *p, uint32_t src_id)
{
	struct vc_timing_src *ret = NULL;

	if(!p || !p->force_select)
		return ret;

	ret = p->force_select(p, src_id);

	return ret;
}

int vc_policy_change_strategy(struct vc_policy *p, uint32_t id)
{
	int ret = 1;

	if(!p || !p->change_strategy)
		return ret;

	ret = p->change_strategy(p, id);

	return ret;
}

int vc_policy_exit(struct vc_policy *p)
{
	int ret = 1;
	struct vc_timing_src *src;
	int n_list;
	int i;

	if(!p)
		return ret;

	/* 1. First call specify policy exit if any */
	if(p->exit)
		ret = p->exit(p);

	/* 2. Free all VC Timing sources */
	n_list = p->n_tsrc_list;

	for(i = 0 ; i < n_list ; i++) {
		src = p->tsrc_list[i];
		vc_tsrc_free(src);
	}

	/* 3. Free Timing source internal list */
	free(p->tsrc_list);

	return ret;
}

struct vc_policy *vc_policy_get(enum vc_policy_code code)
{
	struct vc_policy *p = NULL;

	switch(code) {
	case VC_POLICY_CODE_FOCA:
	case VC_POLICY_CODE_DEFAULT:
	default:
		p = vc_policy_get_foca();
		break;
	};

	return p;
}

#include "fsmlib.h"

/*
 * TCP handshake FSM. Implements part of the TCP FSM (up to connection
 * establishment).
 *
 * It uses synchronous states like the simpler <test3>, but it adds timeouts to
 * the implementation, as well as transition actions.
 *
 * When working with synchronous states and transitions, it's up to the user to
 * implement the event management, timeouts, etc by him/herself. In this case
 * the data input is taken from stdin and the timeouts are implemented using
 * <select>. Fsmlib still offers a state/action/transition framework that is
 * flexible enough for most applications.
 */

/* State functions */
extern void *input_read(void *args);
extern void clean(void *args);

/* Actions */
extern void clear_timer(void *args);

/* Transition functions */
extern int closed_to_listen(void *args);
extern int closed_to_syn_sent(void *args);
extern int listen_to_syn_rcvd(void *args);
extern int listen_to_syn_sent(void *args);
extern int syn_rcvd_to_closed(void *args);
extern int syn_rcvd_to_listen(void *args);
extern int syn_rcvd_to_established(void *args);
extern int syn_sent_to_closed(void *args);
extern int syn_sent_to_syn_rcvd(void *args);
extern int syn_sent_to_established(void *args);

/* Transition actions */
extern void *listen_to_syn_rcvd_action(void);
extern void *listen_to_syn_sent_action(void);
extern void *closed_to_syn_sent_action(void);
extern void *syn_sent_to_syn_rcvd_action(void);
extern void *syn_sent_to_established_action(void);

struct fsm *tcp_fsm(void)
{
	struct fsm *fsm = new_fsm("TCP FSM");

	/* Actions */

	struct action *act_clear_timer = new_action(clear_timer, 0);

	/* States */

	/*
	 * The argument to <input_read> is the timeout in seconds. 0 means no
	 * timeout (blocks until it gets any input).
	 *
	 * The <act_clear_timer> action is used to reset the timer before using
	 * it.
	 */
	struct sync_state *st_closed = new_sync_state("CLOSED",
						input_read, 0, clean);
	add_state((union state *)st_closed, fsm);

	struct sync_state *st_listen = new_sync_state("LISTEN",
						input_read, 0, clean);
	add_state((union state *)st_listen, fsm);

	struct sync_state *st_syn_rcvd = new_sync_state("SYN_RCVD",
						input_read, (void *)5, clean);
	add_state((union state *)st_syn_rcvd, fsm);
	add_action(act_clear_timer, (union state *)st_syn_rcvd, ENTRY);

	struct sync_state *st_syn_sent = new_sync_state("SYN_SENT",
						input_read, (void *)5, clean);
	add_state((union state *)st_syn_sent, fsm);
	add_action(act_clear_timer, (union state *)st_syn_sent, ENTRY);

	struct sync_state *st_established = new_sync_state("ESTABLISHED", 0, 0, 0);
	add_state((union state *)st_established, fsm);


	/*
	 * Transitions.
	 * Note that some transitions have transition actions. These will run
	 * when the transition is triggered.
	 */

	/* From CLOSED */

	struct sync_transition *t_closed_listen = new_sync_transition(
		st_closed, (union state *)st_listen, closed_to_listen, 0);
	if (!t_closed_listen)
		return 0;

	struct sync_transition *t_closed_syn_sent = new_sync_transition(
		st_closed, (union state *)st_syn_sent,
		closed_to_syn_sent, closed_to_syn_sent_action);
	if (!t_closed_syn_sent)
		return 0;

	/* From LISTEN */

	struct sync_transition *t_listen_syn_rcvd = new_sync_transition(
		st_listen, (union state *)st_syn_rcvd,
		listen_to_syn_rcvd, listen_to_syn_rcvd_action);
	if (!t_listen_syn_rcvd)
		return 0;

	struct sync_transition *t_listen_syn_sent = new_sync_transition(
		st_listen, (union state *)st_syn_sent,
		listen_to_syn_sent, listen_to_syn_sent_action);
	if (!t_listen_syn_sent)
		return 0;

	/* From SYN_RCVD */

	struct sync_transition *t_syn_rcvd_closed = new_sync_transition(
		st_syn_rcvd, (union state *)st_closed, syn_rcvd_to_closed, 0);
	if (!t_syn_rcvd_closed)
		return 0;

	struct sync_transition *t_syn_rcvd_listen = new_sync_transition(
		st_syn_rcvd, (union state *)st_listen, syn_rcvd_to_listen, 0);
	if (!t_syn_rcvd_listen)
		return 0;

	struct sync_transition *t_syn_rcvd_established = new_sync_transition(
		st_syn_rcvd, (union state *)st_established,
		syn_rcvd_to_established, 0);
	if (!t_syn_rcvd_established)
		return 0;

	/* From SYN_SENT */

	struct sync_transition *t_syn_sent_closed = new_sync_transition(
		st_syn_sent, (union state *)st_closed, syn_sent_to_closed, 0);
	if (!t_syn_sent_closed)
		return 0;

	struct sync_transition *t_syn_sent_syn_rcvd = new_sync_transition(
		st_syn_sent, (union state *)st_syn_rcvd,
		syn_sent_to_syn_rcvd, syn_sent_to_syn_rcvd_action);
	if (!t_syn_sent_syn_rcvd)
		return 0;

	struct sync_transition *t_syn_sent_established = new_sync_transition(
		st_syn_sent, (union state *)st_established,
		syn_sent_to_established, syn_sent_to_established_action);
	if (!t_syn_sent_established)
		return 0;

	return fsm;
}

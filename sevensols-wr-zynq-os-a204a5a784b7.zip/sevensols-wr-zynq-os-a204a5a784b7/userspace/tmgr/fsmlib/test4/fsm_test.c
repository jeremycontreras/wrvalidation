#include "fsmlib.h"

/*
 * fsm_test.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 22, 2019
 */

extern struct fsm *tcp_fsm(void);

int main(void)
{
	struct fsm *fsm = tcp_fsm();

	if (!fsm)
		return 1;

	run(fsm, SYNC);
	wait_for_fsm(fsm);
	free_fsm(fsm);

	return 0;
}

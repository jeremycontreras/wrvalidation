#include "fsmlib.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/timerfd.h>

/*
 * Struct to pass data between the state function and the transition <check>
 * functions.
 *
 * timeout: 1 if a timeout happened. 0 otherwise.
 * str:     A pointer to a buffer with the received data if something was received
 *          (ie. if timeout == 0).
 */
struct params {
	int timeout;
	char *str;
};

static struct params params;

/* Global flag for timer management */
static int timer_running;

/* File descriptor for the timer */
static int timerfd;


/* Disarms a runing timer */
void clear_timer(void *args)
{
	struct itimerspec ts = {0};

	if (timer_running) {
		timerfd_settime(timerfd, 0, &ts, NULL);
		timer_running = 0;
	}
}

void *input_read(void *args)
{
	fd_set readfds;
	int nfds = 0;
	int ready = 0;
	size_t size = 0;
	struct itimerspec ts = {0};

	/* If a timeout is specified */
	if (args > 0) {
		/* Create (if necessary) and set the timer */
		if (!timer_running) {
			if (!timerfd)
				timerfd = timerfd_create(CLOCK_MONOTONIC, 0);
			ts.it_value.tv_sec = (time_t)args;
			timerfd_settime(timerfd, 0, &ts, NULL);
			timer_running = 1;
		}

		FD_ZERO(&readfds);
		FD_SET(STDIN_FILENO, &readfds);
		if (STDIN_FILENO >= nfds)
			nfds = STDIN_FILENO + 1;
		FD_SET(timerfd, &readfds);
		if (timerfd >= nfds)
			nfds = timerfd + 1;

		/* Wait for input */
		ready = select(nfds, &readfds, 0, 0, 0);
		if (ready && FD_ISSET(timerfd, &readfds)) {
			params.timeout = 1;
			return 0;
		}
	}

	getline(&params.str, &size, stdin);

	return 0;
}

void clean(void *args)
{
	free(params.str);
	memset(&params, 0, sizeof(params));
}


/* Synchronous transition <check> functions and actions */


int closed_to_listen(void *args)
{
	if (strcmp(params.str, "open\n") == 0) {
		return 1;
	}

	return 0;
}

int closed_to_syn_sent(void *args)
{
	if (strcmp(params.str, "active_open\n") == 0) {
		return 1;
	}

	return 0;
}

void *closed_to_syn_sent_action(void)
{
	printf("SYN\n");

	return 0;
}

int listen_to_syn_rcvd(void *args)
{
	if (strcmp(params.str, "syn\n") == 0) {
		return 1;
	}

	return 0;
}

void *listen_to_syn_rcvd_action(void)
{
	printf("SYN,ACK\n");

	return 0;
}

int listen_to_syn_sent(void *args)
{
	if (strcmp(params.str, "data\n") == 0) {
		return 1;
	}

	return 0;
}

void *listen_to_syn_sent_action(void)
{
	printf("SYN\n");

	return 0;
}

int syn_rcvd_to_listen(void *args)
{
	if (strcmp(params.str, "rst\n") == 0) {
		return 1;
	}

	return 0;
}

int syn_rcvd_to_closed(void *args)
{
	if (params.timeout)
		return 1;

	return 0;
}

int syn_rcvd_to_established(void *args)
{
	if (strcmp(params.str, "ack\n") == 0) {
		return 1;
	}

	return 0;
}

int syn_sent_to_closed(void *args)
{
	if (params.timeout)
		return 1;

	return 0;
}

int syn_sent_to_syn_rcvd(void *args)
{
	if (strcmp(params.str, "syn\n") == 0) {
		return 1;
	}

	return 0;
}

void *syn_sent_to_syn_rcvd_action(void)
{
	printf("SYN,ACK\n");

	return 0;
}

int syn_sent_to_established(void *args)
{
	if (strcmp(params.str, "syn,ack\n") == 0) {
		return 1;
	}

	return 0;
}

void *syn_sent_to_established_action(void)
{
	printf("ACK\n");

	return 0;
}

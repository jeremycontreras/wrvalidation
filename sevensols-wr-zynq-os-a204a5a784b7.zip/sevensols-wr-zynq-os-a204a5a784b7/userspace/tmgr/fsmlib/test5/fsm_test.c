#include "fsmlib.h"

/*
 * fsm_test.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: May 2, 2019
 */

/*
 * Nested FSMs example. fsm2 will run completely as part of one of the states of
 * fsm1.
 */

/* The FSMs are defined elsewhere (see fsmdef1.c and fsmdef2.c) */
extern struct fsm *test_fsm1(void);
extern struct fsm *test_fsm2(void);

struct fsm *fsm1;
struct fsm *fsm2;

int main(void)
{
	fsm1 = test_fsm1();
	fsm2 = test_fsm2();

	if (fsm1)
		run(fsm1, SYNC);

	free_fsm(fsm1);
	free_fsm(fsm2);

	return 0;
}

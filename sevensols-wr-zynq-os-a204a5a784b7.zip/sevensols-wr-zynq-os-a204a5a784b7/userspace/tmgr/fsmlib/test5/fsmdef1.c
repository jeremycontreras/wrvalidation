#include "fsmlib.h"

/*
 * A FSM that uses asynchronous transitions to move from one state to the next.
 *
 * It uses timed transitions to cycle through states A - B - C and an
 * event-triggered transition to finish the cycle and move to the End State when
 * a certain condition is met.
 *
 * State B runs a separate FSM, this is a way to abstract complex FSMs into
 * multiple simpler ones. In this case, the result is the same as if B
 * transitioned to the first state of the second FSM and the last state of the
 * second FSM transitioned to C.
 *
 * Implementation:
 *
 *  - Four states: A, B, C and End state.
 *
 *   _______________
 *  |               |
 *  v               |
 *  A ----> B ----> C
 *  |	   |  ^
 *  |	   |  |
 *  |  	   |  |
 *  |	   v  |
 *  |	   ------
 *  |	  | FSM2 |
 *  |	   ------
 *  v
 *  End
 *
 *  - <A> transitions to <B> using a time-triggered transition.
 *
 *  - <B> runs FSM2, waits for it to finish and then transitions to <C>.
 *
 *  - <C> transitions to <A> using a time-triggered transition.
 *
 *  - <A> transitions to the End state after being activated a number of times.
 *
 * Note that the FSM definition is unaware of the nested FSM. There are no
 * explicit mechanisms to define sub-FSMs. Running a FSM is the same as any
 * other operation and, since there are no runtime dependencies between FSMs,
 * there are no restrictions on how to run them and it's up to the application
 * code to define how to do it.
 *
 * In this test FSM2 runs in <transition_test_fun>, the event-checker function
 * of t_b_c.
 */


/* Application-dependent code is defined elsewhere (see test_code.c) */
extern void *transition_end_condition(void *args);
extern void *transition_test_fun(void *args);

/*
 * Creates and returns the state machine.
 *
 * 1 - Create a new fsm
 * 2 - Create the states
 *
 * Then, in any order you want:
 * - Create actions if needed
 * - Link states using transitions
 * - Add the created actions to states
 * - Add the states to the fsm
 *
 * Finally, return the fsm.
 */
struct fsm *test_fsm1(void)
{
	struct fsm *fsm = new_fsm("Test FSM 1");

	/* States */

	struct async_state *st_a = new_async_state("Test state A");
	add_state((union state *)st_a, fsm);

	struct async_state *st_b = new_async_state("Test state B");
	add_state((union state *)st_b, fsm);

	struct async_state *st_c = new_async_state("Test state C");
	add_state((union state *)st_c, fsm);

	struct async_state *st_end = new_async_state("End state");
	add_state((union state *)st_end, fsm);

	/* Transitions */

	struct timed_transition *t_a_b = new_timed_transition(
		st_a, (union state *)st_b, 100000000, 0);
	if (!t_a_b)
		return 0;

	struct event_transition *t_b_c = new_event_transition(
		st_b, (union state *)st_c, transition_test_fun, 0);
	if (!t_b_c)
		return 0;

	struct timed_transition *t_c_a = new_timed_transition(
		st_c, (union state *)st_a, 100000000, 0);
	if (!t_c_a)
		return 0;

	struct event_transition *t_a_end = new_event_transition(
		st_a, (union state *)st_end, transition_end_condition, 0);
	if (!t_a_end)
		return 0;

	return fsm;
}

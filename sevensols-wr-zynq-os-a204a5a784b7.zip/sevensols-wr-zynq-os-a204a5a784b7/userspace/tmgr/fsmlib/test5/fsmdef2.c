#include "fsmlib.h"

/*
 * A FSM that uses asynchronous transitions to move from one state to the next.
 *
 * It uses timed transitions to loop through states A and B and an
 * event-triggered transition to finish the cycle and move to the End State when
 * a certain condition is met.
 *
 * Implementation:
 *
 *  - Three states: A, B and End state.
 *
 *   _______________
 *  |               |
 *  v               |
 *  A ------------> B
 *  |
 *  |
 *  v
 *  End
 *
 *  - <A> transitions to <B> using a time-triggered transition.
 *
 *  - <B> transitions to <A> using a time-triggered transition.
 *
 *  - <A> transitions to the End state after being activated a number of times.
 *
 * This FSM will need to run multiple times, so we need a way to reset any
 * internal state it may have to its initial condition. We'll do this by
 * defining an entry action for the end state that will run a <cleanup>
 * function.
 */

/* Application-dependent code is defined elsewhere (see test_code.c) */
extern void cleanup(void *args);
extern void *transition_end_condition2(void *args);


/*
 * Creates and returns the state machine.
 *
 * 1 - Create a new fsm
 * 2 - Create the states
 *
 * Then, in any order you want:
 * - Create actions if needed
 * - Link states using transitions
 * - Add the created actions to states
 * - Add the states to the fsm
 *
 * Finally, return the fsm.
 */
struct fsm *test_fsm2(void)
{
	struct fsm *fsm = new_fsm("Test FSM 2");

	/* States */

	struct async_state *st_a = new_async_state("Test state A2");
	add_state((union state *)st_a, fsm);

	struct async_state *st_b = new_async_state("Test state B2");
	add_state((union state *)st_b, fsm);

	struct async_state *st_end = new_async_state("End state 2");
	add_state((union state *)st_end, fsm);


	/* Actions */

	struct action *act_clean = new_action(cleanup, 0);
	add_action(act_clean, (union state *)st_end, ENTRY);

	/* Transitions */

	struct timed_transition *t_a_b = new_timed_transition(
		st_a, (union state *)st_b, 100000000, 0);
	if (!t_a_b)
		return 0;

	struct timed_transition *t_b_a = new_timed_transition(
		st_b, (union state *)st_a, 100000000, 0);
	if (!t_b_a)
		return 0;

	struct event_transition *t_a_end = new_event_transition(
		st_a, (union state *)st_end, transition_end_condition2, 0);
	if (!t_a_end)
		return 0;

	return fsm;
}

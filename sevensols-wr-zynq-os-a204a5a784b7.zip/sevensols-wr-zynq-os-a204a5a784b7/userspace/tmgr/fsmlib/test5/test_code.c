#include "fsmlib.h"
#include <stdio.h>

/***** FSM 1 application code and data *****/

/* fsm2 is declared and created elsewhere. */
extern struct fsm *fsm2;


/* Checker function for state B of FSM 1 */
/* <args> is a pointer to the <struct transition> */
void *transition_test_fun(void *args)
{
	run(fsm2, SYNC);

	notify_event(args);

	return 0;
}

/* Checks end condition for FSM 1 */
/* <args> is a pointer to the <struct transition> */
void *transition_end_condition(void *args)
{
	static int cycles;

	if (++cycles >= 10) {
		notify_event(args);
	}

	return 0;
}



/***** FSM 2 application code and data *****/

/* Number of times that FSM2 has looped. */
static int cycles2;

/* Resets the cycles counter to 0 */
void cleanup(void *args)
{
	cycles2 = 0;
}


/* Checks end condition for FSM 2 */
/* <args> is a pointer to the <struct transition> */
void *transition_end_condition2(void *args)
{
	if (++cycles2 >= 10) {
		notify_event(args);
	}

	return 0;
}

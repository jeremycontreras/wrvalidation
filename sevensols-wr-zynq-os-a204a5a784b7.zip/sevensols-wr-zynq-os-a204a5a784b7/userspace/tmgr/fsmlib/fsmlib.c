#include "fsmlib.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*
 * fsmlib.c
 *
 * FSM library.
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 17, 2019
 *
 * Last updated: Aug 30, 2019
 */

/*
 * TODO
 * ====
 *
 * - [DONE] Once a transition has been done, cancel the rest of pending
 *   transitions coming from the source state. For instance, if a state has to
 *   outgoing transitions: A (timed) and B (event-triggered) and B is taken,
 *   cancel A's timeout.
 *
 * - [DONE] Implement a stop condition ==> a state with no outgoing transitions
 *   is an end state. Stop the FSM after running this state actions.
 *
 * - [DONE] Multiple independent FSMs.
 *
 * - [DONE] Support asynchronous states (event-triggered and time-triggered) as
 *   well as synchronous ones.
 *
 * - [DONE] Improve API for action and transition creation. Make fields opaque
 *   to the client code.
 *
 * - Create some macros to make all the union castings easier on the eyes.
 *
 * - Debug traces and utils.
 *
 * - More throrough documentation.
 *
 * - Double-check all error conditions.
 *
 * - Remove unnecessary variables.
 *
 * - Implement both types of transitions as event-triggered transitions.
 *
 * - Notify the main thread that the FSM thread is ready?
 */

/************************************************************
 * Global library-wide variables                            *
 ************************************************************/

/* [TODO] Not really necessary, we can remove them. */
/* Global IDs for internal library use */
static int global_state_ids;
static int global_action_ids;
//static int global_transition_ids;

/* Thread attributes for detached threads. */
static pthread_attr_t attr;
/* 1 if attr is initialized, 0 otherwise. */
static int attr_isset;


/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Busy-waits for permission from the event loop to send notifications.
 *
 * Parameters:
 *   fsm: the FSM to wait for.
 *
 * NOTE: This function is very unlikely to run.
 */
static inline void wait_event_loop_ready(struct fsm *fsm)
{
	/* Wait for fsm->ready_for_notifications to be set */
	while (!__atomic_load_n(&fsm->ready_for_notifications, __ATOMIC_SEQ_CST))
		continue;
}

/*
 * Sets a value in the "ready_for_notifications" flag of a FSM.
 * 0 -> not ready
 * 1 -> ready.
 *
 * Parameters:
 *   fsm:   the FSM to change.
 *   ready: the value to set in the flag.
 */
static inline void set_event_loop_ready(struct fsm *fsm, int ready)
{
	__atomic_store_n(&fsm->ready_for_notifications, ready, __ATOMIC_SEQ_CST);
}


/*
 * This callback will be automatically called by the system when the timer of a
 * timed-triggered transition expires.
 *
 * It notifies the FSM event loop using the FSM monitor and saves itself in
 * fsm->triggered.
 *
 * Parameters:
 *   sv: union sigval that contains the triggered transition in its sival_ptr
 *       field
 */
static void notify_timed_event(union sigval sv)
{
	struct timed_transition *t = sv.sival_ptr;
	struct async_state *s = &t->src->as;
	pthread_mutex_t *mutex = &s->fsm->mutex;
	pthread_cond_t *cond = &s->fsm->cond;

	/* Wait for the event loop to accept notifications */
	wait_event_loop_ready(s->fsm);

	/* Send trigger notification */
	pthread_mutex_lock(mutex);
	if (!s->fsm->triggered) {
		s->fsm->triggered = (union transition *)t;
		pthread_cond_signal(cond);
	}
	pthread_mutex_unlock(mutex);
}

/*
 * Starts the timer associated to the time-triggered transition <t>.
 *
 * Parameters:
 *   t: the time-triggered transition that owns the timer.
 *
 * Returns:
 *   0 if the timer could be armed.
 *   1 otherwise.
 */
static int init_timed_transition(struct timed_transition *t)
{
	if (timer_settime(t->timer, 0, &t->timerspec, NULL) < 0)
		return 1;

	return 0;
}


/*
 * Starts the thread associated to the event-triggered transition <t>.
 *
 * The thread will run the function pointed by <t->check> with <t> as its
 * argument.
 *
 * Parameters:
 *   t: the event-triggered transition that owns the thread.
 *
 * Returns:
 *   0 if the thread could be started.
 *   1 otherwise.
 */
static int init_event_transition(struct event_transition *t)
{
	if (pthread_create(&t->thread, 0, t->check, t))
		return 1;

	return 0;
}


/*
 * Waits (blocks) until any of the running asynchronous transitions notifies
 * that it has been triggered.
 *
 * This function will run only when the current active state is an asynchronous
 * state. When this is called, all the outgoing transitions of that state
 * (time-triggered and event-triggered) must be already created, initialized and
 * running (ie. waiting for events).
 *
 * The FSM event loop thread blocks here on the FSM monitor and the
 * notifications are done by signaling it (see notify_timed_event and
 * notify_event).
 *
 * By the time the monitor is signaled, fsm->triggered must point to the
 * transition that was triggered.
 *
 * Parameters:
 *   s: The current running asynchronous state.
 *
 * Returns:
 *   The transition that was triggered.
 */
static union transition *wait_for_transition(struct async_state *s)
{
	union transition *t;
	pthread_mutex_t *mutex = &s->fsm->mutex;
	pthread_cond_t *cond = &s->fsm->cond;

	pthread_mutex_lock(mutex);

	/* Allow transition threads to send notifications. */
	set_event_loop_ready(s->fsm, 1);

	while (!s->fsm->triggered)
		pthread_cond_wait(cond, mutex);

	t = s->fsm->triggered;

	pthread_mutex_unlock(mutex);

	return t;
}

/*
 * Clears the <triggered> and <ready_for_notifications> flags (sets the event
 * loop as NOT READY so that transition threads won't send it notifications).
 *
 * NOTE: Flags are reset here and set in <wait_for_transition>.
 *
 * Parameters:
 *   fsm: The running FSM.
 */
static void init_async_run_flags(struct fsm *fsm)
{
	pthread_mutex_t *mutex = &fsm->mutex;

	pthread_mutex_lock(mutex);
	fsm->triggered = 0;
	pthread_mutex_unlock(mutex);

	/*
	 * Prevent the transition threads from sending notifications until the
	 * event loop is ready.
	 */
	set_event_loop_ready(fsm, 0);
}

static void run_action(struct action *a)
{
	if (a->fun) {
		a->fun(a->args);
	}
}

static void free_timed_transition(struct timed_transition *t)
{
	if (!t)
		return;

	timer_delete(t->timer);
	free(t);
}

static void free_action(struct action *a)
{
	if (!a)
		return;

	free(a);
}

static void free_event_transition(struct event_transition *t)
{
	if (!t)
		return;

	free(t);
}

static void free_sync_transition(struct sync_transition *t)
{
	if (!t)
		return;

	free(t);
}

/*
 * De-allocates state <s> as well as its associated actions and transitions.
 *
 * NOTE: If any of the actions is used by more than one state, the result of
 * freeing them is undefined.
 *
 * Parameters:
 *   s: the state to free.
 *
 * Returns:
 *   0 if <s> is not null
 *   1 if <s> is a null pointer
 */
static int free_state(union state *s)
{
	int i;

	if (!s)
		return 1;

	free(s->as.name);

	for (i = 0; i < s->as.num_entry_actions; i++) {
		free_action(s->as.entry_action[i]);
	}
	for (i = 0; i < s->as.num_exit_actions; i++) {
		free_action(s->as.exit_action[i]);
	}

	if (s->as.type == ASYNC) {
		if (s->as.t_trans) {
			free_timed_transition(s->as.t_trans);
		}
		for (i = 0; i < s->as.num_e_trans; i++) {
			free_event_transition(s->as.e_trans[i]);
		}
	} else {
		for (i = 0; i < s->ss.num_s_trans; i++) {
			free_sync_transition(s->ss.s_trans[i]);
		}
	}
	free(s);

	return 0;
}

/*
 * Disarms the timer of transition <t>.
 *
 * Parameters:
 *   t: the timed_transition that owns the timer.
 *
 * Returns:
 *   0 if the timer could be disarmed.
 *   -1 otherwise.
 */
static int disable_timed_transition(struct timed_transition *t)
{
	struct itimerspec ts;

	memset(&ts, 0, sizeof(ts));
	return timer_settime(t->timer, 0, &ts, 0);
}

/*
 * Stops the thread of the event-triggered transition <t>.
 *
 * Parameters:
 *   t: The event_transition that owns the thread
 *
 * Returns:
 *   0    if the thread could be cancelled
 *   != 0 otherwise
 */
static int disable_event_transition(struct event_transition *t)
{
	pthread_mutex_t *mutex = &t->src->as.fsm->mutex;
	void *res;

	/*
	 * Make sure that the cancelled thread will NOT leave the mutex in a
	 * locked state.
	 */
	pthread_mutex_lock(mutex);
	pthread_cancel(t->thread);
	pthread_mutex_unlock(mutex);

	/* Wait for it to be cleanly stopped. */
	return pthread_join(t->thread, &res);

	/* DEBUG ONLY
	if (res == PTHREAD_CANCELED)
		printf("Thread canceled\n");
	else
		printf("Thread was NOT canceled\n");
	*/
}

/*
 * Returns 1 if state <s> is an end state. 0 otherwise.
 */
static int end_state(union state *s)
{
	if (s->as.type == ASYNC) {
		if (!s->as.t_trans && s->as.num_e_trans == 0) {
			return 1;
		}
	} else {
		if (s->ss.num_s_trans == 0) {
			return 1;
		}
	}

	return 0;
}


/*
 * Initializes the transitions of an asynchronous state and waits for any of
 * them to be triggered.
 *
 * Parameters:
 *   s: The current state (the state to run)
 *
 * Returns:
 *   The transition that was triggered.
 */
static union transition * run_async_state(struct async_state *s)
{
	struct fsm *fsm = s->fsm;
	union transition *t;
	int i;

	/*
	 * Prepare the FSM for running an asynchronous state (clear flags).
	 * No transitions should be running at this point.
	 */
	init_async_run_flags(fsm);

	/* Initialize transitions (start timers and threads) */
	if (s->t_trans) {
		if (init_timed_transition(s->t_trans)) {
			printf("init_timed_transition failed\n");
			return 0;
		}
	}
	for (i = 0; i < s->num_e_trans; i++) {
		if (init_event_transition(s->e_trans[i])) {
			printf("init_event_transition failed\n");
			return 0;
		}
	}

	/*
	 * This is a blocking call. It should return when a transition is
	 * triggered, and that transition is returned.
	 */
	t = wait_for_transition(s);

	/* Disable all pending events and timers */
	if (s->t_trans) {
		disable_timed_transition(s->t_trans);
	}
	for (i = 0; i < s->num_e_trans; i++) {
		disable_event_transition(s->e_trans[i]);
	}

	return t;
}


/*
 * Runs the function of a synchronous state (if it's defined) and then checks
 * all of its outgoing transitions to see if any of them matches its condition
 * to be triggered.
 *
 * Note that the transitions are checked sequentially so, in case that more than
 * one matches their trigger conditions, the first one in the sequence to do so
 * is the one that will be triggered.
 *
 * Parameters:
 *   s: The current state (the state to run)
 *
 * Returns:
 *   The first transition that was triggered.
 */
static union transition * run_sync_state(struct sync_state *s)
{
	//struct fsm *fsm = s->fsm;
	union transition *t = 0;
	int i;
	void *args = 0;

	/*
	 * Run the state function. Once it finishes, run all the outgoing
	 * transition checks passing them the value returned by the state
	 * function.
	 *
	 * If none of the transitions meet their trigger condition, the loop is
	 * repeated. The cleanup function, if defined, is called after every
	 * iteration.
	 *
	 * Return the first transition that passed its check.
	 */
	while (!t) {
		if (s->fun) {
			args = s->fun(s->funargs);
		}

		for (i = 0; i < s->num_s_trans; i++) {
			if (s->s_trans[i]->check(args)) {
				t = (union transition*)(s->s_trans[i]);
				break;
			}
		}

		if (s->cleanup) {
			s->cleanup(args);
		}
	}

	return t;
}


/*
 * Entry point of a FSM control flow.
 *
 * Parameters:
 *   args: The FSM to run.
 *
 * Returns:
 *   0
 */
static void *fsm_loop(void *args)
{
	struct fsm *fsm = args;
	int i;
	union transition *t;
	union state *s = fsm->states;

	/*
	 * Event loop:
	 *   - Run all the defined ENTRY actions in sequence.
	 *   - Wait for a transition to occur.
	 *   - Once a transition is triggered, run its action if defined.
	 *   - Run all the defined EXIT actions in sequence.
	 *   - Move to the next state through the triggered transition.
	 *
	 *   Repeat until it reaches an end state.
	 */
	while (s) {
		/* Run entry actions */
		for (i = 0; i < s->as.num_entry_actions; i++) {
			run_action(s->as.entry_action[i]);
		}

		/* Stop FSM if the current state is an end state */
		if (end_state(s)) {
			break;
		}

		/* Wait for transitions */
		if (s->as.type == ASYNC) {
			t = run_async_state(&s->as);
		} else {
			t = run_sync_state(&s->ss);
		}

		/* Run transition actions if defined */
		if (t->et.action) {
			t->et.action();
		}

		/* Run exit actions */
		for (i = 0; i < s->as.num_exit_actions; i++) {
			run_action(s->as.exit_action[i]);
		}

		/* Go to next state */
		s = t->tt.dst;
	}

	fsm->running = 0;
	return 0;
}


/************************************************************
 * Public API                                               *
 ************************************************************/


void notify_event(struct event_transition *t)
{
	struct async_state *s = &t->src->as;
	pthread_mutex_t *mutex = &s->fsm->mutex;
	pthread_cond_t *cond = &s->fsm->cond;
	int oldstate;

	/* Wait for the event loop to accept notifications */
	wait_event_loop_ready(s->fsm);

	/*
	 * Disable cancel state to avoid leaving a locked mutex if the thread is
	 * cancelled before it unlocks it. Set a cancellation point before the
	 * critical section.
	 */
	pthread_testcancel();
	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldstate);

	/* Send trigger notification */
	pthread_mutex_lock(mutex);
	if (!s->fsm->triggered) {
		s->fsm->triggered = (union transition *)t;
		pthread_cond_signal(cond);
	}
	pthread_mutex_unlock(mutex);

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &oldstate);
}

struct fsm *new_fsm(char *name)
{
	struct fsm *fsm = calloc(1, sizeof(struct fsm));

	if (!fsm)
		return 0;

	fsm->name = strdup(name);
	if (pthread_mutex_init(&fsm->mutex, 0)) {
		free(fsm->name);
		free(fsm);
		return 0;
	}
	if (pthread_cond_init(&fsm->cond, 0)) {
		pthread_mutex_destroy(&fsm->mutex);
		free(fsm->name);
		free(fsm);
		return 0;
	}

	/*
	 * Initialize a pthread_attr_t to be used by all detached threads from
	 * now on.
	 */
	if (!attr_isset) {
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		attr_isset = 1;
	}

	return fsm;
}

int free_fsm(struct fsm *fsm)
{
	/*
	 * NOTE [TODO]: Make sure the mutex is not locked, the condition
	 * variable has no threads waiting and the timers are stopped.
	 */
	union state *st = fsm->states;

	if (fsm->running)
		return 1;

	/* Free all the states */
	while (st) {
		union state *next = st->as.next;
		free_state(st);
		st = next;
	}
	fsm->states = 0;

	if (pthread_mutex_destroy(&fsm->mutex))
		return 1;
	if (pthread_cond_destroy(&fsm->cond))
		return 1;

	free(fsm->name);
	free(fsm);

	return 0;
}

struct async_state *new_async_state(char *name)
{
	struct async_state *s = calloc(1, sizeof(struct async_state));

	if (!s)
		return 0;

	s->type = ASYNC;
	s->name = strdup(name);

	if (!s->name) {
		free(s);
		return 0;
	}

	s->id = global_state_ids++;

	return s;
}

struct sync_state *new_sync_state(char *name, void * (*fun)(void *),
				void *args, void (*cleanup)(void *))
{
	struct sync_state *s = calloc(1, sizeof(struct sync_state));

	if (!s)
		return 0;

	s->type = SYNC;
	s->name = strdup(name);

	if (!s->name) {
		free(s);
		return 0;
	}

	s->fun = fun;
	s->funargs = args;
	s->cleanup = cleanup;

	s->id = global_state_ids++;

	return s;
}

struct action *new_action(void (*fun)(void *), void *args)
{
	struct action *a;

	if (!fun) {
		printf("Error: new_action needs a function as a parameter\n");
		return 0;
	}

	a = calloc(1, sizeof(struct action));

	if (!a)
		return 0;

	a->fun = fun;
	a->args = args;
	a->id = global_action_ids++;

	return a;
}

int add_action(struct action *a, union state *s, entry_exit_t entry_exit)
{
	switch (entry_exit) {
	case ENTRY:
		if (s->as.num_entry_actions >= MAX_ACTIONS)
			return 1;

		s->as.entry_action[s->as.num_entry_actions] = a;
		s->as.num_entry_actions++;
		break;
	case EXIT:
		if (s->as.num_exit_actions >= MAX_ACTIONS)
			return 1;

		s->as.exit_action[s->as.num_exit_actions] = a;
		s->as.num_exit_actions++;
		break;
	default:
		return 1;
	}

	return 0;
}

int add_state(union state *s, struct fsm *fsm)
{
	union state *sp;

	if (!fsm || !s)
		return 1;

	sp = fsm->states;
	if (sp) {
		/*
		 * fsm has at least one state already. Add this one to the end
		 * of the list.
		 */
		while(sp->as.next) {
			sp = sp->as.next;
		}
		sp->as.next = s;
	} else {
		/* No states in fsm. Set this one as the first in the list. */
		fsm->states = s;
	}

	s->as.fsm = fsm;

	return 0;
}

struct timed_transition *new_timed_transition(struct async_state *src,
					union state *dst,
					unsigned long timeout_ns,
					void * (*action)(void))
{
	struct timed_transition *t;

	if (!src || !dst || src->t_trans)
		return 0;

	t = calloc(1, sizeof(struct timed_transition));
	if (!t)
		return 0;

	/* Time-triggered transitions use thread-based timers */
	t->sev.sigev_notify = SIGEV_THREAD;
	t->sev.sigev_notify_function = notify_timed_event;
	t->sev.sigev_notify_attributes = &attr;
	t->sev.sigev_value.sival_ptr = t;

	if (timer_create(CLOCK_MONOTONIC_RAW, &t->sev, &t->timer) < 0) {
		free(t);
		return 0;
	}
	/* Link the transition to its source and destination states */
	t->src = (union state *)src;
	t->dst = dst;

	t->action = action;
	t->timerspec.it_value.tv_sec = timeout_ns / 1000000000;
	t->timerspec.it_value.tv_nsec = timeout_ns % 1000000000;

	src->t_trans = t;

	return t;
}

struct event_transition *new_event_transition(struct async_state *src,
					union state *dst,
					void * (*check)(void *),
					void * (*action)(void))
{
	struct event_transition *t;

	if (!src || !dst || !check || src->num_e_trans >= MAX_EVENT_TRANSITIONS)
		return 0;

	t = calloc(1, sizeof(struct event_transition));
	if (!t)
		return 0;

	/* Link the transition to its source and destination states */
	t->src = (union state *)src;
	t->dst = dst;

	t->check = check;
	t->action = action;;

	src->e_trans[src->num_e_trans] = t;
	src->num_e_trans++;

	return t;
}

struct sync_transition *new_sync_transition(struct sync_state *src,
					union state *dst,
					int (*check)(void *),
					void * (*action)(void))
{
	struct sync_transition *t;

	if (!src || !dst || src->num_s_trans >= MAX_EVENT_TRANSITIONS)
		return 0;

	t = calloc(1, sizeof(struct sync_transition));
	if (!t)
		return 0;

	/* Link the transition to its source and destination states */
	t->src = (union state *)src;
	t->dst = dst;

	t->check = check;
	t->action = action;

	src->s_trans[src->num_s_trans] = t;
	src->num_s_trans++;

	return t;
}

void run(struct fsm *fsm, int mode)
{
	if (mode == SYNC) {
		/* Blocking call */
		fsm->running = 1;
		fsm_loop(fsm);
	} else {
		/*
		 * Start the event loop in its own thread.
		 */
		fsm->mode = 1;
		fsm->running = 1;
		pthread_create(&fsm->thread, 0, fsm_loop, fsm);
	}
}

void wait_for_fsm(struct fsm *fsm)
{
	if (fsm->mode && fsm->running)
		pthread_join(fsm->thread, 0);
}

#include "fsmlib.h"

/*
 * fsmdef2.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 17, 2019
 */

/*
 * Test FSM 2
 *
 * A FSM that checks a condition every 0.1 secs. It finishes after checking it
 * 10000 times.
 *
 * Implementation:
 *
 *   - Two states: State A and End state. Neither perform any actions.
 *   - State A has a timed transition to itself, triggered every 0.1 seconds.
 *   - State A has an event transition to the End state. It checks if a counter
 *     has reached a certain value (10000). If not, it increments the counter.
 */

static void *transition_end_condition(void *args)
{
	static int times;

	if (++times >= 10000)
		notify_event(args);

	return 0;
}

struct fsm *create_fsm2(void)
{
	struct fsm *fsm = new_fsm("Test FSM 2");

	/* Create states and actions */
	struct async_state *st_a = new_async_state("Test state A");
	struct async_state *st_end = new_async_state("End state");

	/* Create and program transitions */
	struct timed_transition *t_a_a = new_timed_transition(
		st_a, (union state*)st_a, 10000000, 0);
	if (!t_a_a)
		return 0;
	struct event_transition *t_a_end = new_event_transition(
		st_a, (union state*)st_end, transition_end_condition, 0);
	if (!t_a_end)
		return 0;

	add_state((union state*)st_a, fsm);
	add_state((union state*)st_end, fsm);

	return fsm;
}

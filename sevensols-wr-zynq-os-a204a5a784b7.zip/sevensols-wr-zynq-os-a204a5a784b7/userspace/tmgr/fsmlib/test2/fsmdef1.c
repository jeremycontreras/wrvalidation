#include "fsmlib.h"
#include <stdio.h>
#include <time.h>

/*
 * fsmdef1.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 17, 2019
 */

/*
 * Test FSM 1
 *
 * A FSM that mixes time-triggered transitions and event-triggered transitions
 * in multiple ways. This is useful to test that after transitioning to a new
 * state all pending transitions are stopped.
 *
 * Implementation:
 *
 *   - Four states: A, B, C and End state.
 *
 *    _______________
 *   |               |
 *   v               |
 *   A ----> B ----> C
 *   |
 *   |
 *   v
 *   End
 *
 *   - <A> transitions to B using a time-triggered transition and two
 *     event-triggered transitions. The event-triggered transitions, in turn,
 *     implement time-triggered transitions using nanosleep.
 *
 *   - <A> transitions to the End state after being activated 100 times.
 */



/*
 * Example of a time-triggered transition implemented as an event-triggered
 * transition.
 */
/* <args> is a pointer to the <struct transition> */
static void *transition_test_fun(void *args)
{
	struct timespec ts;

	ts.tv_sec = 1;
	ts.tv_nsec = 0;
	nanosleep(&ts, 0);
	notify_event(args);

	return 0;
}

/*
 * Example of a time-triggered transition implemented as an event-triggered
 * transition.
 */
/* <args> is a pointer to the <struct transition> */
static void *transition_test_fun2(void *args)
{
	struct timespec ts;

	ts.tv_sec = 2;
	ts.tv_nsec = 0;
	nanosleep(&ts, 0);
	notify_event(args);

	return 0;
}

/* <args> is a pointer to the <struct transition> */
static void *transition_end_condition(void *args)
{
	static int times;

	if (++times >= 100) {
		notify_event(args);
	}

	return 0;
}

static void action1_fun(void *args)
{
	time_t t = time(0);
	FILE *f = fopen("./testout.txt", "a");

	if (!f)
		return;

	fprintf(f, "Action 1: %s\n", ctime(&t));
	fclose(f);
}

static void action2_fun(void *args)
{
	time_t t = time(0);
	FILE *f = fopen("./testout.txt", "a");

	if (!f)
		return;

	fprintf(f, "Action 2: %s\n", ctime(&t));
	fclose(f);
}

static void action3_fun(void *args)
{
	time_t t = time(0);
	FILE *f = fopen("./testout.txt", "a");

	if (!f)
		return;

	fprintf(f, "Action 3: %s\n", ctime(&t));
	fclose(f);
}

/*
 * Creates and returns the state machine.
 *
 * 1 - Create a new fsm
 * 2 - Create the states
 *
 * Then, in any order you want:
 * - Create actions if needed
 * - Link states using transitions
 * - Add the created actions to states
 * - Add the states to the fsm
 *
 * Finally, return the fsm.
 */
struct fsm *create_fsm1(void)
{
	struct fsm *fsm = new_fsm("Test FSM 1");

	/* Create states and actions */
	struct async_state *st_a = new_async_state("Test state A");
	struct async_state *st_b = new_async_state("Test state B");
	struct async_state *st_c = new_async_state("Test state C");
	struct async_state *st_end = new_async_state("End state");
	struct action *act_1 = new_action(action1_fun, 0);
	struct action *act_2 = new_action(action2_fun, 0);
	struct action *act_3 = new_action(action3_fun, 0);

	/* Create and program transitions */

	/* Timed transition from st_a to st_b, 0.2 secs timeout. */
	struct timed_transition *t_a_b = new_timed_transition(
		st_a, (union state *)st_b, 200000000, 0);
	if (!t_a_b)
		return 0;

	/*
	 * Event transition from st_a to st_b. The trigger condition is checked
	 * by <transition_test_fun>.
	 */
	struct event_transition *t_a_b_2 = new_event_transition(
		st_a, (union state *)st_b, transition_test_fun, 0);
	if (!t_a_b_2)
		return 0;

	/*
	 * Event transition from st_a to st_b. The trigger condition is checked
	 * by <transition_test_fun2>.
	 */
	struct event_transition *t_a_b_3 = new_event_transition(
		st_a, (union state *)st_b, transition_test_fun2, 0);
	if (!t_a_b_3)
		return 0;

	/*
	 * Event transition from st_b to st_c. The trigger condition is checked
	 * by <transition_test_fun>.
	 */
	struct event_transition *t_b_c = new_event_transition(
		st_b, (union state *)st_c, transition_test_fun, 0);
	if (!t_b_c)
		return 0;

	/* Timed transition from st_c to st_a, 0.1 secs timeout. */
	struct timed_transition *t_c_a = new_timed_transition(
		st_c, (union state *)st_a, 100000000, 0);
	if (!t_c_a)
		return 0;

	/*
	 * Event transition from st_a to st_end. The trigger condition is
	 * checked by <transition_end_condition>.
	 */
	struct event_transition *t_a_end = new_event_transition(
		st_a, (union state *)st_end, transition_end_condition, 0);
	if (!t_a_end)
		return 0;

	/* Add actions to states */
	add_action(act_1, (union state *)st_a, ENTRY);
	add_action(act_2, (union state *)st_b, EXIT);
	add_action(act_3, (union state *)st_c, ENTRY);

	/*
	 * Add states to the fsm. The first state added will be the initial
	 * state.
	 */
	add_state((union state *)st_a, fsm);
	add_state((union state *)st_b, fsm);
	add_state((union state *)st_c, fsm);
	add_state((union state *)st_end, fsm);

	return fsm;
}

#include "fsmlib.h"

/*
 * fsm_test.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 17, 2019
 */

/*
 * Simple example of a program running two FSMs concurrently.
 */

/* The FSMs are defined elsewhere (see fsmdef1.c and fsmdef2.c) */
extern struct fsm *create_fsm1(void);
extern struct fsm *create_fsm2(void);

int main(void)
{
	struct fsm *fsm1 = create_fsm1();
	struct fsm *fsm2 = create_fsm2();

	/*
	 * Run both state machines in ASYNC mode (concurrently) and wait for
	 * them to finish.
	 */
	if (fsm1)
		run(fsm1, ASYNC);

	if (fsm2)
		run(fsm2, ASYNC);

	wait_for_fsm(fsm1);
	free_fsm(fsm1);

	wait_for_fsm(fsm2);
	free_fsm(fsm2);

	return 0;
}

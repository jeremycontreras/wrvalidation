#include "fsmlib.h"

/*
 * A FSM with synchronous states that works with the same principle as a
 * lexer. Every state has an outgoing transition that is triggered depending on
 * some input. In this case the input data is taken from stdin.
 *
 * Implementation:
 *
 *  - Four states: A, B, C and End state.
 *
 *   _______________
 *  |               |
 *  v               |
 *  A ----> B ----> C
 *  |
 *  |
 *  v
 *  End
 *
 *  - <A> transitions to <B> when the string "a->b" is received.
 *
 *  - <B> transitions to <C> when the string "b->c" is received.
 *
 *  - <C> transitions to <A> when the string "c->a" is received.
 *
 *  - <A> transitions to the End state after being activated a number of times.
 */


/*
 * Code for actions and transitions is defined in test_code.c.
 */

extern void action1(void *args);
extern void action2(void *args);
extern void action3(void *args);

extern void *read_input(void *args);
extern void clean(void *args);

extern int a_to_b(void *args);
extern int b_to_c(void *args);
extern int c_to_a(void *args);
extern int transition_end_condition(void *args);


struct fsm *test_fsm(void)
{
	struct fsm *fsm = new_fsm("Test FSM");

	/* Actions */

	struct action *act_1 = new_action(action1, 0);
	struct action *act_2 = new_action(action2, 0);
	struct action *act_3 = new_action(action3, 0);

	/* States */

	/*
	 * Note that all these states use the same function for receiving data
	 * input. They also use a cleanup funcion (clean).
	 */
	struct sync_state *st_a = new_sync_state("Test state A",
						read_input, 0, clean);
	add_state((union state *)st_a, fsm);
	add_action(act_1, (union state *)st_a, ENTRY);

	struct sync_state *st_b = new_sync_state("Test state B",
						read_input, 0, clean);
	add_state((union state *)st_b, fsm);
	add_action(act_2, (union state *)st_b, ENTRY);

	struct sync_state *st_c = new_sync_state("Test state C",
						read_input, 0, clean);
	add_state((union state *)st_c, fsm);
	add_action(act_3, (union state *)st_c, ENTRY);

	/* The end state won't do anything. */
	struct sync_state *st_end = new_sync_state("End state", 0, 0, 0);
	add_state((union state *)st_end, fsm);


	/* Transitions */

	/*
	 * NOTE: In synchronous states, all the outgoing transitions are checked
	 * sequentially starting from the first one, so we want to put the most
	 * prioritary ones (an exit condition in this case) at the beginning to
	 * avoid them being "masked" by other transitions.
	 */
	struct sync_transition *t_a_end = new_sync_transition(
		st_a, (union state *)st_end, transition_end_condition, 0);
	if (!t_a_end)
		return 0;

	/*
	 * Each transition defines its own check function. These functions will
	 * receive the data returned by <read_input> as a parameter.
	 */
	struct sync_transition *t_a_b = new_sync_transition(
		st_a, (union state *)st_b, a_to_b, 0);
	if (!t_a_b)
		return 0;

	struct sync_transition *t_b_c = new_sync_transition(
		st_b, (union state *)st_c, b_to_c, 0);
	if (!t_b_c)
		return 0;

	struct sync_transition *t_c_a = new_sync_transition(
		st_c, (union state *)st_a, c_to_a, 0);
	if (!t_c_a)
		return 0;

	return fsm;
}

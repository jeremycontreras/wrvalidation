#include "fsmlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int times;

void action1(void *args)
{
	printf("action1\n");
	times++;
}

void action2(void *args)
{
	printf("action2\n");
}

void action3(void *args)
{
	printf("action3\n");
}


/*
 * Get input data. Depending on the data received a transition may be triggered.
 * In this case the input is taken from stdin.
 *
 * This function returns the buffer that will be passed to the <check> function
 * of every outgoing transition.
 * Note that this buffer is allocated by getline and must be freed at some
 * point. See the <clean> function below.
 */
void *read_input(void *args)
{
	char *buf = 0;
	size_t size;

	getline(&buf, &size, stdin);

	return buf;

}

/* Frees the buffer returned by <read_input> */
void clean(void *args)
{
	free(args);
}


/*
 * Synchronous transition <check> functions. They take the data returned by
 * <read_input> as a parameter.
 */


int a_to_b(void *args)
{
	char *str = args;

	if (strcmp(str, "a->b\n") == 0) {
		return 1;
	}

	return 0;
}

int b_to_c(void *args)
{
	char *str = args;

	if (strcmp(str, "b->c\n") == 0) {
		return 1;
	}

	return 0;
}

int c_to_a(void *args)
{
	char *str = args;

	if (strcmp(str, "c->a\n") == 0) {
		return 1;
	}

	return 0;
}

/*
 * Triggers a transition after running 3 times (<times> is incremented by
 * <action1> above).
 */
int transition_end_condition(void *args)
{
	if (times >= 3) {
		printf("end\n");
		return 1;
	}
	return 0;
}

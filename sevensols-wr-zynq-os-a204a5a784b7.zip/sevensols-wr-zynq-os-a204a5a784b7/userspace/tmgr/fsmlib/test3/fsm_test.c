#include "fsmlib.h"

/*
 * fsm_test.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 22, 2019
 */

extern struct fsm *test_fsm(void);

int main(void)
{
	struct fsm *fsm = test_fsm();

	if (!fsm)
		return 1;

	run(fsm, SYNC);
	/*
	 * wait_for_fsm won't wait in this case because the fsm will have
	 * already finished when <run> returns.
	 */
	wait_for_fsm(fsm);
	free_fsm(fsm);

	return 0;
}

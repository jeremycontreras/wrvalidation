#ifndef __FSMLIB_H__
#define __FSMLIB_H__

#include <signal.h>
#include <pthread.h>
#include <time.h>

/*
 * fsmlib.h
 *
 * FSM library.
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 17, 2019
 *
 * Last updated: May 20, 2019
 */

 /*
 *
 * Design goals and features:
 *
 *   - Small footprint.
 *   - Portable (POSIX-compatible).
 *   - Support for synchronous and asynchronous (event-triggered and
 *     time-triggered) state transitions.
 *   - Support for synchronous and asynchronous (threaded) FSMs.
 *   - Application agnostic.
 *
 * Limitations:
 *
 *   - Fixed number of transitions and actions per state.
 *   - This library is not intended to be used for real-time applications, so it
 *     offers no real-time guarantees (hard or soft).
 *
 *
 * FSM design:
 *
 * A FSM contains a set of states linked together through transitions in the
 * form of an oriented graph (where the states are the nodes and transitions are
 * the edges). Each state may have a set of input actions -- which are run when
 * the state starts running -- and a set of output actions -- which are run
 * before the state gives way to the next after a transition has been triggered.
 *
 * A state can be either synchronous or asynchronous, a synchronous state may
 * have only synchronous outgoing transitions and an ansynchronous state may
 * have only asynchronous outgoing transitions. They are implemented differently
 * and they work in a different way: an asynchronous state simply waits for any
 * of their outgoing transitions to be triggered by an external event or a
 * timeout. A synchronous state explicitly runs a function to collect data, wait
 * for an event or produce a result, and then every outgoing transition is
 * checked in sequence until one matches its trigger condition.
 *
 * Transitions can also be synchronous or asynchronous. Asynchronous transitions
 * are triggered automatically by an external event and are all waiting
 * concurrently to be triggered. There are two types of asynchronous
 * transitions: event-triggered and time-triggered. Event-triggered transitions
 * define a function that waits for a condition to be met, while time-triggered
 * transitions simply define a timeout after which the transition should be
 * taken.
 *
 * Synchronous transitions work similarly to event-triggered asynchronous
 * transitions except that they don't wait concurrently and are checked
 * sequentially after their source state reads/updates whatever input data may
 * trigger a transition.
 *
 * A FSM can also be run in synchronous mode (ie. the caller code is blocked
 * until the FSM ends) or in asynchronous/background mode (the caller keeps
 * running concurrently to the FSM).
 *
 * Implementation notes:
 *
 * - Asynchronous FSMs, states and transitions are pthread-based. This has some
 *   implications:
 *
 *     - There are no guarantees (in theory) that threads will run in a timely
 *       manner and no mechanism to ensure that thread-based timers (for
 *       time-triggered transitions) will run in the exact moment when the timer
 *       expires. In practice, this shouldn't be an issue, but see note [1].
 *
 *     - Client code that notifies transition changes must be thread-safe.
 *
 *
 * NOTES:
 *
 *   [1] Event-triggered transitions may be used to implement time-triggered
 *       transitions, so we could just use event-triggered transitions for
 *       everything and stop using threaded timers altogether, which make the
 *       implementation more complex.
 */


/************************************************************
 * Macros and typedefs                                      *
 ************************************************************/

#define MAX_EVENT_TRANSITIONS   10
#define MAX_ACTIONS             10

#define STATE(x) ((union state *)x)

/* Action type */
typedef enum {
	ENTRY,
	EXIT,
} entry_exit_t;

/* State type: Asynchronous/Synchronous */
typedef enum {
	ASYNC,
	SYNC,
} state_type_t;


/************************************************************
 * Datatypes                                                *
 ************************************************************/

/*
 * Action: a function that a state will run when it enters or exits its running
 * stage.
 */
struct action {
	int id;
	void (*fun)(void *);
	void (*args)(void *);
};

/*
 * Synchronous transition: Connects states <src> and <dst>. Runs <action> if
 * defined.
 *
 * The <check> function can take arbitrary parameters and should return != 0 if
 * the trigger condition is met, 0 otherwise.
 */
struct sync_transition {
	/* Common fields */
	union state *src;
	union state *dst;
	int (*check)(void *);
	void * (*action)(void);
};

/*
 * Asynchronous event-triggered transition: Connects states <src> and
 * <dst>. Runs <action> if defined.
 *
 * The <check> function takes a pointer to this transition as a parameter and
 * should call <notify_event> once the trigger condition is met.
 */
struct event_transition {
	/* Common fields */
	union state *src;
	union state *dst;
	void * (*check)(void *);
	void * (*action)(void);

	/* Class-specific fields */
	pthread_t thread;
};

/*
 * Asynchronous time-triggered transition: Connects states <src> and
 * <dst>. Runs <action> if defined.
 */
struct timed_transition {
	/* Common fields */
	union state *src;
	union state *dst;
	int (*check)(void *);
	void * (*action)(void);

	/* Class-specific fields */
	struct itimerspec timerspec;
	struct sigevent sev;
	timer_t timer;
};

union transition {
	struct sync_transition st;
	struct event_transition et;
	struct timed_transition tt;
};


/*
 * Asynchronous state
 */
struct async_state {
	/* Common fields */

	/* type should be ASYNC */
	state_type_t type;
	int id;
	char *name;
	//int active;

	struct action *entry_action[MAX_ACTIONS];
	int num_entry_actions;
	struct action *exit_action[MAX_ACTIONS];
	int num_exit_actions;

	struct fsm *fsm;
	/* Linked list implementation (for de-allocation purposes) */
	union state *next;

	/* Class-specific fields */

	struct timed_transition *t_trans;
	struct event_transition *e_trans[MAX_EVENT_TRANSITIONS];
	int num_e_trans;
};


/*
 * Synchronous state
 */
struct sync_state {
	/* Common fields */

	/* type should be SYNC */
	state_type_t type;
	int id;
	char *name;
	//int active;

	struct action *entry_action[MAX_ACTIONS];
	int num_entry_actions;
	struct action *exit_action[MAX_ACTIONS];
	int num_exit_actions;

	struct fsm *fsm;
	/* Linked list implementation (for de-allocation purposes) */
	union state *next;

	/* Class-specific fields */

	struct sync_transition *s_trans[MAX_EVENT_TRANSITIONS];
	int num_s_trans;

	/*
	 * This function should perform the necessary steps to collect data
	 * input, wait for events, etc. After it runs, the runtime checks the
	 * conditions of every outgoing transition sequentially (may be
	 * omitted).
	 * The return value of this function is passed as a parameter to the
	 * <check> function of every outgoing transition.
	 */
	void * (*fun)(void *);
	/* Parameters for <fun> */
	void *funargs;
	/*
	 * If defined, this function is run after checking the outgoing
	 * transitions for triggers. It's meant to cleanup and free the
	 * resources that may have been created in <fun> and it receives the
	 * data returned by <fun> as a parameter.
	 */
	void (*cleanup)(void *);
};

union state {
	struct async_state as;
	struct sync_state ss;
};

/*
 * FSM definition.
 *
 * Each FSM may run its event loop in its own thread.
 *
 * Each FSM defines a monitor to communicate/synchronize transitions. When an
 * asynchronous state is running, the FSM waits on the monitor for events and
 * the transitions signal the monitor to notify an event.
 * Synchronous states and transitions are run and queried sequentially.
 */
struct fsm {
	char *name;
	pthread_t thread;
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	/*
	 * Pointer to the asynchronous transition that was triggered. 0 if no
	 * transition has been triggered yet.
	 *
	 * This variable is shared across all asynchronous transitions and the
	 * event loop, so it must be protected from race conditions.
	 *
	 * NOTE: This is used in the event loop only when the current active
	 * state is asynchronous. It's not needed for synchronous states because
	 * the event loop doesn't need to wait for asynchronous notifications in
	 * that case.
	 */
	union transition *triggered;

	/*
	 * 0 -> The FSM is not accepting notifications from the transition
	 *      threads yet.
	 * 1 -> The FSM is ready to accept notifications.
	 */
	int ready_for_notifications;

	int mode;
	int running;

	/*
	 * Linked list of states. This list is only used to keep track of them
	 * so we can free them easily.
	 *
	 * NOTE: The first state in the list is the starting state.
	 */
	union state *states;

	/* [TODO] Unused fields. Decide if they're needed or not. */
	//struct state *current_state;
};


/************************************************************
 * Public API                                               *
 ************************************************************/


/*
 * Allocates and returns a new finite state machine with all its related data
 * structures properly initialized.
 *
 * Parameters:
 *   name: Name of the FSM.
 *
 * Returns:
 *   A pointer to the new fsm if everything is ok.
 *   0 if the fsm couldn't be created.
 */
struct fsm *new_fsm(char *name);


/*
 * Allocates and returns a new asynchronous state.
 *
 * Parameters:
 *   name: Name of the state.
 *
 * Returns:
 *   A pointer to the new state if everything is ok.
 *   0 if the state couldn't be created.
 */
struct async_state *new_async_state(char *name);


/*
 * Allocates and returns a new synchronous state.
 *
 * Parameters:
 *   name:     Name of the state.
 *   fun:      State function, 0 if no function needed.
 *   args:     Arguments to <fun>, 0 if no arguments needed.
 *   cleanup:  Cleanup function, 0 if no function needed.
 *
 * Returns:
 *   A pointer to the new state if everything is ok.
 *   0 if the state couldn't be created.
 */
struct sync_state *new_sync_state(char *name, void * (*fun)(void *),
				void *args, void (*cleanup)(void *));


/*
 * Allocates and returns a new action.
 *
 * Parameters:
 *   fun:  Action function.
 *   args: Arguments to <fun>, 0 if no arguments needed.
 *
 * Returns:
 *   A pointer to the new action if it could be created.
 *   0 otherwise.
 */
struct action *new_action(void (*fun)(void *), void *args);

/*
 * Allocates and returns a new Event-triggered transition and links it to the
 * <src> and <dst> states.
 *
 * Parameters:
 *   src:    Source state.
 *   dst:    Destination state.
 *   check:  Function to check the trigger condition.
 *   action: Function to run when the transition is triggered. 0 if no action
 *           needed.
 *
 * Returns:
 *   A pointer to the transition if it could be created.
 *   0 otherwise.
 */
struct event_transition *new_event_transition(struct async_state *src,
					union state *dst,
					void * (*check)(void *),
					void * (*action)(void));


/*
 * Allocates and returns a new Time-triggered transition and links it to the
 * <src> and <dst> states.
 *
 * Parameters:
 *   src:        Source state.
 *   dst:        Destination state.
 *   timeout_ns: Trigger timeout in nanoseconds.
 *   action:     Function to run when the transition is triggered. 0 if no
 *               action needed.
 *
 * Returns:
 *   A pointer to the transition if it could be created.
 *   0 otherwise.
 */
struct timed_transition *new_timed_transition(struct async_state *src,
					union state *dst,
					unsigned long timeout_ns,
					void * (*action)(void));


/*
 * Allocates and returns a new synchronous transition and links it to the <src>
 * and <dst> states.
 *
 * Parameters:
 *   src:    Source state.
 *   dst:    Destination state.
 *   check:  Function to check the trigger condition.
 *   action: Function to run when the transition is triggered. 0 if no action
 *           needed.
 *
 * Returns:
 *   A pointer to the transition if it could be created.
 *   0 otherwise.
 */
struct sync_transition *new_sync_transition(struct sync_state *src,
					union state *dst,
					int (*check)(void *),
					void * (*action)(void));



/*
 * Adds action <a> to state <s>.
 *
 * Parameters:
 *   a:          Action to add.
 *   s:          State to add the action to.
 *   entry_exit: Whether it is an ENTRY or EXIT action.
 *
 * Returns:
 *   0 if the action could be added to the state.
 *   1 otherwise.
 */
int add_action(struct action *a, union state *s, entry_exit_t entry_exit);


/*
 * Adds state <s> to <fsm>, appending it to the state list.
 * Note that the first state in the list will be the starting state.
 *
 * Parameters:
 *   s:   State to add.
 *   fsm: FSM to add the state to.
 *
 * Returns:
 *   0 if the state could be added to the FSM.
 *   1 otherwise.
 */
int add_state(union state *s, struct fsm *fsm);


/*
 * Triggers event-transition <t>. This function is meant to be called by the
 * <check> function of an asynchronous event-triggered transition when it
 * detects that the trigger condition is met.
 *
 * Parameters:
 *   t: Event transition to trigger.
 */
void notify_event(struct event_transition *t);


/*
 * Starts a FSM.
 *
 * Parameters:
 *   fsm:        The FSM to run.
 *   mode:       SYNC to run the FSM synchronously (blocking). ASYNC to run it
 *               asynchronously (threaded).
 */
void run(struct fsm *fsm, int mode);


/*
 * Frees the memory resources of <fsm> and its associated states, actions and
 * transitions.
 *
 * Parameters:
 *   fsm: The FSM to free.
 *
 * Returns:
 *   0 if all deallocations were ok.
 *   1 otherwise, or if <fsm> is still running.
 */
int free_fsm(struct fsm *fsm);

/*
 * If <fsm> is running in asynchronous (background) mode, block until it
 * finishes.
 *
 * Parameters:
 *   fsm: FSM to wait for.
 */
void wait_for_fsm(struct fsm *fsm);

#endif

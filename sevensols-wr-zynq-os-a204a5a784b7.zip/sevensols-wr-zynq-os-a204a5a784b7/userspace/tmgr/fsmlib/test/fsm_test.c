#include "fsmlib.h"

/*
 * fsm_test.c
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Created: Apr 22, 2019
 */

/*
 * Simple example of a program running a synchronous FSM.
 */

/* The FSM is defined elsewhere (see fsmdef.c) */
extern struct fsm *test_fsm(void);

int main(void)
{
	struct fsm *fsm = test_fsm();

	if (!fsm)
		return 1;

	/*
	 * Run the state machine synchronously (the <run> call will return when
	 * the FSM finishes).
	 */
	run(fsm, SYNC);
	free_fsm(fsm);

	return 0;
}

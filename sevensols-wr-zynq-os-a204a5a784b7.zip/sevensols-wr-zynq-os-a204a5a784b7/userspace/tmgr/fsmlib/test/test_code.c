#include "fsmlib.h"
#include <stdio.h>

void action1(void *args)
{
	printf("action1\n");
}

/* <args> is a pointer to the <struct transition> */
/* Triggers a transition after running 10 times */
void *transition_end_condition(void *args)
{
	static int times;

	if (++times >= 10) {
		notify_event(args);
	}

	return 0;
}

/*
 * ptpd.c
 *
 * ptpd gpa interface module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Nov 14, 2019
 * Last modified: Nov 25, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <libgpa.h>

#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "ptpd.h"
#include "utils.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define PTPD_MODULE_ID gpa_mod_wptpd

#define PTPD_MAX_PARAMS 400

#define MAX_RETRIES 5

#define PTPD_PORTS_ETH_IFACE_OID        2000
#define PTPD_PORTS_WR_IFACE_OID         5000
#define PTPD_PORTS_IFACE_REL_OID        100
#define PTPD_PORTS_CONFIG_REL_OID       10
#define PTPD_PORTS_INFO_REL_OID         10

enum ptpd_params_enum {
	/* Clock info paramteres */
	PTPD_CLKQ_CLKID,
	PTPD_CLKQ_CLASS,
	PTPD_CLKQ_ACCURACY,
	PTPD_CLKQ_VARIANCE,
	PTPD_CLKQ_PRIORITY1,
	PTPD_CLKQ_PRIORITY2,
	PTPD_TPROP_UTC_OFFSET,
	PTPD_TPROP_UTC_OFFSET_VALID,
	PTPD_TPROP_TIME_VALID,
	PTPD_TPROP_FREQ_VALID,

	N_PTPD_BASE_PARAMS
};

enum ptpd_port_params_enum {
	PTPD_PORT_MODE,
	PTPD_PORT_SYNCE,
	PTPD_PORT_RUN_STOP,
	PTPD_PORT_LINK_STATUS,
	PTPD_PORT_STATE,
	PTPD_PORT_CLOCK_STATE,
	PTPD_PORT_SERVO_STATE,
	PTPD_PORT_STATE_TRANSITIONS,
	PTPD_PORT_STATE_REASON,
	PTPD_PORT_SYNCE_STATE,

	PTPD_PORT_CLKQ_CLKID,
	PTPD_PORT_CLKQ_CLASS,
	PTPD_PORT_CLKQ_ACCURACY,
	PTPD_PORT_CLKQ_VARIANCE,
	PTPD_PORT_CLKQ_PRIORITY1,
	PTPD_PORT_CLKQ_PRIORITY2,
	PTPD_PORT_CLKQ_N_HOPS,
	PTPD_PORT_TPROP_TIME_SOURCE,
	PTPD_PORT_TPROP_UTC_OFFSET,
	PTPD_PORT_TPROP_UTC_OFFSET_VALID,
	PTPD_PORT_TPROP_TIME_VALID,
	PTPD_PORT_TPROP_FREQ_VALID,
	PTPD_PORT_TPROP_PTP_TSCALE,

	N_PTPD_PORT_PARAMS
};

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;

static int nports;
static char port_names[MAX_PORTS][MAX_STR_LEN];

static struct param_def ptpd_params[PTPD_MAX_PARAMS] = {

	/* Clock info parameters */
	[PTPD_CLKQ_CLKID]               = {.key = "act/clkinfo/Q/clock_identity",
					   .modir_oid = 520, .prm_oid = 1},
	[PTPD_CLKQ_PRIORITY1]           = {.key = "act/clkinfo/Q/priority1",
					   .modir_oid = 520, .prm_oid = 2},
	[PTPD_CLKQ_PRIORITY2]           = {.key = "act/clkinfo/Q/priority2",
					   .modir_oid = 520, .prm_oid = 3},
	[PTPD_CLKQ_CLASS]               = {.key = "act/clkinfo/Q/clock_class",
					   .modir_oid = 520, .prm_oid = 10},
	[PTPD_CLKQ_ACCURACY]            = {.key = "act/clkinfo/Q/clock_accuracy",
					   .modir_oid = 520, .prm_oid = 11},
	[PTPD_CLKQ_VARIANCE]            = {.key = "act/clkinfo/Q/variance",
					   .modir_oid = 520, .prm_oid = 12},

	[PTPD_TPROP_UTC_OFFSET]         = {.key = "act/clkinfo/tprop/utc_offset",
					   .modir_oid = 530, .prm_oid = 2},
	[PTPD_TPROP_TIME_VALID]         = {.key = "act/clkinfo/tprop/time_valid",
					   .modir_oid = 530, .prm_oid = 10},
	[PTPD_TPROP_FREQ_VALID]         = {.key = "act/clkinfo/tprop/freq_valid",
					   .modir_oid = 530, .prm_oid = 11},
	[PTPD_TPROP_UTC_OFFSET_VALID]   = {.key = "act/clkinfo/tprop/utc_off_val",
					   .modir_oid = 530, .prm_oid = 12},
};

/*
 * The modir oid of port params is calculated dynamically from the port number
 * and the .modir_oid field in these definitions (see the <get_port_param_modir>
 * function in this file).
 */
static struct param_def port_params_structure[] = {
	[PTPD_PORT_RUN_STOP]               = {.key = "1/wproc/run_stop",
					      .modir_oid = 1, .prm_oid = 5},
	[PTPD_PORT_MODE]                   = {.key = "1/cfg/mode",
					      .modir_oid = 3, .prm_oid = 7},
	[PTPD_PORT_SYNCE]                  = {.key = "1/cfg/synce",
					      .modir_oid = 3, .prm_oid = 56},
	[PTPD_PORT_LINK_STATUS]             = {.key = "1/info/link_status",
	                                      .modir_oid = 2, .prm_oid = 61},
	[PTPD_PORT_STATE]                  = {.key = "1/info/port_state",
					      .modir_oid = 2, .prm_oid = 2},
	[PTPD_PORT_CLOCK_STATE]            = {.key = "1/info/clock_state",
					      .modir_oid = 2, .prm_oid = 3},
	[PTPD_PORT_SERVO_STATE]            = {.key = "1/info/servo_state",
					      .modir_oid = 2, .prm_oid = 4},
	[PTPD_PORT_STATE_TRANSITIONS]      = {.key = "1/info/state_transitions",
					      .modir_oid = 2, .prm_oid = 5},
	[PTPD_PORT_STATE_REASON]           = {.key = "1/info/state_reason",
					      .modir_oid = 2, .prm_oid = 6},
	[PTPD_PORT_SYNCE_STATE]            = {.key = "1/info/synce_state",
					      .modir_oid = 2, .prm_oid = 57},

	[PTPD_PORT_CLKQ_CLKID]             = {.key = "1/clkinfo/Q/clock_identity",
					      .modir_oid = 5, .prm_oid = 1},
	[PTPD_PORT_CLKQ_PRIORITY1]         = {.key = "1/clkinfo/Q/priority1",
					      .modir_oid = 5, .prm_oid = 2},
	[PTPD_PORT_CLKQ_PRIORITY2]         = {.key = "1/clkinfo/Q/priority2",
					      .modir_oid = 5, .prm_oid = 3},
	[PTPD_PORT_CLKQ_CLASS]             = {.key = "1/clkinfo/Q/clock_class",
					      .modir_oid = 5, .prm_oid = 10},
	[PTPD_PORT_CLKQ_ACCURACY]          = {.key = "1/clkinfo/Q/clock_accuracy",
					      .modir_oid = 5, .prm_oid = 11},
	[PTPD_PORT_CLKQ_VARIANCE]          = {.key = "1/clkinfo/Q/variance",
					      .modir_oid = 5, .prm_oid = 12},
	[PTPD_PORT_CLKQ_N_HOPS]             = {.key = "1/clkinfo/Q/n_hops",
					      .modir_oid = 5, .prm_oid = 20},

	[PTPD_PORT_TPROP_TIME_SOURCE]      = {.key = "1/clkinfo/tprop/time_source",
					      .modir_oid = 6, .prm_oid = 1},
	[PTPD_PORT_TPROP_UTC_OFFSET]       = {.key = "1/clkinfo/tprop/utc_offset",
					      .modir_oid = 6, .prm_oid = 2},
	[PTPD_PORT_TPROP_PTP_TSCALE]       = {.key = "1/clkinfo/tprop/ptp_tscale",
					      .modir_oid = 6, .prm_oid = 3},
	[PTPD_PORT_TPROP_TIME_VALID]       = {.key = "1/clkinfo/tprop/time_valid",
					      .modir_oid = 6, .prm_oid = 10},
	[PTPD_PORT_TPROP_FREQ_VALID]       = {.key = "1/clkinfo/tprop/freq_valid",
					      .modir_oid = 6, .prm_oid = 11},
	[PTPD_PORT_TPROP_UTC_OFFSET_VALID] = {.key = "1/clkinfo/tprop/utc_off_val",
					      .modir_oid = 6, .prm_oid = 12},
};

static struct gpa_mod *ptpd_mod;

/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Returns the modir oid of parameter <param> for port <port>.
 */
static int get_port_param_modir(int port, int param)
{
	char *port_name;
	int port_oid_base;

	if (get_port_iface_name(port, &port_name))
		return 1;

	if (strstr(port_name, "wr")) {
		port_oid_base = PTPD_PORTS_WR_IFACE_OID;
	} else if (strstr(port_name, "eth")) {
		port_oid_base = PTPD_PORTS_ETH_IFACE_OID;
	} else {
		pr_error("Error getting parameter modir for "
			"interface %s\n", port_name);
		return 1;
	}

	return port_oid_base
		+ PTPD_PORTS_IFACE_REL_OID * port
		+ PTPD_PORTS_CONFIG_REL_OID
		+ port_params_structure[param].modir_oid;
}

/*
 * Returns the absolute index (in the ptpd_params array) of a port parameter.
 *
 * Parameters:
 *   - port:  Port number
 *   - param: Parameter index in the port_params_structure array
 */
static int ptpd_get_port_param_idx(int port, int param)
{
	return N_PTPD_BASE_PARAMS + (N_PTPD_PORT_PARAMS * port)
		+ param;
}

static int ptpd_subscribe_port_params(int port, char *name)
{
	int i;

	for (i = 0; i < N_PTPD_PORT_PARAMS; i++) {
		int idx = ptpd_get_port_param_idx(port, i);

		ptpd_params[idx].param = gpa_mod_prm_subscribe(
			ptpd_mod, get_port_param_modir(port, i),
			port_params_structure[i].prm_oid);
		if (!ptpd_params[idx].param)
			return 1;
	}

	return 0;
}

/*
 * Returns the port index of a <port_name> (a string).
 * Returns -1 if the port name can't be found or the string is invalid.
 */
static int ptpd_port_index(const char *port_name)
{
	int i;

	if (!port_name)
		return -1;

	for (i = 0; i < nports; i++) {
		if (strcmp(port_name, port_names[i]) == 0)
			return i;
	}

	return -1;
}




/************************************************************
 * Public API                                               *
 ************************************************************/

struct param_def *ptpd_init(void)
{
	int i;

	if (initialized) {
		return ptpd_params;
	}

	/* Create user connected to the PTPD module */
	ptpd_mod = gpa_mod_create_user(PTPD_MODULE_ID,
				gpa_mod_tmgrd, (uint16_t)getppid(),
				GPA_MOD_FLAG_MB_WRITE);
	if (!ptpd_mod) {
		pr_error("Can't connect to the ptpd module "
			"(is it running?)\n");
		return 0;
	}

	/* Subscribe to parameters */
	for (i = 0; i < N_PTPD_BASE_PARAMS; i++) {
		ptpd_params[i].param = gpa_mod_prm_subscribe(
			ptpd_mod, ptpd_params[i].modir_oid,
			ptpd_params[i].prm_oid);
	}

	/* Port parameters */
	nports = find_ports(PORT_TYPE_WR, port_names, MAX_PORTS);

	if (nports <= 0) {
		pr_error("Error scanning ptpd ports\n");
	}

	for (i = 0; i < nports; i++) {
		ptpd_subscribe_port_params(i, port_names[i]);
	}

	initialized = 1;

	return ptpd_params;
}

/********** Getter functions **********/

/* Clock parameters */

int ptpd_get_clock_clockid(char *clockid)
{
	if(!clockid) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	gpa_prm_val_tostr_r(ptpd_params[PTPD_CLKQ_CLKID].param, clockid, MAX_STR_LEN-1);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int ptpd_get_clock_class(uint8_t *class)
{
	uint8_t aux;

	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[PTPD_CLKQ_CLASS].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*class = aux;
	}

	return 0;
}

int ptpd_get_clock_accuracy(uint8_t *accuracy)
{
	uint8_t aux;

	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[PTPD_CLKQ_ACCURACY].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*accuracy = aux;
	}

	return 0;
}

int ptpd_get_clock_variance(uint16_t *variance)
{
	uint16_t aux;

	if (!variance) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[PTPD_CLKQ_VARIANCE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*variance = aux;
	}

	return 0;
}

int ptpd_get_clock_priority1(uint8_t *p)
{
	uint8_t aux;

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[PTPD_CLKQ_PRIORITY1].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ptpd_get_clock_priority2(uint8_t *p)
{
	uint8_t aux;

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[PTPD_CLKQ_PRIORITY2].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ptpd_get_clock_utc_offset(int16_t *offset)
{
	uint16_t aux;

	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ptpd_params[PTPD_TPROP_UTC_OFFSET].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*offset = aux;
	}

	return 0;
}

int ptpd_get_clock_utc_offset_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[PTPD_TPROP_UTC_OFFSET_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ptpd_get_clock_time_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[PTPD_TPROP_TIME_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ptpd_get_clock_freq_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[PTPD_TPROP_FREQ_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

/* Port parameters */

int ptpd_get_port_link_status(const char *port_name, int *links)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_LINK_STATUS);

	if (!links) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*links = (aux == 1) ? 1 : 0;
	}

	return 0;
}

int ptpd_get_port_enable_synce(const char *port_name, int *enable)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_SYNCE);

	if (!enable) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enable = aux;
	}

	return 0;
}

int ptpd_get_port_state(const char *port_name, enum ptpd_port_state *state)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_STATE);

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

int ptpd_get_port_clock_state(const char *port_name, enum ptpd_clock_state *state)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLOCK_STATE);

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

int ptpd_get_port_servo_state(const char *port_name, enum ptpd_servo_state *state)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_SERVO_STATE);

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

int ptpd_get_port_state_transitions(const char *port_name, uint32_t *t)
{
	uint32_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_STATE_TRANSITIONS);

	if (!t) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*t = aux;
	}

	return 0;
}

int ptpd_get_port_state_reason(const char *port_name, enum ptpd_state_reason *reason)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_STATE_REASON);

	if (!reason) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*reason = aux;
	}

	return 0;
}

int ptpd_get_port_synce_state(const char *port_name, enum ptpd_synce_state *state)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_SYNCE_STATE);

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

int ptpd_get_port_clock_clockid(const char *port_name, char *clockid)
{
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_CLKID);

	if(!clockid) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	gpa_prm_val_tostr_r(ptpd_params[param_idx].param, clockid, MAX_STR_LEN-1);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int ptpd_get_port_clock_class(const char *port_name, uint8_t *class)
{
	uint8_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_CLASS);

	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*class = aux;
	}

	return 0;
}

int ptpd_get_port_clock_accuracy(const char *port_name, uint8_t *accuracy)
{
	uint8_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_ACCURACY);

	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*accuracy = aux;
	}

	return 0;
}

int ptpd_get_port_clock_variance(const char *port_name, uint16_t *variance)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_VARIANCE);

	if (!variance) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*variance = aux;
	}

	return 0;
}

int ptpd_get_port_clock_n_hops(const char *port_name, uint16_t *n_hops)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_N_HOPS);

	if (!n_hops) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_hops = aux;
	}

	return 0;
}

int ptpd_get_port_clock_priority1(const char *port_name, uint8_t *p)
{
	uint8_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_PRIORITY1);

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ptpd_get_port_clock_priority2(const char *port_name, uint8_t *p)
{
	uint8_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_CLKQ_PRIORITY2);

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ptpd_get_port_clock_time_source(const char *port_name, uint8_t *time_source)
{
	uint8_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_TIME_SOURCE);

	if (!time_source) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*time_source = aux;
	}

	return 0;
}

int ptpd_get_port_clock_ptp_tscale(const char *port_name, int *ptp_tscale)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_PTP_TSCALE);

	if (!ptp_tscale) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ptp_tscale = (aux) ? 1 : 0;
	}

	return 0;
}

int ptpd_get_port_clock_utc_offset(const char *port_name, int16_t *offset)
{
	uint16_t aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_UTC_OFFSET);

	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*offset = aux;
	}

	return 0;
}

int ptpd_get_port_clock_utc_offset_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_UTC_OFFSET_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ptpd_get_port_clock_time_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_TIME_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ptpd_get_port_clock_freq_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ptpd_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ptpd_get_port_param_idx(port, PTPD_PORT_TPROP_FREQ_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ptpd_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

/********** Setter functions **********/

/*
 * NOTE: Set operations on ptpd may be unreliable. The following functions use a
 * wait-and-retry policy if something goes wrong. This makes the operations a
 * bit more robust but they still may fail (and there's no way of knowing how
 * and when they failed so far).
 */

/* Port parameters */

int ptpd_set_port_mode(const char *port_name, enum ptpd_port_mode mode)
{
	int port_idx;
	int param_idx;

	port_idx = ptpd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	param_idx = ptpd_get_port_param_idx(port_idx, PTPD_PORT_MODE);
	if (mode < 0 || mode >= N_PTPD_PORT_MODES) {
		pr_error("Invalid port mode %d\n", mode);
		return 1;
	}

	return _gpa_mod_prm_snd_u16_poll(ptpd_mod,
		ptpd_params[param_idx].param, mode);
}

int ptpd_set_port_enable_synce(const char *port_name, int enable)
{
	int port_idx;
	int param_idx;

	port_idx = ptpd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	if(enable)
		enable = 1;
	else
		enable = 0;

	param_idx = ptpd_get_port_param_idx(port_idx, PTPD_PORT_SYNCE);

	return _gpa_mod_prm_snd_u16_poll(ptpd_mod,
					ptpd_params[param_idx].param, enable);
}

int ptpd_set_run_stop(const char *port_name, int32_t stop)
{
	int retries = MAX_RETRIES;
	int param_idx;
	struct timespec ts = {.tv_sec = 1, .tv_nsec = 0};
	int port_idx = 0;

	port_idx = ptpd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	param_idx = ptpd_get_port_param_idx(port_idx, PTPD_PORT_RUN_STOP);

	while (gpa_mod_prm_snd_i32(ptpd_mod,
		ptpd_params[param_idx].param, stop)
		&& retries) {
		retries--;
		nanosleep(&ts, 0);
	}

	/* Extra sleep if PTPd re-start has been performed */
	//if(retries)
	//	nanosleep(&ts, 0);

	return retries ? 0 : 1;
}

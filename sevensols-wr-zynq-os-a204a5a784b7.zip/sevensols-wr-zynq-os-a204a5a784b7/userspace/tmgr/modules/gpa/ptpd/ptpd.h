#ifndef __PTPD_H__
#define __PTPD_H__

/*
 * ptpd.h
 *
 * ptpd gpa interface module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Nov 14, 2019
 * Last modified: Nov 25, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "common.h"

/*
 * ptpd gpa interface.
 *
 * Provides functions to get and set ptpd parameters.
 */

enum ptpd_port_mode {
	PTPD_PORT_MODE_MASTER,
	PTPD_PORT_MODE_AUTO,
	PTPD_PORT_MODE_SLAVE,
	PTPD_PORT_MODE_DISABLED,

	N_PTPD_PORT_MODES
};

enum ptpd_port_state {
	PTPD_PORT_STATE_NONE,
	PTPD_PORT_STATE_INITIALIZING,
	PTPD_PORT_STATE_FAULTY,
	PTPD_PORT_STATE_DISABLED,
	PTPD_PORT_STATE_LISTENING,
	PTPD_PORT_STATE_PRE_MASTER,
	PTPD_PORT_STATE_MASTER,
	PTPD_PORT_STATE_PASSIVE,
	PTPD_PORT_STATE_UNCALIBRATED,
	PTPD_PORT_STATE_SLAVE,
	N_PTPD_PORT_STATES
};

enum ptpd_clock_state {
	PTPD_CLOCK_STATE_IDLE,
	PTPD_CLOCK_STATE_LOCKING,
	PTPD_CLOCK_STATE_ERROR,
	PTPD_CLOCK_STATE_LOCKED_TO_REF,
	PTPD_CLOCK_STATE_FREE_RUNNING,
	N_PTPD_CLOCK_STATES
};

enum ptpd_servo_state {
	PTPD_SERVO_STATE_DISABLED,
	PTPD_SERVO_STATE_RSVD1,
	PTPD_SERVO_STATE_WAITING_SECP,
	PTPD_SERVO_STATE_WAITING_SECM,
	PTPD_SERVO_STATE_ERROR,
	PTPD_SERVO_STATE_FREQ_EST,
	PTPD_SERVO_STATE_TRACKING,
	PTPD_SERVO_STATE_NOT_UPDATED,
	PTPD_SERVO_STATE_LOCKED,
	N_PTPD_SERVO_STATES
};

enum ptpd_state_reason {
	PTPD_STATE_REASON_UNKNOWN,
	PTPD_STATE_REASON_INTERNAL,
	PTPD_STATE_REASON_OFFSET_CHANGE,
	PTPD_STATE_REASON_IDLE,
	PTPD_STATE_REASON_SYNCING,
	PTPD_STATE_REASON_TIMEOUT,
	PTPD_STATE_REASON_REF_CHANGE,
	PTPD_STATE_REASON_QUALITY_CHANGE,
	PTPD_STATE_REASON_FORCED_BY_CONFIG,
	PTPD_STATE_REASON_FAULT,
	N_PTPD_STATE_REASONS
};

enum ptpd_synce_state {
	PTPD_SYNCE_STATE_UNKNOWN,
	PTPD_SYNCE_STATE_LOCKED,
	PTPD_SYNCE_STATE_UNLOCKED,
	N_PTPD_SYNCE_STATE
};

struct param_def *ptpd_init(void);


/********** Getter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */

/* Clock parameters */

int ptpd_get_clock_clockid(char *);
int ptpd_get_clock_class(uint8_t *);
int ptpd_get_clock_accuracy(uint8_t *);
int ptpd_get_clock_variance(uint16_t *);
int ptpd_get_clock_priority1(uint8_t *);
int ptpd_get_clock_priority2(uint8_t *);
int ptpd_get_clock_utc_offset(int16_t *);
int ptpd_get_clock_utc_offset_valid(int *);
int ptpd_get_clock_time_valid(int *);
int ptpd_get_clock_freq_valid(int *);

/* Port parameters */
int ptpd_get_port_link_status(const char *, int *);
int ptpd_get_port_enable_synce(const char *, int *);
int ptpd_get_port_state(const char *, enum ptpd_port_state *);
int ptpd_get_port_clock_state(const char *, enum ptpd_clock_state *);
int ptpd_get_port_servo_state(const char *, enum ptpd_servo_state *);
int ptpd_get_port_state_transitions(const char *, uint32_t *);
int ptpd_get_port_state_reason(const char *, enum ptpd_state_reason *);
int ptpd_get_port_synce_state(const char *, enum ptpd_synce_state *);
int ptpd_get_port_clock_clockid(const char *, char *);
int ptpd_get_port_clock_class(const char *, uint8_t *);
int ptpd_get_port_clock_accuracy(const char *, uint8_t *);
int ptpd_get_port_clock_variance(const char *, uint16_t *);
int ptpd_get_port_clock_n_hops(const char *, uint16_t *);
int ptpd_get_port_clock_priority1(const char *, uint8_t *);
int ptpd_get_port_clock_priority2(const char *, uint8_t *);
int ptpd_get_port_clock_time_source(const char *, uint8_t *);
int ptpd_get_port_clock_ptp_tscale(const char *, int *);
int ptpd_get_port_clock_utc_offset(const char *, int16_t *);
int ptpd_get_port_clock_utc_offset_valid(const char *, int *);
int ptpd_get_port_clock_time_valid(const char *, int *);
int ptpd_get_port_clock_freq_valid(const char *, int *);


/********** Setter functions **********/

/* Port parameters */

int ptpd_set_port_mode(const char *, enum ptpd_port_mode);
int ptpd_set_port_enable_synce(const char *, int);
int ptpd_set_run_stop(const char *, int32_t);


#endif

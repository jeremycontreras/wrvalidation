#ifndef __PPSI_H__
#define __PPSI_H__

/*
 * ppsi.h
 *
 * ppsi gpa interface module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 13, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "common.h"

/*
 * ppsi gpa interface.
 *
 * Provides functions to get and set ppsi parameters.
 */

enum ppsi_port_mode {
	PPSI_PORT_MODE_DISABLED,
	PPSI_PORT_MODE_MASTER,
	PPSI_PORT_MODE_SLAVE,
	PPSI_PORT_MODE_PASSIVE,
	PPSI_PORT_MODE_AUTO,

	N_PPSI_PORT_MODES
};

enum ppsi_timing_mode {
	PPSI_TM_BC,
	PPSI_TM_GM,
	PPSI_TM_FR,
	PPSI_TM_OC,

	N_PPSI_TIMING_MODES
};

enum ppsi_servo_state {
	PPSI_SERVO_UNITIALIZED,
	PPSI_SERVO_SYNC_TAI,
	PPSI_SERVO_SYNC_NSEC,
	PPSI_SERVO_SYNC_PHASE,
	PPSI_SERVO_TRACK_PHASE,
	PPSI_SERVO_WAIT_OFFSET_STABLE,
	PPSI_SERVO_WAIT_TIME_ADJ,
	PPSI_SERVO_WAIT_PHASE_ADJ,
	PPSI_SERVO_WAIT_UNINIT,
	PPSI_SERVO_NOT_UPDATED,
	PPSI_SERVO_INVALID,
	PPSI_SERVO_UNDEFINED,
	N_PPSI_SERVO_STATES,
};

struct param_def *ppsi_init(void);



/********** Getter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */


/* Config parameters */

int ppsi_get_cfg_timing_mode(enum ppsi_timing_mode *);
int ppsi_get_cfg_ext_port_config(int *);


/* Clock parameters */

int ppsi_get_clock_clockid(char *);
int ppsi_get_clock_class(uint8_t *);
int ppsi_get_clock_accuracy(uint8_t *);
int ppsi_get_clock_variance(uint16_t *);
int ppsi_get_clock_n_hops(uint16_t *);
int ppsi_get_clock_priority1(uint8_t *);
int ppsi_get_clock_priority2(uint8_t *);
int ppsi_get_clock_utc_offset(int16_t *);
int ppsi_get_clock_utc_offset_valid(int *);
int ppsi_get_clock_time_valid(int *);
int ppsi_get_clock_freq_valid(int *);
int ppsi_get_ext_clk(int *);


/* Port parameters */

int ppsi_get_port_mode(const char *, enum ppsi_port_mode *);
int ppsi_get_port_linkup(const char *, int *);
int ppsi_get_port_n_frgns(const char *, uint16_t *);
int ppsi_get_port_n_tx_ptp(const char *, uint32_t *);
int ppsi_get_port_n_rx_ptp(const char *, uint32_t *);
int ppsi_get_port_clock_clockid(const char *, char *);
int ppsi_get_port_clock_class(const char *, uint8_t *);
int ppsi_get_port_clock_accuracy(const char *, uint8_t *);
int ppsi_get_port_clock_variance(const char *, uint16_t *);
int ppsi_get_port_clock_n_hops(const char *, uint16_t *);
int ppsi_get_port_clock_priority1(const char *, uint8_t *);
int ppsi_get_port_clock_priority2(const char *, uint8_t *);
int ppsi_get_port_clock_time_source(const char *, uint8_t *);
int ppsi_get_port_clock_ptp_tscale(const char *, int *);
int ppsi_get_port_clock_utc_offset(const char *, int16_t *);
int ppsi_get_port_clock_utc_offset_valid(const char *, int *);
int ppsi_get_port_clock_time_valid(const char *, int *);
int ppsi_get_port_clock_freq_valid(const char *, int *);
int ppsi_get_port_servo_state(const char *, enum ppsi_servo_state *);


/* Servo info parameters */
int ppsi_get_servo_state(enum ppsi_servo_state *state);

/* Other parameters */

int ppsi_get_run_stop(int32_t *);


/********** Setter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   value to store
 *
 * Return:
 *   0: success
 *   1: error
 */


/* Config parameters */

int ppsi_set_cfg_timing_mode(enum ppsi_timing_mode);
int ppsi_set_cfg_ext_port_config(int);


/* Clock parameters */

int ppsi_set_ext_clk(int);


/* Port parameters */

int ppsi_set_port_mode(const char *, enum ppsi_port_mode);


/* Other parameters */

int ppsi_set_run_stop(int32_t);

#endif

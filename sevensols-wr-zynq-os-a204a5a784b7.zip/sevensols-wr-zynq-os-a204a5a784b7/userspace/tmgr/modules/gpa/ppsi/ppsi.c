/*
 * ppsi.c
 *
 * ppsi gpa interface module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 13, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <libgpa.h>

#include "commondefs.h"
#include "ppsi.h"
#include "gpa_access.h"
#include "utils.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define PPSI_MODULE_ID gpa_mod_ppsi

#define PPSI_MAX_PARAMS 400

#define PPSI_PORTS_IFACE_OID            2000
#define PPSI_PORTS_IFACE_REL_OID        100
#define PPSI_PORTS_CONFIG_REL_OID       10
#define PPSI_PORTS_INFO_REL_OID         10

enum ppsi_params_enum {
	/* Config parameters */
	PPSI_CFG_TIMING_MODE,
	PPSI_CFG_EXT_PORT_CONFIG,

	/* Clock config parameters */
	PPSI_CLKQ_EXT_CLK,

	/* Clock info parameters */
	PPSI_CLKQ_CLOCKID,
	PPSI_CLKQ_CLASS,
	PPSI_CLKQ_ACCURACY,
	PPSI_CLKQ_ALLANVARIANCE,
	PPSI_CLKQ_N_HOPS,
	PPSI_CLKQ_PRIORITY1,
	PPSI_CLKQ_PRIORITY2,
	PPSI_TPROP_UTC_OFFSET,
	PPSI_TPROP_UTC_OFFSET_VALID,
	PPSI_TPROP_TIME_VALID,
	PPSI_TPROP_FREQ_VALID,

	/* Servo info parameters */
	PPSI_SERVO_STATE,

	/* Other parameters */
	PPSI_RUN_STOP,

	N_PPSI_BASE_PARAMS,
};

enum ppsi_port_params_enum {
	PPSI_PORT_MODE,
	PPSI_PORT_LINKUP,
	PPSI_PORT_N_FRGNS,
	PPSI_PORT_N_TX_PTP,
	PPSI_PORT_N_RX_PTP,
	PPSI_PORT_CLKQ_CLOCKID,
	PPSI_PORT_CLKQ_PRIORITY1,
	PPSI_PORT_CLKQ_PRIORITY2,
	PPSI_PORT_CLKQ_CLASS,
	PPSI_PORT_CLKQ_ACCURACY,
	PPSI_PORT_CLKQ_ALLANVARIANCE,
	PPSI_PORT_CLKQ_N_HOPS,
	PPSI_PORT_TPROP_TIME_SOURCE,
	PPSI_PORT_TPROP_UTC_OFFSET,
	PPSI_PORT_TPROP_PTP_TSCALE,
	PPSI_PORT_TPROP_TIME_VALID,
	PPSI_PORT_TPROP_FREQ_VALID,
	PPSI_PORT_TPROP_UTC_OFFSET_VALID,
	PPSI_PORT_SERVO_STATE,

	N_PPSI_PORT_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;

static int nports;
static char port_names[MAX_PORTS][MAX_STR_LEN];

static struct param_def ppsi_params[PPSI_MAX_PARAMS] = {

	/* Config parameters */
	[PPSI_CFG_TIMING_MODE]        = {.key = "cfg/timing_mode",
					.modir_oid = 1100, .prm_oid = 50},
	[PPSI_CFG_EXT_PORT_CONFIG]    = {.key = "cfg/ext_port_config",
					.modir_oid = 1100, .prm_oid = 106},

	/* Clock config parameters */
	[PPSI_CLKQ_EXT_CLK]           = {.key = "cfg/clk/Q/ext_clk",
					.modir_oid = 1121, .prm_oid = 107},

	/* Clock info parameters */
	[PPSI_CLKQ_CLOCKID]           = {.key = "act/clkinfo/Q/clock_identity",
					.modir_oid = 1231, .prm_oid = 1},
	[PPSI_CLKQ_PRIORITY1]         = {.key = "act/clkinfo/Q/priority1",
					.modir_oid = 1231, .prm_oid = 2},
	[PPSI_CLKQ_PRIORITY2]         = {.key = "act/clkinfo/Q/priority2",
					.modir_oid = 1231, .prm_oid = 3},
	[PPSI_CLKQ_CLASS]             = {.key = "act/clkinfo/Q/clock_class",
					.modir_oid = 1231, .prm_oid = 10},
	[PPSI_CLKQ_ACCURACY]          = {.key = "act/clkinfo/Q/clock_accuracy",
					.modir_oid = 1231, .prm_oid = 11},
	[PPSI_CLKQ_ALLANVARIANCE]     = {.key = "act/clkinfo/Q/variance",
					.modir_oid = 1231, .prm_oid = 12},
	[PPSI_CLKQ_N_HOPS]             = {.key = "act/clkinfo/Q/n_hops",
					.modir_oid = 1231, .prm_oid = 20},

	[PPSI_TPROP_UTC_OFFSET]       = {.key = "act/clkinfo/tprop/utc_offset",
					.modir_oid = 1232, .prm_oid = 2},
	[PPSI_TPROP_UTC_OFFSET_VALID] = {.key = "act/clkinfo/tprop/utc_off_val",
					.modir_oid = 1232, .prm_oid = 12},
	[PPSI_TPROP_TIME_VALID]       = {.key = "act/clkinfo/tprop/time_valid",
					.modir_oid = 1232, .prm_oid = 10},
	[PPSI_TPROP_FREQ_VALID]       = {.key = "act/clkinfo/tprop/freq_valid",
					.modir_oid = 1232, .prm_oid = 11},

	/* Servo info parameters */
	[PPSI_SERVO_STATE]            = {.key = "act/servo/state",
					 .modir_oid = 1220, .prm_oid = 6},
	/* Other parameters */
	[PPSI_RUN_STOP]               = {.key = "wproc/run_stop",
					.modir_oid = 901, .prm_oid = 5},
};

/*
 * The modir oid of port params is calculated dynamically from the port number
 * and the .modir_oid field in these definitions (see the <get_port_param_modir>
 * function in this file).
 */
static struct param_def port_params_structure[] = {
	[PPSI_PORT_MODE]                   = {.key = "1/cfg/mode",
					      .modir_oid = 1, .prm_oid = 114},
	[PPSI_PORT_LINKUP]                 = {.key = "1/link",
					      .modir_oid = 0, .prm_oid = 5},
	[PPSI_PORT_N_FRGNS]                = {.key = "1/n_frgns",
					      .modir_oid = 0, .prm_oid = 21},
	[PPSI_PORT_N_TX_PTP]               = {.key = "1/n_tx_ptp",
					      .modir_oid = 0, .prm_oid = 25},
	[PPSI_PORT_N_RX_PTP]               = {.key = "1/n_rx_ptp",
					      .modir_oid = 0, .prm_oid = 26},
	[PPSI_PORT_CLKQ_CLOCKID]           = {.key = "1/clk/Q/clock_identity",
					      .modir_oid = 21, .prm_oid = 1},
	[PPSI_PORT_CLKQ_PRIORITY1]         = {.key = "1/clk/Q/priority1",
					      .modir_oid = 21, .prm_oid = 2},
	[PPSI_PORT_CLKQ_PRIORITY2]         = {.key = "1/clk/Q/priority2",
					      .modir_oid = 21, .prm_oid = 3},
	[PPSI_PORT_CLKQ_CLASS]             = {.key = "1/clk/Q/clock_class",
					      .modir_oid = 21, .prm_oid = 10},
	[PPSI_PORT_CLKQ_ACCURACY]          = {.key = "1/clk/Q/clock_accuracy",
					      .modir_oid = 21, .prm_oid = 11},
	[PPSI_PORT_CLKQ_ALLANVARIANCE]     = {.key = "1/clk/Q/variance",
					      .modir_oid = 21, .prm_oid = 12},
	[PPSI_PORT_CLKQ_N_HOPS]            = {.key = "1/clk/Q/n_hops",
					      .modir_oid = 21, .prm_oid = 20},
	[PPSI_PORT_TPROP_TIME_SOURCE]      = {.key = "1/clk/tprop/time_source",
					      .modir_oid = 22, .prm_oid = 1},
	[PPSI_PORT_TPROP_UTC_OFFSET]       = {.key = "1/clk/tprop/utc_offset",
					      .modir_oid = 22, .prm_oid = 2},
	[PPSI_PORT_TPROP_PTP_TSCALE]       = {.key = "1/clk/tprop/ptp_tscale",
					      .modir_oid = 22, .prm_oid = 3},
	[PPSI_PORT_TPROP_TIME_VALID]       = {.key = "1/clk/tprop/time_valid",
					      .modir_oid = 22, .prm_oid = 10},
	[PPSI_PORT_TPROP_FREQ_VALID]       = {.key = "1/clk/tprop/freq_valid",
					      .modir_oid = 22, .prm_oid = 11},
	[PPSI_PORT_TPROP_UTC_OFFSET_VALID] = {.key = "1/clk/tprop/utc_off_val",
					      .modir_oid = 22, .prm_oid = 12},
	[PPSI_PORT_SERVO_STATE]            = {.key = "1/servo/state",
	                                      .modir_oid = 10, .prm_oid = 6},
};

static struct gpa_mod *ppsi_mod;


/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Returns the modir oid of parameter <param> for port <port>.
 */
static int get_port_param_modir(int port, int param)
{
	return PPSI_PORTS_IFACE_OID
		+ PPSI_PORTS_IFACE_REL_OID * port
		+ PPSI_PORTS_CONFIG_REL_OID
		+ port_params_structure[param].modir_oid;
}

/*
 * Returns the absolute index (in the ppsi_params array) of a port parameter.
 *
 * Parameters:
 *   - port:  Port number
 *   - param: Parameter index in the port_params_structure array
 */
static int ppsi_get_port_param_idx(int port, int param)
{
	return N_PPSI_BASE_PARAMS + (N_PPSI_PORT_PARAMS * port)
		+ param;
}

static int ppsi_subscribe_port_params(int port, char *name)
{
	int i;

	for (i = 0; i < N_PPSI_PORT_PARAMS; i++) {
		int idx = ppsi_get_port_param_idx(port, i);

		ppsi_params[idx].param = gpa_mod_prm_subscribe(
			ppsi_mod, get_port_param_modir(port, i),
			port_params_structure[i].prm_oid);
		if (!ppsi_params[idx].param)
			return 1;
	}

	return 0;
}

/*
 * Returns the port index of a <port_name> (a string).
 * Returns -1 if the port name can't be found or the string is invalid.
 */
static int ppsi_port_index(const char *port_name)
{
	int i;

	if (!port_name)
		return -1;

	for (i = 0; i < nports; i++) {
		if (strcmp(port_name, port_names[i]) == 0)
			return i;
	}

	return -1;
}


/************************************************************
 * Public API                                               *
 ************************************************************/

struct param_def *ppsi_init(void)
{
	int i;

	if (initialized) {
		return ppsi_params;
	}

	/* Create user connected to the PPSI module */
	ppsi_mod = gpa_mod_create_user(PPSI_MODULE_ID,
				gpa_mod_tmgrd, (uint16_t)getppid(),
				GPA_MOD_FLAG_MB_WRITE);
	if (!ppsi_mod) {
		pr_error("Can't connect to the ppsi module "
			"(is it running?)\n");
		return 0;
	}

	/* Subscribe to parameters */
	for (i = 0; i < N_PPSI_BASE_PARAMS; i++) {
		ppsi_params[i].param = gpa_mod_prm_subscribe(
			ppsi_mod, ppsi_params[i].modir_oid,
			ppsi_params[i].prm_oid);
	}

	/* Port parameters */
	nports = find_ports(PORT_TYPE_WR, port_names, MAX_PORTS);

	if (nports <= 0) {
		pr_error("Error scanning ppsi ports\n");
	}

	for (i = 0; i < nports; i++) {
		ppsi_subscribe_port_params(i, port_names[i]);
	}

	initialized = 1;

	return ppsi_params;
}


/********** Getter functions **********/


/* Config parameters */

int ppsi_get_cfg_timing_mode(enum ppsi_timing_mode *tm)
{
	enum ppsi_timing_mode aux;

	if (!tm) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[PPSI_CFG_TIMING_MODE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*tm = aux;
	}

	return 0;
}

int ppsi_get_cfg_ext_port_config(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[PPSI_CFG_EXT_PORT_CONFIG].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}


/* Clock parameters */

int ppsi_get_clock_clockid(char *clockid)
{
	if(!clockid) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	gpa_prm_val_tostr_r(ppsi_params[PPSI_CLKQ_CLOCKID].param, clockid, MAX_STR_LEN-1);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int ppsi_get_clock_class(uint8_t *class)
{
	uint8_t aux;

	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[PPSI_CLKQ_CLASS].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*class = aux;
	}

	return 0;
}

int ppsi_get_clock_accuracy(uint8_t *accuracy)
{
	uint8_t aux;

	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[PPSI_CLKQ_ACCURACY].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*accuracy = aux;
	}

	return 0;
}

int ppsi_get_clock_variance(uint16_t *variance)
{
	uint16_t aux;

	if (!variance) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[PPSI_CLKQ_ALLANVARIANCE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*variance = aux;
	}

	return 0;
}

int ppsi_get_clock_n_hops(uint16_t *n_hops)
{
	uint16_t aux;

	if (!n_hops) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[PPSI_CLKQ_N_HOPS].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_hops = aux;
	}

	return 0;
}

int ppsi_get_clock_priority1(uint8_t *p)
{
	uint8_t aux;

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[PPSI_CLKQ_PRIORITY1].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ppsi_get_clock_priority2(uint8_t *p)
{
	uint8_t aux;

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[PPSI_CLKQ_PRIORITY2].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ppsi_get_clock_utc_offset(int16_t *offset)
{
	uint16_t aux;

	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ppsi_params[PPSI_TPROP_UTC_OFFSET].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*offset = aux;
	}

	return 0;
}

int ppsi_get_clock_utc_offset_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[PPSI_TPROP_UTC_OFFSET_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ppsi_get_clock_time_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[PPSI_TPROP_TIME_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ppsi_get_clock_freq_valid(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[PPSI_TPROP_FREQ_VALID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ppsi_get_ext_clk(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[PPSI_CLKQ_EXT_CLK].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

/* Port parameters */

int ppsi_get_port_mode(const char *port_name, enum ppsi_port_mode *mode)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_MODE);

	if (!mode) {
		pr_error("NULL output parameter\n");
		return 1;
	}
	if (port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_PPSI_PORT_MODES) {
			pr_error("Invalid mode %u\n", aux);
			return 1;
		}
		*mode = aux;
	}

	return 0;
}

int ppsi_get_port_linkup(const char *port_name, int *linkup)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_LINKUP);

	if(!linkup) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if (port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*linkup = (aux) ? 1 : 0;
	}

	return 0;
}

int ppsi_get_port_n_frgns(const char *port_name, uint16_t *n_frgns)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_N_FRGNS);

	if(!n_frgns) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_frgns = aux;
	}

	return 0;
}

int ppsi_get_port_n_tx_ptp(const char *port_name, uint32_t *n_tx_ptp)
{
	uint32_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_N_TX_PTP);

	if(!n_tx_ptp) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(ppsi_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_tx_ptp = aux;
	}

	return 0;
}

int ppsi_get_port_n_rx_ptp(const char *port_name, uint32_t *n_rx_ptp)
{
	uint32_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_N_RX_PTP);

	if(!n_rx_ptp) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(ppsi_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_rx_ptp = aux;
	}

	return 0;
}

int ppsi_get_port_clock_clockid(const char *port_name, char *clockid)
{
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_CLOCKID);

	if(!clockid) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	gpa_prm_val_tostr_r(ppsi_params[param_idx].param, clockid, MAX_STR_LEN-1);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

int ppsi_get_port_clock_class(const char *port_name, uint8_t *class)
{
	uint8_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_CLASS);

	if (!class) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*class = aux;
	}

	return 0;
}

int ppsi_get_port_clock_accuracy(const char *port_name, uint8_t *accuracy)
{
	uint8_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_ACCURACY);

	if (!accuracy) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*accuracy = aux;
	}

	return 0;
}

int ppsi_get_port_clock_variance(const char *port_name, uint16_t *variance)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_ALLANVARIANCE);

	if (!variance) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*variance = aux;
	}

	return 0;
}

int ppsi_get_port_clock_n_hops(const char *port_name, uint16_t *n_hops)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_N_HOPS);

	if (!n_hops) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n_hops = aux;
	}

	return 0;
}

int ppsi_get_port_clock_priority1(const char *port_name, uint8_t *p)
{
	uint8_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_PRIORITY1);

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ppsi_get_port_clock_priority2(const char *port_name, uint8_t *p)
{
	uint8_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_CLKQ_PRIORITY2);

	if (!p) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*p = aux;
	}

	return 0;
}

int ppsi_get_port_clock_time_source(const char *port_name, uint8_t *time_source)
{
	uint8_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_TIME_SOURCE);

	if (!time_source) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u8(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*time_source = aux;
	}

	return 0;
}

int ppsi_get_port_clock_ptp_tscale(const char *port_name, int *ptp_tscale)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_PTP_TSCALE);

	if (!ptp_tscale) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ptp_tscale = (aux) ? 1 : 0;
	}

	return 0;
}

int ppsi_get_port_clock_utc_offset(const char *port_name, int16_t *offset)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_UTC_OFFSET);

	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i16(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*offset = aux;
	}

	return 0;
}

int ppsi_get_port_clock_utc_offset_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_UTC_OFFSET_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ppsi_get_port_clock_time_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_TIME_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int ppsi_get_port_clock_freq_valid(const char *port_name, int *enabled)
{
	int aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_TPROP_FREQ_VALID);

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(ppsi_params[param_idx].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

/* Servo info parameters */

int ppsi_get_servo_state(enum ppsi_servo_state *state)
{
	uint16_t aux;

	if(!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[PPSI_SERVO_STATE].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

int ppsi_get_port_servo_state(const char *port_name, enum ppsi_servo_state *state)
{
	uint16_t aux;
	int port;

	port = ppsi_port_index(port_name);
	if(port < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	int param_idx = ppsi_get_port_param_idx(port, PPSI_PORT_SERVO_STATE);

	if(!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	if(port >= nports) {
		pr_error("Invalid port number: %d\n", port);
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(ppsi_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*state = aux;
	}

	return 0;
}

/* Other parameters */

int ppsi_get_run_stop(int32_t *stop)
{
	int32_t aux;

	if (!stop) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(ppsi_params[PPSI_RUN_STOP].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*stop = aux;
	}

	return 0;
}



/********** Setter functions **********/

/*
 * NOTE: Set operations on ppsi may be unreliable. The following functions use a
 * wait-and-retry policy if something goes wrong. This makes the operations a
 * bit more robust but they still may fail (and there's no way of knowing how
 * and when they failed so far).
 */

/* Config parameters */


int ppsi_set_cfg_timing_mode(enum ppsi_timing_mode tm)
{
	if (tm < 0 || tm >= N_PPSI_TIMING_MODES) {
		pr_error("Invalid ppsi timing mode %d\n", tm);
		return 1;
	}

	return _gpa_mod_prm_snd_u16_poll(ppsi_mod,
		ppsi_params[PPSI_CFG_TIMING_MODE].param, tm);
}


int ppsi_set_cfg_ext_port_config(int enable)
{
	uint16_t state;

	if (enable)
		state = 1;
	else
		state = 0;

	return _gpa_mod_prm_snd_u16_poll(ppsi_mod,
		ppsi_params[PPSI_CFG_EXT_PORT_CONFIG].param, state);
}

/* Clock parameters */

int ppsi_set_ext_clk(int enable)
{
	uint16_t state;

	if (enable)
		state = 1;
	else
		state = 0;

	return _gpa_mod_prm_snd_u16_poll(ppsi_mod,
		ppsi_params[PPSI_CLKQ_EXT_CLK].param, state);
}

/* Port parameters */

int ppsi_set_port_mode(const char *port_name, enum ppsi_port_mode mode)
{
	int port_idx;
	int param_idx;

	port_idx = ppsi_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	param_idx = ppsi_get_port_param_idx(port_idx, PPSI_PORT_MODE);
	if (mode < 0 || mode >= N_PPSI_PORT_MODES) {
		pr_error("Invalid port mode %d\n", mode);
		return 1;
	}

	return _gpa_mod_prm_snd_u16_poll(ppsi_mod,
		ppsi_params[param_idx].param, mode);
}


/* Other parameters */

int ppsi_set_run_stop(int32_t stop)
{
	struct timespec ts = {.tv_sec = 1, .tv_nsec = 0};

	/* we do not perform retry because this prm could fail */
	gpa_mod_prm_snd_i32(ppsi_mod,ppsi_params[PPSI_RUN_STOP].param, stop);

	/* Extra sleep if PPSi re-start has been performed */
	nanosleep(&ts, 0);

	return 0;
}

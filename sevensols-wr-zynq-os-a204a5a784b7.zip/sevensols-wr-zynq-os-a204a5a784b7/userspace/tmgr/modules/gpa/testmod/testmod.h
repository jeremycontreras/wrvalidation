#ifndef __TESTMOD_H__
#define __TESTMOD_H__

/*
 * testmod.h
 *
 * API to access the test time source gpa interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 13, 2019
 * Last modified: Jun 13, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "common.h"



struct param_def *testmod_init(void);



/********** Getter functions **********/

/*
 * testmod_get_status
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */
int testmod_get_status(uint16_t *);

int testmod_check_status(unsigned int timeout_s);


#endif

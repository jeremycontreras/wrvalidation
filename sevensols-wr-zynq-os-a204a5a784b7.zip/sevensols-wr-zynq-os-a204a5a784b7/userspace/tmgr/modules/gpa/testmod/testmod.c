/*
 * testmod.c
 *
 * Test clock source implementation.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Jun 13, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <libgpa.h>

#include "testmod.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define TEST_MODULE_ID gpa_mod_user1

enum testmod_params_enum {
	TEST_STATUS,
	N_TEST_PARAMS
};

/* State definition for the <status> parameter */
enum {
	STATUS_OFF,
	STATUS_INITIALIZING,
	STATUS_ERROR,
	STATUS_OK,
	N_STATUS_ENTRIES
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;

static struct param_def test_params[] = {
	[TEST_STATUS] = {.key = "test_params/status",
			    .modir_oid = 1, .prm_oid = 0},
};

static struct gpa_mod *test_mod;


/************************************************************
 * Public API                                               *
 ************************************************************/


struct param_def *testmod_init(void)
{
	if (!initialized) {
		int i;

		/* Create user connected to the TEST module */
		test_mod = gpa_mod_create_user(TEST_MODULE_ID,
			gpa_user_gen_readonly, (uint16_t)getppid(), 0);

		if (gpa_mod_check_status(test_mod)) {
			free(test_mod);
			pr_error("Test clock source module "
				"is not ready\n");
			return 0;
		}

		/* Subscribe to parameters */
		for (i = 0; i < N_TEST_PARAMS; i++) {
			test_params[i].param = gpa_mod_prm_subscribe(
				test_mod, test_params[i].modir_oid,
				test_params[i].prm_oid);
		}
		initialized = 1;
	}

	return test_params;
}


/********** Getter functions **********/

int testmod_get_status(uint16_t *status)
{
	uint16_t aux;

	if (!status) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(test_params[TEST_STATUS].param);

	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*status = aux;
	}

	return 0;
}

int testmod_check_status(unsigned int timeout_s)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = 100000000};
	int retries = timeout_s * 10;
	int ret = 0;
	uint16_t status;

	if (testmod_get_status(&status))
		return 0;

	while (status == STATUS_INITIALIZING && retries--) {
		nanosleep(&ts, 0);
		testmod_get_status(&status);
	}

	switch (status) {
	case STATUS_OK:
		ret = 1;
		break;
	case STATUS_INITIALIZING:
	case STATUS_ERROR:
	case STATUS_OFF:
		ret = 0;
		break;
	default:
		ret = 0;
		break;
	}

	return ret;
}


/********** Setter functions **********/

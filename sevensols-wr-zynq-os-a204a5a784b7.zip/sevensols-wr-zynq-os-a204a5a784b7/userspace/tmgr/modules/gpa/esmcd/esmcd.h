/**
 * @file esmcd.h
 *
 * @brief This file contains ESMCd GPA interface module definitions for allowing
 * communication between TMGR and ESMCd
 *
 * @author Miguel Jimenez Lopez (miguel.jimenez@sevensols.com)
 * @ingroup tmgr
 * @date 17-06-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of tmgr
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: tmgr.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#ifndef __ESMCD_H__
#define __ESMCD_H__

#include "common.h"

enum esmcd_port_provider_mode {
	ESMCD_PORT_PROVIDER_MODE_MANUAL = 0,
	ESMCD_PORT_PROVIDER_MODE_AUTO,
	N_ESMCD_PORT_PROVIDER_MODE,
};

enum esmcd_port_ssm {
	ESMCD_PORT_SSM_RSVD0 = 0x0,
	ESMCD_PORT_SSM_QL_PRC = 0x2,
	ESMCD_PORT_SSM_QL_SSU_A = 0x4,
	ESMCD_PORT_SSM_QL_SSU_B = 0x8,
	ESMCD_PORT_SSM_QL_SEC = 0xB,
	ESMCD_PORT_SSM_QL_DNU = 0xF,
	N_ESMCD_PORT_SSM = 6,
};

enum esmcd_port_packet_type {
	ESMCD_PORT_PACKET_TYPE_DATA = 0,
	ESMCD_PORT_PACKET_TYPE_EVENT,
	N_ESMCD_PORT_PACKET_TYPE,
};

/*
 * esmcd gpa interface.
 *
 * Provides functions to get and set esmcd parameters.
 */

struct param_def *esmcd_init(void);

/********** Getter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */

int esmcd_get_port_cfg_provider_enable(const char *port_name, int *enable);
int esmcd_get_port_cfg_provider_ssm(const char *port_name, enum esmcd_port_ssm *ssm);
int esmcd_get_port_cfg_provider_msg_rate(const char *port_name, uint32_t *rate);
int esmcd_get_port_info_received_packets(const char *port_name, uint32_t *n);
int esmcd_get_port_info_received_events(const char *port_name, uint32_t *n);
int esmcd_get_port_info_transmited_packets(const char *port_name, uint32_t *n);
int esmcd_get_port_info_transmited_events(const char *port_name, uint32_t *n);
int esmcd_get_port_info_client_ssm(const char *port_name, enum esmcd_port_ssm *ssm);
int esmcd_get_port_info_client_packet_type(const char *port_name, enum esmcd_port_packet_type *ptype);
int esmcd_get_port_info_client_levt_ssm(const char *port_name, enum esmcd_port_ssm *ssm);
int esmcd_get_port_info_client_levt_date(const char *port_name, char *date);

/********** Setter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   value to store
 *
 * Return:
 *   0: success
 *   1: error
 */

int esmcd_set_port_cfg_provider_enable(const char *port_name, int enable);
int esmcd_set_port_cfg_provider_ssm(const char *port_name, enum esmcd_port_ssm ssm);
int esmcd_issue_event_msg(const char *port_name);
int esmcd_set_port_cfg_provider_msg_rate(const char *port_name, uint32_t rate);

#endif /* __ESMCD_H__ */

/**
 * @file esmcd.c
 *
 * @brief This file contains ESMCd GPA interface module implementation for allowing
 * communication between TMGR and ESMCd
 *
 * @author Miguel Jimenez Lopez (miguel.jimenez@sevensols.com)
 * @ingroup tmgr
 * @date 17-06-2020
 * @copyright Copyright (c) 2020 Seven Solutions S.L (www.sevensols.com)
 *
 * This file is part of tmgr
 * You might use, distribute and modify this code and its resulting
 * binary form under the terms of the LICENSE.txt provided within the
 * module/project: tmgr.
 *
 * If you do not have received a copy of the LICENSE.txt along with
 * this file please write to info@sevensols.com and consider that
 * this file can not be copied and/or distributed in any forms.
 */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <libgpa.h>

#include "commondefs.h"
#include "esmcd.h"
#include "gpa_access.h"
#include "utils.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define ESMCD_MODULE_ID gpa_mod_esmcd

#define ESMCD_MAX_PARAMS 400

#define ESMCD_BASE_OID                     2000
#define ESMCD_PORT_REL_OID                 100
#define ESMCD_PORT_CFG_PROVIDER_REL_OID    12
#define ESMCD_PORT_INFO_REL_OID            8
#define ESMCD_PORT_INFO_CLIENT_REL_OID     21

enum esmcd_port_params_enum {
	ESMCD_PORT_CFG_PROVIDER_ENABLE = 0,
	ESMCD_PORT_CFG_PROVIDER_SSM_CODE,
	ESMCD_PORT_CFG_PROVIDER_EVENT,
	ESMCD_PORT_CFG_PROVIDER_MSG_RATE,
	ESMCD_PORT_INFO_RECEIVED_PACKETS,
	ESMCD_PORT_INFO_RECEIVED_EVENTS,
	ESMCD_PORT_INFO_TRANSMITED_PACKETS,
	ESMCD_PORT_INFO_TRANSMITED_EVENTS,
	ESMCD_PORT_INFO_CLIENT_SSM_CODE,
	ESMCD_PORT_INFO_CLIENT_PACKET_TYPE,
	ESMCD_PORT_INFO_CLIENT_LEVT_SSM_CODE,
	ESMCD_PORT_INFO_CLIENT_LEVT_DATE,
	N_ESMCD_PORT_PARAMS
};


/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;
static int nports;
static char port_names[MAX_PORTS][MAX_STR_LEN];
static struct param_def esmcd_params[ESMCD_MAX_PARAMS] = {0};

/*
 * The modir oid of port params is calculated dynamically from the port number
 * and the .modir_oid field in these definitions (see the <get_port_param_modir>
 * function in this file).
 */
static struct param_def esmcd_port_params_structure[] = {
	// Provider configuration parameters
	[ESMCD_PORT_CFG_PROVIDER_ENABLE]         = {.key = "server/cfg/enable",
						    .modir_oid = ESMCD_PORT_CFG_PROVIDER_REL_OID,
						    .prm_oid = 0},
	[ESMCD_PORT_CFG_PROVIDER_SSM_CODE]       = {.key = "server/cfg/force_ssm_code",
						    .modir_oid = ESMCD_PORT_CFG_PROVIDER_REL_OID,
						    .prm_oid = 1},
	[ESMCD_PORT_CFG_PROVIDER_EVENT]          = {.key = "server/cfg/event",
						    .modir_oid = ESMCD_PORT_CFG_PROVIDER_REL_OID,
						    .prm_oid = 2},
	[ESMCD_PORT_CFG_PROVIDER_MSG_RATE]       = {.key = "server/cfg/msg_rate",
						    .modir_oid = ESMCD_PORT_CFG_PROVIDER_REL_OID,
						    .prm_oid = 3},
	// General info parameters
	[ESMCD_PORT_INFO_RECEIVED_PACKETS]       = {.key = "info/rx_packets",
						     .modir_oid = ESMCD_PORT_INFO_REL_OID,
						     .prm_oid = 0},
	[ESMCD_PORT_INFO_RECEIVED_EVENTS]        = {.key = "info/rx_events",
						     .modir_oid = ESMCD_PORT_INFO_REL_OID,
						     .prm_oid = 1},
	[ESMCD_PORT_INFO_TRANSMITED_PACKETS]     = {.key = "info/tx_packets",
						     .modir_oid = ESMCD_PORT_INFO_REL_OID,
						     .prm_oid = 2},
	[ESMCD_PORT_INFO_TRANSMITED_EVENTS]      = {.key = "info/tx_events",
						     .modir_oid = ESMCD_PORT_INFO_REL_OID,
						     .prm_oid = 3},
	// Client info parameters
	[ESMCD_PORT_INFO_CLIENT_SSM_CODE]        = {.key = "client/info/ssm_code",
						     .modir_oid = ESMCD_PORT_INFO_CLIENT_REL_OID,
						     .prm_oid = 0},
	[ESMCD_PORT_INFO_CLIENT_PACKET_TYPE]     = {.key = "client/info/packet_type",
						     .modir_oid = ESMCD_PORT_INFO_CLIENT_REL_OID,
						     .prm_oid = 1},
	[ESMCD_PORT_INFO_CLIENT_LEVT_SSM_CODE]   = {.key = "client/info/levt_ssm_code",
						     .modir_oid = ESMCD_PORT_INFO_CLIENT_REL_OID,
						     .prm_oid = 2},
	[ESMCD_PORT_INFO_CLIENT_LEVT_DATE]       = {.key = "client/info/levt_date",
						     .modir_oid = ESMCD_PORT_INFO_CLIENT_REL_OID,
						     .prm_oid = 3},
};

static struct gpa_mod *esmcd_mod;


/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Returns the modir oid of parameter <param> for port <port>.
 */
static int get_port_param_modir(int port, int param)
{
	return ESMCD_BASE_OID
		+ ESMCD_PORT_REL_OID * port
		+ esmcd_port_params_structure[param].modir_oid;
}

/*
 * Returns the absolute index (in the esmcd_params array) of a port parameter.
 *
 * Parameters:
 *   - port:  Port number
 *   - param: Parameter index in the port_params_structure array
 */
static int esmcd_get_port_param_idx(int port, int param)
{
	return (N_ESMCD_PORT_PARAMS * port)
		+ param;
}

static int esmcd_subscribe_port_params(int port, char *name)
{
	int i;

	for (i = 0; i < N_ESMCD_PORT_PARAMS ; i++) {
		int idx = esmcd_get_port_param_idx(port, i);

		esmcd_params[idx].param = gpa_mod_prm_subscribe(
			esmcd_mod, get_port_param_modir(port, i),
			esmcd_port_params_structure[i].prm_oid);
		if (!esmcd_params[idx].param)
			return 1;
	}

	return 0;
}

/*
 * Returns the port index of a <port_name> (a string).
 * Returns -1 if the port name can't be found or the string is invalid.
 */
static int esmcd_port_index(const char *port_name)
{
	int i;

	if (!port_name)
		return -1;

	for (i = 0; i < nports; i++) {
		if (strcmp(port_name, port_names[i]) == 0)
			return i;
	}

	return -1;
}


/************************************************************
 * Public API                                               *
 ************************************************************/

struct param_def *esmcd_init(void)
{
	int i;

	if (initialized) {
		return esmcd_params;
	}

	/* Create user connected to the ESMCd module */
	esmcd_mod = gpa_mod_create_user(ESMCD_MODULE_ID,
				gpa_mod_tmgrd, (uint16_t)getppid(),
				GPA_MOD_FLAG_MB_WRITE);
	if (!esmcd_mod) {
		pr_error("Can't connect to the esmcd module "
			"(is it running?)\n");
		return 0;
	}

	/* Port parameters */
	nports = find_ports(PORT_TYPE_WR, port_names, MAX_PORTS);

	if (nports <= 0) {
		pr_error("Error scanning esmcd ports\n");
	}

	for (i = 0; i < nports; i++) {
		esmcd_subscribe_port_params(i, port_names[i]);
	}

	initialized = 1;

	return esmcd_params;
}


/********** Getter functions **********/

int esmcd_get_port_cfg_provider_enable(const char *port_name, int *enable)
{
	uint16_t aux;
	int port_idx;
	int param_idx;

	if(!enable) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_ENABLE);

	errno = 0;
	aux = gpa_prm_get_u16(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enable = aux;
	}

	return 0;
}

int esmcd_get_port_cfg_provider_ssm(const char *port_name, enum esmcd_port_ssm *ssm)
{
	uint8_t aux;
	int port_idx;
	int param_idx;

	if(!ssm) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_SSM_CODE);

	errno = 0;
	aux = gpa_prm_get_u8(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ssm = aux;
	}

	return 0;
}

int esmcd_get_port_cfg_provider_msg_rate(const char *port_name, uint32_t *rate)
{
	uint32_t aux;
	int port_idx;
	int param_idx;

	if(!rate) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_MSG_RATE);

	errno = 0;
	aux = gpa_prm_get_u32(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*rate = aux;
	}

	return 0;
}

int esmcd_get_port_info_received_packets(const char *port_name, uint32_t *n)
{
	uint32_t aux;
	int port_idx;
	int param_idx;

	if(!n) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_RECEIVED_PACKETS);

	errno = 0;
	aux = gpa_prm_get_u32(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n = aux;
	}

	return 0;
}

int esmcd_get_port_info_received_events(const char *port_name, uint32_t *n)
{
	uint32_t aux;
	int port_idx;
	int param_idx;

	if(!n) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_RECEIVED_EVENTS);

	errno = 0;
	aux = gpa_prm_get_u32(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n = aux;
	}

	return 0;
}

int esmcd_get_port_info_transmited_packets(const char *port_name, uint32_t *n)
{
	uint32_t aux;
	int port_idx;
	int param_idx;

	if(!n) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_TRANSMITED_PACKETS);

	errno = 0;
	aux = gpa_prm_get_u32(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n = aux;
	}

	return 0;
}

int esmcd_get_port_info_transmited_events(const char *port_name, uint32_t *n)
{
	uint32_t aux;
	int port_idx;
	int param_idx;

	if(!n) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_TRANSMITED_EVENTS);

	errno = 0;
	aux = gpa_prm_get_u32(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*n = aux;
	}

	return 0;
}

int esmcd_get_port_info_client_ssm(const char *port_name, enum esmcd_port_ssm *ssm)
{
	uint8_t aux;
	int port_idx;
	int param_idx;

	if(!ssm) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_CLIENT_SSM_CODE);

	errno = 0;
	aux = gpa_prm_get_u8(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ssm = aux;
	}

	return 0;
}

int esmcd_get_port_info_client_packet_type(const char *port_name, enum esmcd_port_packet_type *ptype)
{
	uint16_t aux;
	int port_idx;
	int param_idx;

	if(!ptype) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_CLIENT_PACKET_TYPE);

	errno = 0;
	aux = gpa_prm_get_u16(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ptype = aux;
	}

	return 0;
}

int esmcd_get_port_info_client_levt_ssm(const char *port_name, enum esmcd_port_ssm *ssm)
{
	uint8_t aux;
	int port_idx;
	int param_idx;

	if(!ssm) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_CLIENT_LEVT_SSM_CODE);

	errno = 0;
	aux = gpa_prm_get_u8(esmcd_params[param_idx].param);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*ssm = aux;
	}

	return 0;
}

int esmcd_get_port_info_client_levt_date(const char *port_name, char *date)
{
	int port_idx;
	int param_idx;

	if(!date) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_INFO_CLIENT_LEVT_DATE);

	errno = 0;
	gpa_prm_val_tostr_r(esmcd_params[param_idx].param, date, MAX_STR_LEN-1);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}

/********** Setter functions **********/

/*
 * NOTE: Set operations on ppsi may be unreliable. The following functions use a
 * wait-and-retry policy if something goes wrong. This makes the operations a
 * bit more robust but they still may fail (and there's no way of knowing how
 * and when they failed so far).
 */

int esmcd_set_port_cfg_provider_enable(const char *port_name, int enable)
{
	uint16_t en;
	int port_idx;
	int param_idx;

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_ENABLE);

	// Convert value to 0/1
	if (enable)
		en = 1;
	else
		en = 0;

	// Send new value to ESMCd
	return _gpa_mod_prm_snd_u16_poll(esmcd_mod,
					esmcd_params[param_idx].param,
					en);
}

int esmcd_set_port_cfg_provider_ssm(const char *port_name, enum esmcd_port_ssm ssm)
{
	int port_idx;
	int param_idx;

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_SSM_CODE);

	// Send new value to ESMCd
	return _gpa_mod_prm_snd_u8_poll(esmcd_mod,
					esmcd_params[param_idx].param,
					ssm);
}

int esmcd_issue_event_msg(const char *port_name)
{
	int port_idx;
	int param_idx;

	// Get port index
	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_EVENT);

	// Send new value to ESMCd
	// FIXME: It could fail however polling mechanism does not work because
	// ESMCd put param value to 0 when event issue event is processed
	return gpa_mod_prm_snd_u16(esmcd_mod, esmcd_params[param_idx].param, 1);
}

int esmcd_set_port_cfg_provider_msg_rate(const char *port_name, uint32_t rate)
{
	int port_idx;
	int param_idx;

	if(rate == 0) {
		pr_error("Invalid msg rate: %d (should be >= 1)\n", rate);
		return 1;
	}

	port_idx = esmcd_port_index(port_name);
	if (port_idx < 0) {
		pr_error("Invalid port: %s\n", port_name);
		return 1;
	}

	// Get param index
	param_idx = esmcd_get_port_param_idx(port_idx, ESMCD_PORT_CFG_PROVIDER_MSG_RATE);

	// Send new value to ESMCd
	return _gpa_mod_prm_snd_u32_poll(esmcd_mod,
					esmcd_params[param_idx].param,
					rate);
}


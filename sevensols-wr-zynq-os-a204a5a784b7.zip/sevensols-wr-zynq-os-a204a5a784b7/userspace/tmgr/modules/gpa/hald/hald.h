#ifndef __HALD_H__
#define __HALD_H__

/*
 * hald.h
 *
 * API to access the hald gpa interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 13, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "common.h"

/*
 * hald gpa interface.
 *
 * Provides functions to get and set hald parameters.
 */

enum led_id {
	LED_ID_STATUS = 0,
	LED_ID_IN,
	LED_ID_OUT,
	N_LED_ID,
};

enum led_mode {
	LED_MODE_EMIO = 0,
	LED_MODE_OFF,
	LED_MODE_ON,
	LED_MODE_PPS,
	LED_MODE_PPS_INVERTED,
	LED_MODE_PPS_BYPASS,
	N_LED_MODE,
};

enum led_color {
	LED_COLOR_RED = 0,
	LED_COLOR_GREEN,
	LED_COLOR_YELLOW,
	N_LED_COLOR,
};

enum pps_mode_controller {
	PPS_MODE_CONTROLLER_PPSI = 0,
	PPS_MODE_CONTROLLER_TMGR,
	N_PPS_MODE_CONTROLLER,
};

enum softpll_mode {
	SOFTPLL_MODE_UNINITIALIZED,
	SOFTPLL_MODE_GM,
	SOFTPLL_MODE_FREE_RUNNING_MASTER,
	SOFTPLL_MODE_SLAVE,
	SOFTPLL_MODE_DISABLED,
	N_SOFTPLL_MODES,
};

enum softpll_seq_state {
	SOFTPLL_SEQ_STATE_UNINITIALIZED,
	SOFTPLL_SEQ_STATE_START_EXT,
	SOFTPLL_SEQ_STATE_WAIT_EXT,
	SOFTPLL_SEQ_STATE_START_HELPER,
	SOFTPLL_SEQ_STATE_WAIT_HELPER,
	SOFTPLL_SEQ_STATE_START_MAIN,
	SOFTPLL_SEQ_STATE_WAIT_MAIN,
	SOFTPLL_SEQ_STATE_DISABLED,
	SOFTPLL_SEQ_STATE_READY,
	SOFTPLL_SEQ_STATE_CLEAR_DACS,
	SOFTPLL_SEQ_STATE_WAIT_CLEAR_DACS,
	N_SOFTPLL_SEQ_STATES,
};

enum softpll_ext_src_id {
	SOFTPLL_EXT_SRC_ID_FPANEL,
	SOFTPLL_EXT_SRC_ID_GNSS,
	SOFTPLL_EXT_SRC_ID_HOLDOVER,
	N_SOFTPLL_EXT_SRC_IDS,
};

enum softpll_ext_fpanel {
	SOFTPLL_EXT_DETECTED_NONE,
	SOFTPLL_EXT_DETECTED_PPS,
	SOFTPLL_EXT_DETECTED_CLK,
	SOFTPLL_EXT_DETECTED_PPSCLK,
	N_SOFTPLL_EXT_FPANEL,
};

enum softpll_align_state {
	SOFTPLL_ALIGN_STATE_EXT_OFF,
	SOFTPLL_ALIGN_STATE_START,
	SOFTPLL_ALIGN_STATE_INIT_CSYNC,
	SOFTPLL_ALIGN_STATE_WAIT_CSYNC,
	SOFTPLL_ALIGN_STATE_WAIT_SAMPLE,
	SOFTPLL_ALIGN_STATE_COMPENSATE_DELAY,
	SOFTPLL_ALIGN_STATE_LOCKED,
	SOFTPLL_ALIGN_STATE_START_ALIGNMENT,
	SOFTPLL_ALIGN_STATE_START_MAIN,
	SOFTPLL_ALIGN_STATE_WAIT_CLKIN,
	SOFTPLL_ALIGN_STATE_WAIT_PLOCK,
	SOFTPLL_ALIGN_STATE_RESERVED_1,
	SOFTPLL_ALIGN_STATE_RESERVED_2,
	SOFTPLL_ALIGN_STATE_RESERVED_3,
	SOFTPLL_ALIGN_STATE_RESERVED_4,
	SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_COARSE,
	SOFTPLL_ALIGN_STATE_COMPENSATE_PPS_FINE,
	N_SOFTPLL_ALIGN_STATES,
};

enum ho_detected {
	HO_NONE,
	HO_PPS,
	HO_CLK,
	HO_PPS_CLK,
	N_HO_DETECTED_STATES,
};

enum ho_state {
	HO_UNAVAILABLE,
	HO_DISABLED,
	HO_LOCKING,
	HO_LEARNING,
	HO_READY,
	HO_ACTIVATED,
	HO_EXPIRED,
	N_HO_STATES,
};

enum ho_trig {
	HO_TRIGGER_NONE,
	HO_TRIGGER_MANUAL,
	HO_TRIGGER_PPS_DRIFT,
	HO_TRIGGER_NO_DATA,
	HO_TRIGGER_TRACK_LOST,
	HO_TRIGGER_RESERVED5,
	HO_TRIGGER_RESERVED6,
	HO_TRIGGER_RESERVED7,
	HO_TRIGGER_LINKDOWN,
	HO_TRIGGER_EXTCLK_DOWN,
	HO_TRIGGER_EXTPPS_DOWN,
	HO_TRIGGER_CLK_DRIFT,
	N_HO_TRIGGERS,
};

/*
 * TODO:
 *
 *   - OIDs are not defined yet in the spec.
 *   - Parameter types are not fully defined in the spec.
 */


struct param_def *hald_init(void);



/********** Getter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   pointer to a variable to hold the result (only pointer operations involved,
 *     no string copies)
 *
 * Return:
 *   0: success (saves the result in the variable pointed by the parameter)
 *   1: error (the parameter is not modified)
 */

/**** Version parameters ****/
int hald_get_ver_product(char *product, size_t size);


/**** GM Healthy parameters ****/

#if 0
int hald_get_gm_pps_present(int *);
int hald_get_gm_clk_present(int *);
int hald_get_gm_clk_frequency(int32_t *);
int hald_get_gm_pps_drift(int32_t *);
#endif


/* SoftPLL parameters */

int hald_get_softpll_mode(enum softpll_mode *);
int hald_get_softpll_update(uint32_t *);
int hald_get_softpll_seq_state(enum softpll_seq_state *);
int hald_get_softpll_n_delock(uint32_t *);
int hald_get_softpll_info_version(uint32_t *);
int hald_get_softpll_mpll_locked(uint32_t *);
int hald_get_softpll_mpll_pi_y(uint32_t *);
int hald_get_softpll_hpll_locked(uint32_t *);
int hald_get_softpll_hpll_pi_y(uint32_t *);
int hald_get_softpll_ext_src_id(enum softpll_ext_src_id *);
int hald_get_softpll_ext_align_state(enum softpll_align_state *);
int hald_get_softpll_ext_align_pps(int *);
int hald_get_softpll_ext_user_offset(int32_t *);
int hald_get_softpll_ext_fpanel_detected(enum softpll_ext_fpanel *);
int hald_get_softpll_ext_fpanel_pps_delta(int32_t *);
int hald_get_softpll_ext_fpanel_clk_cfreq(uint32_t *);


/* SoftPLL Holdover parameters */

int hald_get_softpll_ho_detected(enum ho_detected *);
int hald_get_softpll_ho_pps_delta(int32_t *);
int hald_get_softpll_ho_clk_cfreq(uint32_t *);
int hald_get_softpll_ho_fpo_detected(uint16_t *);
int hald_get_softpll_ho_enabled(int *);
int hald_get_softpll_ho_state(enum ho_state *);
//char *hald_holdover_status_msg(void);
int hald_get_softpll_ho_trig_origin(enum ho_trig *);
int hald_get_softpll_ho_state_time(uint32_t *);
int hald_get_softpll_ho_trig_time(uint32_t *);
int hald_get_softpll_ho_ready_tlapse(uint32_t *);
int hald_get_softpll_ho_expired_tlapse(uint32_t *);
int hald_get_softpll_ho_run(int *);
int hald_get_softpll_ho_trig_force_ext_trig(enum ho_trig *);
int hald_get_softpll_ho_trig_internal_en(uint16_t *);
int hald_get_softpll_ho_trig_pps_threshold(uint32_t *);
int hald_get_softpll_ho_trig_pps_tlapse(uint32_t *);
int hald_get_softpll_ho_trig_clk_threshold(uint32_t *);
int hald_get_softpll_ho_trig_clk_tlapse(uint32_t *);


/* HOLDOVER trigger parameters */

#if 0

/*
 * TODO: Undefined parameters. Remove if they're not necessary.
 */

int hald_get_ho_trigger_link_down_enabled(int *);
int hald_get_ho_trigger_pps_drift_enabled(int *);
int hald_get_ho_trigger_pps_drift_phase_threshold(int32_t *);
int hald_get_ho_trigger_pps_drift_timelapse(uint32_t *);
int hald_get_ho_trigger_clk_drift_enabled(int *);
int hald_get_ho_trigger_clk_drift_phase_threshold(int32_t *);
int hald_get_ho_trigger_clk_drift_timelapse(uint32_t *);
int hald_get_ho_trigger_gm_pps_drift_enabled(int *);
int hald_get_ho_trigger_gm_pps_drift_phase_threshold(int32_t *);
int hald_get_ho_trigger_gm_pps_drift_timelapse(uint32_t *);
int hald_get_ho_trigger_gm_clk_drift_enabled(int *);
int hald_get_ho_trigger_gm_clk_drift_phase_threshold(int32_t *);
int hald_get_ho_trigger_gm_clk_drift_timelapse(uint32_t *);
int hald_get_ho_trigger_bmc_enabled(int *);
int hald_get_ho_trigger_bmc_clk_quality_threshold(uint32_t *);

#endif



/********** Setter functions **********/

/*
 * Same interface for all of them:
 *
 * Parameters:
 *   value to store
 *
 * Return:
 *   0: success
 *   1: error
 */

/**** GM Healthy parameters ****/

#if 0
int hald_set_gm_pps_present(int);
int hald_set_gm_clk_present(int);
int hald_set_gm_clk_frequency(int32_t);
int hald_set_gm_pps_drift(int32_t);
#endif

/* LED parameters */
int hald_set_led_mode(enum led_id, enum led_mode);
int hald_set_led_color(enum led_id, enum led_color);
int hald_set_led_width(enum led_id, uint32_t);
int hald_update_led(enum led_id);

/* PPS mode parameters */

int hald_set_pps_mode_controller(enum pps_mode_controller);
int hald_set_pps_mode_state_tmgr(int);

/* SoftPLL parameters */

int hald_set_softpll_mode(enum softpll_mode);
int hald_set_softpll_ext_src_id(enum softpll_ext_src_id);
int hald_set_softpll_ext_align_pps(int);
int hald_set_softpll_ext_user_offset(int32_t);


/* SoftPLL Holdover parameters */

int hald_set_softpll_ho_detected(enum ho_detected);
int hald_set_softpll_ho_pps_delta(int32_t);
int hald_set_softpll_ho_clk_cfreq(uint32_t);
int hald_set_softpll_ho_fpo_detected(uint16_t);
int hald_set_softpll_ho_enabled(int);
int hald_set_softpll_ho_state(enum ho_state);
int hald_set_softpll_ho_trig_origin(enum ho_trig);
int hald_set_softpll_ho_state_time(uint32_t);
int hald_set_softpll_ho_trig_time(uint32_t);
int hald_set_softpll_ho_ready_tlapse(uint32_t);
int hald_set_softpll_ho_expired_tlapse(uint32_t);
int hald_set_softpll_ho_run(int);
int hald_set_softpll_ho_trig_force_ext_trig(enum ho_trig);
int hald_set_softpll_ho_trig_internal_en(uint16_t);
int hald_set_softpll_ho_trig_pps_threshold(uint32_t);
int hald_set_softpll_ho_trig_pps_tlapse(uint32_t);
int hald_set_softpll_ho_trig_clk_threshold(uint32_t);
int hald_set_softpll_ho_trig_clk_tlapse(uint32_t);
int hald_sync_plls(void);


/* HOLDOVER trigger parameters */

#if 0

/*
 * TODO: Undefined parameters. Remove if they're not necessary.
 */

int hald_set_ho_trigger_link_down_enabled(int);
int hald_set_ho_trigger_pps_drift_enabled(int);
int hald_set_ho_trigger_pps_drift_phase_threshold(int32_t);
int hald_set_ho_trigger_pps_drift_timelapse(uint32_t);
int hald_set_ho_trigger_clk_drift_enabled(int);
int hald_set_ho_trigger_clk_drift_phase_threshold(int32_t);
int hald_set_ho_trigger_clk_drift_timelapse(uint32_t);
int hald_set_ho_trigger_gm_pps_drift_enabled(int);
int hald_set_ho_trigger_gm_pps_drift_phase_threshold(int32_t);
int hald_set_ho_trigger_gm_pps_drift_timelapse(uint32_t);
int hald_set_ho_trigger_gm_clk_drift_enabled(int);
int hald_set_ho_trigger_gm_clk_drift_phase_threshold(int32_t);
int hald_set_ho_trigger_gm_clk_drift_timelapse(uint32_t);
int hald_set_ho_trigger_bmc_enabled(int);
int hald_set_ho_trigger_bmc_clk_quality_threshold(uint32_t);

#endif


#endif

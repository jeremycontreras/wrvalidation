/*
 * hald.c
 *
 * API to access the hald gpa interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 13, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <libgpa.h>
#include <unistd.h>
#include <stdlib.h>

#include "hald.h"


/*
 * TODO:
 *
 *   - OIDs are not defined yet in the spec.
 *   - Parameter types are not fully defined in the spec.
 */


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define HALD_MODULE_ID gpa_mod_hal
#define LED_WIDTH_MAX 1000000000

enum hald_params_enum {

	/* Version parameters */
	HALD_VER_PRODUCT,

	/* GM Healthy parameters */
	/* Not defined yet
	HALD_GM_PPS_PRESENT,
	HALD_GM_CLK_PRESENT,
	HALD_GM_CLK_FREQ,
	HALD_GM_PPS_DRIFT,
	*/

	/* LEDS paramters */
	HALD_LEDS_STATUS_COLOR,
	HALD_LEDS_STATUS_MODE,
	HALD_LEDS_STATUS_LOAD,
	HALD_LEDS_STATUS_WIDTH,
	HALD_LEDS_IN_COLOR,
	HALD_LEDS_IN_MODE,
	HALD_LEDS_IN_LOAD,
	HALD_LEDS_IN_WIDTH,
	HALD_LEDS_OUT_COLOR,
	HALD_LEDS_OUT_MODE,
	HALD_LEDS_OUT_LOAD,
	HALD_LEDS_OUT_WIDTH,

	/* PPS mode parameters */
	HALD_PPS_MODE_CONTROLLER,
	HALD_PPS_MODE_STATE_TMGR,

	/* SoftPLL parameters */
	HALD_SOFTPLL_MODE,
	HALD_SOFTPLL_UPDATE,
	HALD_SOFTPLL_SEQ_STATE,
	HALD_SOFTPLL_N_DELOCK,
	HALD_SOFTPLL_INFO_VERSION,
	HALD_SOFTPLL_MPLL_LOCKED,
	HALD_SOFTPLL_MPLL_PI_Y,
	HALD_SOFTPLL_HPLL_LOCKED,
	HALD_SOFTPLL_HPLL_PI_Y,
	HALD_SOFTPLL_EXT_SRC_ID,
	HALD_SOFTPLL_EXT_ALIGN_STATE,
	HALD_SOFTPLL_EXT_ALIGN_PPS,
	HALD_SOFTPLL_EXT_USER_OFFSET,
	HALD_SOFTPLL_EXT_FPANEL_DETECTED,
	HALD_SOFTPLL_EXT_FPANEL_PPS_DELTA,
	HALD_SOFTPLL_EXT_FPANEL_CLK_CFREQ,

	/* SoftPLL Holdover parameters */
	HALD_SOFTPLL_EXT_HO_DETECTED,
	HALD_SOFTPLL_EXT_HO_PPS_DELTA,
	HALD_SOFTPLL_EXT_HO_CLK_CFREQ,
	HALD_SOFTPLL_EXT_HO_FPO_DETECTED,
	HALD_SOFTPLL_EXT_HO_ENABLED,
	HALD_SOFTPLL_EXT_HO_STATE,
	HALD_SOFTPLL_EXT_HO_TRIG_ORIGIN,
	HALD_SOFTPLL_EXT_HO_STATE_TIME,
	HALD_SOFTPLL_EXT_HO_TRIG_TIME,
	HALD_SOFTPLL_EXT_HO_READY_TLAPSE,
	HALD_SOFTPLL_EXT_HO_EXPIRED_TLAPSE,
	HALD_SOFTPLL_EXT_HO_RUN,
	HALD_SOFTPLL_EXT_HO_TRIG_FORCE_EXT_TRIG,
	HALD_SOFTPLL_EXT_HO_TRIG_INTERNAL_EN,
	HALD_SOFTPLL_EXT_HO_TRIG_PPS_THRESHOLD,
	HALD_SOFTPLL_EXT_HO_TRIG_PPS_TLAPSE,
	HALD_SOFTPLL_EXT_HO_TRIG_CLK_THRESHOLD,
	HALD_SOFTPLL_EXT_HO_TRIG_CLK_TLAPSE,

	/* PLL Syncs */
	HALD_PPSYNC_AD_SYNC,
	HALD_PPSYNC_LMK_SYNC,

	/* HOLDOVER trigger parameters */
	/* Not defined yet
	HALD_HO_TRIGGER_LINK_DOWN_ENABLED,
	HALD_HO_TRIGGER_PPS_DRIFT_ENABLED,
	HALD_HO_TRIGGER_PPS_DRIFT_PHASE_THRESHOLD,
	HALD_HO_TRIGGER_PPS_DRIFT_TIMELAPSE,
	HALD_HO_TRIGGER_CLK_DRIFT_ENABLED,
	HALD_HO_TRIGGER_CLK_DRIFT_PHASE_THRESHOLD,
	HALD_HO_TRIGGER_CLK_DRIFT_TIMELAPSE,
	HALD_HO_TRIGGER_GM_PPS_DRIFT_ENABLED,
	HALD_HO_TRIGGER_GM_PPS_DRIFT_PHASE_THRESHOLD,
	HALD_HO_TRIGGER_GM_PPS_DRIFT_TIMELAPSE,
	HALD_HO_TRIGGER_GM_CLK_DRIFT_ENABLED,
	HALD_HO_TRIGGER_GM_CLK_DRIFT_PHASE_THRESHOLD,
	HALD_HO_TRIGGER_GM_CLK_DRIFT_TIMELAPSE,
	HALD_HO_TRIGGER_BMC_ENABLED,
	HALD_HO_TRIGGER_BMC_CLK_QUALITY_THRESHOLD,
	*/

	N_HALD_PARAMS,
};

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;

static struct param_def hald_params[] = {
	/* Version parameters */
	[HALD_VER_PRODUCT]                  = {.key = "ver/hw/base/product",
					        .modir_oid = 1410, .prm_oid = 21},

	/* GM Healthy parameters */
	/* Not defined yet
	[HALD_GM_PPS_PRESENT]   = {.key = "gm_healthy_pps_present",
					.modir_oid = 1, .prm_oid = 0},
	[HALD_GM_CLK_PRESENT]   = {.key = "gm_healthy_clk_present",
					.modir_oid = 1, .prm_oid = 0},
	[HALD_GM_CLK_FREQ]      = {.key = "gm_healthy_clk_frequency",
					.modir_oid = 1, .prm_oid = 0},
	[HALD_GM_PPS_DRIFT]     = {.key = "gm_healthy_pps_drift",
					.modir_oid = 1, .prm_oid = 0},
	*/

	/* PPS mode parameters */
	[HALD_LEDS_STATUS_COLOR]            = {.key = "leds/status/color",
					       .modir_oid = 9231, .prm_oid = 1},
	[HALD_LEDS_STATUS_MODE]             = {.key = "leds/status/mode",
					       .modir_oid = 9231, .prm_oid = 2},
	[HALD_LEDS_STATUS_LOAD]             = {.key = "leds/status/load",
					       .modir_oid = 9231, .prm_oid = 3},
	[HALD_LEDS_STATUS_WIDTH]            = {.key = "leds/status/width",
					       .modir_oid = 9231, .prm_oid = 4},
	[HALD_LEDS_IN_COLOR]                = {.key = "leds/in/color",
					       .modir_oid = 9232, .prm_oid = 1},
	[HALD_LEDS_IN_MODE]                 = {.key = "leds/in/mode",
					       .modir_oid = 9232, .prm_oid = 2},
	[HALD_LEDS_IN_LOAD]                 = {.key = "leds/in/load",
					       .modir_oid = 9232, .prm_oid = 3},
	[HALD_LEDS_IN_WIDTH]                = {.key = "leds/in/width",
					       .modir_oid = 9232, .prm_oid = 4},
	[HALD_LEDS_OUT_COLOR]               = {.key = "leds/out/color",
					       .modir_oid = 9233, .prm_oid = 1},
	[HALD_LEDS_OUT_MODE]                = {.key = "leds/out/mode",
					       .modir_oid = 9233, .prm_oid = 2},
	[HALD_LEDS_OUT_LOAD]                = {.key = "leds/out/load",
					       .modir_oid = 9233, .prm_oid = 3},
	[HALD_LEDS_OUT_WIDTH]               = {.key = "leds/out/width",
					       .modir_oid = 9233, .prm_oid = 4},

	/* PPS mode parameters */
	[HALD_PPS_MODE_CONTROLLER]          = {.key = "pps/controller",
					        .modir_oid = 1700, .prm_oid = 7},
	[HALD_PPS_MODE_STATE_TMGR]          = {.key = "pps/state_tmgr",
					        .modir_oid = 1700, .prm_oid = 9},

	/* SoftPLL parameters */
	[HALD_SOFTPLL_MODE]                 = {.key = "spll/mode",
						.modir_oid = 8000, .prm_oid = 1},
	[HALD_SOFTPLL_UPDATE]               = {.key = "spll/update",
						.modir_oid = 8000, .prm_oid = 3},
	[HALD_SOFTPLL_SEQ_STATE]            = {.key = "spll/seq_state",
						.modir_oid = 8000, .prm_oid = 2},
	[HALD_SOFTPLL_N_DELOCK]             = {.key = "spll/n_delock",
						.modir_oid = 8000, .prm_oid = 4},
	[HALD_SOFTPLL_INFO_VERSION]         = {.key = "spll/info/version",
						.modir_oid = 8100, .prm_oid = 2},
	[HALD_SOFTPLL_MPLL_LOCKED]          = {.key = "spll/mpll/locked",
						.modir_oid = 8200, .prm_oid = 1},
	[HALD_SOFTPLL_MPLL_PI_Y]            = {.key = "spll/mpll/pi.y",
						.modir_oid = 8200, .prm_oid = 8},
	[HALD_SOFTPLL_HPLL_LOCKED]          = {.key = "spll/hpll/locked",
						.modir_oid = 8300, .prm_oid = 1},
	[HALD_SOFTPLL_HPLL_PI_Y]            = {.key = "spll/hpll/pi.y",
						.modir_oid = 8300, .prm_oid = 8},
	[HALD_SOFTPLL_EXT_SRC_ID]           = {.key = "spll/ext/src_id",
						.modir_oid = 8400, .prm_oid = 1},
	[HALD_SOFTPLL_EXT_ALIGN_STATE]      = {.key = "spll/ext/align_state",
						.modir_oid = 8400, .prm_oid = 2},
	[HALD_SOFTPLL_EXT_ALIGN_PPS]        = {.key = "spll/ext/align_pps",
						.modir_oid = 8400, .prm_oid = 3},
	[HALD_SOFTPLL_EXT_USER_OFFSET]      = {.key = "spll/ext/user_offset",
						.modir_oid = 8400, .prm_oid = 4},
	[HALD_SOFTPLL_EXT_FPANEL_DETECTED]  = {.key = "spll/ext/fpanel/detected",
						.modir_oid = 8410, .prm_oid = 1},
	[HALD_SOFTPLL_EXT_FPANEL_PPS_DELTA] = {.key = "spll/ext/fpanel/pps_delta",
						.modir_oid = 8410, .prm_oid = 4},
	[HALD_SOFTPLL_EXT_FPANEL_CLK_CFREQ] = {.key = "spll/ext/fpanel/clk_cfreq",
						.modir_oid = 8410, .prm_oid = 5},


	/* SoftPLL Holdover parameters */
	[HALD_SOFTPLL_EXT_HO_DETECTED]            = {.key = "spll/ext/ho/detected",
							.modir_oid = 8430, .prm_oid = 1},
	[HALD_SOFTPLL_EXT_HO_PPS_DELTA]           = {.key = "spll/ext/ho/pps_delta",
							.modir_oid = 8430, .prm_oid = 4},
	[HALD_SOFTPLL_EXT_HO_CLK_CFREQ]           = {.key = "spll/ext/ho/clk_cfreq",
							.modir_oid = 8430, .prm_oid = 5},
	[HALD_SOFTPLL_EXT_HO_FPO_DETECTED]        = {.key = "spll/ext/ho/fpo_detected",
							.modir_oid = 8430, .prm_oid = 11},
	[HALD_SOFTPLL_EXT_HO_ENABLED]             = {.key = "spll/ext/ho/enabled",
							.modir_oid = 8430, .prm_oid = 12},
	[HALD_SOFTPLL_EXT_HO_STATE]               = {.key = "spll/ext/ho/state",
							.modir_oid = 8430, .prm_oid = 13},
	[HALD_SOFTPLL_EXT_HO_TRIG_ORIGIN]         = {.key = "spll/ext/ho/trig_origin",
							.modir_oid = 8430, .prm_oid = 14},
	[HALD_SOFTPLL_EXT_HO_STATE_TIME]          = {.key = "spll/ext/ho/state_time",
							.modir_oid = 8430, .prm_oid = 15},
	[HALD_SOFTPLL_EXT_HO_TRIG_TIME]           = {.key = "spll/ext/ho/trig_time",
							.modir_oid = 8430, .prm_oid = 16},
	[HALD_SOFTPLL_EXT_HO_READY_TLAPSE]        = {.key = "spll/ext/ho/ready_tlapse",
							.modir_oid = 8430, .prm_oid = 17},
	[HALD_SOFTPLL_EXT_HO_EXPIRED_TLAPSE]      = {.key = "spll/ext/ho/expired_tlapse",
							.modir_oid = 8430, .prm_oid = 18},
	[HALD_SOFTPLL_EXT_HO_RUN]                 = {.key = "spll/ext/ho/run",
							.modir_oid = 8430, .prm_oid = 30},
	[HALD_SOFTPLL_EXT_HO_TRIG_FORCE_EXT_TRIG] = {.key = "spll/ext/ho/trig/force_ext_trig",
							.modir_oid = 8430, .prm_oid = 31},
	[HALD_SOFTPLL_EXT_HO_TRIG_INTERNAL_EN]    = {.key = "spll/ext/ho/trig/internal_en",
							.modir_oid = 8431, .prm_oid = 22},
	[HALD_SOFTPLL_EXT_HO_TRIG_PPS_THRESHOLD]  = {.key = "spll/ext/ho/trig/pps_threshold",
							.modir_oid = 8431, .prm_oid = 23},
	[HALD_SOFTPLL_EXT_HO_TRIG_PPS_TLAPSE]     = {.key = "spll/ext/ho/trig/pps_tlapse",
							.modir_oid = 8431, .prm_oid = 24},
	[HALD_SOFTPLL_EXT_HO_TRIG_CLK_THRESHOLD]  = {.key = "spll/ext/ho/trig/clk_threshold",
							.modir_oid = 8431, .prm_oid = 25},
	[HALD_SOFTPLL_EXT_HO_TRIG_CLK_TLAPSE]     = {.key = "spll/ext/ho/trig/clk_tlapse",
						        .modir_oid = 8431, .prm_oid = 26},

	[HALD_PPSYNC_AD_SYNC]                     = {.key = "timing_output/sync_ad9516",
						        .modir_oid = 1800, .prm_oid = 4},
	[HALD_PPSYNC_LMK_SYNC]                    = {.key = "timing_output/sync_lmk",
						        .modir_oid = 1800, .prm_oid = 5},


	/* HOLDOVER trigger parameters */
	/* Not defined yet
	[HALD_HO_TRIGGER_LINK_DOWN_ENABLED] = {
				.key = "ho_trigger_link_down_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_PPS_DRIFT_ENABLED] = {
				.key = "ho_trigger_pps_drift_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_PPS_DRIFT_PHASE_THRESHOLD] = {
				.key = "ho_trigger_pps_drift_phase_threshold",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_PPS_DRIFT_TIMELAPSE] = {
				.key = "ho_trigger_pps_drift_timelapse",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_CLK_DRIFT_ENABLED] = {
				.key = "ho_trigger_clk_drift_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_CLK_DRIFT_PHASE_THRESHOLD] = {
				.key = "ho_trigger_clk_drift_phase_threshold",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_CLK_DRIFT_TIMELAPSE] = {
				.key = "ho_trigger_clk_drift_timelapse",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_PPS_DRIFT_ENABLED] = {
				.key = "ho_trigger_gm_pps_drift_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_PPS_DRIFT_PHASE_THRESHOLD] = {
				.key = "ho_trigger_gm_pps_drift_phase_threshold",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_PPS_DRIFT_TIMELAPSE] = {
				.key = "ho_trigger_gm_pps_drift_timelapse",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_CLK_DRIFT_ENABLED] = {
				.key = "ho_trigger_gm_clk_drift_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_CLK_DRIFT_PHASE_THRESHOLD] = {
				.key = "ho_trigger_gm_clk_drift_phases_threshold",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_GM_CLK_DRIFT_TIMELAPSE] = {
				.key = "ho_trigger_gm_clk_drift_timelapse",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_BMC_ENABLED] = {
				.key = "ho_trigger_bmc_enabled",
				.modir_oid = 1, .prm_oid = 0},
	[HALD_HO_TRIGGER_BMC_CLK_QUALITY_THRESHOLD] = {
				.key = "ho_trigger_clk_quality_threshold",
				.modir_oid = 1, .prm_oid = 0},
	*/
};

static struct gpa_mod *hald_mod;


/************************************************************
 * Public API                                               *
 ************************************************************/

struct param_def *hald_init(void)
{
	int i;

	if (initialized)
		return hald_params;

	/* Create user connected to the HALD module */
	hald_mod = gpa_mod_create_user(HALD_MODULE_ID,
				gpa_user_gen_readonly, (uint16_t)getppid(),
				GPA_MOD_FLAG_MB_WRITE);

	if (!hald_mod) {
		pr_error("Can't connect to the hald module "
			"(is it running?)\n");
		return 0;
	}

	/* Subscribe to parameters */
	for (i = 0; i < N_HALD_PARAMS; i++) {
		hald_params[i].param = gpa_mod_prm_subscribe(
			hald_mod, hald_params[i].modir_oid,
			hald_params[i].prm_oid);
	}
	initialized = 1;

	return hald_params;
}


/********** Getter functions **********/

int hald_get_ver_product(char *product, size_t size)
{
	if(!product) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	gpa_prm_val_tostr_r(hald_params[HALD_VER_PRODUCT].param, product, size);
	if(errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}

	return 0;
}


/**** GM Healthy parameters ****/

#if 0
int hald_get_gm_pps_present(int *present)
{
	int aux;

	if (!present) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_GM_PPS_PRESENT].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*present = aux;
	}

	return 0;
}


int hald_get_gm_clk_present(int *present)
{
	int aux;

	if (!present) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_GM_CLK_PRESENT].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*present = aux;
	}

	return 0;
}


int hald_get_gm_clk_frequency(int32_t *freq)
{
	int32_t aux;

	if (!freq) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_GM_CLK_FREQ].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*freq = aux;
	}

	return 0;
}

int hald_get_gm_pps_drift(int32_t *drift)
{
	int32_t aux;

	if (!drift) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_GM_PPS_DRIFT].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*drift = aux;
	}

	return 0;
}
#endif


/* SoftPLL parameters */

int hald_get_softpll_mode(enum softpll_mode *mode)
{
	uint16_t aux;

	if (!mode) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_MODE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_SOFTPLL_MODES) {
			pr_error("Invalid mode %u\n", aux);
			return 1;
		}
		*mode = aux;
	}

	return 0;
}

int hald_get_softpll_update(uint32_t *update)
{
	uint32_t aux;

	if (!update) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_UPDATE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*update = aux;
	}

	return 0;
}

int hald_get_softpll_seq_state(enum softpll_seq_state *state)
{
	uint16_t aux;

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_SEQ_STATE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_SOFTPLL_SEQ_STATES) {
			pr_error("Invalid state %u\n", aux);
			return 1;
		}
		*state = aux;
	}

	return 0;
}

int hald_get_softpll_n_delock(uint32_t *delock)
{
	uint32_t aux;

	if (!delock) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_N_DELOCK].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*delock = aux;
	}

	return 0;
}

int hald_get_softpll_info_version(uint32_t *version)
{
	uint32_t aux;

	if (!version) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_INFO_VERSION].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*version = aux;
	}

	return 0;
}

int hald_get_softpll_mpll_locked(uint32_t *locked)
{
	uint32_t aux;

	if (!locked) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_MPLL_LOCKED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*locked = aux;
	}

	return 0;
}

int hald_get_softpll_mpll_pi_y(uint32_t *pi_y)
{
	uint32_t aux;

	if (!pi_y) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_MPLL_PI_Y].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*pi_y = aux;
	}

	return 0;
}

int hald_get_softpll_hpll_locked(uint32_t *locked)
{
	uint32_t aux;

	if (!locked) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_HPLL_LOCKED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*locked = aux;
	}

	return 0;
}

int hald_get_softpll_hpll_pi_y(uint32_t *pi_y)
{
	uint32_t aux;

	if (!pi_y) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_HPLL_PI_Y].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*pi_y = aux;
	}

	return 0;
}

int hald_get_softpll_ext_src_id(enum softpll_ext_src_id *id)
{
	uint16_t aux;

	if (!id) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_SRC_ID].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_SOFTPLL_EXT_SRC_IDS) {
			pr_error("Invalid id %u\n", aux);
			return 1;
		}
		*id = aux;
	}

	return 0;
}

int hald_get_softpll_ext_align_state(enum softpll_align_state *state)
{
	uint16_t aux;

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_ALIGN_STATE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_SOFTPLL_ALIGN_STATES) {
			pr_error("Invalid state %u\n", aux);
			return 1;
		}
		*state = aux;
	}

	return 0;
}

int hald_get_softpll_ext_align_pps(int *align)
{
	int aux;

	if (!align) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_SOFTPLL_EXT_ALIGN_PPS].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*align = aux;
	}

	return 0;
}

int hald_get_softpll_ext_user_offset(int32_t *offset)
{
	int32_t aux;

	if (!offset) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_SOFTPLL_EXT_USER_OFFSET].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*offset = aux;
	}

	return 0;
}

int hald_get_softpll_ext_fpanel_detected(enum softpll_ext_fpanel *fpanel)
{
	uint16_t aux;

	if (!fpanel) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_FPANEL_DETECTED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_SOFTPLL_EXT_FPANEL) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*fpanel = aux;
	}

	return 0;
}

int hald_get_softpll_ext_fpanel_pps_delta(int32_t *delta)
{
	int32_t aux;

	if (!delta) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_SOFTPLL_EXT_FPANEL_PPS_DELTA].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*delta = aux;
	}

	return 0;
}

int hald_get_softpll_ext_fpanel_clk_cfreq(uint32_t *cfreq)
{
	uint32_t aux;

	if (!cfreq) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_FPANEL_CLK_CFREQ].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*cfreq = aux;
	}

	return 0;
}


/* SoftPLL Holdover parameters */

int hald_get_softpll_ho_detected(enum ho_detected *detected)
{
	uint16_t aux;

	if (!detected) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_DETECTED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_HO_DETECTED_STATES) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*detected = aux;
	}

	return 0;
}

int hald_get_softpll_ho_pps_delta(int32_t *delta)
{
	int32_t aux;

	if (!delta) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_SOFTPLL_EXT_HO_PPS_DELTA].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*delta = aux;
	}

	return 0;
}

int hald_get_softpll_ho_clk_cfreq(uint32_t *cfreq)
{
	uint32_t aux;

	if (!cfreq) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_CLK_CFREQ].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*cfreq = aux;
	}

	return 0;
}

int hald_get_softpll_ho_fpo_detected(uint16_t *detected)
{
	uint16_t aux;

	if (!detected) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_FPO_DETECTED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*detected = aux;
	}

	return 0;
}

int hald_get_softpll_ho_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_SOFTPLL_EXT_HO_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_softpll_ho_state(enum ho_state *state)
{
	uint16_t aux;

	if (!state) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_STATE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_HO_STATES) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*state = aux;
	}

	return 0;
}


/*
int hald_holdover_in_warning_state(void)
{
	enum ho_state state;

	hald_get_softpll_ho_state(&state);

	switch (state) {
	case HO_UNAVAILABLE:
	case HO_LOCKING:
	case HO_LEARNING:
		case HO_ACTIVATED:
		break;
		break;
	}
}
*/

/*
char *hald_holdover_status_msg(void)
{
	char *msg;
	enum ho_state state;
	uint16_t detected;

	if (hald_get_softpll_ho_fpo_detected(&detected)) {
		pr_warning("Error detecting Holdover presence\n");
		return "";
	}
	if (hald_get_softpll_ho_state(&state)) {
		pr_warning("Error getting Holdover status\n");
		return "";
	}

	switch (state) {
	case HO_UNAVAILABLE:
		msg = "Not available";
		break;
	case HO_DISABLED:
		msg = "Disabled";
		break;
	case HO_LOCKING:
		msg = "Locking";
		break;
	case HO_LEARNING:
		msg = "Learning";
		break;
	case HO_READY:
		msg = "Ready";
		break;
	case HO_ACTIVATED:
		msg = "Activated";
		break;
	case HO_EXPIRED:
		msg = "Expired";
		break;
	case N_HO_STATES:
	default:
		msg = "Invalid state";
		break;
	}

	return msg;
}
*/

int hald_get_softpll_ho_trig_origin(enum ho_trig *orig)
{
	uint16_t aux;

	if (!orig) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_ORIGIN].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_HO_TRIGGERS) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*orig = aux;
	}

	return 0;
}

int hald_get_softpll_ho_state_time(uint32_t *time)
{
	uint32_t aux;

	if (!time) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_STATE_TIME].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*time = aux;
	}

	return 0;
}

int hald_get_softpll_ho_trig_time(uint32_t *time)
{
	uint32_t aux;

	if (!time) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_TIME].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*time = aux;
	}

	return 0;
}

int hald_get_softpll_ho_ready_tlapse(uint32_t *tlapse)
{
	uint32_t aux;

	if (!tlapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_READY_TLAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*tlapse = aux;
	}

	return 0;
}

int hald_get_softpll_ho_expired_tlapse(uint32_t *tlapse)
{
	uint32_t aux;

	if (!tlapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_EXPIRED_TLAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*tlapse = aux;
	}

	return 0;
}

int hald_get_softpll_ho_run(int *run)
{
	int aux;

	if (!run) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_SOFTPLL_EXT_HO_RUN].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*run = aux;
	}

	return 0;
}



int hald_get_softpll_ho_trig_force_ext_trig(enum ho_trig *force)
{
	uint16_t aux;

	if (!force) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_FORCE_EXT_TRIG].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		if (aux >= N_HO_TRIGGERS) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*force = aux;
	}

	return 0;
}

int hald_get_softpll_ho_trig_internal_en(uint16_t *enable)
{
	uint16_t aux;

	if (!enable) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u16(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_INTERNAL_EN].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	} else {
		*enable = aux;
	}
	/*
	else {
		if (aux >= N_HO_TRIGGERS) {
			pr_error("Invalid value %u\n", aux);
			return 1;
		}
		*enable = aux;
	}
	*/

	return 0;
}

int hald_get_softpll_ho_trig_pps_threshold(uint32_t *thres)
{
	uint32_t aux;

	if (!thres) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_PPS_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*thres = aux;
	}

	return 0;
}

int hald_get_softpll_ho_trig_pps_tlapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_PPS_TLAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}

int hald_get_softpll_ho_trig_clk_threshold(uint32_t *thres)
{
	uint32_t aux;

	if (!thres) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_CLK_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*thres = aux;
	}

	return 0;
}

int hald_get_softpll_ho_trig_clk_tlapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_SOFTPLL_EXT_HO_TRIG_CLK_TLAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}


/* HOLDOVER trigger parameters */

/*
 * TODO: Undefined parameters. Remove if they're not necessary.
 */

#if 0

int hald_get_ho_trigger_link_down_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_LINK_DOWN_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_pps_drift_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_PPS_DRIFT_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_pps_drift_phase_threshold(int32_t *threshold)
{
	int32_t aux;

	if (!threshold) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_HO_TRIGGER_PPS_DRIFT_PHASE_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*threshold = aux;
	}

	return 0;
}

int hald_get_ho_trigger_pps_drift_timelapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_HO_TRIGGER_PPS_DRIFT_TIMELAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}

int hald_get_ho_trigger_clk_drift_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_CLK_DRIFT_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_clk_drift_phase_threshold(int32_t *threshold)
{
	int32_t aux;

	if (!threshold) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_HO_TRIGGER_CLK_DRIFT_PHASE_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*threshold = aux;
	}

	return 0;
}

int hald_get_ho_trigger_clk_drift_timelapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_HO_TRIGGER_CLK_DRIFT_TIMELAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_pps_drift_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_pps_drift_phase_threshold(int32_t *threshold)
{
	int32_t aux;

	if (!threshold) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_PHASE_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*threshold = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_pps_drift_timelapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_TIMELAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_clk_drift_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_clk_drift_phase_threshold(int32_t *threshold)
{
	int32_t aux;

	if (!threshold) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_i32(hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_PHASE_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*threshold = aux;
	}

	return 0;
}

int hald_get_ho_trigger_gm_clk_drift_timelapse(uint32_t *lapse)
{
	uint32_t aux;

	if (!lapse) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_TIMELAPSE].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*lapse = aux;
	}

	return 0;
}

int hald_get_ho_trigger_bmc_enabled(int *enabled)
{
	int aux;

	if (!enabled) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_bool(hald_params[HALD_HO_TRIGGER_BMC_ENABLED].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*enabled = aux;
	}

	return 0;
}

int hald_get_ho_trigger_bmc_clk_quality_threshold(uint32_t *threshold)
{
	uint32_t aux;

	if (!threshold) {
		pr_error("NULL output parameter\n");
		return 1;
	}

	errno = 0;
	aux = gpa_prm_get_u32(hald_params[HALD_HO_TRIGGER_BMC_CLK_QUALITY_THRESHOLD].param);
	if (errno) {
		pr_error("Error getting parameter\n");
		return 1;
	}
	else {
		*threshold = aux;
	}

	return 0;
}

#endif



/********** Setter functions **********/


/**** GM Healthy parameters ****/

#if 0
int hald_set_gm_pps_present(int present)
{
	char *state;

	if (present)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_GM_PPS_PRESENT].param, state);
}

int hald_set_gm_clk_present(int present)
{
	char *state;

	if (present)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_GM_CLK_PRESENT].param, state);
}

int hald_set_gm_clk_frequency(int32_t freq)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_GM_CLK_FREQ].param, freq);
}

int hald_set_gm_pps_drift(int32_t drift)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_GM_CLK_FREQ].param, drift);
}
#endif

/**** LED parameters ****/

int hald_set_led_mode(enum led_id id, enum led_mode mode)
{
	enum hald_params_enum led_prm;

	if(mode >= N_LED_MODE) {
		pr_warn("Invalid LED mode %d\n", mode);
		return 1;
	}

	switch(id) {
	case LED_ID_STATUS:
		led_prm = HALD_LEDS_STATUS_MODE;
		break;
	case LED_ID_IN:
		led_prm = HALD_LEDS_IN_MODE;
		break;
	case LED_ID_OUT:
		led_prm = HALD_LEDS_OUT_MODE;
		break;
	default:
		pr_warn("Invalid LED ID %d\n", id);
		return 1;
	};
	return gpa_mod_prm_snd_u16(hald_mod,
				hald_params[led_prm].param, mode);
}

int hald_set_led_color(enum led_id id, enum led_color color)
{
	enum hald_params_enum led_prm;

	if(color >= N_LED_COLOR) {
		pr_warn("Invalid LED color %d\n", color);
		return 1;
	}

	switch(id) {
	case LED_ID_STATUS:
		led_prm = HALD_LEDS_STATUS_COLOR;
		break;
	case LED_ID_IN:
		led_prm = HALD_LEDS_IN_COLOR;
		break;
	case LED_ID_OUT:
		led_prm = HALD_LEDS_OUT_COLOR;
		break;
	default:
		pr_warn("Invalid LED ID %d\n", id);
		return 1;
	};

	return gpa_mod_prm_snd_u16(hald_mod,
				hald_params[led_prm].param, color);
}

int hald_set_led_width(enum led_id id, uint32_t width)
{
	enum hald_params_enum led_prm;

	if(width >= LED_WIDTH_MAX) {
		pr_warn("Invalid LED width %d\n", width);
		return 1;
	}

	switch(id) {
	case LED_ID_STATUS:
		led_prm = HALD_LEDS_STATUS_WIDTH;
		break;
	case LED_ID_IN:
		led_prm = HALD_LEDS_IN_WIDTH;
		break;
	case LED_ID_OUT:
		led_prm = HALD_LEDS_OUT_WIDTH;
		break;
	default:
		pr_warn("Invalid LED ID %d\n", id);
		return 1;
	};

	return gpa_mod_prm_snd_u32(hald_mod,
				hald_params[led_prm].param, width);
}

int hald_update_led(enum led_id id)
{
	enum hald_params_enum led_prm;

	switch(id) {
	case LED_ID_STATUS:
		led_prm = HALD_LEDS_STATUS_LOAD;
		break;
	case LED_ID_IN:
		led_prm = HALD_LEDS_IN_LOAD;
		break;
	case LED_ID_OUT:
		led_prm = HALD_LEDS_OUT_LOAD;
		break;
	default:
		pr_warn("Invalid LED ID %d\n", id);
		return 1;
	};

	return gpa_mod_prm_snd_u32(hald_mod,
				hald_params[led_prm].param, 1);
}

/**** PPS mode parameters ****/

int hald_set_pps_mode_controller(enum pps_mode_controller mc)
{
	if(mc < 0 || mc >= N_PPS_MODE_CONTROLLER) {
		pr_error("Invalid PPS mode controller %d\n", mc);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_PPS_MODE_CONTROLLER].param, mc);
}

int hald_set_pps_mode_state_tmgr(int state)
{
	char *s;

	if (state)
		s = "1";
	else
		s = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_PPS_MODE_STATE_TMGR].param, s);
}

/* SoftPLL parameters */

int hald_set_softpll_mode(enum softpll_mode mode)
{
	if (mode < 0 || mode >= N_SOFTPLL_MODES) {
		pr_error("Invalid SoftPLL mode %d\n", mode);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_MODE].param, mode);
}

int hald_set_softpll_ext_src_id(enum softpll_ext_src_id id)
{
	if (id < 0 || id >= N_SOFTPLL_EXT_SRC_IDS) {
		pr_error("Invalid external src id %d\n", id);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_SRC_ID].param, id);
}

int hald_set_softpll_ext_align_pps(int align)
{
	char *state;

	if (align)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_ALIGN_PPS].param, state);
}

int hald_set_softpll_ext_user_offset(int32_t offset)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_USER_OFFSET].param, offset);
}


/* SoftPLL Holdover parameters */

int hald_set_softpll_ho_detected(enum ho_detected detected)
{
	if (detected < 0 || detected >= N_HO_DETECTED_STATES) {
		pr_error("Invalid SoftPLL Holdover detected value %d\n",
			detected);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_DETECTED].param, detected);
}

int hald_set_softpll_ho_pps_delta(int32_t delta)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_PPS_DELTA].param, delta);
}

int hald_set_softpll_ho_clk_cfreq(uint32_t cfreq)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_CLK_CFREQ].param, cfreq);
}

int hald_set_softpll_ho_fpo_detected(uint16_t detected)
{
	return gpa_mod_prm_snd_u16(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_FPO_DETECTED].param, detected);
}

int hald_set_softpll_ho_enabled(int enabled)
{
	char *state;

	if (enabled)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_ENABLED].param, state);
}

int hald_set_softpll_ho_state(enum ho_state state)
{
	if (state < 0 || state >= N_HO_STATES) {
		pr_error("Invalid SoftPLL Holdover state %d\n",
			state);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_STATE].param, state);
}

int hald_set_softpll_ho_trig_origin(enum ho_trig orig)
{
	if (orig < 0 || orig >= N_HO_TRIGGERS) {
		pr_error("Invalid SoftPLL Holdover trigger origin %d\n",
			orig);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_ORIGIN].param, orig);
}

int hald_set_softpll_ho_state_time(uint32_t time)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_STATE_TIME].param, time);
}

int hald_set_softpll_ho_trig_time(uint32_t time)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_TIME].param, time);
}

int hald_set_softpll_ho_ready_tlapse(uint32_t tlapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_READY_TLAPSE].param, tlapse);
}

int hald_set_softpll_ho_expired_tlapse(uint32_t tlapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_EXPIRED_TLAPSE].param, tlapse);
}

int hald_set_softpll_ho_run(int run)
{
	char *state;

	if (run)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_RUN].param, state);
}

int hald_set_softpll_ho_trig_force_ext_trig(enum ho_trig force)
{
	if (force < 0 || force >= N_HO_TRIGGERS) {
		pr_error("Invalid SoftPLL Holdover trigger %d\n",
			force);
		return 1;
	}

	return gpa_mod_prm_snd_enum(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_FORCE_EXT_TRIG].param, force);
}

int hald_set_softpll_ho_trig_internal_en(uint16_t enable)
{
	/*
	if (enable < 0 || enable >= N_HO_TRIGGERS) {
		pr_error("Invalid SoftPLL Holdover trigger enable type %d\n",
			enable);
		return 1;
	}
	*/

	return gpa_mod_prm_snd_u16(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_FORCE_EXT_TRIG].param, enable);
}

int hald_set_softpll_ho_trig_pps_threshold(uint32_t thres)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_PPS_THRESHOLD].param,
		thres);
}

int hald_set_softpll_ho_trig_pps_tlapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_PPS_TLAPSE].param, lapse);
}

int hald_set_softpll_ho_trig_clk_threshold(uint32_t thres)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_CLK_THRESHOLD].param,
		thres);
}

int hald_set_softpll_ho_trig_clk_tlapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_SOFTPLL_EXT_HO_TRIG_CLK_TLAPSE].param, lapse);
}

int hald_sync_plls(void)
{
	int ret;
	int32_t s;

	s = gpa_prm_get_i32(hald_params[HALD_PPSYNC_AD_SYNC].param);
	ret = gpa_mod_prm_snd_i32(hald_mod,
			hald_params[HALD_PPSYNC_AD_SYNC].param, s);
	if(ret) {
		pr_error("Error sending sync to AD (%d)\n",ret);
		return ret;
	}

	s = gpa_prm_get_i32(hald_params[HALD_PPSYNC_LMK_SYNC].param);
	ret = gpa_mod_prm_snd_i32(hald_mod,
			hald_params[HALD_PPSYNC_LMK_SYNC].param, s);
	if(ret) {
		pr_error("Error sending sync to LMK (%d)\n",ret);
	}

	return ret;
}


/* HOLDOVER trigger parameters */

/*
 * TODO: Undefined parameters. Remove if they're not necessary.
 */
#if 0

int hald_set_ho_trigger_link_down_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_LINK_DOWN_ENABLED].param, state);
}

int hald_set_ho_trigger_pps_drift_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_PPS_DRIFT_ENABLED].param, state);
}

int hald_set_ho_trigger_pps_drift_phase_threshold(int32_t threshold)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_HO_TRIGGER_PPS_DRIFT_PHASE_THRESHOLD].param,
		threshold);
}

int hald_set_ho_trigger_pps_drift_timelapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_HO_TRIGGER_PPS_DRIFT_TIMELAPSE].param, lapse);
}

int hald_set_ho_trigger_clk_drift_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_CLK_DRIFT_ENABLED].param, state);
}

int hald_set_ho_trigger_clk_drift_phase_threshold(int32_t threshold)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_HO_TRIGGER_CLK_DRIFT_PHASE_THRESHOLD].param,
		threshold);
}

int hald_set_ho_trigger_clk_drift_timelapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_HO_TRIGGER_CLK_DRIFT_TIMELAPSE].param, lapse);
}

int hald_set_ho_trigger_gm_pps_drift_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_ENABLED].param, state);
}

int hald_set_ho_trigger_gm_pps_drift_phase_threshold(int32_t threshold)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_PHASE_THRESHOLD].param,
		threshold);
}

int hald_set_ho_trigger_gm_pps_drift_timelapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_PPS_DRIFT_TIMELAPSE].param, lapse);
}

int hald_set_ho_trigger_gm_clk_drift_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_ENABLED].param, state);
}

int hald_set_ho_trigger_gm_clk_drift_phase_threshold(int32_t threshold)
{
	return gpa_mod_prm_snd_i32(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_PHASE_THRESHOLD].param,
		threshold);
}

int hald_set_ho_trigger_gm_clk_drift_timelapse(uint32_t lapse)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_HO_TRIGGER_GM_CLK_DRIFT_TIMELAPSE].param, lapse);
}

int hald_set_ho_trigger_bmc_enabled(int set)
{
	char *state;

	if (set)
		state = "1";
	else
		state = "0";

	return gpa_mod_prm_snd_fromstr(hald_mod,
		hald_params[HALD_HO_TRIGGER_BMC_ENABLED].param, state);
}

int hald_set_ho_trigger_bmc_clk_quality_threshold(uint32_t threshold)
{
	return gpa_mod_prm_snd_u32(hald_mod,
		hald_params[HALD_HO_TRIGGER_BMC_CLK_QUALITY_THRESHOLD].param,
		threshold);
}

#endif


#ifndef __KTMGR_H__
#define __KTMGR_H__

/*
 * ktmgr.h
 *
 * API to access the ktmgr module interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Oct 11, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

/*
 * ktmgr interface.
 *
 * Provides functions to get and set ktmgr attributes.
 */


enum ktmgr_attrs{
	KTMGR_CLK_CLASS,
	KTMGR_CLK_ACCURACY,
	KTMGR_CLK_VARIANCE,
	KTMGR_CURRENT_UTC_OFFSET,
	KTMGR_CURRENT_UTC_OFFSET_VALID,
	KTMGR_PRIORITY1,
	KTMGR_PRIORITY2,
	KTMGR_TIMESOURCE,
	KTMGR_LEAP_SECOND,
	KTMGR_LEAP_59,
	KTMGR_LEAP_61,
	KTMGR_ENABLE_ALIGN,
	KTMGR_UTC_REASONABLE,
	KTMGR_FREQ_VALID,
	KTMGR_TIME_VALID,
	KTMGR_TM_LOCKSTATE,
	KTMGR_UPDATE,

	N_KTMGR_ATTRS
};


/*
 * ktmgr_init
 *
 * Initializes the ktmgr module.
 *
 * Returns:
 *   0 if the module was correctly initialized.
 *   1 otherwise.
 */
int ktmgr_init(void);


/*
 * ktmgr_get_attr
 *
 * Gets the value of a ktmgr attribute.
 *
 * Parameters:
 *   attr: The attribute identifier (enum ktmgr_attrs)
 *   ret (output): A pointer to an existing integer to hold the retrieved value.
 *
 * Returns:
 *   0 if the attribute could be retrieved
 *   1 otherwise.
 *
 * Notes:
 *   The ktmgr module must be initialized (ktmgr_init) before using this
 *   function.
 */
int ktmgr_get_attr(enum ktmgr_attrs attr, long *ret);


/*
 * ktmgr_set_attr
 *
 * Sets the value of a ktmgr attribute.
 *
 * Parameters:
 *   attr: The attribute identifier (enum ktmgr_attrs)
 *   val : The value to set.
 *
 * Returns:
 *   0 if the attribute could be set
 *   1 otherwise.
 *
 * Notes:
 *   The ktmgr module must be initialized (ktmgr_init) before using this
 *   function.
 */
int ktmgr_set_attr(enum ktmgr_attrs attr, long val);

#endif


/*
 * ktmgr.c
 *
 * API to access the ktmgr module interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Oct 11, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <libgpa.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#include "ktmgr.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define KTMGR_SYSFS_DIR "/sys/kernel/ktmgr"
#define BUF_SIZE 100

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static int initialized;

char *ktmgr_files[] = {
	[KTMGR_CLK_CLASS]                = KTMGR_SYSFS_DIR"/clock_class",
	[KTMGR_CLK_ACCURACY]             = KTMGR_SYSFS_DIR"/clock_accuracy",
	[KTMGR_CLK_VARIANCE]             = KTMGR_SYSFS_DIR"/clock_variance",
	[KTMGR_CURRENT_UTC_OFFSET]       = KTMGR_SYSFS_DIR"/current_utc_offset",
	[KTMGR_CURRENT_UTC_OFFSET_VALID] = KTMGR_SYSFS_DIR"/current_utc_offset_valid",
	[KTMGR_PRIORITY1]                = KTMGR_SYSFS_DIR"/priority1",
	[KTMGR_PRIORITY2]                = KTMGR_SYSFS_DIR"/priority2",
	[KTMGR_TIMESOURCE]               = KTMGR_SYSFS_DIR"/timesource",
	[KTMGR_LEAP_SECOND]              = KTMGR_SYSFS_DIR"/leap_second",
	[KTMGR_LEAP_59]                  = KTMGR_SYSFS_DIR"/leap_59",
	[KTMGR_LEAP_61]                  = KTMGR_SYSFS_DIR"/leap_61",
	[KTMGR_ENABLE_ALIGN]             = KTMGR_SYSFS_DIR"/enable_align",
	[KTMGR_UTC_REASONABLE]           = KTMGR_SYSFS_DIR"/utc_reasonable",
	[KTMGR_FREQ_VALID]               = KTMGR_SYSFS_DIR"/freq_traceable",
	[KTMGR_TIME_VALID]               = KTMGR_SYSFS_DIR"/time_traceable",
	[KTMGR_TM_LOCKSTATE]             = KTMGR_SYSFS_DIR"/tm_lockstate",
	[KTMGR_UPDATE]                   = KTMGR_SYSFS_DIR"/update"
};


/************************************************************
 * Private functions                                        *
 ************************************************************/


/************************************************************
 * Public API                                               *
 ************************************************************/

int ktmgr_init(void)
{
	DIR *dir;

	if (initialized) {
		pr_info("ktmgr module already initialized.\n");
		return 0;
	}

	/*
	 * This function checks if the ktmgr kernel module is installed by
	 * trying to read the sysfs directory created by it.
	 */
	if (!(dir = opendir(KTMGR_SYSFS_DIR))) {
		pr_warning("Can't initialize the ktmgr module. "
			"Maybe the ktmgr kernel module is not loaded?\n");
		return 1;
	}
	closedir(dir);
	initialized = 1;

	return 0;
}

int ktmgr_get_attr(enum ktmgr_attrs attr, long *ret)
{
	int fd;
	char buf[BUF_SIZE] = {0};

	if (!initialized) {
		pr_warning("ktmgr module not initialized.\n");
		return 1;
	}

	if (attr < 0 || attr >= N_KTMGR_ATTRS) {
		pr_warning("Undefined ktmgr attribute %d\n", attr);
		return 1;
	}

	fd = open(ktmgr_files[attr], O_RDONLY);
	if (fd < 0) {
		pr_warning("Can't open file %s\n", ktmgr_files[attr]);
		return 1;
	}

	if (read(fd, buf, BUF_SIZE - 1) < 0) {
		pr_warning("Can't read file %s\n", ktmgr_files[attr]);
		close(fd);
		return 1;
	}

	*ret = strtol(buf, 0, 0);
	close(fd);

	return 0;
}

int ktmgr_set_attr(enum ktmgr_attrs attr, long val)
{
	int fd;
	char buf[BUF_SIZE] = {0};
	struct timespec ts = {.tv_sec = 2, .tv_nsec = 0};

	if (!initialized) {
		pr_warning("ktmgr module not initialized.\n");
		return 1;
	}

	if (attr < 0 || attr >= N_KTMGR_ATTRS) {
		pr_warning("Undefined ktmgr attribute %d\n", attr);
		return 1;
	}

	fd = open(ktmgr_files[attr], O_WRONLY);
	if (fd < 0) {
		pr_warning("Can't open file %s\n", ktmgr_files[attr]);
		return 1;
	}

	snprintf(buf, BUF_SIZE - 1, "%ld", val);
	if (write(fd, buf, strlen(buf)) < 0) {
		pr_warning("Can't write to %s (wrong value?)\n",
			ktmgr_files[attr]);
		close(fd);
		return 1;
	}

	close(fd);

	/*
	 * Workaround to mitigate ktmgr parameter loading-related bugs: wait a
	 * bit after writing the update parameter.
	 */
	if (attr == KTMGR_UPDATE)
		nanosleep(&ts, 0);

	return 0;
}

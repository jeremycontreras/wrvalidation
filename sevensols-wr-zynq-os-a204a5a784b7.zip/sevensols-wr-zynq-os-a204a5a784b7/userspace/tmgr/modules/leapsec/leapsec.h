#ifndef __LEAPSEC_H__
#define __LEAPSEC_H__


enum leapsec_exp_status {
	/* Leap-second files are valid */
	LEAPSEC_EXP_OK,

	/*
	 * Files non-existent, can't be read or don't have an expiration date.
	 */
	LEAPSEC_EXP_ERROR,

	/* Files have expired */
	LEAPSEC_EXP_EXPIRED,
};


/*
 * Returns the greatest expiration date found in the leap-seconds files.
 *
 * Returns:
 *
 *   The expiration date in seconds.
 *
 *   -1 if the system leap-second file doesn't exist, can't be read,
 *      doesn't contain an expiration date or if the expiration date is
 *      earlier than the UNIX epoch.
 */
int64_t leapsec_get_expiration_date(void);


/*
 * Returns the status of the leap-second files.
 *
 * Returns:
 *   - LEAPSEC_EXP_OK:      If the files are valid.
 *
 *   - LEAPSEC_EXP_ERROR:   If the files don't exist, can't be read or don't
 *                          have an expiration date.
 *
 *   - LEAPSEC_EXP_EXPIRED: If the files have expired.
 */
enum leapsec_exp_status leapsec_check_expiration_date(void);

#endif

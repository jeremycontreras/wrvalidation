/*
 * leapsec.c
 *
 * Utility functions to check the validity (expiration date) of the leap seconds
 * files.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Sep 13, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */



#include <unistd.h>
#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <sys/time.h>
#include <libgpa.h>

#include "leapsec.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define LEAPSEC_SYSTEM_FILE "/etc/leap-seconds.list"

// Real path: "/usr/local/etc/custom-leap-seconds.list" (copied from /media/data/usr/local/etc)
#define LEAPSEC_USER_FILE   "/etc/custom-leap-seconds.list"

/*
 * The date functions in the C standard library use 32-bit time_t values, so
 * there's no way to get them to compute this number in a reliable and portable
 * way.
 *
 * This was computed in a 64-bit machine and it takes leap years into account.
 */
#define SECS_FROM_1900_TO_1970 2208988800ll


/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Returns the expiration date from the file path passed as a parameter.
 *
 * The file should be one of the leap seconds list provided by the IETF, where
 * the expiration date is a value in seconds in a line by itself starting with
 * "#@" and a hard tab.
 *
 * Parameters:
 *   - file: The path of the leap-seconds list
 *
 * Returns:
 *   The expiration date in seconds.
 *   0 if the file doesn't exist, if it can't be read or if it doesn't contain
 *     an expiration date.
 */
static int64_t leapsec_get_file_expiration_date(char *file)
{
	FILE *fp;
	size_t read_size;
	ssize_t ret;
	char *line = 0;
	int64_t leap = 0;

	if (!file)
		return 0;

	if (access(file, F_OK)) {
		return 0;
	}

	fp = fopen(file, "r");
	if (!fp) {
		return 0;
	}

	while ((ret = getline(&line, &read_size, fp)) > -1) {
		if (line[0] == '#' && line[1] == '@') {
			sscanf(line, "#@\t%" PRId64 "\n", &leap);
			if (leap > 0)
				break;
		}
	}
	free(line);
	fclose(fp);

	return leap;
}

/************************************************************
 * Public API                                               *
 ************************************************************/

int64_t leapsec_get_expiration_date(void)
{
	int64_t expiration_system;
	int64_t expiration_user;
	int64_t exp_date;

	/*
	 * Get the greater expiration date from the leap_seconds files relative
	 * to the UNIX epoch.
	 */
	expiration_system = leapsec_get_file_expiration_date(LEAPSEC_SYSTEM_FILE);
	expiration_user = leapsec_get_file_expiration_date(LEAPSEC_USER_FILE);

	if (!expiration_system) {
		/*
		pr_warning("%s not found, can't be read or doesn't "
			"have an expiration date\n", LEAPSEC_SYSTEM_FILE);
		*/
		return -1;
	}

	exp_date = expiration_system > expiration_user ?
		expiration_system :
		expiration_user;

	if (exp_date < SECS_FROM_1900_TO_1970) {
		/*
		pr_warning("Invalid expiration date (too small)\n");
		*/
		return -1;
	} else {
		/*
		 * The expiration date in the leap-seconds file is based on the
		 * NTP epoch (1-1-1900 -- 00:00:00). Convert it to UNIX epoch.
		 */
		exp_date -= SECS_FROM_1900_TO_1970;
	}

	return exp_date;
}

enum leapsec_exp_status leapsec_check_expiration_date(void)
{
	time_t curr_time;
	int64_t exp_date = leapsec_get_expiration_date();

	if (exp_date == -1)
		return LEAPSEC_EXP_ERROR;

	/* Compare the expiration date to the current date */
	curr_time = time(0);

	if (curr_time >= leapsec_get_expiration_date()) {
		/*
		pr_warning("Leap seconds file(s) expired\n");
		*/
		return LEAPSEC_EXP_EXPIRED;
	}

	return LEAPSEC_EXP_OK;
}

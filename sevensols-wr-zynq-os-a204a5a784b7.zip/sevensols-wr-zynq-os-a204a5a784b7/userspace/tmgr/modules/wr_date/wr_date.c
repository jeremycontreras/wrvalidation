/*
 * wr_date.c
 *
 * API to wr_date.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 26, 2019
 * Last modified: Jul 2, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <libgpa.h>

#include "wr_date.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define WR_DATE           "/wr/bin/wr_date"
#define FIX_TAI_CMD       WR_DATE" -n set host"
#define SET_FPGA_TIME_CMD WR_DATE" set host"


/************************************************************
 * Public API                                               *
 ************************************************************/

int fix_kernel_tai(void)
{
	int ret;

	if (access(WR_DATE, F_OK)) {
		pr_error("%s not found\n", WR_DATE);
		return 1;
	}
	if (access(WR_DATE, X_OK)) {
		pr_error("Can't run %s (no execute permissions)\n",
			WR_DATE);
		return 1;
	}

	ret = system(FIX_TAI_CMD);
	if (WEXITSTATUS(ret)) {
		pr_error("Can't set kernel TAI. "
			"Error running wr_date\n");
	}
	return ret;
}

int set_fpga_time(void)
{
	int ret;

	if (access(WR_DATE, F_OK)) {
		pr_error("%s not found\n", WR_DATE);
		return 1;
	}
	if (access(WR_DATE, X_OK)) {
		pr_error("Can't run %s (no execute permissions)\n",
			WR_DATE);
		return 1;
	}

	ret = system(SET_FPGA_TIME_CMD);
	if (WEXITSTATUS(ret)) {
		pr_error("Can't set FPGA time from hostname. "
			"Error running wr_date\n");
	}
	return ret;
}

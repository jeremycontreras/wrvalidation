#ifndef __WR_DATE_H__
#define __WR_DATE_H__

/*
 * wr_date.h
 *
 * API to wr_date.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * copyright Copyright (c) 2019 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 26, 2019
 * Last modified: Jul 2, 2019
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


/*
 * Temporary module for setting the correct TAI in the kernel according to the
 * leap seconds file.
 *
 * For now we're using wr_date for that. Eventually the Time Manager will take
 * over this task and replace wr_date.
 */

/*
 * Fixes the TAI offset in the kernel clock.
 *
 * Returns:
 *   0 if success
 *   1 if error
 */
int fix_kernel_tai(void);

/*
 * Sets the FPGA time to match the current system time.
 *
 * Returns:
 *   0 if success
 *   1 if error
 */
int set_fpga_time(void);

#endif

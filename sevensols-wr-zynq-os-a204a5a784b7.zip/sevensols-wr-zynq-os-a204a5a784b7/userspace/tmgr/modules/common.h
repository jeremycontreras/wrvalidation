#ifndef __COMMON_H__
#define __COMMON_H__

#include <libgpa.h>

struct param_def {
	char *key;
	uint16_t modir_oid;
	uint16_t prm_oid;
	struct gpa_prm *param;
};

#endif

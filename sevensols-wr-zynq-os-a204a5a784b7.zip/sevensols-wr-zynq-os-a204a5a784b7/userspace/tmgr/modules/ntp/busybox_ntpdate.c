/*
 * busybox_ntpdate.c
 *
 * Busybox + ntpdate implementation for the ntp module.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <regex.h>
#include <libgpa.h>

#include "ntp.h"
#include "gpa_interface.h"


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define MAX_LINE_LENGTH 256

#define BUSYBOX         "/bin/busybox"
#define NTPDATE         "/usr/bin/ntpdate"
#define NTP_GET_OFFSET  NTPDATE" -q "
#define NTP_SYNC        BUSYBOX" ntpd -n -q -p "

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

/************************************************************
 * Private functions                                        *
 ************************************************************/

/*
 * Check that the binaries exist and have execute permission.
 */
enum ntp_error ntp_init_busybox(void)
{
	/* Check if ntpd and ntpdate are available */
	if (access(BUSYBOX, F_OK)) {
		pr_error("%s not found\n", BUSYBOX);
		return NTP_ERROR_OTHER;
	}
	if (access(BUSYBOX, X_OK)) {
		pr_error("Can't run %s (no execute permissions)\n",
			BUSYBOX);
		return NTP_ERROR_OTHER;
	}
	if (access(NTPDATE, F_OK)) {
		pr_error("%s not found\n", NTPDATE);
		return NTP_ERROR_OTHER;
	}
	if (access(NTPDATE, X_OK)) {
		pr_error("Can't run %s (no execute permissions)\n",
			NTPDATE);
		return NTP_ERROR_OTHER;
	}

	return 0;
}

/*
 * In the busybox + ntpdate implementation time synchronization is done through
 * ntpd (as a client).
 */
enum ntp_error ntp_synchronize_busybox(int n)
{
	FILE *fp;
	char cmd[MAX_LINE_LENGTH] = {0};
	char *line = 0;
	size_t s;
	ssize_t read_size = 0;
	int ret = 0;
	int pclose_ret = 0;
	const char *server = 0;

	if (get_ntp_server_config_ip(n, &server)) {
		pr_error("Error: get_ntp_server_config_ip\n");
		return NTP_ERROR_OTHER;
	}
	if (strcmp(server, "") == 0) {
		pr_error("Error: NTP server parameter is not configured\n");
		return NTP_ERROR_SERVER;
	}

	snprintf(cmd, MAX_LINE_LENGTH, "%s %s 2>/dev/null", NTP_SYNC, server);

	fp = popen(cmd, "r");
	if (!fp) {
		return NTP_ERROR_OTHER;
	}

	/* Read the first line */
	read_size = getline(&line, &s, fp);

	/* Keep reading until EOF */
	if (read_size > -1) {
		char *discard = 0;
		while (getline(&discard, &s, fp) > -1) {
			free(discard);
			discard = 0;
		}
		free(discard);
	}

	pclose_ret = pclose(fp);
	if (WEXITSTATUS(pclose_ret)) {
		/* Error running the sync command (network error?) */
		pr_warning("Can't set NTP time from %s "
			"(server down?)\n", server);
		ret = NTP_ERROR_QUERY;
	}

	free(line);
	return ret;
}

/*
 * In the busybox + ntpdate implementation the time offset is queried using
 * ntpdate and parsing its output.
 *
 * When the time can be retrieved, ntpdate returns 0 and the output message
 * looks like this:
 *
 * server 192.168.77.1, stratum 3, offset 348898.839722, delay 0.02582
 *
 * When the time can't be retrieved, ntpdate returns 1.
 */
enum ntp_error ntp_get_offset_busybox(int n, float *offset)
{
	FILE *fp;
	char cmd[MAX_LINE_LENGTH] = {0};
	char *line = 0;
	size_t s;
	ssize_t read_size = 0;
	char match[MAX_LINE_LENGTH] = {0};
	regex_t re;
	char *re_string = "offset (.+),";
	regmatch_t group_array[2];
	int pclose_ret = 0;
	float value = 0;
	int ret = 0;
	const char *server = 0;
	char errmsg[MAX_LINE_LENGTH] = {0};
	int err;

	if (get_ntp_server_config_ip(n, &server)) {
		pr_warning("Error: get_ntp_config_server\n");
		return NTP_ERROR_OTHER;
	}
	if (strcmp(server, "") == 0) {
		pr_error("Error: NTP server parameter is not configured\n");
		return NTP_ERROR_SERVER;
	}

	snprintf(cmd, MAX_LINE_LENGTH, "%s %s 2>/dev/null",
		NTP_GET_OFFSET, server);

	fp = popen(cmd, "r");
	if (!fp) {
		ret = NTP_ERROR_OTHER;
		goto error_0;
	}

	/* Read the first line */
	read_size = getline(&line, &s, fp);

	/*
	 * Keep reading until EOF (this is a way of waiting until the program
	 * finishes before calling pclose)
	 */
	if (read_size > -1) {
		char *discard = 0;
		while (getline(&discard, &s, fp) > -1) {
			free(discard);
			discard = 0;
		}
		free(discard);
	}

	/* Save and check return code */
	pclose_ret = pclose(fp);
	if (WEXITSTATUS(pclose_ret) || read_size == - 1) {
		/* Error running the get_offset command (network error?) */
		/*
		pr_warning("Can't retrieve NTP time from %s "
			"(server down?)\n", server);
		*/
		ret = NTP_ERROR_QUERY;
		goto error_1;
	}

	err = regcomp(&re, re_string, REG_EXTENDED);
	if (err) {
		regerror(err, &re, errmsg, sizeof(errmsg));
		pr_error("Error compiling regexp: %s\n", errmsg);
		ret = NTP_ERROR_OTHER;
		goto error_1;
	}
	err = regexec(&re, line, 2, group_array, 0);
	if (err) {
		regerror(err, &re, errmsg, sizeof(errmsg));
		pr_error("regexec error: %s\n", errmsg);
		ret = NTP_ERROR_OTHER;
		goto error_2;
	}
	memmove(match, &line[group_array[1].rm_so],
		group_array[1].rm_eo - group_array[1].rm_so);
	errno = 0;
	value = strtof(match, 0);
	if (errno) {
		pr_error("Error in strtof\n");
		ret = NTP_ERROR_OTHER;
	} else {
		*offset = value;
	}

error_2:
	regfree(&re);
error_1:
	free(line);
error_0:
	return ret;
}

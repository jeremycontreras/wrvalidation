#ifndef __NTP_H__
#define __NTP_H__

/*
 * ntp.h
 *
 * ntp client module interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


enum ntp_implementation {
	NTP_NULL,
	NTP_BUSYBOX,
};

/* Specific error codes */
enum ntp_error {
	NTP_ERROR_OK,
	/* General parameter error */
	NTP_ERROR_PARAMETER,
	/* NTP server is not configured */
	NTP_ERROR_SERVER,
	/* Error retrieving time from the NTP server */
	NTP_ERROR_QUERY,
	/* Operation not implemented */
	NTP_ERROR_NOT_IMPLEMENTED,

	/* Any other type of error */
	NTP_ERROR_OTHER,
};


/*
 * Common API for the NTP module. All the implementations of this module must
 * comply and implement this API.
 */

/*
 * Initializes the NTP module.
 *
 * Parameters:
 *
 *   impl: Concrete implementation to initialize.
 *
 * Returns:
 *
 *   0                          If the initialization was successful
 *   NTP_ERROR_NOT_IMPLEMENTED  If the specified implementation doesn't
 *                              implement an <init> method
 *   NTP_ERROR_OTHER            In any other error case
 */
enum ntp_error ntp_init(enum ntp_implementation impl);

/*
 * Fetches the NTP time from the configured servers and updates the system
 * clock.
 *
 * Returns:
 *
 *   0                          If the synchronization was successful
 *   NTP_ERROR_NOT_IMPLEMENTED  If the specified implementation doesn't
 *                              implement a <synchronize> method
 *   NTP_ERROR_SERVER           If there's no configured NTP server
 *   NTP_ERROR_QUERY            If the query to the server failed
 *   NTP_ERROR_OTHER            In any other error case
 */
#define ntp_server0_synchronize() ntp_synchronize(0)
enum ntp_error ntp_synchronize(int n);


/*
 * Queries the configured NTP server and saves the offset between its time and
 * the current system time.
 *
 * Parameters:
 *
 *   offset (output): A pointer to a float to store the time offset
 *
 * Returns:
 *
 *   0                          If the offset could be correctly retrieved
 *   NTP_ERROR_NOT_IMPLEMENTED  If the specified implementation doesn't
 *                              implement a <synchronize> method
 *   NTP_ERROR_PARAMETER        If <offset> is not a valid pointer
 *   NTP_ERROR_SERVER           If there's no configured NTP server
 *   NTP_ERROR_QUERY            If the query to the server failed
 *   NTP_ERROR_OTHER            In any other error case
 */
#define ntp_server0_get_offset(offset) ntp_get_offset(0, offset)
enum ntp_error ntp_get_offset(int n, float *offset);

#endif

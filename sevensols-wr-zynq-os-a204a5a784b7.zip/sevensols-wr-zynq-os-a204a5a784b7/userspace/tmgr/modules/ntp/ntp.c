/*
 * ntp.c
 *
 * ntp client module interface.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <libgpa.h>
#include "ntp.h"

/************************************************************
 * External declarations                                    *
 ************************************************************/

extern int ntp_init_busybox(void);
extern int ntp_synchronize_busybox(int);
extern int ntp_get_offset_busybox(int, float *);


/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

/************************************************************
 * Internal data structures                                 *
 ************************************************************/

static enum ntp_implementation ntp_impl = NTP_NULL;

/************************************************************
 * Private functions                                        *
 ************************************************************/


/************************************************************
 * Public API                                               *
 ************************************************************/

enum ntp_error ntp_init(enum ntp_implementation impl)
{
	int ret = 0;

	if (ntp_impl != NTP_NULL) {
		pr_warning("NTP module already initialized\n");
		return NTP_ERROR_OTHER;
	}

	switch(impl) {
	case NTP_BUSYBOX:
		ret = ntp_init_busybox();
		break;
	case NTP_NULL:
		pr_error("Invalid NTP implementation (%d)\n", impl);
		ret = NTP_ERROR_NOT_IMPLEMENTED;
		break;
	}

	if (!ret)
		ntp_impl = impl;

	return ret;
}

enum ntp_error ntp_synchronize(int n)
{
	int ret = 0;

	switch(ntp_impl) {
	case NTP_BUSYBOX:
		ret = ntp_synchronize_busybox(n);
		break;
	case NTP_NULL:
		pr_error("ntp_synchronize not implemented in "
			"NTP implementation (%d)\n", ntp_impl);
		ret = NTP_ERROR_NOT_IMPLEMENTED;
		break;
	}

	return ret;
}

enum ntp_error ntp_get_offset(int n, float *offset)
{
	int ret = 0;

	if (!offset) {
		pr_error("NULL output parameter\n");
		return NTP_ERROR_PARAMETER;
	}

	switch(ntp_impl) {
	case NTP_BUSYBOX:
		ret = ntp_get_offset_busybox(n, offset);
		break;
	case NTP_NULL:
		pr_error("ntp_get_offset not implemented in "
			"NTP implementation (%d)\n", ntp_impl);
		ret = NTP_ERROR_NOT_IMPLEMENTED;
		break;
	}

	return ret;
}

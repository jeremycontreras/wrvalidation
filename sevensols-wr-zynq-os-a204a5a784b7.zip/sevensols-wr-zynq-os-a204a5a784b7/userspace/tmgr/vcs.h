#ifndef __VCS_H__
#define __VCS_H__

/*
 * vcs.h
 *
 * Header for Virtual Clock use Cases (VCS)
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

/*
 * Enum type for VCS
 *
 */
enum tmgr_vcs_code {
	// General codes
	VCS_UNINITIALIZED = 0,
	VCS_READY = 9000,
	VCS_SYSTEM_ERROR = 9100,
	VCS_INITIALIZING = 9110,
	VCS_MULTIREF_COMPROMISED = 9111,
	// GM use cases
	VCS_GM_LOCKED = 10000,
	VCS_GM_UNLOCKED_10M_NOT_PRESENT = 10101,
	VCS_GM_UNLOCKED_HO_10M_NOT_PRESENT = 11101,
	VCS_GM_UNLOCKED_PPS_NOT_PRESENT = 10102,
	VCS_GM_UNLOCKED_HO_PPS_NOT_PRESENT = 11102,
	VCS_GM_UNLOCKED_10M_AND_PPS_NOT_PRESENT = 10103,
	VCS_GM_UNLOCKED_HO_10M_AND_PPS_NOT_PRESENT = 11103,
	VCS_GM_UNLOCKED_10M_NOT_STABLE = 10104,
	VCS_GM_UNLOCKED_REP_LOCK_UNLOCK = 10105,
	VCS_GM_LOCKED_PPS_LOST = 10110,
	VCS_GM_LOCKED_NTP_NOT_SET = 10201,
	VCS_GM_LOCKED_LEAPS_EXPIRED = 10202,
	VCS_GM_LOCKED_NTP_OFFSET_1S = 10203,
	VCS_GM_LOCKED_NTP_NOT_REPLY = 10204,
	VCS_GM_LOCKED_GM_MAINTENANCE = 10271,
	// BC use cases
	VCS_BC_WR_LOCKED = 20001,
	VCS_BC_PTP_LOCKED = 20002,
	VCS_BC_WR_LOCKED_LEGACY = 20003,
	VCS_BC_LOCKED_FR = 20004,
	VCS_BC_NOLINK_IFACE_DOWN = 20301,
	VCS_BC_NOLINK_HO_IFACE_DOWN = 21301,
	VCS_BC_NOLINK_GM_MAINTENANCE = 20302,
	VCS_BC_HO_MAINTENANCE = 21302,
	VCS_BC_NOLINK_MASTER_NOT_DETECTED = 20303,
	VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED = 21303,
	VCS_BC_NOLINK_PTP_ERROR = 20304,
	VCS_BC_NOLINK_NOLOCK = 20305,
	VCS_BC_NOLINK_REP_LOCK_UNLOCK = 20306,
	VCS_BC_NOLINK_SYNCE_BAD_QL = 20307,
	VCS_BC_NOLINK_HO_SYNCE_BAD_QL = 21307,
	VCS_BC_NOLINK_LOCKED_FR = 20320,
	VCS_BC_NOLINK_HO_FR = 21320,
	VCS_BC_10M_PPS_LOCKED_FR = 20201,
	VCS_BC_10M_PPS_HO_FR = 21201,
	VCS_BC_HO_LOCKED = 20210,
	VCS_BC_HO_LOCKED2 = 20211,
	VCS_BC_NOLINK_LOCKED_GM_MAINTENANCE = 20321,
	VCS_BC_LOCKED_GM_NTP_ERROR = 20110,
	VCS_BC_LOCKED_GM_LEAPS_EXPIRED = 20111,
	VCS_BC_LOCKED_GM_NTP_INTEGRITY = 20112,
	VCS_BC_LOCKED_NTP_INTEGRITY = 20113,
	VCS_BC_LOCKED_SYNCE_NOT_LOCKED = 20114,
	VCS_BC_LOCKED_HO_SYNCE_NOT_LOCKED = 21114,
	VCS_BC_LOCKED_SFP_CAL = 20720,
	VCS_BC_LOCKED_FIBER_CAL = 20721,
	// GNSS use cases
	VCS_GNSS_OK = 30000,
	VCS_GNSS_CHIP_ERROR = 30701,
	VCS_GNSS_BAD_SIGNAL = 30201,
	VCS_GNSS_HO = 31201,
	VCS_GNSS_JAMMING_CRITICAL = 30202,
	VCS_GNSS_TOD_ERROR = 30111,
	VCS_GNSS_INTEGRITY_ERROR = 30112,
	VCS_GNSS_LOW_SIGNAL = 30210,
	VCS_GNSS_JAMMING = 30211,
	// FR/HO use cases
	VCS_MANUAL_FR_OK = 90000,
	VCS_FR_EXPIRED = 91101,
	VCS_FR_MAINTENANCE = 91102,
	VCS_FR_FAIL = 91111,
};

/* VCS functions prototypes*/
enum vc_status convert_vcs_state_into_vc_status(enum tmgr_vcs_code code);
signed char get_vcs_prio0(enum tmgr_vcs_code code);
int insert_vcs_msg_string_args(enum tmgr_vcs_code code, const char **args, const int nargs, char *msg);
int insert_vcs_act_ref_string_args(enum tmgr_vcs_code code, const char **args, const int nargs, char *msg);

#endif

/*
 * fr_ho.c
 *
 * Application logic for the Free-Running Master Virtual Clock timing source.
 * Based on previous work for FR VC mode developed by Ricardo Canuelo.
 *
 * Author: Ricardo Cañuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>

#include "commondefs.h"
#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "vcs.h"
#include "vc_fr_ho_defs.h"
#include "gpa_interface.h"
#include "ktmgr.h"
#include "ppsi.h"


/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

#define DEFAULT_CLK_CLASS_MANUAL_FR GPA_1588_CLASS_GM_ARB_UNLOCKED

/* Structure for FR/HO internal data */
struct vc_tsrc_fr_ho_data {
	/* Holdover parameters */
	enum ho_state holdover_state;
};

/***********************************************************************
 * FSM shared data                                                     *
 ***********************************************************************/

/***********************************************************************
 * Utility functions                                                   *
 ***********************************************************************/

static void fr_ho_ktmgr_align(struct vc_timing_src *src, int enable)
{
	int en = (enable) ? 1 : 0;

	if((src == NULL) || (vc_tsrc_is_active(src) == 0))
		return;

	ktmgr_set_attr(KTMGR_ENABLE_ALIGN, en);
}

static int fr_ho_check_datap(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	if(!src->fsm_ext)
		return 0;

	return 1;
}

static int fr_ho_get_internal_data(struct vc_timing_src *src, struct vc_tsrc_fr_ho_data **data)
{
	if(!fr_ho_check_datap(src))
		return 0;

	if(!data)
		return 0;

	*data = (struct vc_tsrc_fr_ho_data *) src->fsm_ext;

	return 1;
}

int vc_tsrc_fr_ho_init_data(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src || src->fsm_ext)
		return ret;

	/* Reserve memory and initialize it */
	src->fsm_ext = malloc(sizeof(struct vc_tsrc_fr_ho_data));
	memset (src->fsm_ext, 0, sizeof(struct vc_tsrc_fr_ho_data));

	vc_tsrc_set_vcs_code(src, VCS_INITIALIZING);

	ret = 0;

	return ret;
}

void vc_tsrc_fr_ho_free_data(struct vc_timing_src *src)
{
	if(!src || !src->fsm_ext)
		return;

	free(src->fsm_ext);
	src->fsm_ext = NULL;
}

void vc_tsrc_fr_ho_update_vc_info(struct vc_timing_src *src)
{
	struct vc_tsrc_fr_ho_data *data;

	if(!fr_ho_get_internal_data(src, &data))
		return;

	/* Update VC info using VCS code (no arguments for msg and aref) */
	vc_tsrc_update_vc_info_data_vcs_simple(src);

	/* Update clockQ parameter from PPSi */
	if(vc_tsrc_is_active(src) && src->priv.fr_ho.mode == VC_TSRC_FR_HO_MODE_MANUAL)
		update_clockq(src);
}

void vc_tsrc_fr_ho_init_manual_fr(struct vc_timing_src *src)
{
	struct vc_tsrc_fr_ho_data *data;

	if(!fr_ho_get_internal_data(src, &data))
		return;

	vc_tsrc_set_vcs_code(src, VCS_MANUAL_FR_OK);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* Set ktmgr parameters */
	ktmgr_set_attr(KTMGR_CLK_CLASS, DEFAULT_CLK_CLASS_MANUAL_FR);
	ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_UNKNOWN);
	ktmgr_set_attr(KTMGR_TIMESOURCE, GPA_1588_SRC_INTERNAL_OSCILLATOR);
	ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
	ktmgr_set_attr(KTMGR_TIME_VALID, 0);
	ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
	fr_ho_ktmgr_align(src, 1);

	ktmgr_set_attr(KTMGR_UPDATE, 1);

	/* Enable PPS & Update HALd LED */
	hald_set_pps_mode_state_tmgr(1);
	update_hald_out_led(HALD_LED_OUT_STATE_OK);

	/* Set Freerunning source */
	ppsi_set_ext_clk(1);
	ppsi_set_cfg_timing_mode(PPSI_TM_FR);
	ppsi_set_run_stop(1);

}

void vc_tsrc_fr_ho_init_fail_fr(struct vc_timing_src *src)
{
	enum pps_mode m;
	struct vc_tsrc_fr_ho_data *data;

	if(!fr_ho_get_internal_data(src, &data))
		return;

	/* Read HO state */
	hald_get_softpll_ho_state(&data->holdover_state);

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m == PPS_MODE_TMGR_LEGACY || data->holdover_state == HO_ACTIVATED)
		hald_set_pps_mode_state_tmgr(1);
	else if(m == PPS_MODE_TMGR_ONLY_LOCKED)
		hald_set_pps_mode_state_tmgr(0);

	/* Update LED out (WARNING) */
	update_hald_out_led(HALD_LED_OUT_STATE_TRANS_WARN);

	vc_tsrc_set_vcs_code(src, VCS_FR_FAIL);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);
}

void vc_tsrc_fr_ho_expired(struct vc_timing_src *src, int ho)
{
	enum pps_mode m;
	struct vc_tsrc_fr_ho_data *data;

	if(!fr_ho_get_internal_data(src, &data))
		return;

	vc_tsrc_set_vcs_code(src, VCS_FR_EXPIRED);

	set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* Set ktmgr parameters */
	ktmgr_set_attr(KTMGR_CLK_CLASS, (ho == 1) ? GPA_1588_CLASS_GM_PTP_UNLOCKED : GPA_1588_CLASS_DEFAULT);
	ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_UNKNOWN);
	ktmgr_set_attr(KTMGR_TIMESOURCE, GPA_1588_SRC_INTERNAL_OSCILLATOR);
	ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
	ktmgr_set_attr(KTMGR_TIME_VALID, 0);
	ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
	fr_ho_ktmgr_align(src, 0);

	ktmgr_set_attr(KTMGR_UPDATE, 1);

	/* Update LED out (CRITICAL) */
	get_tmgr_config_pps_mode(&m);
	if(m == PPS_MODE_TMGR_LEGACY || m == PPS_MODE_TMGR_ALWAYS_ON)
		update_hald_out_led(HALD_LED_OUT_STATE_CRIT_PPS_ON);
	else
		update_hald_out_led(HALD_LED_OUT_STATE_CRIT_PPS_OFF);

}

/***********************************************************************
 * Action functions.                                                   *
 ***********************************************************************/

void vc_tsrc_fr_ho_enter_running(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_RUNNING);

	pr_warning("Starting Free-Running Master source\n");

	if(src->priv.fr_ho.mode == VC_TSRC_FR_HO_MODE_MANUAL)
		vc_tsrc_fr_ho_init_manual_fr(src);
	else
		vc_tsrc_fr_ho_init_fail_fr(src);

}


/***********************************************************************
 * State functions.                                                    *
 ***********************************************************************/

void *vc_tsrc_fr_ho_idle(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Set quality metric to MAX value (OK), Wait for ACK */
	if (!vc_tsrc_checkp_fsm_is_enabled(src))
		src->qm.value = VC_TSRC_MV_MAX;

	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_READY);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* Substitute this for some ACTUAL work */
	nanosleep(&ts, 0);

	return args;
}

void *vc_tsrc_fr_ho_running(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	int retries = 0;
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_fr_ho_data *data = (struct vc_tsrc_fr_ho_data *) src->fsm_ext;
	enum holdover_force_trigger ft;
	int expired = 0;

	if(hald_get_softpll_ho_state(&data->holdover_state)) {
		pr_err("Error retrieving holdover_state from HALd\n");
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
		return args;
	}

	if(src->priv.fr_ho.mode == VC_TSRC_FR_HO_MODE_MANUAL) {
		retries = -1; /* no expiration */
	}
	else {
		switch(data->holdover_state) {
		case HO_ACTIVATED:
			retries = -2; /* Check HO expiration */
			break;
		case HO_EXPIRED:
			expired = 1;
			vc_tsrc_fr_ho_expired(src, 1);
			break;
		default:
			retries = SECS_TO_RETRIES(TMO_FR_EXPIRED);
			break;
		};
	}

	if(expired)
		return args;

	do {
		if (!vc_tsrc_is_active(src))
			break;

		nanosleep(&ts, 0);

		if(get_ho_config_force_trigger(&ft)) {
			pr_err("Error retrieving force_trigger from HALd\n");
			vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
			break;
		}

		if(retries != -2 && (ft == HO_FORCE_TRIGGER_STOP || ft == HO_FORCE_TRIGGER_START))
			set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);

		// TODO: Implement clock_accuracy degradation algorithm

		if(retries > 0) {
			retries--;
			expired = (retries == 0) ? 1 : 0;
			if(expired)
				vc_tsrc_fr_ho_expired(src, 0);
		}
		else {
			/* HO activated case */
			if (retries == -2) {
				if(hald_get_softpll_ho_state(&data->holdover_state)) {
					pr_err("Error retrieving holdover_state from HALd\n");
					vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
					break;
				}

				if(ft == HO_FORCE_TRIGGER_START)
					set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);

				if(data->holdover_state == HO_EXPIRED || ft == HO_FORCE_TRIGGER_STOP) {
					expired = 1;
					vc_tsrc_fr_ho_expired(src, 1);
				}
			}
		}

		/* Update VC info */
		vc_tsrc_update_vc_info(src);

	} while (!expired);

	return args;
}


/***********************************************************************
 * Transition checker functions.                                       *
 ***********************************************************************/


int vc_tsrc_fr_ho_idle_to_running(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return (vc_tsrc_is_active(src) && !vc_tsrc_checkp_fsm_is_enabled(src));
}

int vc_tsrc_fr_ho_running_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	int active = vc_tsrc_is_active(src);
	int error = (src->vc_info.status == VC_STATUS_ERROR);

	/* Mark checkpoint flag is any error raised */
	if(error)
		vc_tsrc_set_checkp_fsm(src);

	if(error || !active) {
		/* Set quality metric to MIN value (CRITICAL) */
		src->qm.value = VC_TSRC_MV_MIN;
		vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_NOT_READY);
	}

	return !active || error;
}

int vc_tsrc_fr_ho_idle_to_end(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return vc_tsrc_fsm_has_to_stop(src);
}

/*
 * vc_fr_ho_defs.h
 *
 * Common definitions for the FR/HO FSM.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#ifndef __VC_FR_HO_DEFS_H__
#define __VC_FR_HO_DEFS_H__

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

enum vc_tsrcs_fr_ho_states {
	VC_TSRC_FR_HO_IDLE,
	VC_TSRC_FR_HO_RUNNING,
	VC_TSRC_FR_HO_END,

	N_VC_TSRC_FR_HO_STATES,
};

void vc_tsrc_fr_ho_update_vc_info(struct vc_timing_src *);
int vc_tsrc_fr_ho_init_data(struct vc_timing_src *);
void vc_tsrc_fr_ho_free_data(struct vc_timing_src *);

/***********************************************************************
 * FSM functions                                                       *
 ***********************************************************************/

/*
 * Action functions.
 */
void vc_tsrc_fr_ho_enter_running(void *);


/*
 * State functions. All of them take a pointer to the vc_timing_src struct as an
 * argument.
 */

void *vc_tsrc_fr_ho_idle(void *);
void *vc_tsrc_fr_ho_running(void *);


/*
 * Transition checker functions. All of them take as an argument the value
 * returned by the state function of the current state.
 */

int vc_tsrc_fr_ho_idle_to_running(void *);
int vc_tsrc_fr_ho_idle_to_end(void *);
int vc_tsrc_fr_ho_running_to_idle(void *);

#endif

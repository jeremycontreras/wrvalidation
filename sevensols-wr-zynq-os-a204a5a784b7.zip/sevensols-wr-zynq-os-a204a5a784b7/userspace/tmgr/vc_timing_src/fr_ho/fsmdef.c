/*
 * fsmdef.c
 *
 * FSM for the Free-Running Master / Holdover Virtual Clock timing resource.
 * Based on fsmdef.c from FR VC mode developed by Ricardo Canuelo.
 *
 * Author: Ricardo Cañuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "fsmlib.h"
#include "vc_timing_src.h"
#include "vc_fr_ho_defs.h"

/***********************************************************************
 * External declarations                                               *
 ***********************************************************************/

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

static char *vc_tsrc_fr_ho_states_names[N_VC_TSRC_FR_HO_STATES] = {
	[VC_TSRC_FR_HO_IDLE]       = "FR_IDLE",
	[VC_TSRC_FR_HO_RUNNING]    = "FR_RUNNING",
	[VC_TSRC_FR_HO_END]        = "FR_END",
};


/***********************************************************************
 * Public API                                                          *
 ***********************************************************************/

int create_fr_ho_fsm(struct vc_timing_src *src)
{
	int ret = 0;
	struct fsm *fsm = NULL;

	if(!src)
		return 1;

	fsm = new_fsm("FR/HO");


	/********** Actions **********/

	struct action *enter_running = new_action(vc_tsrc_fr_ho_enter_running,
					src);

	/********** States **********/

	/* IDLE state */
	struct sync_state *st_idle = new_sync_state(
		vc_tsrc_fr_ho_states_names[VC_TSRC_FR_HO_IDLE],
		vc_tsrc_fr_ho_idle, src, 0);
	add_state((union state *)st_idle, fsm);

	/* RUNNING state */
	struct sync_state *st_running = new_sync_state(
		vc_tsrc_fr_ho_states_names[VC_TSRC_FR_HO_RUNNING],
		vc_tsrc_fr_ho_running, src, 0);
	add_state((union state *)st_running, fsm);
	add_action(enter_running, (union state *)st_running, ENTRY);

	/* END state */
	struct sync_state *st_end = new_sync_state(
		vc_tsrc_fr_ho_states_names[VC_TSRC_FR_HO_END],
		0, src, 0);
	add_state((union state *)st_end, fsm);


	/********** Transitions **********/

	/* From IDLE state */
	/* From IDLE to END */
	struct sync_transition *t_idle_end = new_sync_transition(
		st_idle, (union state *)st_end, vc_tsrc_fr_ho_idle_to_end, 0);
	if (!t_idle_end)
		return 0;

	/* From IDLE to INIT */
	struct sync_transition *t_idle_running = new_sync_transition(
		st_idle, (union state *)st_running,
		vc_tsrc_fr_ho_idle_to_running, 0);
	if (!t_idle_running)
		return 0;

	/* From RUNNING state */
	/* From RUNNING to IDLE */
	struct sync_transition *t_running_idle = new_sync_transition(
		st_running, (union state *)st_idle,
		vc_tsrc_fr_ho_running_to_idle, 0);
	if (!t_running_idle)
		return 0;

	/* Update timing source structure */
	src->fsm = fsm;
	src->vc_info.pre_update = NULL;
	src->vc_info.post_update = NULL;
	src->vc_info.update = vc_tsrc_fr_ho_update_vc_info;

	/* Initialize private data for FR/HO */
	ret = vc_tsrc_fr_ho_init_data(src);

	return ret;
}


int free_fr_ho_fsm(struct vc_timing_src *src)
{
	int ret;

	/* Stop FSM */
	ret = vc_tsrc_terminate(src);

	/* Free private data for FR/HO */
	vc_tsrc_fr_ho_free_data(src);

	return ret;
}


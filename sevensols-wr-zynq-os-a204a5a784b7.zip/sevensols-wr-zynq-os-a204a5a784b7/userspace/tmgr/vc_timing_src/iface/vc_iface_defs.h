/*
 * vc_iface_defs.h
 *
 * Common definitions for the interface timing source FSM.
 *
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#ifndef __VC_IFACE_DEFS_H__
#define __VC_IFACE_DEFS_H__

#include "commondefs.h"
#include "vc_tsrc_common.h"
#include "ppsi.h"
#include "ptpd.h"
#include "esmcd.h"

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

enum vc_tsrc_iface_states {
	VC_TSRC_IFACE_IDLE,
	VC_TSRC_IFACE_WAIT_LOCK,
	VC_TSRC_IFACE_LOCKED,
	VC_TSRC_IFACE_ERROR,
	VC_TSRC_IFACE_END,

	N_VC_TSRC_IFACE_STATES,
};

struct vc_tsrc_iface_common_data {
	/* ClockQ */
	char clockid[MAX_STR_LEN];
	uint8_t clock_class;
	uint8_t clock_accuracy;
	uint16_t clock_variance;
	uint8_t clock_priority1;
	uint8_t clock_priority2;
	int16_t clock_utc_offset;
	int clock_utc_offset_valid;
	int clock_time_valid;
	int clock_freq_valid;
	uint16_t n_hops;

	/* State fields */
	int linkup;
	uint16_t n_frgns;
	union {
		enum ppsi_servo_state ppsi;
		enum ptpd_servo_state ptpd;
	} servo_state;
	int gm_present;

	/* SyncE */
	int synce_enabled;
	enum ptpd_synce_state synce_state;
	enum esmcd_port_ssm synce_ssm;

	/* Holdover */
	enum ho_state holdover_state;
	enum holdover_force_trigger ho_force_trig;
	int launch_manual_ho;

	/* Misc */
	enum hald_led_out_state los_prev;

	/*  Extra private data */
	void *extra;
};

int vc_tsrc_iface_init_data(struct vc_timing_src *);
void vc_tsrc_iface_free_data(struct vc_timing_src *);

/***********************************************************************
 * FSM functions                                                       *
 ***********************************************************************/
/*
 * Action functions.
 */

/* IDLE */
/* Enter actions */
/* Exit actions */

/* WAIT_LOCK */
/* Enter actions */
void vc_tsrc_iface_enter_wait_lock(void *);

/* Exit actions */

/* LOCKED */
/* Enter actions */
void vc_tsrc_iface_enter_locked(void *args);

/* Exit actions */

/* ERROR */
/* Enter actions */
/* Exit actions */

/* END */
/* Enter actions */
void vc_tsrc_iface_enter_end(void *args);

/* Exit actions */

/*
 * State functions. All of them take a pointer to the vc_timing_src struct as an
 * argument.
 */

/* IDLE */
void *vc_tsrc_iface_idle(void *);

/* WAIT_LOCK */
void *vc_tsrc_iface_wait_lock(void *);

/* LOCKED */
void *vc_tsrc_iface_locked(void *);

/* ERROR */
void *vc_tsrc_iface_error(void *);

/*
 * Transition checker functions. All of them take as an argument the value
 * returned by the state function of the current state.
 */

/* From IDLE */
int vc_tsrc_iface_idle_to_wait_lock(void *);
int vc_tsrc_iface_idle_to_end(void *);

/* From WAIT_LOCK */
int vc_tsrc_iface_wait_lock_to_idle(void *);
int vc_tsrc_iface_wait_lock_to_error(void *);
int vc_tsrc_iface_wait_lock_to_locked(void *);

/* From LOCKED */
int vc_tsrc_iface_locked_to_idle(void *);
int vc_tsrc_iface_locked_to_error(void *);

/* From ERROR */
int vc_tsrc_iface_error_to_idle(void *);

#endif

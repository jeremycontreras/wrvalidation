/*
 * iface_impl_def.c
 *
 * Generic interface implementation definition for interface timing sources.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "iface_impl_def.h"
#include "vc_timing_src.h"

/*
 *
 * References to external structures
 *
 */
extern struct vc_tsrc_iface_impl_def vc_tsrc_iface_common;

/* Global table for interface implementation definitions */
static struct vc_tsrc_iface_impl_def *iface_impl_def_tbl[N_PORT_PROTOS] = {
	[PORT_PROTO_DISABLED] = NULL,
	[PORT_PROTO_WR] = &vc_tsrc_iface_common,
	[PORT_PROTO_PTP] = &vc_tsrc_iface_common,
};

struct vc_tsrc_iface_impl_def *iface_get_idef(struct vc_timing_src *src)
{
	if(!src || src->type != VC_TSRC_TYPE_IFACE)
		return NULL;

	return iface_impl_def_tbl[src->priv.iface.proto];
}

int iface_idef_create(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 1;

	if(!idef || !src)
		return ret;

	if(idef->create)
		ret = idef->create(idef, src);

	return ret;
}

int iface_idef_init(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 1;

	if(!idef || !src)
		return ret;

	if(idef->init)
		ret = idef->init(idef, src);

	return ret;
}

int iface_idef_update(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 1;

	if(!idef || !src)
		return ret;

	if(idef->update)
		ret = idef->update(idef, src);

	return ret;
}

void iface_idef_start_locking(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	if(!idef || !src)
		return;

	if(idef->start_locking)
		idef->start_locking(idef, src);

	return;
}

int iface_idef_check_link(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src, enum vc_tsrc_idef_chlnk_type type)
{
	int ret = 0;

	if(!idef || !src)
		return ret;

	if(idef->check_link)
		ret = idef->check_link(idef, src, type);

	return ret;
}

void iface_idef_notify_event(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src, enum vc_tsrc_idef_event_type type)
{
	if(!idef || !src)
		return;

	if(idef->notify_event)
		idef->notify_event(idef, src, type);

	return;
}

int iface_idef_exit(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 1;

	if(!idef || !src)
		return ret;

	if(idef->exit)
		ret = idef->exit(idef, src);

	return ret;
}

int iface_idef_destroy(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 1;

	if(!idef || !src)
		return ret;

	if(idef->destroy)
		ret = idef->destroy(idef, src);

	return ret;
}






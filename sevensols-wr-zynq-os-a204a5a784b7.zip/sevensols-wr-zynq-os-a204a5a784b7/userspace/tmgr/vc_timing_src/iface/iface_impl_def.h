/*
 * iface_impl_def.h
 *
 * Header for Generic interface implementation definition.
 *
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#ifndef __IFACE_IMPL_DEF_H__
#define __IFACE_IMPL_DEF_H__

#include "vc_timing_src.h"

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/
enum vc_tsrc_idef_chlnk_type {
	VC_TSRC_IDEF_CHLNK_PREREQ = 0,
	VC_TSRC_IDEF_CHLNK_LOCKING,
	VC_TSRC_IDEF_CHLNK_LOCKED,
};

enum vc_tsrc_idef_event_type {
	VC_TSRC_IDEF_EVENT_LOCK = 0,
	VC_TSRC_IDEF_EVENT_TMOUT,
	VC_TSRC_IDEF_EVENT_ERROR,
	VC_TSRC_IDEF_EVENT_PREEMPT,
};

struct vc_tsrc_iface_impl_def {
	char *name;
	int (*create)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
	int (*init)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
	int (*update)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
	void (*start_locking)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
	int (*check_link)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *, enum vc_tsrc_idef_chlnk_type);
	void (*notify_event)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *, enum vc_tsrc_idef_event_type);
	int (*exit)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
	int (*destroy)(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
};

/***********************************************************************
 * Public API                                                          *
 ***********************************************************************/

/* Get a specific interface implementation for a timing source */
struct vc_tsrc_iface_impl_def *iface_get_idef(struct vc_timing_src *src);

/* Generic function to init/create an interface implementation */
/*
 * Reserve and Initialize resources for interface implementation
 *
 * Return:
 *   - 0: If everything was OK
 *   - 1: If an error raised
 */
int iface_idef_create(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
int iface_idef_init(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);

/* Generic funtions to update data for a specific interface implementation */
/*
 * Update data for interface implementation
 *
 * Return:
 *   - 0: If data has updated
 *   - 1: If an error raised
 */
int iface_idef_update(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);

/* Generic function to start hardware locking for a specific interface implementation */
void iface_idef_start_locking(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);

/* Generic functions to check link status for a specific interface implementation (PREREQ, LOCKING, LOCKED) */
/*
 * Check link status for different iface states (PREREQ, LOCKING, LOCKED)
 *
 * Return:
 *   - 1: If link conditions are met
 *   - 0: If link status has some errors
 */
#define iface_idef_chlnk_prereq(idef, src) iface_idef_check_link(idef, src, VC_TSRC_IDEF_CHLNK_PREREQ)
#define iface_idef_chlnk_locking(idef, src) iface_idef_check_link(idef, src, VC_TSRC_IDEF_CHLNK_LOCKING)
#define iface_idef_chlnk_locked(idef, src) iface_idef_check_link(idef, src, VC_TSRC_IDEF_CHLNK_LOCKED)
int iface_idef_check_link(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *, enum vc_tsrc_idef_chlnk_type);

/* Generic funtions to notify a specific event for an implementation interface (LOCKED, TMOUT) */
#define iface_idef_notify_tmout(idef, src) iface_idef_notify_event(idef, src, VC_TSRC_IDEF_EVENT_TMOUT)
#define iface_idef_notify_lock(idef, src) iface_idef_notify_event(idef, src, VC_TSRC_IDEF_EVENT_LOCK)
#define iface_idef_notify_error(idef, src) iface_idef_notify_event(idef, src, VC_TSRC_IDEF_EVENT_ERROR)
#define iface_idef_notify_preempt(idef, src) iface_idef_notify_event(idef, src, VC_TSRC_IDEF_EVENT_PREEMPT)
void iface_idef_notify_event(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *, enum vc_tsrc_idef_event_type);

/* Generic function to deinit/destroy an interface implementation */
/*
 * Free resources for interface implementation
 *
 * Return:
 *   - 0: If everything was OK
 *   - 1: If an error raised
 */
int iface_idef_exit(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);
int iface_idef_destroy(struct vc_tsrc_iface_impl_def *, struct vc_timing_src *);

#endif

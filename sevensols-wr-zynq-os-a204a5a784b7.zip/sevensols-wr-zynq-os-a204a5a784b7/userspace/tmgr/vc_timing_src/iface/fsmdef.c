/*
 * fsmdef.c
 *
 * FSM for the Interface timing source.
 * This is based on previous works for VC BC mode for Ricardo Canuelo.
 *
 * Author: Ricardo Cañuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jiménez López <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

/*
 * FSM for the Interface timing source.
 *
 *
 * Simplified diagram
 * ------------------
 *
 *  +--------------------------------------------+
 *  |  +------------------+                      |
 *  |  |                  |                      |
 *  v  v                  |                      |
 *  IDLE  -----------> WAIT_LOCK -----------> LOCKED
 *   ^                    |                      |
 *   |                    |                      |
 *   |                    v                      |
 *   +----------------- ERROR <------------------+
 *
 *
 *
 * States
 * ------
 *
 *   - IDLE:            Waiting state when the timing source is not active.
 *
 *   - WAIT_LOCK:       Run the initialization steps and wait for the timing daemon reaches Locked
 *                      state.
 *
 *   - LOCKED:          Working state when the timing source is active and the timind daemon is locked.
 *                      The timing source status is continuously monitored.
 *
 *
 *   - ERROR:           Brings the timing source back to idle state after an error
 *                      condition and takes care of notifying the user about the
 *                      errors.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "fsmlib.h"
#include "vc_timing_src.h"
#include "vc_iface_defs.h"

/***********************************************************************
 * External declarations                                               *
 ***********************************************************************/

static char *vc_tsrc_iface_states_names[N_VC_TSRC_IFACE_STATES] = {
	[VC_TSRC_IFACE_IDLE]       = "IFACE_IDLE",
	[VC_TSRC_IFACE_WAIT_LOCK]  = "IFACE_WAIT_LOCK",
	[VC_TSRC_IFACE_LOCKED]     = "IFACE_LOCKED",
	[VC_TSRC_IFACE_ERROR]      = "IFACE_ERROR",
	[VC_TSRC_IFACE_END]        = "IFACE_END",
};


/***********************************************************************
 * Public API                                                          *
 ***********************************************************************/


int create_iface_fsm(struct vc_timing_src *src)
{
	int ret = 0;
	struct fsm *fsm = NULL;

	if(!src)
		return 1;

	/* TODO: Update FSM name with interface info? */
	fsm = new_fsm("IFACE");

	/********** Actions **********/

	struct action *enter_wait_lock = new_action(vc_tsrc_iface_enter_wait_lock, src);
	struct action *enter_locked = new_action(vc_tsrc_iface_enter_locked, src);


	/********** States **********/

	/* IDLE state */
	struct sync_state *st_idle = new_sync_state(
		vc_tsrc_iface_states_names[VC_TSRC_IFACE_IDLE],
		vc_tsrc_iface_idle, src, 0);
	add_state((union state *)st_idle, fsm);

	/* WAIT_LOCK state */
	struct sync_state *st_wait_lock = new_sync_state(
		vc_tsrc_iface_states_names[VC_TSRC_IFACE_WAIT_LOCK],
		vc_tsrc_iface_wait_lock, src, 0);
	add_state((union state *)st_wait_lock, fsm);
	add_action(enter_wait_lock, (union state *)st_wait_lock, ENTRY);

	/* LOCKED state */
	struct sync_state *st_locked = new_sync_state(
		vc_tsrc_iface_states_names[VC_TSRC_IFACE_LOCKED],
		vc_tsrc_iface_locked, src, 0);
	add_state((union state *)st_locked, fsm);
	add_action(enter_locked, (union state *)st_locked, ENTRY);

	/* ERROR state */
	struct sync_state *st_error = new_sync_state(
		vc_tsrc_iface_states_names[VC_TSRC_IFACE_ERROR],
		vc_tsrc_iface_error, src, 0);

	/* END state */
	struct sync_state *st_end = new_sync_state(
		vc_tsrc_iface_states_names[VC_TSRC_IFACE_END],
		0, src, 0);
	add_state((union state *)st_end, fsm);

	/********** Transitions **********/

	/* From IDLE state */

	/* From IDLE to END */
	struct sync_transition *t_idle_end = new_sync_transition(
		st_idle, (union state *)st_end,
		vc_tsrc_iface_idle_to_end, 0);
	if (!t_idle_end)
		return 0;

	/* From IDLE to WAIT_LOCK */
	struct sync_transition *t_idle_wait_lock = new_sync_transition(
		st_idle, (union state *)st_wait_lock,
		vc_tsrc_iface_idle_to_wait_lock, 0);
	if (!t_idle_wait_lock)
		return 0;

	/* From WAIT_LOCK state */

	/* From WAIT_LOCK to IDLE */
	struct sync_transition *t_wait_lock_idle = new_sync_transition(
		st_wait_lock, (union state *)st_idle,
		vc_tsrc_iface_wait_lock_to_idle, 0);
	if (!t_wait_lock_idle)
		return 0;

	/* From WAIT_LOCK to ERROR */
	struct sync_transition *t_wait_lock_error = new_sync_transition(
		st_wait_lock, (union state *)st_error,
		vc_tsrc_iface_wait_lock_to_error, 0);
	if (!t_wait_lock_error)
		return 0;

	/* From WAIT_LOCK to LOCKED */
	struct sync_transition *t_wait_lock_locked = new_sync_transition(
		st_wait_lock, (union state *)st_locked,
		vc_tsrc_iface_wait_lock_to_locked, 0);
	if (!t_wait_lock_locked)
		return 0;


	/* From LOCKED state */

	/* From LOCKED to IDLE */
	struct sync_transition *t_locked_idle = new_sync_transition(
		st_locked, (union state *)st_idle,
		vc_tsrc_iface_locked_to_idle, 0);
	if (!t_locked_idle)
		return 0;

	/* From LOCKED to ERROR */
	struct sync_transition *t_locked_error = new_sync_transition(
		st_locked, (union state *)st_error,
		vc_tsrc_iface_locked_to_error, 0);
	if (!t_locked_error)
		return 0;

	/* From ERROR state */

	/* From ERROR to IDLE */
	struct sync_transition *t_error_idle = new_sync_transition(
		st_error, (union state *)st_idle,
		vc_tsrc_iface_error_to_idle, 0);
	if (!t_error_idle)
		return 0;

	src->fsm = fsm;

	/* Init internal data for iface */
	ret = vc_tsrc_iface_init_data(src);

	return ret;
}

int free_iface_fsm(struct vc_timing_src *src)
{
	int ret;

	/* Stop FSM */
	ret = vc_tsrc_terminate(src);

	/* Free internal data for iface */
	vc_tsrc_iface_free_data(src);

	return ret;
}


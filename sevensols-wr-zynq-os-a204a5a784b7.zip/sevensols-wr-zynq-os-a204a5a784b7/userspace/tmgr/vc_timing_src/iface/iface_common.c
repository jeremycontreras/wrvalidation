/*
 * iface-common.c
 *
 * Application logic for Interface timing source (WR and PTP).
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jun 18, 2020
 * Last modified: Jun 18, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>

#include "commondefs.h"
#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "vc_iface_defs.h"
#include "iface_impl_def.h"
#include "gpa_interface.h"
#include "hald.h"
#include "ppsi.h"
#include "ptpd.h"
#include "ktmgr.h"

/***********************************************************************
 * Private functions                                                   *
 ***********************************************************************/

static void vc_tsrc_iface_common_update_hald_leds(struct vc_timing_src *src, struct vc_tsrc_iface_common_data *d)
{
	enum tmgr_vcs_code code;
	enum vc_status status;
	enum hald_led_out_state los = HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS;
	enum pps_mode m;

	code = vc_tsrc_get_vcs_code(src);
	status = convert_vcs_state_into_vc_status(code);

	switch(status) {
	case VC_STATUS_OK:
		los = HALD_LED_OUT_STATE_OK;
		break;
	case VC_STATUS_WARNING:
		if(d->launch_manual_ho || code == VCS_INITIALIZING) {
			los = HALD_LED_OUT_STATE_TRANS_WARN;
		} else {
			los = HALD_LED_OUT_STATE_WARN_LOCKED;
		}
		break;
	case VC_STATUS_ERROR:
		get_tmgr_config_pps_mode(&m);
		if (m == PPS_MODE_TMGR_ALWAYS_ON) {
			los = HALD_LED_OUT_STATE_CRIT_PPS_ON;
		} else {
			los = HALD_LED_OUT_STATE_CRIT_PPS_OFF;
		}
		break;
	default:
		break;
	}

	if(los != d->los_prev) {
		d->los_prev = los;
		update_hald_out_led(los);
	}
}

static void vc_tsrc_iface_common_ktmgr_align(struct vc_timing_src *src, int enable)
{
	int en = (enable) ? 1 : 0;

	if((src == NULL) || (vc_tsrc_is_active(src) == 0))
		return;

	ktmgr_set_attr(KTMGR_ENABLE_ALIGN, en);
}

#define CLOCK_CLASS_SYNCE_UNLOCKED 104
#define HO_CLK_ACU_T0 GPA_1588_ACU_100_NS
static void vc_tsrc_iface_common_ktmgr_update(struct vc_timing_src *src, struct vc_tsrc_iface_common_data *d)
{
	switch(vc_tsrc_get_vcs_code(src)) {
	case VCS_INITIALIZING:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_SYSTEM_ERROR:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_WR_LOCKED:
		break;
	case VCS_BC_PTP_LOCKED:
		break;
	case VCS_BC_WR_LOCKED_LEGACY:
		break;
	case VCS_BC_LOCKED_FR:
		d->clock_utc_offset_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
        case VCS_BC_NOLINK_IFACE_DOWN:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_NOLINK_SYNCE_BAD_QL:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_NOLINK_HO_SYNCE_BAD_QL:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
        case VCS_BC_NOLINK_HO_IFACE_DOWN:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
	case VCS_BC_LOCKED_SYNCE_NOT_LOCKED:
		d->clock_class = CLOCK_CLASS_SYNCE_UNLOCKED;
		d->clock_freq_valid = 0;
		break;
        case VCS_BC_LOCKED_HO_SYNCE_NOT_LOCKED:
		d->clock_class = CLOCK_CLASS_SYNCE_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
	case VCS_BC_NOLINK_GM_MAINTENANCE:
		break;
	case VCS_BC_HO_MAINTENANCE:
		break;
	case VCS_BC_NOLINK_MASTER_NOT_DETECTED:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
	case VCS_BC_NOLINK_HO_FR:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
	case VCS_BC_10M_PPS_HO_FR:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 1;
		d->clock_accuracy = HO_CLK_ACU_T0;
		break;
	case VCS_BC_NOLINK_PTP_ERROR:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_NOLINK_NOLOCK:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_utc_offset_valid = 0;
		d->clock_time_valid = 0;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_NOLINK_REP_LOCK_UNLOCK:
		break;
	case VCS_BC_NOLINK_LOCKED_FR:
		d->clock_class = GPA_1588_CLASS_DEFAULT;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_10M_PPS_LOCKED_FR:
		d->clock_class = GPA_1588_CLASS_GM_PTP_UNLOCKED;
		d->clock_freq_valid = 0;
		d->clock_accuracy = GPA_1588_ACU_UNKNOWN;
		break;
	case VCS_BC_HO_LOCKED:
		break;
	case VCS_BC_HO_LOCKED2:
		break;
	case VCS_BC_NOLINK_LOCKED_GM_MAINTENANCE:
		break;
	case VCS_BC_LOCKED_GM_NTP_ERROR:
		break;
	case VCS_BC_LOCKED_GM_LEAPS_EXPIRED:
		break;
	case VCS_BC_LOCKED_GM_NTP_INTEGRITY:
		break;
	case VCS_BC_LOCKED_NTP_INTEGRITY:
		break;
	case VCS_BC_LOCKED_SFP_CAL:
		break;
	case VCS_BC_LOCKED_FIBER_CAL:
		break;
	default:
		return;
	}

	// Update ktmgr entries
	ktmgr_set_attr(KTMGR_CLK_CLASS, d->clock_class);
	ktmgr_set_attr(KTMGR_CLK_VARIANCE, d->clock_variance);
	ktmgr_set_attr(KTMGR_PRIORITY1, d->clock_priority1);
	ktmgr_set_attr(KTMGR_PRIORITY2, d->clock_priority2);
	ktmgr_set_attr(KTMGR_CLK_ACCURACY, d->clock_accuracy);
	ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, d->clock_utc_offset_valid);
	ktmgr_set_attr(KTMGR_TIME_VALID, d->clock_time_valid);
	ktmgr_set_attr(KTMGR_FREQ_VALID, d->clock_freq_valid);

	// Finally, update ktmgr sysfs
	ktmgr_set_attr(KTMGR_UPDATE, 1);

}

#define MAX_VCS_ARGS 10
static void vc_tsrc_iface_common_vc_info_update(struct vc_timing_src *src)
{
	const char *msg_args[MAX_VCS_ARGS] = {0};
	int n_msg_args = 0;
	const char *act_ref_args[MAX_VCS_ARGS] = {0};
	int n_act_ref_args = 0;
	char *proto = (src->priv.iface.proto == PORT_PROTO_WR) ? "WR" : "PTP";
	const char *ifname = src->priv.iface.name;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;

	switch(vc_tsrc_get_vcs_code(src)) {
	case VCS_BC_WR_LOCKED:
	case VCS_BC_PTP_LOCKED:
	case VCS_BC_WR_LOCKED_LEGACY:
	case VCS_BC_LOCKED_SYNCE_NOT_LOCKED:
		n_msg_args = 0;
		n_act_ref_args = 1;
		act_ref_args[0] = &ifname[0];
		break;
        case VCS_BC_NOLINK_IFACE_DOWN:
        case VCS_BC_NOLINK_HO_IFACE_DOWN:
	case VCS_BC_NOLINK_GM_MAINTENANCE:
	case VCS_BC_HO_MAINTENANCE:
	case VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED:
	case VCS_BC_NOLINK_HO_FR:
	case VCS_BC_10M_PPS_HO_FR:
	case VCS_INITIALIZING:
	case VCS_SYSTEM_ERROR:
	case VCS_READY:
	case VCS_BC_NOLINK_SYNCE_BAD_QL:
	case VCS_BC_NOLINK_HO_SYNCE_BAD_QL:
	case VCS_BC_LOCKED_HO_SYNCE_NOT_LOCKED:
		n_msg_args = 0;
		n_act_ref_args = 0;
		break;
	case VCS_BC_NOLINK_MASTER_NOT_DETECTED:
	case VCS_BC_NOLINK_PTP_ERROR:
		n_msg_args = 1;
		msg_args[0] = &proto[0];
		n_act_ref_args = 2;
		act_ref_args[0] = &proto[0];
		act_ref_args[1] = &ifname[0];
		break;
	case VCS_BC_NOLINK_NOLOCK:
	case VCS_BC_NOLINK_REP_LOCK_UNLOCK:
	case VCS_BC_NOLINK_LOCKED_FR:
	case VCS_BC_10M_PPS_LOCKED_FR:
	case VCS_BC_HO_LOCKED:
	case VCS_BC_HO_LOCKED2:
	case VCS_BC_NOLINK_LOCKED_GM_MAINTENANCE:
	case VCS_BC_LOCKED_GM_NTP_ERROR:
	case VCS_BC_LOCKED_GM_LEAPS_EXPIRED:
	case VCS_BC_LOCKED_GM_NTP_INTEGRITY:
	case VCS_BC_LOCKED_NTP_INTEGRITY:
	case VCS_BC_LOCKED_SFP_CAL:
	case VCS_BC_LOCKED_FIBER_CAL:
	case VCS_BC_LOCKED_FR:
		n_msg_args = 0;
		n_act_ref_args = 2;
		act_ref_args[0] = &proto[0];
		act_ref_args[1] = &ifname[0];
		break;
	default:
		return;
	}

	/* Update VC info using VCS code */
	vc_tsrc_update_vc_info_data_vcs(src, msg_args, n_msg_args, act_ref_args, n_act_ref_args);

	/* Update ktmgr info if timing source is active*/
	if(vc_tsrc_is_active(src)) {
		vc_tsrc_iface_common_ktmgr_update(src, d);
		vc_tsrc_iface_common_update_hald_leds(src, d);
	}

	/* Update clockQ parameter from interface internal data (avoid to call ppsi funcs again) */
	strncpy(&src->vc_info.clockid[0], &d->clockid[0], MAX_STR_LEN-1);
	src->vc_info.clock_class = d->clock_class;
	src->vc_info.clock_accuracy = d->clock_accuracy;
	src->vc_info.clock_variance = d->clock_variance;
	src->vc_info.clock_priority1 = d->clock_priority1;
	src->vc_info.clock_priority2 = d->clock_priority2;
	src->vc_info.tprop_utc_offset = d->clock_utc_offset;
	src->vc_info.tprop_utc_offset_valid = d->clock_utc_offset_valid;
	src->vc_info.tprop_time_valid = d->clock_time_valid;
	src->vc_info.tprop_freq_valid = d->clock_freq_valid;
	src->vc_info.n_hops = d->n_hops;

}

static int vc_tsrc_iface_common_init_data(struct vc_timing_src *src)
{
	int ret = 1;
	struct vc_tsrc_iface_common_data *d;

	if(!src)
		return ret;

	/* Reserve memory for internal data (only first time) */
	if(!src->fsm_ext)
		src->fsm_ext = malloc(sizeof(*d));

	memset(src->fsm_ext, 0, sizeof(*d));

	d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;

	d->gm_present = 0;
	d->launch_manual_ho = 0;

	/* Init hooks for VC info */
	src->vc_info.pre_update = NULL;
	src->vc_info.update = vc_tsrc_iface_common_vc_info_update;
	src->vc_info.post_update = NULL;

	ret = 0;

	return ret;
}

static int iface_get_ho_state(struct vc_timing_src *src)
{
	int ret;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	char *sys_err;

	ret = hald_get_softpll_ho_state(&d->holdover_state);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving holdover_state from HALd");
	}

	ret = get_ho_config_force_trigger(&d->ho_force_trig);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving force_trigger from HALd");
	}

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_error("%s\n", sys_err);
	return ret;
}

static int is_ho_activated(enum ho_state state)
{
	return (state == HO_ACTIVATED || state == HO_EXPIRED);
}

static int is_ho_ready(enum ho_state state)
{
	return (state == HO_READY || state == HO_LEARNING);
}

static int handle_ho_force_trigger(enum ho_state state, enum holdover_force_trigger ft)
{
	if((ft == HO_FORCE_TRIGGER_START && state != HO_READY) ||
		ft == HO_FORCE_TRIGGER_STOP) {
		set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);
	}

	return (state == HO_READY && ft == HO_FORCE_TRIGGER_START);
}

static int vc_tsrc_iface_common_update_gen_params(struct vc_timing_src *src)
{
	int ret = 0;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	const char *port_name = src->priv.iface.name;
	char *sys_err;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		ret = ppsi_get_port_linkup(port_name, &d->linkup);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving linkup from PPSi");
		}

		ret = ppsi_get_port_n_frgns(port_name, &d->n_frgns);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving n_frgns from PPSi");
		}
		break;
	case PORT_PROTO_PTP:
		ret = ptpd_get_port_link_status(port_name, &d->linkup);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving linkup from PTPd");
		}
		d->n_frgns = 1;
		break;
	default:
		ret = 1;
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_error("%s\n", sys_err);
	return ret;
}

static int vc_tsrc_iface_common_update_servo_params(struct vc_timing_src *src)
{
	int ret = 0;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	const char *port_name = src->priv.iface.name;
	char *sys_err;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		ret = ppsi_get_port_servo_state(port_name, &d->servo_state.ppsi);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving servo state from PPSi");
		}
		break;
	case PORT_PROTO_PTP:
		ret = ptpd_get_port_servo_state(port_name, &d->servo_state.ptpd);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving servo state from PTPd");
		}
		ret = ptpd_get_port_enable_synce(port_name, &d->synce_enabled);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving SyncE enable from PTPd");
		}
		ret = ptpd_get_port_synce_state(port_name, &d->synce_state);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving SyncE state from PTPd");
		}
		if(d->synce_enabled) {
			ret = esmcd_get_port_info_client_ssm(port_name, &d->synce_ssm);
			if(ret) {
				EXIT_SYS_ERROR("Error retrieving info from ESMCd");
			}
		}
		break;
	default:
		ret = 1;
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_error("%s\n", sys_err);
	return ret;
}

static int vc_tsrc_iface_common_update_tprop_params(struct vc_timing_src *src)
{
	int ret = 0;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	const char *port_name = src->priv.iface.name;
	char *sys_err;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		ret = ppsi_get_port_clock_class(port_name, &d->clock_class);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_class for port from PPSi");
		}
		ret = ppsi_get_port_clock_accuracy(port_name, &d->clock_accuracy);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_accuracy for port from PPSi");
		}
		ret = ppsi_get_port_clock_variance(port_name, &d->clock_variance);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_variance for port from PPSi");
		}
		ret = ppsi_get_port_clock_priority1(port_name, &d->clock_priority1);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_priority1 for port from PPSi");
		}
		ret = ppsi_get_port_clock_priority2(port_name, &d->clock_priority2);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_priority1 for port from PPSi");
		}
		ret = ppsi_get_port_clock_utc_offset(port_name, &d->clock_utc_offset);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_utc_offset for port from PPSi");
		}
		ret = ppsi_get_port_clock_utc_offset_valid(port_name, &d->clock_utc_offset_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_utc_offset_valid for port from PPSi");
		}
		ret = ppsi_get_port_clock_time_valid(port_name, &d->clock_time_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_time_valid for port from PPSi");
		}
		ret = ppsi_get_port_clock_freq_valid(port_name, &d->clock_freq_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_freq_valid for port from PPSi");
		}
		ret = ppsi_get_port_clock_clockid(port_name, &d->clockid[0]);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clockid for port from PPSi");
		}
		ret = ppsi_get_port_clock_n_hops(port_name, &d->n_hops);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving n_hops for port from PPSi");
		}
		break;
	case PORT_PROTO_PTP:
		ret = ptpd_get_port_clock_class(port_name, &d->clock_class);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_class for port from PTPd");
		}
		ret = ptpd_get_port_clock_accuracy(port_name, &d->clock_accuracy);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_accuracy for port from PTPd");
		}
		ret = ptpd_get_port_clock_variance(port_name, &d->clock_variance);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_variance for port from PTPd");
		}
		ret = ptpd_get_port_clock_priority1(port_name, &d->clock_priority1);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_priority1 for port from PTPd");
		}
		ret = ptpd_get_port_clock_priority2(port_name, &d->clock_priority2);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_priority1 for port from PTPd");
		}
		ret = ptpd_get_port_clock_utc_offset(port_name, &d->clock_utc_offset);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_utc_offset for port from PTPd");
		}
		ret = ptpd_get_port_clock_utc_offset_valid(port_name, &d->clock_utc_offset_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_utc_offset_valid for port from PTPd");
		}
		ret = ptpd_get_port_clock_time_valid(port_name, &d->clock_time_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_time_valid for port from PTPd");
		}
		ret = ptpd_get_port_clock_freq_valid(port_name, &d->clock_freq_valid);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clock_freq_valid for port from PTPd");
		}
		ret = ptpd_get_port_clock_clockid(port_name, &d->clockid[0]);
		if(ret) {
			EXIT_SYS_ERROR("Error retrieving clockid for port from PTPd");
		}
		break;
	default:
		ret = 1;
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	/* Finaly, update gm_present flag */
	if (d->clock_class == GPA_1588_CLASS_GM_PTP_LOCKED ||
		d->clock_class == GPA_1588_CLASS_GM_PTP_HOLDOVER ||
		d->clock_class == GPA_1588_CLASS_GM_PTP_FR_MASTER ||
		d->clock_class == GPA_1588_CLASS_GM_PTP_UNLOCKED)
		d->gm_present = 1;
	else
		d->gm_present = 0;

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n",sys_err);
	return ret;
}

static int vc_tsrc_iface_common_update_params(struct vc_timing_src *src)
{
	int ret = 0;

	ret = vc_tsrc_iface_common_update_gen_params(src);
	if(ret)
		return ret;

	ret = vc_tsrc_iface_common_update_servo_params(src);
	if(ret)
		return ret;

	ret = vc_tsrc_iface_common_update_tprop_params(src);
	if(ret)
		return ret;

	ret = iface_get_ho_state(src);

	return ret;
}

static void vc_tsrc_iface_common_start_iface_locking(struct vc_timing_src *src)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	const char *port_name = src->priv.iface.name;
	int ret;
	int ho_active = is_ho_activated(d->holdover_state);
	char *sys_err;

	/*  If HO is enabled, reset it before enabling PPSi */
	if(ho_active)
		hald_set_softpll_ho_run(1);

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		/* First of all, put interface in slave mode */
		ret = ppsi_set_port_mode(port_name, PPSI_PORT_MODE_SLAVE);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi port mode to SLAVE");
		}

		/* Report port status as SLAVE */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_SLAVE);

		ret = ppsi_set_ext_clk(1);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi external clock configuration to YES");
		}

		ret = ppsi_set_cfg_timing_mode(PPSI_TM_BC);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi timing mode to BC");
		}

		ret = ppsi_set_run_stop(1);
		if(ret) {
			EXIT_SYS_ERROR("Error re-starting PPSi wrapper");
		}
		break;
	case PORT_PROTO_PTP:
		/* First of all, put interface in slave mode */
		ret = ptpd_set_port_mode(port_name, PTPD_PORT_MODE_SLAVE);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PTPd port mode to SLAVE");
		}

		/* Report port status as SLAVE */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_SLAVE);

		/* Re-start PTPd instance */
		ret = ptpd_set_run_stop(port_name, 1);
		if(ret) {
			EXIT_SYS_ERROR("Error re-starting PTPd wrapper");
		}
		break;
	default:
		ret = 1;
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	/* Set VCS code as Initializing */
	vc_tsrc_set_vcs_code(src, VCS_INITIALIZING);
	return;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);

}

static int _vc_tsrc_iface_common_check_link_prereq(struct vc_timing_src *src, int idle)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	int ready = 0;
	int ho_active = is_ho_activated(d->holdover_state);
	int ho_ready = is_ho_ready(d->holdover_state);

	/* Update ready flag */
	ready = (d->linkup && d->n_frgns > 0) ? 1 : 0;

	/* Error 1: Link down */
	if(!d->linkup) {
		if(!ho_active)
			vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_IFACE_DOWN);
		else
			vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_IFACE_DOWN);
	} else {
		/* Error 2: No Announce packets or invalid ones */
		if(!d->n_frgns) {
			if(!ho_active) {
				if(idle || !ho_ready) {
					vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_MASTER_NOT_DETECTED);
				}
				else {
					vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED);
					d->launch_manual_ho = 1;
				}
			} else {
				vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED);
			}
		} else {
			/* Error 3: SyncE-related */
			if(d->synce_enabled) {
				if(idle) {
					if(d->synce_ssm != ESMCD_PORT_SSM_QL_PRC) {
						ready = 0;
						vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_SYNCE_BAD_QL);
					}
				} else {
					if(!ho_ready) {
						if(d->synce_ssm != ESMCD_PORT_SSM_QL_PRC) {
							ready = 0;
							vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_SYNCE_BAD_QL);
						}
					} else {
						if(d->synce_ssm != ESMCD_PORT_SSM_QL_PRC) {
							ready = 0;
							vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_SYNCE_BAD_QL);
							d->launch_manual_ho = 1;
						}
					}
				}
			}
		}
	}

	/*  Everything is OK... if it is IDLE state, mark as READY */
	if(ready && idle)
		vc_tsrc_set_vcs_code(src, VCS_READY);

	return ready;
}

static int vc_tsrc_iface_common_check_link_prereq(struct vc_timing_src *src)
{
	return _vc_tsrc_iface_common_check_link_prereq(src, 1);
}

static int vc_tsrc_iface_common_check_link_locking(struct vc_timing_src *src)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	char *sys_err;
	int locked = 1;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		// Update locked flag
		locked = (d->servo_state.ppsi == PPSI_SERVO_TRACK_PHASE);
		break;
	case PORT_PROTO_PTP:
		// Update locked flag
		locked = (d->servo_state.ptpd == PTPD_SERVO_STATE_LOCKED);
		break;
	default:
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	return locked;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);
	return 0;
}

static int vc_tsrc_iface_common_check_link_locked(struct vc_timing_src *src)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	int ho_active = is_ho_activated(d->holdover_state);
	int ho_ready = is_ho_ready(d->holdover_state);
	int locked = 1;

	/* First, re-check prereq */
	if(!_vc_tsrc_iface_common_check_link_prereq(src,0))
		return 0;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		// Update locked flag
		locked = (d->servo_state.ppsi == PPSI_SERVO_TRACK_PHASE);
		break;
	case PORT_PROTO_PTP:
		// Update locked flag
		locked = (d->servo_state.ptpd == PTPD_SERVO_STATE_LOCKED);
		break;
	default:
		locked = 0;
		break;
	};

	// Check PPSi Locked state
	if(locked) {
		// First, put initial state as LOCKED and modify if error
		vc_tsrc_set_vcs_code(src, (d->clock_class == GPA_1588_CLASS_GM_ARB_UNLOCKED) ?
				VCS_BC_LOCKED_FR : ((src->priv.iface.proto == PORT_PROTO_WR) ?
						VCS_BC_WR_LOCKED : VCS_BC_PTP_LOCKED));

		/* User has request to enter in HO */
		if(handle_ho_force_trigger(d->holdover_state, d->ho_force_trig)) {
			locked = 0;
			vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_FR);
			d->launch_manual_ho = 1;
			goto check_ppsi_link_exit;
		}

		// If GM is the network root...
		if(d->gm_present) {
			// NTP error in GM device
			if (d->clock_class == GPA_1588_CLASS_GM_PTP_LOCKED &&
				(!d->clock_utc_offset_valid) &&
				(!d->clock_time_valid) &&
				d->clock_freq_valid &&
				d->clock_accuracy >= GPA_1588_ACU_GT_10_S) {
				vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_GM_NTP_ERROR);
				goto check_ppsi_link_exit;
			}

			// Leapseconds file expiration in GM device
			if (d->clock_class == GPA_1588_CLASS_GM_PTP_LOCKED &&
				(!d->clock_utc_offset_valid) &&
				d->clock_time_valid &&
				d->clock_freq_valid &&
				d->clock_accuracy >= GPA_1588_ACU_1_S) {
				vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_GM_LEAPS_EXPIRED);
				goto check_ppsi_link_exit;
			}

			// NTP offset drift in GM device
			if (d->clock_class == GPA_1588_CLASS_GM_PTP_LOCKED &&
				d->clock_utc_offset_valid &&
				d->clock_time_valid &&
				d->clock_freq_valid &&
				d->clock_accuracy >= GPA_1588_ACU_1_S &&
				d->clock_accuracy <= GPA_1588_ACU_10_S) {
				vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_GM_NTP_INTEGRITY);
				goto check_ppsi_link_exit;
			}

			// GM degraded to FR/HO
			if ((d->clock_class == GPA_1588_CLASS_GM_PTP_FR_MASTER ||
				d->clock_class == GPA_1588_CLASS_GM_PTP_UNLOCKED)) {
				/*
				 * Here, there are two cases:
				 *   1) We receive clock_class 187 with freq_valid equals to 1. BC in the upper
				 *   layer is in HO and we have to follow it. This is a WARNING use case.
				 *   2) We receive clock_class 187/52 with freq_valid equals to 0. GM is in FR,
				 *   consequently, we have to exit to our FR/HO timing source.
				 */
				if(d->clock_freq_valid && d->clock_class != GPA_1588_CLASS_GM_PTP_FR_MASTER) {
					vc_tsrc_set_vcs_code(src, VCS_BC_HO_LOCKED2);
				}
				else {
					if(ho_ready) {
						/* CRITICAL STATE */
						vc_tsrc_set_vcs_code(src, VCS_BC_10M_PPS_HO_FR);
						locked = 0;
					} else {
						vc_tsrc_set_vcs_code(src, VCS_BC_10M_PPS_LOCKED_FR);
					}
				}

				goto check_ppsi_link_exit;
			}

			// SyncE checks
			if((d->synce_enabled && d->synce_state != PTPD_SYNCE_STATE_LOCKED)) {
				locked = 0;
				if(ho_ready) {
					vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_HO_SYNCE_NOT_LOCKED);
				} else {
					vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_SYNCE_NOT_LOCKED);
				}
				goto check_ppsi_link_exit;
			}

		}
		else {
			if (d->clock_class == GPA_1588_CLASS_DEFAULT) {
				vc_tsrc_set_vcs_code(src, (ho_ready) ? VCS_BC_NOLINK_HO_FR : VCS_BC_NOLINK_LOCKED_FR);
				if(ho_ready) {
					locked = 0;
					d->launch_manual_ho = 1;
				}

				goto check_ppsi_link_exit;
			}
		}
	} else {
		/* Lock has lost!! */
		if(!ho_ready) {
			vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_MASTER_NOT_DETECTED);
		}
		else {
			vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED);
			if(!ho_active)
				d->launch_manual_ho = 1;
		}
	}

check_ppsi_link_exit:
	return locked;
}

static void vc_tsrc_iface_common_notify_tmout(struct vc_timing_src *src)
{
	/* Update VCS code */
	vc_tsrc_set_vcs_code(src, VCS_BC_NOLINK_NOLOCK);
}

static void vc_tsrc_iface_common_notify_lock(struct vc_timing_src *src)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	enum pps_mode m;
	struct timespec ts = {.tv_sec = 1, .tv_nsec = NS_PER_SLEEP};

	/* Update VCS code */
	switch(d->clock_class) {
	case GPA_1588_CLASS_GM_ARB_UNLOCKED:
		vc_tsrc_set_vcs_code(src, VCS_BC_LOCKED_FR);
		break;
	case GPA_1588_CLASS_GM_PTP_LOCKED:
		vc_tsrc_set_vcs_code(src, (src->priv.iface.proto == PORT_PROTO_WR) ?
				VCS_BC_WR_LOCKED : VCS_BC_PTP_LOCKED);
		break;
	default:
		break;
	}

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(1);

	/* Sleep for a while to ensure PPS when Sync is requested */
	nanosleep(&ts, 0);

	// Sync PLLs
	hald_sync_plls();
	// Enable KTMGR aligner
	vc_tsrc_iface_common_ktmgr_align(src, 1);

}

static void vc_tsrc_iface_common_notify_error(struct vc_timing_src *src)
{
	const char *port_name = src->priv.iface.name;
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	int ret;
	char *sys_err;
	enum pps_mode m;

	/* First, lauch manual trigger for HO if any */
	if(d->launch_manual_ho) {
		hald_set_softpll_ho_trig_force_ext_trig(HO_TRIGGER_MANUAL);
		d->launch_manual_ho = 0;
	} else {
		/* Set PPS if it is controlled by TMGR */
		get_tmgr_config_pps_mode(&m);
		if(m != PPS_MODE_TMGR_ALWAYS_ON && d->holdover_state != HO_ACTIVATED)
			hald_set_pps_mode_state_tmgr(0);
	}

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		/* Put port mode as passive */
		ret = ppsi_set_port_mode(port_name, PPSI_PORT_MODE_PASSIVE);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi port mode to PASSIVE");
		}

		/* Report port status as PASSIVE */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_PASSIVE);

		/* Re-start PPSi */
		ret = ppsi_set_ext_clk(1);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi external clock configuration to YES");
		}

		ret = ppsi_set_cfg_timing_mode(PPSI_TM_BC);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi timing mode to BC");
		}

		ret = ppsi_set_run_stop(1);
		if(ret) {
			EXIT_SYS_ERROR("Error re-starting PPSi wrapper");
		}
		break;
	case PORT_PROTO_PTP:
		/* Put port mode as disabled */
		ret = ptpd_set_port_mode(port_name, PTPD_PORT_MODE_DISABLED);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PTPd port mode to DISABLED");
		}

		/* Report port status as DISABLED */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_DISABLED);

		/* Re-start PTPd instance */
		ret = ptpd_set_run_stop(port_name, 1);
		if(ret) {
			EXIT_SYS_ERROR("Error re-starting PTPd wrapper");
		}

		break;
	default:
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	vc_tsrc_iface_common_ktmgr_align(src, 0);
	return;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);
	vc_tsrc_iface_common_ktmgr_align(src, 0);
}

static int vc_tsrc_iface_common_exit_data(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src)
		return ret;

	/* Free memory for internal data */
	if(src->fsm_ext) {
		free(src->fsm_ext);
		src->fsm_ext = NULL;
	}

	ret = 0;

	return ret;
}

/***********************************************************************
 * API implementation                                                  *
 ***********************************************************************/

static int vc_tsrc_iface_common_init(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	struct vc_tsrc_iface_common_data *d = (struct vc_tsrc_iface_common_data *) src->fsm_ext;
	const char *port_name = src->priv.iface.name;
	int ret;
	char *sys_err;

	switch(src->priv.iface.proto) {
	case PORT_PROTO_WR:
		/* First of all, put interface in passive mode */
		ret = ppsi_set_port_mode(port_name, PPSI_PORT_MODE_PASSIVE);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PPSi port mode to PASSIVE");
		}

		/* Report port as PASSIVE */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_PASSIVE);
		break;
	case PORT_PROTO_PTP:
		/* First of all, put interface in disabled mode */
		ret = ptpd_set_port_mode(port_name, PTPD_PORT_MODE_DISABLED);
		if(ret) {
			EXIT_SYS_ERROR("Error setting PTPd port mode to DISABLED");
		}

		/* Report port as DISABLED */
		set_port_status(src->priv.iface.port_idx, PORT_STATUS_DISABLED);

		break;
	default:
		ret = 1;
		EXIT_SYS_ERROR("Error port proto");
		break;
	};

	d->launch_manual_ho = 0;

	return 0;
sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);
	return ret;
}

static int vc_tsrc_iface_common_create(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret;

	ret = vc_tsrc_iface_common_init_data(src);
	if(ret)
		return ret;

	ret = vc_tsrc_iface_common_init(idef, src);

	return ret;
}

static int vc_tsrc_iface_common_update(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret = 0;

	ret = vc_tsrc_iface_common_update_params(src);

	return ret;
}

static void vc_tsrc_iface_common_start_locking(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	enum pps_mode m;

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(0);

	/* Disable KTMGR aligner */
	vc_tsrc_iface_common_ktmgr_align(src, 0);

	/* Start hardware locking */
	vc_tsrc_iface_common_start_iface_locking(src);
}

static int vc_tsrc_iface_common_check_link(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src, enum vc_tsrc_idef_chlnk_type type)
{
	int ret = 0;

	switch(type) {
	case VC_TSRC_IDEF_CHLNK_PREREQ:
		ret = vc_tsrc_iface_common_check_link_prereq(src);
		break;
	case VC_TSRC_IDEF_CHLNK_LOCKING:
		ret = vc_tsrc_iface_common_check_link_locking(src);
		break;
	case VC_TSRC_IDEF_CHLNK_LOCKED:
		ret = vc_tsrc_iface_common_check_link_locked(src);
		break;
	default:
		break;
	}

	return ret;
}

static void vc_tsrc_iface_common_notify_event(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src, enum vc_tsrc_idef_event_type event)
{
	switch(event) {
	case VC_TSRC_IDEF_EVENT_TMOUT:
		vc_tsrc_iface_common_notify_tmout(src);
		break;
	case VC_TSRC_IDEF_EVENT_LOCK:
		vc_tsrc_iface_common_notify_lock(src);
		break;
	case VC_TSRC_IDEF_EVENT_ERROR:
		vc_tsrc_iface_common_notify_error(src);
		break;
        case VC_TSRC_IDEF_EVENT_PREEMPT:
		vc_tsrc_iface_common_notify_error(src);
		break;
	default:
		break;
	}
}

static int vc_tsrc_iface_common_exit(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	return 0;
}

static int vc_tsrc_iface_common_destroy(struct vc_tsrc_iface_impl_def *idef, struct vc_timing_src *src)
{
	int ret;

	ret = vc_tsrc_iface_common_exit(idef, src);
	if(ret)
		return ret;

	return vc_tsrc_iface_common_exit_data(src);
}

/***********************************************************************
 * Global data                                                         *
 ***********************************************************************/

struct vc_tsrc_iface_impl_def vc_tsrc_iface_common = {
	.name = "Interface time source implementation for WR and PTP",
	.create = vc_tsrc_iface_common_create,
	.init = vc_tsrc_iface_common_init,
	.update = vc_tsrc_iface_common_update,
	.start_locking = vc_tsrc_iface_common_start_locking,
	.check_link = vc_tsrc_iface_common_check_link,
	.notify_event = vc_tsrc_iface_common_notify_event,
	.exit = vc_tsrc_iface_common_exit,
	.destroy = vc_tsrc_iface_common_destroy,
};

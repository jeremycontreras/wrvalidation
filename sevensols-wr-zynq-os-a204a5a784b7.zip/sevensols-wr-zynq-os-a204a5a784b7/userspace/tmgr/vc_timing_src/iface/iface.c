/*
 * iface.c
 *
 * Application logic for Interface timing source.
  *
 * Author: Ricardo Cañuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <time.h>
#include <libgpa.h>

#include "commondefs.h"
#include "vc_timing_src.h"
#include "vc_iface_defs.h"
#include "iface_impl_def.h"
#include "gpa_interface.h"
#include "ppsi.h"

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

/* Number of seconds to wait for lock */
#define SECS_WAIT_LOCK 300

/***********************************************************************
 * FSM shared data                                                     *
 ***********************************************************************/

/***********************************************************************
 * Utility functions                                                   *
 ***********************************************************************/

int vc_tsrc_iface_init_data(struct vc_timing_src *src)
{
	int ret;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	ret = iface_idef_create(idef, src);
	return ret;
}

void vc_tsrc_iface_free_data(struct vc_timing_src *src)
{
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	iface_idef_destroy(idef, src);
}

/***********************************************************************
 * Action functions.                                                   *
 ***********************************************************************/

/* IDLE */
/* Enter actions */
/* Exit actions */

/* WAIT_LOCK */
/* Enter actions */

void vc_tsrc_iface_enter_wait_lock(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	/* Set interface source as running one */
	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_RUNNING);

	/* Init interface locking process */
	iface_idef_start_locking(idef, src);

	/* Update vc info parameters */
	vc_tsrc_update_vc_info(src);
}

/* Exit actions */

/* LOCKED */
/* Enter actions */

void vc_tsrc_iface_enter_locked(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Update vc info parameters */
	vc_tsrc_update_vc_info(src);
}

/* Exit actions */

/* ERROR */
/* Enter actions */
/* Exit actions */

/* END */
/* Enter actions */
/* Exit actions */

/***********************************************************************
 * State functions.                                                    *
 ***********************************************************************/

/* IDLE */
void *vc_tsrc_iface_idle(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	/* Init interface definition implementation */
	if(iface_idef_init(idef, src))
		goto idle_update_vc_info;

	/* Update internal parameters */
	if(iface_idef_update(idef, src))
		goto idle_update_vc_info;

	/* If prereq are met, mark as ready */
	if(iface_idef_chlnk_prereq(idef, src)) {
		/* Set quality metric to MAX value (OK), Wait for ACK */
		if (!vc_tsrc_checkp_fsm_is_enabled(src))
			src->qm.value = VC_TSRC_MV_MAX;
		vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_READY);
	}

idle_update_vc_info:
	/* Update vc info parameters */
	vc_tsrc_update_vc_info(src);

	/* Substitute this for some ACTUAL work */
	nanosleep(&ts, 0);

	return args;
}

/* WAIT_LOCK */
void *vc_tsrc_iface_wait_lock(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	int retries = SECS_TO_RETRIES(SECS_WAIT_LOCK);
	int locked = 0;
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	pr_warning("Starting Interface timing source\n");

	/* Wait for the interface synchronization to lock */
	do {
		/*
		 * Exit conditions:
		 *
		 * Bail out if the mode becomes inactive (if it's preempted or
		 * if the user selects another one).
		 *
		 */
		if (!vc_tsrc_is_active(src))
			break;

		nanosleep(&ts, 0);

		/* Update interface parameters */
		if(iface_idef_update(idef, src))
			break;

		/* Check if interface is locked */
		if(iface_idef_chlnk_locking(idef, src)) {
			iface_idef_notify_lock(idef, src);
			locked = 1;
		}
	} while (!locked && retries--);

	if (retries <= 0)
		iface_idef_notify_tmout(idef, src);

	/* Update vc info parameters */
	vc_tsrc_update_vc_info(src);

	return args;
}

/* LOCKED */
void *vc_tsrc_iface_locked(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	int locked = 1;
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	do {
		if(!vc_tsrc_is_active(src))
			break;

		nanosleep(&ts, 0);

		/* Update interface parameters */
		if (iface_idef_update(idef, src))
			break;

		/* Check link status */
		locked = iface_idef_chlnk_locked(idef, src);

		/* Update vc info parameters */
		vc_tsrc_update_vc_info(src);
	} while(locked);

	return args;
}

/* ERROR */
void *vc_tsrc_iface_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);

	/* Update vc info parameters */
	vc_tsrc_update_vc_info(src);

	/* Set interface source as not ready and notify interface before */
	iface_idef_notify_error(idef, src);
	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_NOT_READY);

	return args;
}


/***********************************************************************
 * Transition checker functions.                                       *
 ***********************************************************************/
/* From IDLE */
int vc_tsrc_iface_idle_to_wait_lock(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Just check if interface source is active and is ready */
	return (vc_tsrc_get_run_status(src) == VC_TSRC_RUN_STATUS_READY &&
		vc_tsrc_is_active(src) && !vc_tsrc_checkp_fsm_is_enabled(src));
}

int vc_tsrc_iface_idle_to_end(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return vc_tsrc_fsm_has_to_stop(src);
}

/* From WAIT_LOCK */
int vc_tsrc_iface_wait_lock_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);
	int active = vc_tsrc_is_active(src);

	if(!active)
		iface_idef_notify_preempt(idef, src);

	/* Just check interface source has been disabled */
	return !active;
}

int vc_tsrc_iface_wait_lock_to_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);
	int locked = iface_idef_chlnk_locking(idef, src);

	return (!locked) ? 1 : 0;
}

int vc_tsrc_iface_wait_lock_to_locked(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);
	int locked = iface_idef_chlnk_locking(idef, src);

	return (locked) ? 1 : 0;
}

/* From LOCKED */
int vc_tsrc_iface_locked_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);
	int active = vc_tsrc_is_active(src);

	if(!active)
		iface_idef_notify_preempt(idef, src);

	/* Just check if interface source has been disabled */
	return !active;
}

int vc_tsrc_iface_locked_to_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_iface_impl_def *idef = iface_get_idef(src);
	int locked = iface_idef_chlnk_locked(idef, src);

	return (!locked) ? 1 : 0;
}

/* From ERROR */
int vc_tsrc_iface_error_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	vc_tsrc_set_checkp_fsm(src);

	/* Set quality metric to MIN value (CRITICAL) */
	src->qm.value = VC_TSRC_MV_MIN;

	/* Always go back to IDLE state to re-start FSM */
	return 1;
}

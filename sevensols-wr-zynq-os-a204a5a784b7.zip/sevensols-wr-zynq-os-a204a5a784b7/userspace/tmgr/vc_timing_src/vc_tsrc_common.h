/*
 * vc_tsrc_common.h
 *
 * General API for controlling Virtual Clock Timing Sources.
 * Common code header
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#ifndef __VC_TSRC_COMMON_H__
#define __VC_TSRC_COMMON_H__

#include "vc_timing_src.h"

enum hald_led_in_state {
	HALD_LED_IN_STATE_GM_LOCKED_PPS = 0,
	HALD_LED_IN_STATE_GM_LOCKED_NO_PPS,
	HALD_LED_IN_STATE_GM_ACT_REFS,
	HALD_LED_IN_STATE_GM_ACT_NO_REFS,
	HALD_LED_IN_STATE_GM_NO_ACT_PPS,
	HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS,
	N_HALD_LED_IN_STATE,
};

enum hald_led_out_state {
	HALD_LED_OUT_STATE_OK = 0,
	HALD_LED_OUT_STATE_WARN_LOCKED,
	HALD_LED_OUT_STATE_CRIT_PPS_ON,
	HALD_LED_OUT_STATE_TRANS_WARN,
	HALD_LED_OUT_STATE_CRIT_PPS_OFF,
	HALD_LED_OUT_STATE_IDLE,
	N_HALD_LED_OUT_STATE,
};

/************************************************************
 * Public API                                               *
 ************************************************************/

int update_clockq(struct vc_timing_src *);
void update_hald_in_led(enum hald_led_in_state);
void update_hald_out_led(enum hald_led_out_state);

#endif

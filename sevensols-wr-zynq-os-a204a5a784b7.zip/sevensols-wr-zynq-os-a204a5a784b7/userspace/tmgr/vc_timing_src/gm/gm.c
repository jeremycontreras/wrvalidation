/*
 * gm.c
 *
 * Application logic for the GM Virtual Clock timing source.
 * This work is based on GM VC mode from Ricardo Canuelo.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>
#include <math.h>

#include "commondefs.h"
#include "vcs.h"
#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "vc_gm_defs.h"
#include "gpa_interface.h"
#include "ktmgr.h"
#include "wr_date.h"
#include "hald.h"
#include "ppsi.h"
#include "ntp.h"
#include "leapsec.h"

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

#define DEFAULT_CLK_ACCURACY_GM         GPA_1588_ACU_100_NS
#define DEFAULT_CLK_CLASS_GM            GPA_1588_CLASS_GM_PTP_LOCKED

/*
 * GM data for FSM
 *
 * + SoftPLL specific:
 *   - spll_ext_fpanel_inputs_status: Status of inputs from Front panel (10MHz & PPS)
 *   - spll_align_state: State of the SoftPLL aligner module
 * + Holdover:
 *   - holdover_state: Holdover state
 * + Internal GM data:
 *   - current_clk_class: Current configured GM clock class
 *   - locked: 1 if the SoftPLL is locked, 0 otherwise
 *   - inputs_warning: 1 if a warning should be raised, 0 otherwise
 *   - inputs_ok: 1 if the input signals are ok (present), 0 otherwise
 *   - inputs_10m_ok: 1 if the 10M input signal is ok, 0 otherwise
 *   - inputs_pps_ok: 1 if the PPS input signal is ok, 0 otherwise
 *   - ho_available: 1 if HO is available and ready, 0 otherwise
 *   - ntp_sync_ok: 1 if the initial NTP synchronization went fine, 0 otherwise
 *   - info_ntp_status: NTP info parameter
 *   - last_ntp_ts, current_ntp_ts, ntp_first_run: Internal data to handle NTP queries
 *   - info_message: GM source info parameter
 *   - gm_cfg_time_source: PTP Time source configured by user for GM
 *   - gm_cfg_priority1: PTP priority1 configured by user for GM
 *   - gm_cfg_priority2: PTP priority2 configured by user for GM
 *   - gm_cfg_offset: Offset configured by user for GM
 *   - gm_cfg_align_pps: Align PPS mechanism settings configured by user for GM
 *   - gm_cfg_accuracy: PTP clock accuracy configured by user for GM
 *   - gm_cfg_class: PTP clock class configured by user for GM
 *
 */
struct vc_tsrc_gm_data {
	/* SoftPLL specific data */
	enum softpll_ext_fpanel spll_ext_fpanel_inputs_status;
	enum softpll_align_state spll_align_state;

	/* Holdover */
	enum ho_state holdover_state;

	/* Internal GM data */
	/* Current clock class */
	uint8_t current_clk_class;

	/* Locked condition flag */
	int locked;

	/* Inputs detected flags */
	int inputs_ok;
	int inputs_warning;
	int inputs_10m_ok;
	int inputs_pps_ok;

	/* HO internal */
	int ho_available;

	/* NTP internal */
	int ntp_sync_ok;
	enum ntp_status info_ntp_status;
	struct timespec last_ntp_ts;
	struct timespec current_ntp_ts;
	int ntp_first_run;

	/* GM general info string */
	char *info_message;

	enum gm_time_source gm_cfg_time_source;
	uint8_t gm_cfg_priority1;
	uint8_t gm_cfg_priority2;
	int32_t gm_cfg_offset;
	int gm_cfg_align_pps;
	uint8_t gm_cfg_accuracy;
	uint8_t gm_cfg_class;

	/* LEDs states */
	enum hald_led_out_state los_prev;
	enum hald_led_in_state lis_prev;
};

/***********************************************************************
 * FSM shared data                                                     *
 ***********************************************************************/

/***********************************************************************
 * Utility functions                                                   *
 ***********************************************************************/

static int gm_check_datap(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	if(!src->fsm_ext)
		return 0;

	return 1;
}

static int gm_get_internal_data(struct vc_timing_src *src, struct vc_tsrc_gm_data **data)
{
	if(!gm_check_datap(src))
		return 0;

	if(!data)
		return 0;

	*data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	return 1;
}

static void gm_update_hald_leds(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;
	enum hald_led_in_state lis = HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS;

	if(!gm_get_internal_data(src, &data))
		return;

	// For LED in
	if(vc_tsrc_is_active(src)) {
		enum tmgr_vcs_code code;
		enum vc_status status;
		enum hald_led_out_state los = HALD_LED_OUT_STATE_IDLE;
		enum pps_mode m;

		code = vc_tsrc_get_vcs_code(src);

		switch(code) {
		case VCS_GM_LOCKED:
			if(data->inputs_pps_ok) {
				lis = HALD_LED_IN_STATE_GM_LOCKED_PPS;
			}
			break;
		case VCS_GM_LOCKED_PPS_LOST:
			lis = HALD_LED_IN_STATE_GM_LOCKED_NO_PPS;
			break;
		default:
			if(!data->locked) {
				if(data->inputs_ok) {
					lis = HALD_LED_IN_STATE_GM_ACT_REFS;
				} else {
					lis = HALD_LED_IN_STATE_GM_ACT_NO_REFS;
				}
			} else {
				if(data->inputs_pps_ok) {
					lis = HALD_LED_IN_STATE_GM_LOCKED_PPS;
				} else {
					lis = HALD_LED_IN_STATE_GM_LOCKED_NO_PPS;
				}
			}
			break;
		};

		// For LED out
		status = convert_vcs_state_into_vc_status(code);

		switch(status) {
		case VC_STATUS_OK:
			los = HALD_LED_OUT_STATE_OK;
			break;
		case VC_STATUS_WARNING:
			if(data->ho_available || code == VCS_INITIALIZING) {
				los = HALD_LED_OUT_STATE_TRANS_WARN;
			} else {
				los = HALD_LED_OUT_STATE_WARN_LOCKED;
			}
			break;
		case VC_STATUS_ERROR:
			get_tmgr_config_pps_mode(&m);
			if (m == PPS_MODE_TMGR_ALWAYS_ON) {
				los = HALD_LED_OUT_STATE_CRIT_PPS_ON;
			} else {
				los = HALD_LED_OUT_STATE_CRIT_PPS_OFF;
			}
			break;
		default:
			break;
		}

		// Update LED out
		if(los != data->los_prev) {
			data->los_prev = los;
			update_hald_out_led(los);
		}
	} else {
		if(data->inputs_pps_ok) {
			lis = HALD_LED_IN_STATE_GM_NO_ACT_PPS;
		} else {
			lis = HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS;
		}
	}

	// Update LED in
	if(lis != data->lis_prev) {
		data->lis_prev = lis;
		update_hald_in_led(lis);
	}
}

/*
 * This function gets status of the inputs of front panel and update
 * internal fields for the VC Timing source structure.
 *
 * Returns:
 *    - 1: If everything was OK
 *    - 0: If any error raised
 */
static int gm_spll_ext_fpanel_inputs_check(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return 0;

	if(hald_get_softpll_ext_fpanel_detected(&data->spll_ext_fpanel_inputs_status)) {
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
		pr_warning("Can't get SoftPLL front panel input\n");
		return 0;
	}

	data->inputs_ok = (data->spll_ext_fpanel_inputs_status == SOFTPLL_EXT_DETECTED_PPSCLK) ? 1 : 0;
	data->inputs_10m_ok = (data->inputs_ok || data->spll_ext_fpanel_inputs_status == SOFTPLL_EXT_DETECTED_CLK) ? 1 : 0;
	data->inputs_pps_ok = (data->inputs_ok || data->spll_ext_fpanel_inputs_status == SOFTPLL_EXT_DETECTED_PPS) ? 1 : 0;

	return 1;
}


static int gm_spll_ext_fpanel_inputs_update_gm_info(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_spll_ext_fpanel_inputs_check(src))
		return 0;

	data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	switch (data->spll_ext_fpanel_inputs_status) {
	case SOFTPLL_EXT_DETECTED_NONE:
		data->info_message = "No PPS or 10MHz inputs detected";
		break;
	case SOFTPLL_EXT_DETECTED_PPS:
		data->info_message = "No 10MHz input detected";
		break;
	case SOFTPLL_EXT_DETECTED_CLK:
		data->info_message = "No PPS input detected";
		break;
	case SOFTPLL_EXT_DETECTED_PPSCLK:
		data->info_message = "PPS and 10MHz inputs detected";
		break;
	default:
		break;
	}

	return 1;
}

/*
 * This function checks lock state of SoftPLL and update
 * internal fields for the VC Timing source structure.
 *
 * Returns:
 *    - 1: If everything was OK
 *    - 0: If any error raised
 */
static int gm_spll_locked_status(struct vc_timing_src *src)
{

	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return 0;

	if (hald_get_softpll_ext_align_state(&data->spll_align_state)) {
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
		pr_warning("Can't get SoftPLL alignment state\n");
		return 0;
	}

	data->locked = (data->spll_align_state == SOFTPLL_ALIGN_STATE_LOCKED);

	return 1;
}

/*
 * Prints a warning message when the input signals are lost and when they are
 * back to normal again. Each message type is printed only once every time the
 * signal status changes.
 *
 * In its initial state it will start printing when the signals are lost for the
 * first time.
 *
 * Parameters:
 *   data: Internal data for GM.
 *
 *   NOTE: inputs_status: 0 if the inputs are not ready, != 0 if they're ok.
 */
static void locked_inputs_lost_msg(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;
	int inputs_status;

	if(!gm_get_internal_data(src, &data))
		return;

	inputs_status = data->inputs_ok;

	if (!inputs_status && !data->inputs_warning) {
		data->inputs_warning = 1;
		pr_warning("SoftPLL fpanel input error: "
			"%s.\n",  data->info_message);
	}
	if (data->inputs_ok && data->inputs_warning) {
		data->inputs_warning = 0;
		pr_warning("SoftPLL fpanel inputs OK\n");
	}
}

/*
 * This function return current clock_class from PPSi and update
 * internal fields for the VC Timing source structure.
 *
 * Returns:
 *    - 1: If everything was OK
 *    - 0: If any error raised
 */
static int gm_ppsi_get_clock_class(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return 0;

	if (ppsi_get_clock_class(&data->current_clk_class)) {
		pr_warning("Error seting GM source: "
			"Can't get PPSi clock class\n");
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	}

	return 1;
}

/*
 * This function checks if Holdover is available and ready and update
 * internal fields for the VC Timing source structure.
 *
 * Returns:
 *    - 1: If everything was OK
 *    - 0: If any error raised
 */
static int gm_get_ho_state(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return 0;

	/*  FIXME: Currently, there is no HO in GM, so skip this check */
	/*
	if(hald_get_softpll_ho_state(&data->holdover_state)) {
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
		pr_warning("Can't get SoftPLL HO state\n");
		return 0;
	}

	data->ho_available = (data->holdover_state == HO_READY) ? 1 : 0;
	*/
	data->ho_available = 0;
	return 1;
}

#define gm_check_inputs_no_ho(src) gm_check_inputs(src, 0)
#define gm_check_inputs_ho(src) gm_check_inputs(src, 1)
/*
 * This function checks if inputs are OK and update VCS code.
 *
 * Returns:
 *    -  1: If everything was OK
 *    -  0: If system error raised
 *    - -1: If inputs error is detected
 */
static int gm_check_inputs(struct vc_timing_src *src, int check_ho)
{
	struct vc_tsrc_gm_data *data;
	int ha = 0;
	int i10mok = 0;
	int ippsok = 0;

	if(!gm_get_internal_data(src, &data))
		return 0;

	if(check_ho) {
		if(!gm_get_ho_state(src))
			return 0;

		ha = data->ho_available;
	}

	if(gm_spll_ext_fpanel_inputs_check(src)) {
		i10mok = data->inputs_10m_ok;
		ippsok = data->inputs_pps_ok;

		if(!i10mok && !ippsok) {
			vc_tsrc_set_vcs_code(src, (ha) ?
					VCS_GM_UNLOCKED_HO_10M_AND_PPS_NOT_PRESENT :
					VCS_GM_UNLOCKED_10M_AND_PPS_NOT_PRESENT);
			return -1;
		}

		if(!i10mok) {
			vc_tsrc_set_vcs_code(src, (ha) ?
					VCS_GM_UNLOCKED_HO_10M_NOT_PRESENT :
					VCS_GM_UNLOCKED_10M_NOT_PRESENT);
			return -1;
		}

		if(!ippsok) {
			/* PPS signal lost */
			if (data->locked) {
				enum gm_pps_mandatory pps_mandatory;

				get_gm_config_pps_mandatory(&pps_mandatory);

				/*
				 * Move out of LOCKED state if the PPS signal is
				 * required. Otherwise stay in LOCKED state but raise a
				 * warning.
				 */
				if (pps_mandatory == GM_PPS_MANDATORY_YES) {
					vc_tsrc_set_vcs_code(src, (ha) ?
							VCS_GM_UNLOCKED_HO_PPS_NOT_PRESENT :
							VCS_GM_UNLOCKED_PPS_NOT_PRESENT);
				} else {
					vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_PPS_LOST);
					data->info_message = "Locked - No PPS";
					return 1;
				}
			} else {
				vc_tsrc_set_vcs_code(src, (ha) ?
						VCS_GM_UNLOCKED_HO_PPS_NOT_PRESENT :
						VCS_GM_UNLOCKED_PPS_NOT_PRESENT);
			}
			return -1;
		}

		return 1;
	}

	return 0;
}

/*
 * Reset the appropriate status variables to default values.
 */
static void clear_status_variables(struct vc_tsrc_gm_data *data)
{
	/* All zeros */
	memset(data, 0, sizeof(struct vc_tsrc_gm_data));

	/* Special cases */
	data->info_ntp_status         = NTP_STATUS_NONE;
	data->ntp_first_run           = 1;
	data->info_message             = "";

	data->spll_ext_fpanel_inputs_status = SOFTPLL_EXT_DETECTED_NONE;
	data->spll_align_state = SOFTPLL_ALIGN_STATE_EXT_OFF;
	data->los_prev = HALD_LED_OUT_STATE_IDLE;
	data->lis_prev = HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS;
}

/*
 * This function reserves memory for internal data of GM timing source and
 * initializes it with some default values.
 *
 * Returns:
 *    - 1: If everything was OK
 *    - 0: If any error raised
 */
int vc_tsrc_gm_init_data(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if (!src || src->fsm_ext)
		return 0;

	/* Reserve memory and clear internal data */
	src->fsm_ext = malloc(sizeof(struct vc_tsrc_gm_data));
	data = (struct vc_tsrc_gm_data *) src->fsm_ext;
	clear_status_variables(data);

	vc_tsrc_set_vcs_code(src, VCS_INITIALIZING);

	return 1;
}

/*
 * This function frees memory for internal data of GM timing source
 */
void vc_tsrc_gm_free_data(struct vc_timing_src *src)
{
	if(!src || !src->fsm_ext)
		return;

	free(src->fsm_ext);
	src->fsm_ext = NULL;
}

/*
 * Returns:
 *
 *   0 if the leap-seconds files exist and are valid.
 *   1 otherwise.
 */
static int is_leapsec_file_expired(struct vc_timing_src *src)
{
	enum leapsec_exp_status leapsec_exp;

	leapsec_exp = leapsec_check_expiration_date();
	if (leapsec_exp == LEAPSEC_EXP_EXPIRED
		|| leapsec_exp == LEAPSEC_EXP_ERROR) {
		/*
		pr_warning("Leap seconds file expired "
			"or not found\n");
		*/
		return 1;
	}

	return 0;
}

/*
 * Updates the GM info parameters. This function is meant to be called
 * periodically to show the real time status of the GM timing source.
 *
 * Returns:
 *   0 if success
 *   1 if failure
 */
static int update_gm_info(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return 1;

	/* GM-specific info */
	if(!gm_spll_ext_fpanel_inputs_check(src))
		return 1;

	if(!gm_spll_locked_status(src))
		return 1;

	if(!gm_get_ho_state(src))
		return 1;

	set_gm_info_detected(data->spll_ext_fpanel_inputs_status);
	set_gm_info_align_state(data->spll_align_state);
	set_gm_info_message(data->info_message);

	/* NTP status */
	set_ntp_server0_info_server_status(data->info_ntp_status);

	/* Leap seconds file status */
	update_gm_info_leapsec_file_exp_date();
	set_gm_info_leapsec_file_valid(!is_leapsec_file_expired(src));

	/* Update HALd leds */
	gm_update_hald_leds(src);

	return 0;
}

static void gm_update_ktmgr(void)
{
	ktmgr_set_attr(KTMGR_UPDATE, 1);
}

static void gm_disable_aligner_ktmgr(void)
{
	ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 0);
	gm_update_ktmgr();
}

/*
 * Updates the current time offset relative to the configured NTP server.
 *
 * This function saves private static data to keep track of the last NTP request
 * and honor the configured refresh interval so, regardless of how frequently
 * it's called, it will only actually poll the NTP server if the time interval
 * between refreshes has been elapsed.
 *
 * A refresh interval of 0 disables the NTP querying.
 *
 * Returns:
 *   0 if the offset could be retrieved or if NTP polling is disabled.
 *   1 if the call didn't poll the NTP server (if it's called more frequently
 *       than the polling interval).
 *   -1 in case of error.
 */
static int update_ntp_offset(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;
	uint32_t ntp_refresh_time;
	float ntp_offset;

	if(!gm_get_internal_data(src, &data))
		return -1;

	if (get_ntp_config_refresh_rate(&ntp_refresh_time)) {
		pr_warning("Can't get NTP refresh rate\n");
		return -1;
	}

	if (ntp_refresh_time == 0)
		return 1;

	/* Set the reference timestamp for the first NTP retrieval */
	if (data->ntp_first_run) {
		clock_gettime(CLOCK_MONOTONIC_RAW, &data->last_ntp_ts);
		data->ntp_first_run = 0;
	}

	clock_gettime(CLOCK_MONOTONIC_RAW, &data->current_ntp_ts);
	if ((data->current_ntp_ts.tv_sec - data->last_ntp_ts.tv_sec) > ntp_refresh_time) {
		clock_gettime(CLOCK_MONOTONIC_RAW, &data->last_ntp_ts);
		if (ntp_server0_get_offset(&ntp_offset)) {
			//pr_warning("Can't get NTP offset\n");
			return -1;
		}
		if (set_ntp_server0_info_offset(ntp_offset)) {
			pr_warning("Can't set NTP offset info param\n");
			return -1;
		}
	} else {
		/* No NTP polling done */
		return 1;
	}

	return 0;
}


/*
 * @brief NTP synchronization calling NTP external clients with retries
 *
 * @param src Timing source instance
 *
 * @return 0 if success and an error code otherwise
 * @retval -EINVAL If GM internal data could not be recovered
 * @retval -EFAULT If NTP sync fails
 * @retval -ETIMEDOUT If no NTP sync has been performed within retries
 */
static int sync_ntp(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;
	uint32_t ntp_retries;
	int i = 0;
	struct timespec wait = {.tv_sec = NTP_SYNC_SECS_BETWEEN_RETRIES,
				.tv_nsec = NS_PER_SLEEP};
	enum ntp_error ret;

	if(!gm_get_internal_data(src, &data))
		return -EINVAL;

	// First, ensure that PPS aligner is disabled
	gm_disable_aligner_ktmgr();

	get_ntp_config_retries(&ntp_retries);

	while (i < ntp_retries) {
		ret = ntp_server0_synchronize();
		if (ret == 0) {
			data->info_ntp_status = NTP_STATUS_OK;
			return 0;
		}
		if (ret != NTP_ERROR_QUERY) {
			data->info_ntp_status = NTP_STATUS_NOT_SYNC;
			return -EFAULT;
		}
		i++;
		pr_warning("Error in NTP synchronization "
			"(retry %d of %d)\n", i, ntp_retries);
		nanosleep(&wait, 0);
	}

	if (i >= ntp_retries) {
		data->info_ntp_status = NTP_STATUS_NOT_SYNC;
		return -ETIMEDOUT;
	}

	return 0;
}


/*
 * NTP offset check for LOCKED state.
 *
 * Returns:
 *   0 if the offset is within the defined threshold
 *   1 otherwise
 */
static int locked_check_ntp_offset(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;
	float ntp_offset;

	if(!gm_get_internal_data(src, &data))
		return 0;

	get_ntp_server0_info_offset(&ntp_offset);
	if (fabsf(ntp_offset) > NTP_DRIFT_THRESHOLD) {
		vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_NTP_OFFSET_1S);
		return 1;
	}

	return 0;
}

/*
 * This function updates VC info parameters using VCS table and current VCS code
 * for GM timing source
 */
void vc_tsrc_gm_update_vc_info(struct vc_timing_src *src)
{
	if(!src)
		return;

	/* Update VC info using VCS code (no arguments for msg and aref) */
	vc_tsrc_update_vc_info_data_vcs_simple(src);

	/* Update clockQ parameter from PPSi */
	if(vc_tsrc_is_active(src))
		update_clockq(src);
}

static void gm_set_dfl_clockQ(struct vc_tsrc_gm_data *data)
{
	if(!data)
		return;

	ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 0);

	/* Values by default */

	/*
	if(!data->gm_cfg_class)
		ktmgr_set_attr(KTMGR_CLK_CLASS, DEFAULT_CLK_CLASS_GM);
	else
		ktmgr_set_attr(KTMGR_CLK_CLASS, data->gm_cfg_class);
	*/

	/* FIXME: Check if here user clock class can be used */
	ktmgr_set_attr(KTMGR_CLK_CLASS, DEFAULT_CLK_CLASS_GM);
	ktmgr_set_attr(KTMGR_TIMESOURCE, data->gm_cfg_time_source);
	ktmgr_set_attr(KTMGR_PRIORITY1, data->gm_cfg_priority1);
	ktmgr_set_attr(KTMGR_PRIORITY2, data->gm_cfg_priority2);

	if(!data->gm_cfg_accuracy)
		ktmgr_set_attr(KTMGR_CLK_ACCURACY, DEFAULT_CLK_ACCURACY_GM);
	else
		ktmgr_set_attr(KTMGR_CLK_ACCURACY, data->gm_cfg_accuracy);

	ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
	ktmgr_set_attr(KTMGR_TIME_VALID, 0);
	ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
}

static void gm_update_clockQ_vcs(enum tmgr_vcs_code code, struct vc_tsrc_gm_data *data)
{
	long gm_locked_clk_accuracy = 0;
	long gm_locked_clk_class = 0;
	long current_clk_accuracy = 0;

	if(!data)
		return;

	/* Values for class and accuracy (LOCKED) */
	gm_locked_clk_class = (data->gm_cfg_class) ? data->gm_cfg_class : DEFAULT_CLK_CLASS_GM;
	gm_locked_clk_accuracy = (data->gm_cfg_accuracy) ? data->gm_cfg_accuracy : DEFAULT_CLK_ACCURACY_GM;

	/* Read current accuracy from ktmgr */
	ktmgr_get_attr(KTMGR_CLK_ACCURACY, &current_clk_accuracy);

	switch(code) {
	case VCS_UNINITIALIZED:
	case VCS_SYSTEM_ERROR:
	case VCS_INITIALIZING:
		ktmgr_set_attr(KTMGR_CLK_CLASS, GPA_1588_CLASS_DEFAULT);
		ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_UNKNOWN);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 0);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
		ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 0);
		break;
	case VCS_GM_LOCKED:
	case VCS_GM_LOCKED_PPS_LOST:
	case VCS_GM_LOCKED_NTP_NOT_REPLY:
	case VCS_GM_LOCKED_GM_MAINTENANCE:
		ktmgr_set_attr(KTMGR_CLK_CLASS, gm_locked_clk_class);
		ktmgr_set_attr(KTMGR_CLK_ACCURACY, gm_locked_clk_accuracy);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 1);
		ktmgr_set_attr(KTMGR_TIME_VALID, 1);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 1);
		ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 1);
		break;
	case VCS_GM_UNLOCKED_10M_NOT_PRESENT:
	case VCS_GM_UNLOCKED_PPS_NOT_PRESENT:
	case VCS_GM_UNLOCKED_10M_AND_PPS_NOT_PRESENT:
	case VCS_GM_UNLOCKED_10M_NOT_STABLE:
	case VCS_GM_UNLOCKED_REP_LOCK_UNLOCK:
		ktmgr_set_attr(KTMGR_CLK_CLASS, GPA_1588_CLASS_GM_PTP_UNLOCKED);
		ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_UNKNOWN);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 0);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
		ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 0);
		break;
	case VCS_GM_LOCKED_NTP_NOT_SET:
		ktmgr_set_attr(KTMGR_CLK_CLASS, gm_locked_clk_class);
		if(current_clk_accuracy < GPA_1588_ACU_GT_10_S)
			ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_GT_10_S);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 0);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 1);
		break;
	case VCS_GM_LOCKED_LEAPS_EXPIRED:
		ktmgr_set_attr(KTMGR_CLK_CLASS, gm_locked_clk_class);
		if(current_clk_accuracy < GPA_1588_ACU_1_S)
			ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_1_S);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 1);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 1);
		break;
	case VCS_GM_LOCKED_NTP_OFFSET_1S:
		ktmgr_set_attr(KTMGR_CLK_CLASS, gm_locked_clk_class);
		if(current_clk_accuracy < GPA_1588_ACU_10_S)
			ktmgr_set_attr(KTMGR_CLK_ACCURACY, GPA_1588_ACU_10_S);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 0);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 1);
		break;
	case VCS_GM_UNLOCKED_HO_10M_NOT_PRESENT:
	case VCS_GM_UNLOCKED_HO_PPS_NOT_PRESENT:
	case VCS_GM_UNLOCKED_HO_10M_AND_PPS_NOT_PRESENT:
		ktmgr_set_attr(KTMGR_CLK_CLASS, GPA_1588_CLASS_GM_PTP_HOLDOVER);
		ktmgr_set_attr(KTMGR_CURRENT_UTC_OFFSET_VALID, 0);
		ktmgr_set_attr(KTMGR_TIME_VALID, 0);
		ktmgr_set_attr(KTMGR_FREQ_VALID, 0);
		ktmgr_set_attr(KTMGR_ENABLE_ALIGN, 0);
		break;
	default:
		break;
	};

	/* Update ktmgr now */
	gm_update_ktmgr();
}

static void gm_update_clockQ(struct vc_timing_src *src)
{
	struct vc_tsrc_gm_data *data;

	if(!gm_get_internal_data(src, &data))
		return;

	return gm_update_clockQ_vcs(vc_tsrc_get_vcs_code(src), data);
}

static void gm_init_hw_lock(struct vc_timing_src *src)
{

	struct vc_tsrc_gm_data *data;
	enum pps_mode m;

	if(!gm_get_internal_data(src, &data))
		return;

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(0);

	/* Get GM config parameters */
	get_gm_config_time_source(&data->gm_cfg_time_source);
	get_gm_config_priority1(&data->gm_cfg_priority1);
	get_gm_config_priority2(&data->gm_cfg_priority2);
	get_gm_config_offset(&data->gm_cfg_offset);
	get_gm_config_align_pps(&data->gm_cfg_align_pps);
	get_gm_config_clock_accuracy(&data->gm_cfg_accuracy);
	get_gm_config_force_clock_class(&data->gm_cfg_class);

	/* Set Grandmaster source: Apply config parameters */
	/* The other part of config is applied by gm_update_clockQ_vcs */
	hald_set_softpll_ext_align_pps(data->gm_cfg_align_pps);
	hald_set_softpll_ext_user_offset(data->gm_cfg_offset);

	/* Load initial values for GM clockQ */
	gm_set_dfl_clockQ(data);

	/*
	 * Clock accuracy and time properties depend on the NTP and
	 * leap-second file status
	 */
	if (data->info_ntp_status != NTP_STATUS_OK) {
		/* NTP sync failed */
		gm_update_clockQ_vcs(VCS_GM_LOCKED_NTP_NOT_SET, data);
	} else if (is_leapsec_file_expired(src)) {
		/* NTP sync ok but leap-second files expired */
		gm_update_clockQ_vcs(VCS_GM_LOCKED_LEAPS_EXPIRED, data);
	}

	/* Update ktmgr */
	gm_update_ktmgr();

	/* Start PPSi as GM */
	ppsi_set_ext_clk(1);
	ppsi_set_cfg_timing_mode(PPSI_TM_GM);
	ppsi_set_run_stop(1);
}

/***********************************************************************
 * Action functions.                                                   *
 ***********************************************************************/

/*
 * Sets the GM source as <running>. This means the VC has signaled the GM source to
 * become active.
 */
void vc_tsrc_gm_exit_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	if(!vc_tsrc_fsm_has_to_stop(src)) {
		vc_tsrc_set_vcs_code(src, VCS_INITIALIZING);
		clear_status_variables(data);
		gm_disable_aligner_ktmgr();
		vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_RUNNING);
	}
}

void vc_tsrc_gm_enter_check_prereq(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	/* Update GM info */
	data->info_message = "Checking init prerequisites";
	update_gm_info(src);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);
}


/*
 * Set GM source before waiting for the SoftPLL to lock.
 *
 * ===================
 * GM source is set HERE
 * ===================
 */
void vc_tsrc_gm_enter_wait_lock(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	data->info_message = "Waiting for SoftPLL to lock";
	update_gm_info(src);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* Init hardware lock for GM */
	gm_init_hw_lock(src);
}

/*
 * The GM source was initialized correctly. Update info parameters and set the
 * appropriate ktmgr attributes if necessary.
 */
void vc_tsrc_gm_enter_locked(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;
	enum pps_mode m;

	/* Update GM info */
	data->info_message = "Locked";
	update_gm_info(src);

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(1);

	vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_NTP_NOT_SET);
	vc_tsrc_update_vc_info(src);

	/* Try to NTP sync again */
	sync_ntp(src);

	/*
	 * Update the rest of the VC info (the part that depends on the
	 * NTP status and leap second file).
	 */
	if (data->info_ntp_status != NTP_STATUS_OK) {
		/* NTP sync failed */
		return;
	} else if (is_leapsec_file_expired(src)) {
		/* NTP sync ok but leap-second files expired */
		vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_LEAPS_EXPIRED);
	} else {
		/* NTP sync and leap second files ok */
		if (set_fpga_time()) {
			pr_warning("Can't set FPGA time\n");
			return;
		}
		vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED);
	}

	/* Update clockQ using VCS code */
	gm_update_clockQ(src);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);
}

/*
 * GM source out of LOCKED state: disable FPGA-to-host time alignment and set the
 * appropriate ktmgr attributes.
 */
void vc_tsrc_gm_exit_locked(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	enum pps_mode m;

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(0);

	/* Update clockQ using VCS code */
	gm_update_clockQ(src);
}

/*
 * Set the GM source as <not runnable>
 */
void vc_tsrc_gm_exit_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_NOT_READY);
}


/***********************************************************************
 * State functions.                                                    *
 ***********************************************************************/

/* All of these take a pointer to the vc_timing_src struct as an argument. */

/*
 * Idle state: Passive monitoring
*/
void *vc_tsrc_gm_idle(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	/* Check if 10MHz and PPS are available */
	if(gm_check_inputs_no_ho(src) && data->inputs_ok) {
		/* Set quality metric to MAX value (OK), Wait for ACK */
		if (!vc_tsrc_checkp_fsm_is_enabled(src))
			src->qm.value = VC_TSRC_MV_MAX;
		vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_READY);
		vc_tsrc_set_vcs_code(src, VCS_READY);
	}
	else {
		/* Set quality metric to MIN value (CRITICAL)*/
		src->qm.value = VC_TSRC_MV_MIN;
		vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_NOT_READY);
	}

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* Update GM info parameters */
	data->info_message = "Idle";
	update_gm_info(src);

	/* Substitute this for some ACTUAL work */
	nanosleep(&ts, 0);

	return args;
}


/*
 * Checks the initialization preconditions:
 *
 * - Input signal status
 * - NTP synchronization and leap-second file status
 * - Current SoftPLL status and clock class
 */
void *vc_tsrc_gm_check_prereq(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	/* Check input signals are ok. Stop right here if they aren't */
	if (!gm_check_inputs_no_ho(src) || !data->inputs_ok) {
		return args;
	}

	/*
	 * NOTE: NTP sync process is done when LOCKED state is reached in the GM FSM,
	 * consequently, we can skip this here.
	 *
	 * Get NTP time and check leap second file expiration.
	 * Keep initialization going even if these fail.
	 */
	//sync_ntp(src);

	/*
	 * Check ppsi and hald status to see if the softPLL is already locked.
	 * If it is, skip the initialization and go to LOCKED state.
	 */
	gm_ppsi_get_clock_class(src);
	gm_spll_locked_status(src);

	return args;
}


/*
 * Wait for the SoftPLL to lock. Fixed timeout for now (SECS_PLL_LOCKED)
 */
void *vc_tsrc_gm_wait_lock(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	int retries = SECS_TO_RETRIES(TMO_GM_LOCK);
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	/* Wait for the softPLL to lock */
	do {
		/*
		 * Exit conditions:
		 *
		 * Bail out if the source becomes inactive (if it's preempted or
		 * if the user selects another one).
		 *
		 * Also stop trying to lock if any of the signals is down.
		 */
		if (!vc_tsrc_is_active(src))
			break;

		nanosleep(&ts, 0);

		/* Update GM status info */
		update_gm_info(src);

		/* Check SoftPLL state */
		if(!gm_spll_locked_status(src))
			break;

	} while (!data->locked && retries--);

	if (retries <= 0) {
		vc_tsrc_set_vcs_code(src, VCS_GM_UNLOCKED_10M_NOT_STABLE);
		vc_tsrc_update_vc_info(src);
	}

	return args;
}


/*
 * SoftPLL locked. Keep checking the GM source status continuously.
 */
void *vc_tsrc_gm_locked(void *args)
{
	struct timespec period_sleep = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;
	int ret;
	int locked_exit = 0;

	/*
	 * Check some things periodically:
	 *
	 * - SPLL locked status
	 * - Input signals
	 * - NTP offset
	 * - Leap-seconds files validity
	 */
	do {
		if (!vc_tsrc_is_active(src))
			break;

		nanosleep(&period_sleep, 0);

		/*
		* FIXME: Ignore ho_force_trig
		 */
		set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);

		/*
		 * Check NTP status if initial sync was fine.
		 *
		 * - If NTP does not reply, raise a WARNING event and re-check periodically.
		 * - If NTP offset is >1, raise a WARNING event and re-check periodically.
		 */
		if (data->info_ntp_status == NTP_STATUS_OK) {
			if(update_ntp_offset(src) >= 0) {
				/* NTP server is reachable? */
				if(!locked_check_ntp_offset(src)) {
					vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED);
				}
			}
			else {
				/* NTP server is not reachable anymore */
				data->info_ntp_status = NTP_STATUS_STOP_REPLY;
				vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_NTP_NOT_REPLY);
			}
		} else {
			if(data->info_ntp_status == NTP_STATUS_STOP_REPLY) {
				if(update_ntp_offset(src) == 0) {
					/* Set NTP_OK by default */
					vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED);
					data->info_ntp_status = NTP_STATUS_OK;
				} else {
					/* NTP is not reachable yet */
					data->info_ntp_status = NTP_STATUS_STOP_REPLY;
					vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_NTP_NOT_REPLY);
				}
			}
		}

		/*
		 * Check ToD drift against the NTP server and the validity of
		 * leap-seconds files if the NTP server is reachable.
		 */

		if (is_leapsec_file_expired(src) && data->info_ntp_status == NTP_STATUS_OK) {
			/*
			 * The leap-seconds files have expired while in
			 * LOCKED status.
			 */
			vc_tsrc_set_vcs_code(src, VCS_GM_LOCKED_LEAPS_EXPIRED);
		}

		/* Check LOCKED status and the presence of signal inputs */
		ret = gm_spll_locked_status(src);
		if(!ret)
			goto gm_locked_update_data;

		ret = gm_check_inputs_ho(src);

	gm_locked_update_data:
		/* Syslog messages when signals are lost and back again */
		locked_inputs_lost_msg(src);

		/* Update GM status info */
		update_gm_info(src);

		/* Update GM clockQ */
		gm_update_clockQ(src);

		/* Update VC info */
		vc_tsrc_update_vc_info(src);

		locked_exit = !data->locked || (ret <= 0);

	} while (!locked_exit);

	return args;
}

void *vc_tsrc_gm_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Update GM info */
	gm_spll_ext_fpanel_inputs_update_gm_info(src);
	update_gm_info(src);

	/* Update clockQ data with VCS */
	gm_update_clockQ(src);

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	return args;
}

/***********************************************************************
 * Transition checker functions.                                       *
 ***********************************************************************/

/*
 * All of these take as an argument the value returned by the state function of
 * the current state.
 */

/**** From IDLE state ****/

/* Transition to next state when the FSM is activated */
int vc_tsrc_gm_idle_to_check_prereq(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return (vc_tsrc_get_run_status(src) == VC_TSRC_RUN_STATUS_READY
		&& vc_tsrc_is_active(src) && !vc_tsrc_checkp_fsm_is_enabled(src));
}

/* Transition to END state when requested by general thread of TMGR */
int vc_tsrc_gm_idle_to_end(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	int stop = vc_tsrc_fsm_has_to_stop(src);

	if(stop) {
		update_hald_in_led(HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS);
	}

	return stop;
}

/**** From CHECK_PREREQ state ****/

/* Go back to idle if the VC deactivates the state */
int vc_tsrc_gm_check_prereq_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return !vc_tsrc_is_active(src);
}

/*
 * Go to WAIT_LOCK state if the SoftPLL is not locked yet and the signal inputs
 * are detected.
 */
int vc_tsrc_gm_check_prereq_to_wait_lock(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	return data->inputs_ok;
}

/*
 * Error if the signal inputs are not detected.
 */
int vc_tsrc_gm_check_prereq_to_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	return (!data->inputs_ok
		|| vc_tsrc_get_vcs_code(src) == VCS_SYSTEM_ERROR);
}


/**** From WAIT_LOCK state ****/


/* Go back to idle if the VC deactivates the state */
int vc_tsrc_gm_wait_lock_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return !vc_tsrc_is_active(src);
}

/*
 * Go to LOCK state if the SoftPLL is locked.
 */
int vc_tsrc_gm_wait_lock_to_locked(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	return data->locked;
}

/*
 * Error if the SoftPLL is not locked.
 */
int vc_tsrc_gm_wait_lock_to_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;
	enum tmgr_vcs_code code = vc_tsrc_get_vcs_code(src);

	return (!data->locked
		|| code == VCS_SYSTEM_ERROR
		|| code == VCS_GM_UNLOCKED_10M_NOT_STABLE);
}


/**** From LOCKED state ****/

/* Go back to idle if the VC deactivates the state */
int vc_tsrc_gm_locked_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return !vc_tsrc_is_active(src);
}

/*
 * Error if the SoftPLL goes out of lock state.
 */
int vc_tsrc_gm_locked_to_error(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gm_data *data = (struct vc_tsrc_gm_data *) src->fsm_ext;

	enum gm_pps_mandatory pps_mandatory;

	if (vc_tsrc_get_vcs_code(src) == VCS_SYSTEM_ERROR) {
		return 1;
	}

	get_gm_config_pps_mandatory(&pps_mandatory);
	if (pps_mandatory == GM_PPS_MANDATORY_YES) {
		return !data->locked || !data->inputs_ok;
	}

	return !data->locked;
}


/**** From ERROR state ****/

int vc_tsrc_gm_error_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Enable checkpoint flag to report ERROR condition */
	vc_tsrc_set_checkp_fsm(src);

	/* Set quality metric to MIN value (CRITICAL) */
	src->qm.value = VC_TSRC_MV_MIN;

	return 1;
}

/*
 * fsmdef.c
 *
 * FSM for the GM Virtual Clock source.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */


/*
 * FSM for the Grand Master virtual clock source.
 *
 *
 * Simplified diagram
 * ------------------
 *
 *   ________________________________
 *  |                                |
 *  |   ______________               |
 *  |  |              |              |
 *  v  v              |              |
 *  IDLE ---------> CHECK_PREREQS    |         LOCKED
 *  ^  ^              |         |    |         ^  | ^
 *  |  |              |         |    |         |  | |
 *  |  |              |         v    |         |  | |
 *  |  |              |   _____ WAIT_LOCK -----+  | |
 *  |  |              |  |                        | |
 *  |  |              v  v                        | |
 *  |  +------------ ERROR <----------------------+ |
 *  |                                               |
 *  +-----------------------------------------------+
 *
 *
 *
 * States
 * ------
 *
 *   - IDLE:            Waiting state when the source is not active.
 *
 *   - CHECK_PREREQS:   The VC signals the GM source to start running. This state
 *                      checks the minimum conditions to start the
 *                      initialization process (input signal status).
 *
 *   - WAIT_LOCK:       Run the initialization steps and wait for the SoftPLL to
 *                      lock.
 *
 *   - LOCKED:          Working state when the source is active and the SotfPLL is
 *                      locked. The source status is continuously monitored.
 *
 *
 *   - ERROR:           Brings the GM source back to idle state after an error
 *                      condition and takes care of notifying the user about the
 *                      errors.
 *
 *   - END:             End state for FSM.
 *
 */


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "fsmlib.h"
#include "vc_timing_src.h"
#include "vc_gm_defs.h"


/***********************************************************************
 * External declarations                                               *
 ***********************************************************************/



/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

static char *vc_tsrc_gm_state_names[N_VC_TSRC_GM_STATES] = {
	[VC_TSRC_GM_IDLE]            = "GM_IDLE",
	[VC_TSRC_GM_CHECK_PREREQ]    = "GM_CHECK_PREREQ,",
	[VC_TSRC_GM_WAIT_LOCK]       = "GM_WAIT_LOCK",
	[VC_TSRC_GM_LOCKED]          = "GM_LOCKED",
	[VC_TSRC_GM_ERROR]           = "GM_ERROR",
	[VC_TSRC_GM_END]             = "GM_END",
};


/***********************************************************************
 * Public API                                                          *
 ***********************************************************************/

int create_gm_fsm(struct vc_timing_src *src)
{
	struct fsm *fsm = NULL;
	int ret;

	if(!src)
		return 1;

	fsm = new_fsm("GM");


	/********** Actions **********/

	struct action *exit_idle = new_action(vc_tsrc_gm_exit_idle, src);

	struct action *enter_check_prereq =
		new_action(vc_tsrc_gm_enter_check_prereq, src);

	struct action *enter_wait_lock =
		new_action(vc_tsrc_gm_enter_wait_lock, src);

	struct action *enter_locked = new_action(vc_tsrc_gm_enter_locked, src);
	struct action *exit_locked = new_action(vc_tsrc_gm_exit_locked, src);

	struct action *exit_error = new_action(vc_tsrc_gm_exit_error, src);


	/********** States **********/

	/* IDLE state */
	struct sync_state *st_idle = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_IDLE],
		vc_tsrc_gm_idle, src, 0);
	add_state((union state *)st_idle, fsm);
	add_action(exit_idle, (union state *)st_idle, EXIT);

	/* CHECK_PREREQ state */
	struct sync_state *st_check_prereq = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_CHECK_PREREQ],
		vc_tsrc_gm_check_prereq, src, 0);
	add_state((union state *)st_check_prereq, fsm);
	add_action(enter_check_prereq, (union state *)st_check_prereq, ENTRY);

	/* WAIT LOCK state */
	struct sync_state *st_wait_lock = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_WAIT_LOCK],
		vc_tsrc_gm_wait_lock, src, 0);
	add_state((union state *)st_wait_lock, fsm);
	add_action(enter_wait_lock, (union state *)st_wait_lock, ENTRY);

	/* LOCKED state */
	struct sync_state *st_locked = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_LOCKED],
		vc_tsrc_gm_locked, src, 0);
	add_state((union state *)st_locked, fsm);
	add_action(enter_locked, (union state *)st_locked, ENTRY);
	add_action(exit_locked, (union state *)st_locked, EXIT);

	/* ERROR state */
	struct sync_state *st_error = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_ERROR],
		vc_tsrc_gm_error, src, 0);
	add_state((union state *)st_error, fsm);
	add_action(exit_error, (union state *)st_error, EXIT);

	/* END state */
	struct sync_state *st_end = new_sync_state(
		vc_tsrc_gm_state_names[VC_TSRC_GM_END],
		0, src, 0);
	add_state((union state *)st_end, fsm);

	/********** Transitions **********/

	/* From IDLE state */

	/* IDLE to END */
	struct sync_transition *t_idle_end = new_sync_transition(
		st_idle, (union state *)st_end,
		vc_tsrc_gm_idle_to_end, 0);
	if(!t_idle_end)
		return 1;

	/* IDLE to CHECK_PREREQ */
	struct sync_transition *t_idle_check_prereq = new_sync_transition(
		st_idle, (union state *)st_check_prereq,
		vc_tsrc_gm_idle_to_check_prereq, 0);
	if (!t_idle_check_prereq)
		return 1;


	/* From CHECK_PREREQ state */

	/* CHECK_PREREQ to ERROR */
	struct sync_transition *t_check_prereq_error = new_sync_transition(
		st_check_prereq, (union state *)st_error,
		vc_tsrc_gm_check_prereq_to_error, 0);
	if (!t_check_prereq_error)
		return 1;

	/* CHECK_PREREQ to IDLE */
	struct sync_transition *t_check_prereq_idle = new_sync_transition(
		st_check_prereq, (union state *)st_idle,
		vc_tsrc_gm_check_prereq_to_idle, 0);
	if (!t_check_prereq_idle)
		return 1;

	/* CHECK_PREREQ to WAIT_LOCK */
	struct sync_transition *t_check_prereq_wait_lock = new_sync_transition(
		st_check_prereq, (union state *)st_wait_lock,
		vc_tsrc_gm_check_prereq_to_wait_lock, 0);
	if (!t_check_prereq_wait_lock)
		return 1;



	/* From WAIT_LOCK state */

	/* WAIT_LOCK to ERROR */
	struct sync_transition *t_wait_lock_error = new_sync_transition(
		st_wait_lock, (union state *)st_error,
		vc_tsrc_gm_wait_lock_to_error, 0);
	if (!t_wait_lock_error)
		return 1;

	/* WAIT_LOCK to IDLE */
	struct sync_transition *t_wait_lock_idle = new_sync_transition(
		st_wait_lock, (union state *)st_idle,
		vc_tsrc_gm_wait_lock_to_idle, 0);
	if (!t_wait_lock_idle)
		return 1;

	/* WAIT_LOCK to LOCKED */
	struct sync_transition *t_wait_lock_locked = new_sync_transition(
		st_wait_lock, (union state *)st_locked,
		vc_tsrc_gm_wait_lock_to_locked, 0);
	if (!t_wait_lock_locked)
		return 1;



	/* From LOCKED state */

	/* LOCKED to ERROR */
	struct sync_transition *t_locked_error = new_sync_transition(
		st_locked, (union state *)st_error,
		vc_tsrc_gm_locked_to_error, 0);
	if (!t_locked_error)
		return 1;

	/* LOCKED to IDLE */
	struct sync_transition *t_locked_idle = new_sync_transition(
		st_locked, (union state *)st_idle,
		vc_tsrc_gm_locked_to_idle, 0);
	if (!t_locked_idle)
		return 1;



	/* From ERROR state */

	/* ERROR to IDLE */
	struct sync_transition *t_error_idle = new_sync_transition(
		st_error, (union state *)st_idle, vc_tsrc_gm_error_to_idle, 0);
	if (!t_error_idle)
		return 1;

	/* Update timing source structure */
	src->fsm = fsm;
	src->vc_info.pre_update = NULL;
	src->vc_info.post_update = NULL;
	src->vc_info.update = vc_tsrc_gm_update_vc_info;

	/* Init internal data for GM */
	ret = vc_tsrc_gm_init_data(src);

	return ret;
}

int free_gm_fsm(struct vc_timing_src *src)
{
	int ret;

	/* Stop FSM */
	ret = vc_tsrc_terminate(src);

	/* Free internal data for GM */
	vc_tsrc_gm_free_data(src);

	return ret;
}

/*
 * vc_gm_defs.h
 *
 * Common definitions for the GM FSM.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#ifndef __VC_GMDEFS_H__
#define __VC_GMDEFS_H__

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

enum vc_tsrc_gm_states {
	VC_TSRC_GM_IDLE,
	VC_TSRC_GM_CHECK_PREREQ,
	VC_TSRC_GM_WAIT_LOCK,
	VC_TSRC_GM_LOCKED,
	VC_TSRC_GM_ERROR,
	VC_TSRC_GM_END,
	N_VC_TSRC_GM_STATES,
};


/***********************************************************************
 * FSM functions                                                       *
 ***********************************************************************/

void vc_tsrc_gm_update_vc_info(struct vc_timing_src *);
int vc_tsrc_gm_init_data(struct vc_timing_src *);
void vc_tsrc_gm_free_data(struct vc_timing_src *);

/*
 * Action functions.
 */
void vc_tsrc_gm_exit_idle(void *);
void vc_tsrc_gm_enter_check_prereq(void *);
void vc_tsrc_gm_enter_wait_lock(void *);
void vc_tsrc_gm_enter_locked(void *);
void vc_tsrc_gm_exit_locked(void *);
void vc_tsrc_gm_exit_error(void *);

/*
 * State functions. All of them take a pointer to the vc_timing_src struct as an
 * argument.
 */
void *vc_tsrc_gm_idle(void *);
void *vc_tsrc_gm_check_prereq(void *);
void *vc_tsrc_gm_wait_lock(void *);
void *vc_tsrc_gm_locked(void *);
void *vc_tsrc_gm_error(void *);

/*
 * Transition checker functions. All of them take as an argument the value
 * returned by the state function of the current state.
 */
int vc_tsrc_gm_idle_to_check_prereq(void *);
int vc_tsrc_gm_idle_to_end(void *);

int vc_tsrc_gm_check_prereq_to_idle(void *);
int vc_tsrc_gm_check_prereq_to_wait_lock(void *);
int vc_tsrc_gm_check_prereq_to_error(void *);

int vc_tsrc_gm_wait_lock_to_idle(void *);
int vc_tsrc_gm_wait_lock_to_locked(void *);
int vc_tsrc_gm_wait_lock_to_error(void *);

int vc_tsrc_gm_locked_to_idle(void *);
int vc_tsrc_gm_locked_to_error(void *);

int vc_tsrc_gm_error_to_idle(void *);


#endif

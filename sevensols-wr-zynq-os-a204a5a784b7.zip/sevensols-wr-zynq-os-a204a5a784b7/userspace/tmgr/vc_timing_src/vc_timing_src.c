/*
 * vc_timing_src.c
 *
 * General API for controlling Virtual Clock Timing Sources.
 * Based on previous works from Ricardo Canuelo.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "commondefs.h"
#include "gpa_common.h"
#include "gpa_interface.h"
#include "vc_timing_src.h"

/************************************************************
 * Public API                                               *
 ************************************************************/

int vc_tsrc_init(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src)
		return ret;

	if(src->build)
		ret = src->build(src);
	else
		ret = 0;

	if(ret)
		ret = 1;

	return ret;
}

int vc_tsrc_free(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src)
		return ret;

	if(src->free)
		ret = src->free(src);
	else
		ret = 0;

	if(ret)
		ret = 1;

	return ret;
}
int vc_tsrc_run(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src)
		return ret;

	run(src->fsm, ASYNC);

	ret = 0;

	return ret;
}

void vc_tsrc_set_vcs_code(struct vc_timing_src *src, enum tmgr_vcs_code code)
{
	if(!src)
		return;

	src->vc_info.vcs_code = code;
}

enum tmgr_vcs_code vc_tsrc_get_vcs_code(struct vc_timing_src *src)
{
	if(!src)
		return VCS_UNINITIALIZED;

	return src->vc_info.vcs_code;
}

void vc_tsrc_set_run_status(struct vc_timing_src *src, enum vc_tsrc_run_status status)
{
	if(!src)
		return;

	__atomic_store_n(&src->run_status, status, __ATOMIC_SEQ_CST);
}

enum vc_tsrc_run_status vc_tsrc_get_run_status(struct vc_timing_src *src)
{
	if(!src)
		return VC_TSRC_RUN_STATUS_NULL;

	return __atomic_load_n(&src->run_status, __ATOMIC_SEQ_CST);
}

void vc_tsrc_activate(struct vc_timing_src *src)
{
	if(!src)
		return;

	__atomic_store_n(&src->active, 1, __ATOMIC_SEQ_CST);
}

int vc_tsrc_deactivate(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	__atomic_store_n(&src->active, 0, __ATOMIC_SEQ_CST);

	return vc_tsrc_get_run_status(src) == VC_TSRC_RUN_STATUS_RUNNING;
}


void vc_tsrc_set_stop_fsm(struct vc_timing_src *src)
{
	if(!src)
		return;

	__atomic_store_n(&src->stop_fsm, 1, __ATOMIC_SEQ_CST);
}

int vc_tsrc_fsm_has_to_stop(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	return __atomic_load_n(&src->stop_fsm, __ATOMIC_SEQ_CST);
}

void vc_tsrc_clear_stop_fsm(struct vc_timing_src *src)
{
	if(!src)
		return;

	__atomic_store_n(&src->stop_fsm, 0, __ATOMIC_SEQ_CST);
}

void vc_tsrc_set_checkp_fsm(struct vc_timing_src *src)
{
	if(!src)
		return;

	__atomic_store_n(&src->checkpoint_fsm, 1, __ATOMIC_SEQ_CST);
}

int vc_tsrc_checkp_fsm_is_enabled(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	return __atomic_load_n(&src->checkpoint_fsm, __ATOMIC_SEQ_CST);
}

void vc_tsrc_clear_checkp_fsm(struct vc_timing_src *src)
{
	if(!src)
		return;

	__atomic_store_n(&src->checkpoint_fsm, 0, __ATOMIC_SEQ_CST);
}

int vc_tsrc_is_active(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	return __atomic_load_n(&src->active, __ATOMIC_SEQ_CST);
}

int vc_tsrc_is_runnable(struct vc_timing_src *src)
{
	if (!src || src->type == VC_TSRC_TYPE_NULL)
		return 0;

	return vc_tsrc_get_run_status(src) != VC_TSRC_RUN_STATUS_NOT_READY;
}

int vc_tsrc_is_critical(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	return src->qm.value == VC_TSRC_MV_MIN;
}

signed char vc_tsrc_get_prio0(struct vc_timing_src *src)
{
	if(!src)
		return -1;

	return src->vc_info.prio0;
}

char *vc_tsrc_name(struct vc_timing_src *src)
{
	if(!src)
		return NULL;

	return src->name;
}

void vc_tsrc_set_src_idx(struct vc_timing_src *src, int idx)
{
	if(!src)
		return;

	__atomic_store_n(&src->vc_info.src_idx, idx, __ATOMIC_SEQ_CST);
}

int vc_tsrc_get_src_idx(struct vc_timing_src *src)
{
	if(!src)
		return -1;

	return __atomic_load_n(&src->vc_info.src_idx, __ATOMIC_SEQ_CST);
}

static void vc_tsrc_update_srcn_vc_info(struct vc_timing_src *src)
{
	int src_idx = vc_tsrc_get_src_idx(src);
	enum tsrc_info_type t;
	int active;

	if(src_idx < 0)
		return;

	switch(src->type) {
	case VC_TSRC_TYPE_GM:
		t = TSRC_INFO_TYPE_GM;
		break;
	case VC_TSRC_TYPE_IFACE:
		if(src->priv.iface.proto == PORT_PROTO_WR)
			t = TSRC_INFO_TYPE_WR;
		else
			t = TSRC_INFO_TYPE_PTP;
		break;
	case VC_TSRC_TYPE_GNSS:
		t = TSRC_INFO_TYPE_GNSS;
		break;
	case VC_TSRC_TYPE_FR_HO:
	case VC_TSRC_TYPE_NULL:
	default:
		t = TSRC_INFO_TYPE_FR_HO;
		break;
	}

	active = vc_tsrc_is_active(src);

	set_tsrc_info_name(src_idx, &src->name[0]);
	set_tsrc_info_type(src_idx, t);
	set_tsrc_info_active_status(src_idx, active);
	set_tsrc_info_vcs_code(src_idx, src->vc_info.vcs_code);
	set_tsrc_info_src_rank(src_idx, src->prio);
	set_tsrc_info_status(src_idx, src->vc_info.status);
	set_tsrc_info_message(src_idx, src->vc_info.msg);
	update_tsrc_info_counter(src_idx);
	set_tsrc_info_clock_id(src_idx, &(src->vc_info.clockid[0]));
	set_tsrc_info_clock_class(src_idx, src->vc_info.clock_class);
	set_tsrc_info_clock_accuracy(src_idx, src->vc_info.clock_accuracy);
	set_tsrc_info_priority1(src_idx, src->vc_info.clock_priority1);
	set_tsrc_info_priority2(src_idx, src->vc_info.clock_priority2);
	set_tsrc_info_clock_variance(src_idx, src->vc_info.clock_variance);
	set_tsrc_info_utc_offset(src_idx, src->vc_info.tprop_utc_offset);
	set_tsrc_info_utc_offset_valid(src_idx, src->vc_info.tprop_utc_offset_valid);
	set_tsrc_info_time_valid(src_idx, src->vc_info.tprop_time_valid);
	set_tsrc_info_freq_valid(src_idx, src->vc_info.tprop_freq_valid);
	set_tsrc_info_n_hops(src_idx, src->vc_info.n_hops);

	/* Finally update GPA parameters */
	sync_tsrc_info_gpa_params(src_idx);
}

void vc_tsrc_update_vc_info(struct vc_timing_src *src)
{
	if(!src || !src->vc_info.update)
		return;

	/* Call pre hook if any */
	if(src->vc_info.pre_update)
		src->vc_info.pre_update(src);


	/* Specific function to update vc_info fields */
	src->vc_info.update(src);

	/* Update srcN VC info parameters */
	vc_tsrc_update_srcn_vc_info(src);

	/* If timing source is active and without a checkpoint, update global VC info */
	if(vc_tsrc_is_active(src) && !vc_tsrc_checkp_fsm_is_enabled(src)) {
		set_vc_info_vcs_code(src->vc_info.vcs_code);
		set_vc_info_status(src->vc_info.status);
		set_vc_info_message(src->vc_info.msg);
		set_vc_info_activeref(src->vc_info.aref);
		set_vc_info_clock_id(src->vc_info.clockid);
		set_vc_info_clock_class(src->vc_info.clock_class);
		set_vc_info_clock_accuracy(src->vc_info.clock_accuracy);
		set_vc_info_priority1(src->vc_info.clock_priority1);
		set_vc_info_priority2(src->vc_info.clock_priority2);
		set_vc_info_clock_variance(src->vc_info.clock_variance);
		set_vc_info_utc_offset(src->vc_info.tprop_utc_offset);
		set_vc_info_utc_offset_valid(src->vc_info.tprop_utc_offset_valid);
		set_vc_info_time_valid(src->vc_info.tprop_time_valid);
		set_vc_info_freq_valid(src->vc_info.tprop_freq_valid);
		set_vc_info_n_hops(src->vc_info.n_hops);
		sync_vc_gpa_params(1);
	}

	/* Call post hook if any */
	if(src->vc_info.post_update)
		src->vc_info.post_update(src);
}

void vc_tsrc_update_vc_info_data_vcs(struct vc_timing_src *src, const char **msg_args, const int msg_n, const char **aref_args, const int aref_n)
{
	int ret;
	const char *aux;

	if(!src)
		return;

	src->vc_info.status = convert_vcs_state_into_vc_status(src->vc_info.vcs_code);
	src->vc_info.prio0 = get_vcs_prio0(src->vc_info.vcs_code);
	ret = insert_vcs_msg_string_args(src->vc_info.vcs_code, msg_args, msg_n, src->vc_info.msg);
	if(ret < 0) {
		// Null errors (not insertion ones)
		get_vc_info_message(&aux);
		strncpy(src->vc_info.msg, aux, MAX_STR_LEN-1);
	}
	ret = insert_vcs_act_ref_string_args(src->vc_info.vcs_code, aref_args, aref_n, src->vc_info.aref);
	if(ret < 0) {
		// Null errors (not insertion ones)
		get_vc_info_activeref(&aux);
		strncpy(src->vc_info.aref, aux, MAX_STR_LEN-1);
	}

}

int vc_tsrc_terminate(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	/* 1. Deactivate source, it put in IDLE state */
	while(vc_tsrc_deactivate(src)) {}

	/* 2. Mark stop_fsm flag of source */
	vc_tsrc_set_stop_fsm(src);

	/*  3. Wait for thread (wait for a while if thread is still running) */
	wait_for_fsm(src->fsm);

	/* 4. Free FSM */
	while(free_fsm(src->fsm)) {}

	return 1;
}

/*
 * vc_tsrc_common.c
 *
 * General API for controlling Virtual Clock Timing Sources.
 * Common code
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "hald.h"
#include "ppsi.h"
#include "ptpd.h"

/************************************************************
 * Public API                                               *
 ************************************************************/

static int update_clockq_ppsi(struct vc_timing_src *src)
{
	int ret = 0;
	char *sys_err;

	ret = ppsi_get_clock_class(&src->vc_info.clock_class);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_class from PPSi");
	}

	ret = ppsi_get_clock_accuracy(&src->vc_info.clock_accuracy);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_accuracy from PPSi");
	}

	ret = ppsi_get_clock_variance(&src->vc_info.clock_variance);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_variance from PPSi");
	}

	ret = ppsi_get_clock_priority1(&src->vc_info.clock_priority1);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_priority1 from PPSi");
	}

	ret = ppsi_get_clock_priority2(&src->vc_info.clock_priority2);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_priority2 from PPSi");
	}

	ret = ppsi_get_clock_utc_offset(&src->vc_info.tprop_utc_offset);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_utc_offset from PPSi");
	}

	ret = ppsi_get_clock_utc_offset_valid(&src->vc_info.tprop_utc_offset_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_utc_offset_valid from PPSi");
	}

	ret = ppsi_get_clock_time_valid(&src->vc_info.tprop_time_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_time_valid from PPSi");
	}

	ret = ppsi_get_clock_freq_valid(&src->vc_info.tprop_freq_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_freq_valid from PPSi");
	}

	ret = ppsi_get_clock_clockid(&(src->vc_info.clockid[0]));
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clockid from PPSi");
	}

	ret = ppsi_get_clock_n_hops(&(src->vc_info.n_hops));
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving n_hops from PPSi");
	}

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);
	return ret;
}

static int update_clockq_ptpd(struct vc_timing_src *src)
{
	int ret = 0;
	char *sys_err;

	ret = ptpd_get_clock_class(&src->vc_info.clock_class);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_class from PTPd");
	}

	ret = ptpd_get_clock_accuracy(&src->vc_info.clock_accuracy);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_accuracy from PTPd");
	}

	ret = ptpd_get_clock_variance(&src->vc_info.clock_variance);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_variance from PTPd");
	}

	ret = ptpd_get_clock_priority1(&src->vc_info.clock_priority1);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_priority1 from PTPd");
	}

	ret = ptpd_get_clock_priority2(&src->vc_info.clock_priority2);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_priority2 from PTPd");
	}

	ret = ptpd_get_clock_utc_offset(&src->vc_info.tprop_utc_offset);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_utc_offset from PTPd");
	}

	ret = ptpd_get_clock_utc_offset_valid(&src->vc_info.tprop_utc_offset_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_utc_offset_valid from PTPd");
	}

	ret = ptpd_get_clock_time_valid(&src->vc_info.tprop_time_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_time_valid from PTPd");
	}

	ret = ptpd_get_clock_freq_valid(&src->vc_info.tprop_freq_valid);
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clock_freq_valid from PTPd");
	}

	ret = ptpd_get_clock_clockid(&(src->vc_info.clockid[0]));
	if(ret) {
		EXIT_SYS_ERROR("Error retrieving clockid from PTPd");
	}

	return 0;

sys_err_exit:
	vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
	pr_err("%s\n", sys_err);
	return ret;
}

int update_clockq(struct vc_timing_src *src)
{
	enum port_proto proto;
	int i;
	int ret;

	// First, search the first port configured and get its protocol
	// FIXME: Efficiency?
	for(i = 0 ; i < get_nports() ; i++) {
		get_port_proto(i, &proto);
		if(proto != PORT_PROTO_DISABLED)
			break;
	}

	// Depending on protocol, call PPSi or PTP functions
	switch(proto) {
	case PORT_PROTO_WR:
		ret = update_clockq_ppsi(src);
		break;
	case PORT_PROTO_PTP:
		ret = update_clockq_ptpd(src);
		break;
	default:
		ret = 1;
		break;
	}

	return ret;
}

void update_hald_in_led(enum hald_led_in_state state)
{
	switch(state) {
	case HALD_LED_IN_STATE_GM_LOCKED_PPS:
		hald_set_led_mode(LED_ID_IN, LED_MODE_PPS);
		hald_set_led_color(LED_ID_IN, LED_COLOR_GREEN);
		break;
	case HALD_LED_IN_STATE_GM_LOCKED_NO_PPS:
		hald_set_led_mode(LED_ID_IN, LED_MODE_ON);
		hald_set_led_color(LED_ID_IN, LED_COLOR_GREEN);
		break;
	case HALD_LED_IN_STATE_GM_ACT_REFS:
		hald_set_led_mode(LED_ID_IN, LED_MODE_PPS);
		hald_set_led_color(LED_ID_IN, LED_COLOR_RED);
		break;
	case HALD_LED_IN_STATE_GM_ACT_NO_REFS:
		hald_set_led_mode(LED_ID_IN, LED_MODE_ON);
		hald_set_led_color(LED_ID_IN, LED_COLOR_RED);
		break;
	case HALD_LED_IN_STATE_GM_NO_ACT_PPS:
		hald_set_led_mode(LED_ID_IN, LED_MODE_PPS);
		hald_set_led_color(LED_ID_IN, LED_COLOR_YELLOW);
		break;
	case HALD_LED_IN_STATE_GM_NO_ACT_NO_REFS:
	default:
		hald_set_led_mode(LED_ID_IN, LED_MODE_OFF);
		break;
	}
	hald_update_led(LED_ID_IN);
}

void update_hald_out_led(enum hald_led_out_state state)
{
	switch(state) {
	case HALD_LED_OUT_STATE_OK:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_PPS);
		hald_set_led_color(LED_ID_OUT, LED_COLOR_GREEN);
		break;
	case HALD_LED_OUT_STATE_WARN_LOCKED:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_PPS);
		hald_set_led_color(LED_ID_OUT, LED_COLOR_YELLOW);
		break;
	case HALD_LED_OUT_STATE_CRIT_PPS_ON:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_PPS);
		hald_set_led_color(LED_ID_OUT, LED_COLOR_RED);
		break;
	case HALD_LED_OUT_STATE_TRANS_WARN:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_ON);
		hald_set_led_color(LED_ID_OUT, LED_COLOR_YELLOW);
		break;
	case HALD_LED_OUT_STATE_CRIT_PPS_OFF:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_ON);
		hald_set_led_color(LED_ID_OUT, LED_COLOR_RED);
		break;
	case HALD_LED_OUT_STATE_IDLE:
	default:
		hald_set_led_mode(LED_ID_OUT, LED_MODE_OFF);
		break;
	}
	hald_update_led(LED_ID_OUT);
}

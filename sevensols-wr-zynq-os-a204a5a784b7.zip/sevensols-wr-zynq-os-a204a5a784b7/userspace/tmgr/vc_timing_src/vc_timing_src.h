#ifndef __VC_TIMING_SRC_H__
#define __VC_TIMING_SRC_H__

/*
 * vc_timing_src.h
 *
 * General API for controlling Virtual Clock (VC) Timing Sources.
 * Based on previous works from Ricardo Canuelo.
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "fsmlib.h"
#include "stdint.h"

#include "vcs.h"
#include "gpa_interface.h"

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

#define EXIT_SYS_ERROR(msg)			\
	do {					\
		sys_err = msg;			\
		goto sys_err_exit;		\
	} while(0)				\

enum vc_tsrc_type {
	VC_TSRC_TYPE_NULL = 0,
	VC_TSRC_TYPE_GM,
	VC_TSRC_TYPE_IFACE,
	VC_TSRC_TYPE_FR_HO,
	VC_TSRC_TYPE_GNSS,
	N_TSRC_TYPE,
};

enum vc_tsrc_run_status {
	VC_TSRC_RUN_STATUS_NULL = 0,
	VC_TSRC_RUN_STATUS_NOT_READY,
	VC_TSRC_RUN_STATUS_READY,
	VC_TSRC_RUN_STATUS_RUNNING,
};

#define VC_TSRC_MV_MIN 0
#define VC_TSRC_MV_MAX 100
struct vc_tsrc_metric {
	char value; /* 0-100 value */
	char *msg;
};

struct vc_tsrc_iface {
	const char *name;
	enum port_mode mode;
	enum port_proto proto;
	uint32_t port_idx;
};

enum vc_tsrc_fr_ho_mode {
	VC_TSRC_FR_HO_MODE_MANUAL = 0,
	VC_TSRC_FR_HO_MODE_FAILED,
};

struct vc_tsrc_fr_ho {
	enum vc_tsrc_fr_ho_mode mode;
};

union vc_tsrc_priv {
	struct vc_tsrc_iface iface;
	struct vc_tsrc_fr_ho fr_ho;
};

struct vc_timing_src;
struct vc_tsrc_vc_info {
	int src_idx;

	enum tmgr_vcs_code vcs_code;
	enum vc_status status;
	signed char prio0;
	char aref[MAX_STR_LEN];
	char msg[MAX_STR_LEN];
	char clockid[MAX_STR_LEN];
	uint8_t clock_class;
	uint8_t clock_accuracy;
	uint16_t clock_variance;
	uint8_t clock_priority1;
	uint8_t clock_priority2;
	int16_t tprop_utc_offset;
	int tprop_utc_offset_valid;
	int tprop_time_valid;
	int tprop_freq_valid;
	uint16_t n_hops;


	void (*pre_update)(struct vc_timing_src *);
	void (*update)(struct vc_timing_src *);
	void (*post_update)(struct vc_timing_src *);
};

struct vc_timing_src {
	/* Internal FSM to handle VC Timing source */
	struct fsm *fsm;

	/* Stop FSM flag. This is set/unset externally to notify to the FSM
	 * that should go to its end state. Then, FSM can be freed safety.
	 */
	int stop_fsm;

	/* Checkpoint FSM flag. This is set by FSM to indicate TMGR that a confirmation
	 * is required to continue running. TMGR should clear it before running
	 * policy that sets/unsets ACTIVE flag.
	 */
	int checkpoint_fsm;

	/* Extension data for FSM */
	void *fsm_ext;

	/* VC info */
	struct vc_tsrc_vc_info vc_info;

	/* quality metric */
	struct vc_tsrc_metric qm;

	/* Type */
	enum vc_tsrc_type type;

	/* Private data for timing resource */
	union vc_tsrc_priv priv;

	/* The current running status of the vc_timing_src */
	enum vc_tsrc_run_status run_status;

	/* Name of the VC Timing source */
	char name[MAX_STR_LEN];

	/* ID of VC Timing source */
	uint32_t id;

	/* VC Timing source priority */
	uint16_t prio;

	/*
	 * Active/inactive flag. This is set/unset externally to notify the
	 * activation/deactivation of the VC Timing source to its FSM.
	 * Only one VC Timing source may be active at any given time.
	 */
	int active;

	/* Pointer to the FSM builder function */
	int (*build)(struct vc_timing_src *);

	/* Pointer to the FSM remove function */
	int (*free)(struct vc_timing_src *);

};

/*
 * Initializes a VC Timing source: creates its FSM.
 *
 * Returns:
 *   0 if the timing source could be initialized properly
 *   1 otherwise
 */
int vc_tsrc_init(struct vc_timing_src *);

/*
 * Free a VC Timing source: destroy its FSM.
 *
 * Returns:
 *   0 if the timing source could be freed properly
 *   1 otherwise
 */
int vc_tsrc_free(struct vc_timing_src *);

/*
 * Starts the VC Timing source, running its FSM in the background.
 *
 * Returns:
 *   0 if the timing source could be started
 *   1 otherwise
 */
int vc_tsrc_run(struct vc_timing_src *);

/*
 * Sets VCS code for a timing source.
 */
void vc_tsrc_set_vcs_code(struct vc_timing_src *, enum tmgr_vcs_code);

/*
 * Returns VCS code for a timing source.
 */
enum tmgr_vcs_code vc_tsrc_get_vcs_code(struct vc_timing_src *);

/*
 * Sets the timing source in run_status <status>.
 */
void vc_tsrc_set_run_status(struct vc_timing_src *, enum vc_tsrc_run_status);

/*
 * Returns the run_status of the timing source.
 */
enum vc_tsrc_run_status vc_tsrc_get_run_status(struct vc_timing_src *);

/*
 * Activate a VC timing source. This selects timing source to run and it will be the
 * source for the Virtual Clock.
 */
void vc_tsrc_activate(struct vc_timing_src *);

/*
 * Returns:
 *   1 if the timing source is active
 *   0 otherwise
 */
int vc_tsrc_is_active(struct vc_timing_src *);

/*
 * Disables the timing source. This will notify the current running timing source that it must stop
 * (ie. move out of its running state back to idle).
 *
 * Returns:
 *   0 if the timing source stopped properly
 *   1 otherwise (retry if necessary until the timing source stops)
 */
int vc_tsrc_deactivate(struct vc_timing_src *);

/*
 * Set stop_fsm flag to indicate that FSM should go to its end state.
 */
void vc_tsrc_set_stop_fsm(struct vc_timing_src *);

/*
 * Returns:
 *   1 if stop_fsm is set
 *   0 otherwise
 */
int vc_tsrc_fsm_has_to_stop(struct vc_timing_src *);

/*
 * Clear stop_fsm flag. It allows a normal operation of FSM.
 */
void vc_tsrc_clear_stop_fsm(struct vc_timing_src *);

/*
 * Set checkpoint flag. It indicates that FSM is requested a check by TMGR policy.
 */
void vc_tsrc_set_checkp_fsm(struct vc_timing_src *);

/*
 * Returns:
 *   1 if checkpoint_fsm is set
 *   0 otherwise
 */
int vc_tsrc_checkp_fsm_is_enabled(struct vc_timing_src *);

/*
 * Clear checkpoint_fsm flag. It indicates to the FSM that can continue normally.
 */
void vc_tsrc_clear_checkp_fsm(struct vc_timing_src *);

/*
 * Returns:
 *   1 if the timing source is ready to run
 *   0 otherwise
 */
int vc_tsrc_is_runnable(struct vc_timing_src *);

/*
 * Returns:
 *   1 if the timing source is in CRITICAL state
 *   0 otherwise
 */
int vc_tsrc_is_critical(struct vc_timing_src *);

/*
 * Returns:
 *   -1 if timing source is NULL
 *   prio0 field value otherwise
 */
signed char vc_tsrc_get_prio0(struct vc_timing_src *);

/*
 * Returns the name of the timing source as a string.
 */
char *vc_tsrc_name(struct vc_timing_src *);

/*
 * Set source index (This is the order in the priority list of policy)
 */
void vc_tsrc_set_src_idx(struct vc_timing_src *, int);

/*
 * Get source index (This is the order in the priority list of policy)
 */
int vc_tsrc_get_src_idx(struct vc_timing_src *);

/*
 * Update VC info for the timing source (it also fires pre and post hooks if any)
 */
void vc_tsrc_update_vc_info(struct vc_timing_src *);

/*
 * Update VC info data using VCS code
 */
#define vc_tsrc_update_vc_info_data_vcs_simple(s) vc_tsrc_update_vc_info_data_vcs(s, NULL, 0, NULL, 0)
void vc_tsrc_update_vc_info_data_vcs(struct vc_timing_src *, const char **, const int, const char **, const int);

/*
 * Terminates timing source FSM allowing its deallocation
 *
 * Returns:
 *   1 if everything was OK
 *   0 otherwise
 */
int vc_tsrc_terminate(struct vc_timing_src *);

#endif /* __VC_TIMING_SRC_H__ */

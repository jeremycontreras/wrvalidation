/*
 * fsmdef.c
 *
 * FSM for the GNSS Virtual Clock timing resource.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "fsmlib.h"
#include "vc_timing_src.h"
#include "vc_gnss_defs.h"

/***********************************************************************
 * External declarations                                               *
 ***********************************************************************/

/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

static char *vc_tsrc_gnss_states_names[N_VC_TSRC_GNSS_STATES] = {
	[VC_TSRC_GNSS_IDLE]       = "GNSS_IDLE",
	[VC_TSRC_GNSS_RUNNING]    = "GNSS_RUNNING",
	[VC_TSRC_GNSS_END]        = "GNSS_END",
};


/***********************************************************************
 * Public API                                                          *
 ***********************************************************************/

int create_gnss_fsm(struct vc_timing_src *src)
{
	int ret = 0;
	struct fsm *fsm = NULL;

	if(!src)
		return 1;

	fsm = new_fsm("GNSS");


	/********** Actions **********/
	struct action *enter_running = new_action(vc_tsrc_gnss_enter_running,
					src);


	/********** States **********/

	/* IDLE state */
	struct sync_state *st_idle = new_sync_state(
		vc_tsrc_gnss_states_names[VC_TSRC_GNSS_IDLE],
		vc_tsrc_gnss_idle, src, 0);
	add_state((union state *)st_idle, fsm);

	/* RUNNING state */
	struct sync_state *st_running = new_sync_state(
		vc_tsrc_gnss_states_names[VC_TSRC_GNSS_RUNNING],
		vc_tsrc_gnss_running, src, 0);
	add_state((union state *)st_running, fsm);
	add_action(enter_running, (union state *)st_running, ENTRY);

	/* END state */
	struct sync_state *st_end = new_sync_state(
		vc_tsrc_gnss_states_names[VC_TSRC_GNSS_END],
		0, src, 0);
	add_state((union state *)st_end, fsm);



	/********** Transitions **********/

	/* From IDLE state */
	/* From IDLE to END */
	struct sync_transition *t_idle_end = new_sync_transition(
		st_idle, (union state *)st_end, vc_tsrc_gnss_idle_to_end, 0);
	if (!t_idle_end)
		return 0;

	/* From IDLE to RUNNING */
	struct sync_transition *t_idle_running = new_sync_transition(
		st_idle, (union state *)st_running,
		vc_tsrc_gnss_idle_to_running, 0);
	if (!t_idle_running)
		return 0;

	/* From RUNNING state */
	/* From RUNNING to IDLE */
	struct sync_transition *t_running_idle = new_sync_transition(
		st_running, (union state *)st_idle,
		vc_tsrc_gnss_running_to_idle, 0);
	if (!t_running_idle)
		return 0;

	/* Update timing source structure */
	src->fsm = fsm;
	src->vc_info.pre_update = NULL;
	src->vc_info.post_update = NULL;
	src->vc_info.update = vc_tsrc_gnss_update_vc_info;

	/* Initialize private data for GNSS */
	ret = vc_tsrc_gnss_init_data(src);

	return ret;
}


int free_gnss_fsm(struct vc_timing_src *src)
{
	int ret;

	/* Stop FSM */
	ret = vc_tsrc_terminate(src);

	/* Free private data for GNSS */
	vc_tsrc_gnss_free_data(src);

	return ret;
}


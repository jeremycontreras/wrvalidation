/*
 * gnss.c
 *
 * Application logic for the GNSS Virtual Clock timing source.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <libgpa.h>
#include <libgpa/ieee1588.h>

#include "commondefs.h"
#include "vc_timing_src.h"
#include "vc_tsrc_common.h"
#include "vcs.h"
#include "vc_gnss_defs.h"
#include "gpa_interface.h"
#include "ktmgr.h"
#include "ppsi.h"


/***********************************************************************
 * Macros and datatypes                                                *
 ***********************************************************************/

#define DEFAULT_CLK_CLASS_GNSS GPA_1588_CLASS_GM_PTP_LOCKED

/* Structure for GNSS internal data */
struct vc_tsrc_gnss_data {
	/* Holdover parameters */
	enum ho_state holdover_state;
};

/***********************************************************************
 * FSM shared data                                                     *
 ***********************************************************************/

/***********************************************************************
 * Utility functions                                                   *
 ***********************************************************************/

static int gnss_check_datap(struct vc_timing_src *src)
{
	if(!src)
		return 0;

	if(!src->fsm_ext)
		return 0;

	return 1;
}

static int gnss_get_internal_data(struct vc_timing_src *src, struct vc_tsrc_gnss_data **data)
{
	if(!gnss_check_datap(src))
		return 0;

	if(!data)
		return 0;

	*data = (struct vc_tsrc_gnss_data *) src->fsm_ext;

	return 1;
}

int vc_tsrc_gnss_init_data(struct vc_timing_src *src)
{
	int ret = 1;

	if(!src || src->fsm_ext)
		return ret;

	/* Reserve memory and initialize it */
	src->fsm_ext = malloc(sizeof(struct vc_tsrc_gnss_data));
	memset (src->fsm_ext, 0, sizeof(struct vc_tsrc_gnss_data));

	vc_tsrc_set_vcs_code(src, VCS_INITIALIZING);

	ret = 0;

	return ret;
}

void vc_tsrc_gnss_free_data(struct vc_timing_src *src)
{
	if(!src || !src->fsm_ext)
		return;

	free(src->fsm_ext);
	src->fsm_ext = NULL;
}

void vc_tsrc_gnss_update_vc_info(struct vc_timing_src *src)
{
	struct vc_tsrc_gnss_data *data;

	if(!gnss_get_internal_data(src, &data))
		return;

	/* Update VC info using VCS code (no arguments for msg and aref) */
	vc_tsrc_update_vc_info_data_vcs_simple(src);

	// TODO: Update clockQ
}

void vc_tsrc_gnss_hw_init(struct vc_timing_src *src)
{
	struct vc_tsrc_gnss_data *data;

	if(!gnss_get_internal_data(src, &data))
		return;

	/* Update VC info */
	vc_tsrc_update_vc_info(src);

	/* TODO: GNSS init procedure? */

}

/***********************************************************************
 * Action functions.                                                   *
 ***********************************************************************/

void vc_tsrc_gnss_enter_running(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	enum pps_mode m;

	pr_warning("Starting GNSS source\n");
	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_RUNNING);

	/* Set PPS if it is controlled by TMGR */
	get_tmgr_config_pps_mode(&m);
	if(m != PPS_MODE_TMGR_ALWAYS_ON)
		hald_set_pps_mode_state_tmgr(0);

	vc_tsrc_gnss_hw_init(src);

}


/***********************************************************************
 * State functions.                                                    *
 ***********************************************************************/

void *vc_tsrc_gnss_idle(void *args)
{
	struct timespec ts = {.tv_sec = 0, .tv_nsec = NS_PER_SLEEP};
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	/* Set quality metric to MAX value (OK), Wait for ACK */
	if (!vc_tsrc_checkp_fsm_is_enabled(src))
		src->qm.value = VC_TSRC_MV_MAX;

	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_READY);
	vc_tsrc_set_vcs_code(src, VCS_READY);

	/* Substitute this for some ACTUAL work */
	nanosleep(&ts, 0);

	return args;
}

void *vc_tsrc_gnss_running(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	struct vc_tsrc_gnss_data *data = (struct vc_tsrc_gnss_data *) src->fsm_ext;

	/* Get Holdover state */
	if(hald_get_softpll_ho_state(&data->holdover_state)) {
		vc_tsrc_set_vcs_code(src, VCS_SYSTEM_ERROR);
		return args;
	}

	/*
	 * FIXME: Ignore ho_force_trig
	 */
	set_ho_config_force_trigger(HO_FORCE_TRIGGER_NONE);

	/* TODO: RUNNING task for GNSS? */
	/* TODO: Detect locked and update state_tmgr for PPS mode */

	return args;
}

/***********************************************************************
 * Transition checker functions.                                       *
 ***********************************************************************/


int vc_tsrc_gnss_idle_to_running(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return (vc_tsrc_is_active(src) && !vc_tsrc_checkp_fsm_is_enabled(src));
}

int vc_tsrc_gnss_running_to_idle(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;
	int active = vc_tsrc_is_active(src);
	int error = (src->vc_info.status == VC_STATUS_ERROR);

	vc_tsrc_set_run_status(src, VC_TSRC_RUN_STATUS_NOT_READY);

	/* Mark checkpoint flag is any error raised */
	if(error)
		vc_tsrc_set_checkp_fsm(src);

	return !active || error;
}

int vc_tsrc_gnss_idle_to_end(void *args)
{
	struct vc_timing_src *src = (struct vc_timing_src *) args;

	return vc_tsrc_fsm_has_to_stop(src);
}

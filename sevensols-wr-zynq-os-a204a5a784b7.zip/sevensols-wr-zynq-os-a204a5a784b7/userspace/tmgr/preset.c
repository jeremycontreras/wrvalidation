/*
 * preset.c
 *
 * General API for controlling preset files for Virtual Clock modes.
 *
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimnenez Lopez <miguel.jimenez@sevensols.com>
 * Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 16, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdio.h>
#include <glob.h>
#include <string.h>
#include <stdlib.h>
#include <libgen.h>

#include <libgpa.h>
#include <libgpa/module.h>
#include "commondefs.h"
#include "gpa_interface.h"
#include "gpa_access.h"
#include "gpa_common.h"
#include "preset.h"

/* Presets defines */
#define N_VC_PRESET_SYS_RESERVED 11
#define VC_PRESET_SYS_CUSTOM 10

/* System path for the presets files */
#define VC_PRESET_SYS_DIR             "/etc/tmgr/vc_presets/sys/"
#define VC_PRESET_USR_DIR             "/etc/tmgr/vc_presets/usr/"
#define PRESET_FILE_PATTERN             "%s%d_*.config"
#define PRESET_FILE_LIST_PATTERN        "%s*_*.config"
#define PRESET_FILE_CUSTOM              "/root/.config"

/* Array of available presets */
static struct preset_name glb_presets[MAX_PRESETS];
struct preset_name * get_glb_presets(void)
{
	return &glb_presets[0];
}

/*
 * Searches for a preset file for preset id <preset> and returns the full path
 * in parameter <path> if found.
 *
 * Returns:
 *   0 If the preset file was found
 *   1 In case of failure (preset file not found or ambiguous preset number)
 *
 * Notes:
 *   The file path saved in <path> is a string allocated with strdup. The caller
 *   must free it at some point.
 */
static int get_preset_file_path(unsigned int preset, enum preset_type type,
				char **path)
{
	char pattern[MAX_STR_LEN] = {0};
	glob_t globdata;
	char *dir;
	char *type_str;
	int ret = 0;

	switch (type) {
	case PRESET_VC_SYS:
		dir = VC_PRESET_SYS_DIR;
		type_str = "VC system";
		break;
	case PRESET_VC_USR:
		dir = VC_PRESET_USR_DIR;
		type_str = "VC user";
		break;
	default:
		pr_error("Unknown preset type: %d\n", type);
		return 1;
	}

	/*
	 * Search for a preset file with number id = <preset> in the presets
	 * directory.
	 */
	snprintf(pattern, MAX_STR_LEN-1, PRESET_FILE_PATTERN, dir, preset);

	if (glob(pattern, 0, 0, &globdata)) {
		pr_warning("Can't open %s preset %d\n",
			type_str, preset);
		ret = 1;
		goto exit;
	}

	if (globdata.gl_pathc < 1) {
		pr_warning("%s preset %d not found\n",
			type_str, preset);
		ret = 1;
		goto exit;
	}

	if (globdata.gl_pathc > 1) {
		pr_warning("Ambiguous %s preset %d. "
			"Check the %s directory\n", type_str, preset, dir);
		ret = 1;
		goto exit;
	}

	*path = strdup(globdata.gl_pathv[0]);

exit:
	globfree(&globdata);
	return ret;
}

/*
 * Load a preset file on demand.
 *
 * Returns:
 *   0 If everything was ok (gpa parameters are updated)
 *   1 In case of failure
 */
static int _load_preset(unsigned int preset, enum preset_type type)
{
	char *path = 0;
	int32_t ret;
	uint32_t current_preset;
	uint32_t loaded_preset;
	int is_sys_custom = (type == PRESET_VC_SYS && preset == VC_PRESET_SYS_CUSTOM);

	/* Disable preset autoload to avoid recursive call to _load_preset */
	set_tmgr_autoload_preset(0);

	/* Get absolute path for the preset file */
	if(is_sys_custom) {
		pr_debug("Custom preset, get settings from %s \n",
			PRESET_FILE_CUSTOM);
		path = PRESET_FILE_CUSTOM;
	}
	else {
		pr_debug("Search config file \n");
		if(get_preset_file_path(preset, type, &path)) {
			pr_error("Preset %d not found!\n", preset);
			return 1;
		}
	}

	/* Load preset file from filesystem */
	get_tmgr_config_preset(&current_preset);
	pr_debug("Current preset %d\n", current_preset);
	pr_debug("Load preset file \n");
	ret = gpa_mod_load_cfg(tmgr_mod, NULL, path);
	if(ret && ret != -ENODATA) {
		pr_error("Error loading %s preset file (ret = %d)",
			path, ret);
		return 1;
	}
	get_tmgr_config_preset(&loaded_preset);
	pr_debug("Set again preset to %d (loaded: %d)\n", current_preset, loaded_preset);
	set_tmgr_config_preset(current_preset);

	pr_debug("%s loaded properly! \n", path);

	if(!is_sys_custom)
		free(path);
	gpa_update_caches();

	/* Enable again preset autoload */
	set_tmgr_autoload_preset(1);

	return 0;
}

int load_preset(struct preset_name *preset)
{
	if(!preset || !preset->used)
		return 1;

	return _load_preset(preset->index, preset->type);
}

int load_glb_preset(unsigned int preset)
{
	if(preset >= MAX_PRESETS)
		return 1;

	return load_preset(&glb_presets[preset]);
}

static int compare_presets(const void *pa, const void *pb)
{
	if (((struct preset_name *)pa)->index < ((struct preset_name *)pb)->index)
		return -1;
	else if (((struct preset_name *)pa)->index > ((struct preset_name *)pb)->index)
		return 1;

	return 0;
}

static void print_detect_dir_msg(enum preset_type type, const char *dir)
{
		if(type == PRESET_VC_USR)
			pr_info("There is not user preset directory. Skipping scanning of %s\n", dir);
		else
			pr_warning("Can't list directory %s\n", dir);
}

int get_available_presets(enum preset_type type, struct preset_name *presets,
			int max, unsigned int opt)
{
	char pattern[MAX_STR_LEN] = {0};
	glob_t globdata;
	char *dir;
	int i;
	int ret = 0;
	int name_indexed = (opt & PRESET_OPT_NAME_INDEXED);

	/* Select the preset path depending on <type> */
	switch (type) {
	case PRESET_VC_SYS:
		dir = VC_PRESET_SYS_DIR;
		max = (max > N_VC_PRESET_SYS_RESERVED) ? N_VC_PRESET_SYS_RESERVED : max;
		break;
	case PRESET_VC_USR:
		dir = VC_PRESET_USR_DIR;
		break;
	default:
		pr_error("Unknown preset type: %d\n", type);
		return -1;
	}

	/* Search for all presets in the appropriate directory. */
	snprintf(pattern, MAX_STR_LEN-1, PRESET_FILE_LIST_PATTERN, dir);

	if (glob(pattern, 0, 0, &globdata)) {
		print_detect_dir_msg(type, dir);
		ret = -1;
		goto exit;
	}

	if (globdata.gl_pathc < 1) {
		pr_warning("No presets found in %s\n", dir);
		ret = 0;
		goto exit;
	}

	if (globdata.gl_pathc > max) {
		pr_warning("Too many presets found in %s "
			"(%d, max is %d)\n", dir, globdata.gl_pathc, max);
		ret = -1;
		goto exit;
	}

	/* Parse and save the found presets in the <presets> table */
	for (i = 0; i < globdata.gl_pathc; i++) {
		char *found;
		char *aux;
		int ipreset;
		int findex;
		int j = 0;

		found = basename(globdata.gl_pathv[i]);

		/* Parse the preset number */
		aux = strtok(found, "_");
		findex = strtol(aux, 0, 10);
		if (errno == ERANGE || (name_indexed && findex >= max)) {
			pr_warning("Error parsing preset filename %s\n",
				globdata.gl_pathv[i]);
			ret = -1;
			goto exit;
		}

		ipreset = (name_indexed) ? findex : i;
		presets[ipreset].index = findex;
		presets[ipreset].type = type;

		/*
		 * Parse and format the preset name. Replace underscores with
		 * spaces.
		 */
		aux = strtok(0, ".");
		while (*aux) {
			if (*aux == '_')
				presets[ipreset].name[j] = ' ';
			else
				presets[ipreset].name[j] = *aux;
			j++;
			aux++;
		}

		presets[ipreset].used = 1;
	}

	/*
	 * Sort the table by preset number. glob retrieves the files in
	 * alphanumeric order and we want single-digit preset numbers to be
	 * first in the table.
	 */
	if(!name_indexed)
		qsort(presets, globdata.gl_pathc, sizeof(struct preset_name),
			compare_presets);
	ret = globdata.gl_pathc;

exit:
	globfree(&globdata);
	return ret;
}

static int get_available_glb_presets_by_type(enum preset_type type)
{
	struct preset_name *p;
	int np;
	unsigned int opt = 0;

	if(MAX_PRESETS < N_VC_PRESET_SYS_RESERVED)
		return -1;

	switch(type) {
	case PRESET_VC_SYS:
		p = &glb_presets[0];
		np = N_VC_PRESET_SYS_RESERVED;
		opt |= PRESET_OPT_NAME_INDEXED;
		break;
        case PRESET_VC_USR:
		p = &glb_presets[N_VC_PRESET_SYS_RESERVED];
		np = MAX_PRESETS - N_VC_PRESET_SYS_RESERVED;
		break;
	default:
		pr_error("Unknown preset type: %d\n", type);
		return -1;
	};

	return get_available_presets(type, p, np, opt);
}

int get_available_glb_presets(unsigned int *last)
{
	int i;
	int ret = 0;
	int np = 0;
	struct preset_name *p;

	memset(&glb_presets[0], 0, sizeof(glb_presets));
	for(i = 0 ; i < N_PRESET_TYPES ; i++) {
		ret = get_available_glb_presets_by_type(i);
		if(ret < 0) {
			if (i == PRESET_VC_USR)
				ret = 0;
			break;
		}

		np += ret;
	}

	if(last) {
		for(i = 0 ; i < MAX_PRESETS ; i++) {
			p = &glb_presets[i];
			if(p->used)
				*last = i;
		}
	}

	return (ret < 0) ? ret : np;
}

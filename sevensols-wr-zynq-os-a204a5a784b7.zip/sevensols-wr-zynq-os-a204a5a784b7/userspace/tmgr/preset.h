#ifndef __PRESET_H__
#define __PRESET_H__

/*
 * preset.h
 *
 * General API for controlling preset for Virtual Clock and port modes.
 *
 *
 * Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Jul 16, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include "commondefs.h"

/************************************************************
 * Macros and datatypes                                     *
 ************************************************************/

#define PRESET_OPT_NAME_INDEXED 0x1

enum preset_type {
	PRESET_VC_SYS,
	PRESET_VC_USR,

	N_PRESET_TYPES,
};

struct preset_name {
	int used;
	int index;
	char name[MAX_STR_LEN];
	enum preset_type type;
};


/************************************************************
 * Public API                                               *
 ************************************************************/

struct preset_name * get_glb_presets(void);

/*
 * Load a preset on demand.
 *
 * Parameters:
 *   - preset: Parameter id (index of glb_presets) or preset pointer reference
 *   to load.
 *
 * Returns:
 *   0 If everything was ok (gpa parameters are updated)
 *   1 In case of failure
 */
int load_preset(struct preset_name *preset);
int load_glb_preset(unsigned int preset);


/*
 * Scans for defined presets and loads the available preset info in a table
 * (preset_index - preset_name).
 *
 * Presets are defined as files with this naming scheme:
 *
 *   xx_preset_name.config
 *
 * where <xx> is the preset number. This function parses the file names and
 * saves the number and the name (with underscores replaced by spaces) to the
 * <presets> table.
 *
 * Parameters:
 *   - type:    Type of presets to search for (PRESET_VC_SYS or PRESET_VC_USR)
 *   - presets: The table to store the preset info. An array of struct
 *              preset_name that must be pre-allocated.
 *   - max:     Number of elements in the <presets> array.
 *   - opt:     Options.
 *                  - PRESET_OPT_NAME_INDEXED: Preset is indexed using its name
 *
 * Returns:
 *   The number of presets found.
 *   -1 in case of error.
 */
int get_available_presets(enum preset_type type, struct preset_name *presets,
			int max, unsigned int opt);
int get_available_glb_presets(unsigned int *last);

#endif

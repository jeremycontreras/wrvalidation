/*
 * vcs.c
 *
 * Virtual Clock use Cases (VSC) source code.
 *
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: Mar 31, 2020
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <stdlib.h>
#include <string.h>

#include "vcs.h"
#include "gpa_interface.h"

// Private defines for VCS table building
#define VCS_TABLE_ENTRY(c,r,s,m,ma,a,aa,p) {.code = c, .role = r, .state = s, .msg = m, .msg_args = ma, .act_ref_args = aa, .act_ref = a, .priority0 = p}
#define VCS_TABLE_SENTRY(c,r,s,m,a,p) VCS_TABLE_ENTRY(c,r,s,m,0,a,0,p)
#define VCS_TABLE_SENTRY_AREF(c,r,s,m,a,aa,p) VCS_TABLE_ENTRY(c,r,s,m,0,a,aa,p)
#define VCS_TABLE_SENTRY_MSG(c,r,s,m,ma,a,p) VCS_TABLE_ENTRY(c,r,s,m,ma,a,0,p)

/*
 * Enum type for Virtual Clock use Cases (VCS) state
 *
 */
enum tmgr_vcs_state {
	VCS_CRITICAL,
	VCS_WARNING,
	VCS_CRIT_WARN,
	VCS_OK
};

enum tmgr_vcs_role {
	VCS_ROLE_GM,
	VCS_ROLE_BC,
	VCS_ROLE_FR_HO,
	VCS_ROLE_GNSS,
	VCS_ROLE_NULL,
};

struct tmgr_vcs_item {
	enum tmgr_vcs_code code;
	enum tmgr_vcs_role role;
	enum tmgr_vcs_state state;
	char *msg;
	int msg_args;
	char *act_ref;
	int act_ref_args;
	signed char priority0;
};

// Global table for VCS
static const struct tmgr_vcs_item _vcs_table[] =
{
	// Special cases
	VCS_TABLE_SENTRY(VCS_UNINITIALIZED, VCS_ROLE_NULL, VCS_OK, "Uninitialized", "None", -1),
	// General cases
	VCS_TABLE_SENTRY(VCS_READY, VCS_ROLE_NULL, VCS_OK, "Timing source is ready", NULL, 25),
	VCS_TABLE_SENTRY(VCS_SYSTEM_ERROR, VCS_ROLE_NULL, VCS_CRITICAL, "System Error", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_INITIALIZING, VCS_ROLE_NULL, VCS_WARNING, "Initializing...", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_MULTIREF_COMPROMISED, VCS_ROLE_NULL, VCS_WARNING, "Locked: Multi-ref integrity compromised", NULL, -1),
	// GM use cases
	VCS_TABLE_SENTRY(VCS_GM_LOCKED, VCS_ROLE_GM, VCS_OK, "Locked", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_10M_NOT_PRESENT, VCS_ROLE_GM, VCS_CRITICAL, "Unlocked: 10MHz not present", "GM: Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_HO_10M_NOT_PRESENT, VCS_ROLE_GM, VCS_CRIT_WARN, "Holdover: 10MHz not present", "GM: Holdover", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_PPS_NOT_PRESENT, VCS_ROLE_GM, VCS_CRITICAL, "Unlocked: PPS not present", "GM: Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_HO_PPS_NOT_PRESENT, VCS_ROLE_GM, VCS_CRIT_WARN, "Holdover: PPS not present", "GM: Holdover", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_10M_AND_PPS_NOT_PRESENT, VCS_ROLE_GM, VCS_CRITICAL, "Unlocked: 10MHz+PPS not present", "GM: Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_HO_10M_AND_PPS_NOT_PRESENT, VCS_ROLE_GM, VCS_CRIT_WARN, "Holdover: 10MHz+PPS not present", "GM: Holdover", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_10M_NOT_STABLE, VCS_ROLE_GM, VCS_CRITICAL, "Unlocked: 10MHz not stable", "GM: Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GM_UNLOCKED_REP_LOCK_UNLOCK, VCS_ROLE_GM, VCS_CRITICAL, "Repetitive lock/unlock", "GM: Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_PPS_LOST, VCS_ROLE_GM, VCS_WARNING, "Locked: PPS not present", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_NTP_NOT_SET, VCS_ROLE_GM, VCS_WARNING, "Locked: Time of Day was not set (NTP error)", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_LEAPS_EXPIRED, VCS_ROLE_GM, VCS_WARNING, "Locked: Leap seconds file has expired", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_NTP_OFFSET_1S, VCS_ROLE_GM, VCS_WARNING, "Locked: ToD offset bigger than 1s (NTP offset)", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_NTP_NOT_REPLY, VCS_ROLE_GM, VCS_WARNING, "Locked: NTP does not reply anymore", "GM: Front-panel", -1),
	VCS_TABLE_SENTRY(VCS_GM_LOCKED_GM_MAINTENANCE, VCS_ROLE_GM, VCS_WARNING, "Locked: Maintenance scheduled", "GM: Front-panel", -1),
	// BC use cases
	VCS_TABLE_SENTRY_AREF(VCS_BC_WR_LOCKED, VCS_ROLE_BC, VCS_OK, "Locked (TRACK_PHASE)", "BC: WR @ %", 1, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_PTP_LOCKED, VCS_ROLE_BC, VCS_OK, "Locked", "BC: PTP @ %", 1, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_WR_LOCKED_LEGACY, VCS_ROLE_BC, VCS_OK, "Locked (TRACK_PHASE) - Legacy GM", "BC: WR @ %", 1, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_FR, VCS_ROLE_BC, VCS_OK, "Locked - Upstream in manual Free-running", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_IFACE_DOWN, VCS_ROLE_BC, VCS_CRITICAL, "No connected reference - link down", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_HO_IFACE_DOWN, VCS_ROLE_BC, VCS_CRIT_WARN, "Lost connected reference - link down", "BC: Holdover", -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_GM_MAINTENANCE, VCS_ROLE_BC, VCS_CRITICAL, "GM under maintenance", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_BC_HO_MAINTENANCE, VCS_ROLE_BC, VCS_CRIT_WARN, "GM under maintenance", "BC: Holdover", -1),
	VCS_TABLE_ENTRY(VCS_BC_NOLINK_MASTER_NOT_DETECTED, VCS_ROLE_BC, VCS_CRITICAL, "No % connected reference", 1, "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_HO_MASTER_NOT_DETECTED, VCS_ROLE_BC, VCS_CRIT_WARN, "No WR servo update", "BC: Holdover", -1),
	VCS_TABLE_ENTRY(VCS_BC_NOLINK_PTP_ERROR, VCS_ROLE_BC, VCS_CRITICAL, "Invalid % exchange", 1, "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_NOLINK_NOLOCK, VCS_ROLE_BC, VCS_CRITICAL, "Can not lock to reference", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_NOLINK_REP_LOCK_UNLOCK, VCS_ROLE_BC, VCS_CRITICAL, "Repetitive lock/unlock", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_SYNCE_BAD_QL, VCS_ROLE_BC, VCS_CRITICAL, "SyncE SSM QL error - Not QL-PRC", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_HO_SYNCE_BAD_QL, VCS_ROLE_BC, VCS_CRITICAL, "SyncE SSM QL error - Not QL-PRC", "BC: Holdover", -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_NOLINK_LOCKED_FR, VCS_ROLE_BC, VCS_CRITICAL, "Locked: Upstream device in Free-running", "BC: % @ %", 2, 50),
	VCS_TABLE_SENTRY(VCS_BC_NOLINK_HO_FR, VCS_ROLE_BC, VCS_CRIT_WARN, "Upstream device in Free-running", "BC: Holdover", -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_10M_PPS_LOCKED_FR, VCS_ROLE_BC, VCS_CRITICAL, "Locked: Upstream GM in Free-running", "BC: % @ %", 2, 50),
	VCS_TABLE_SENTRY(VCS_BC_10M_PPS_HO_FR , VCS_ROLE_BC, VCS_CRIT_WARN, "Upstream GM in Free-running", "BC: Holdover", -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_HO_LOCKED, VCS_ROLE_BC, VCS_WARNING, "Locked: Upstream GM in holdover", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_HO_LOCKED2, VCS_ROLE_BC, VCS_WARNING, "Locked: Upstream device in holdover", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_NOLINK_LOCKED_GM_MAINTENANCE, VCS_ROLE_BC, VCS_WARNING, "Locked: GM under maintenance", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_GM_NTP_ERROR, VCS_ROLE_BC, VCS_WARNING, "Locked: Time of Day not available on GM", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_GM_LEAPS_EXPIRED, VCS_ROLE_BC, VCS_WARNING, "Locked: Leap seconds file on GM has expired", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_GM_NTP_INTEGRITY, VCS_ROLE_BC, VCS_WARNING, "Locked: GM ToD integrity compromised", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_NTP_INTEGRITY, VCS_ROLE_BC, VCS_WARNING, "Locked: NTP integrity compromised", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_SFP_CAL, VCS_ROLE_BC, VCS_WARNING, "Locked: SFP calibration not applied", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_FIBER_CAL, VCS_ROLE_BC, VCS_WARNING, "Locked: Fiber calibration not applied", "BC: % @ %", 2, -1),
	VCS_TABLE_SENTRY_AREF(VCS_BC_LOCKED_SYNCE_NOT_LOCKED, VCS_ROLE_BC, VCS_CRITICAL, "Locked: SyncE unlock error", "BC: PTP @ %", 1, -1),
	VCS_TABLE_SENTRY(VCS_BC_LOCKED_HO_SYNCE_NOT_LOCKED, VCS_ROLE_BC, VCS_CRITICAL, "Locked: SyncE unlock error", "BC: Holdover", -1),
	// GNSS use cases
	VCS_TABLE_SENTRY(VCS_GNSS_OK, VCS_ROLE_GNSS, VCS_OK, "Locked", "GNSS", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_CHIP_ERROR, VCS_ROLE_GNSS, VCS_CRITICAL, "GNSS Chip error", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_BAD_SIGNAL, VCS_ROLE_GNSS, VCS_CRITICAL, "GNSS no signal/bad signal", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_HO, VCS_ROLE_GNSS, VCS_CRIT_WARN, "GNSS holdover", "Holdover", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_JAMMING_CRITICAL, VCS_ROLE_GNSS, VCS_CRITICAL, "GNSS jamming detected", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_TOD_ERROR, VCS_ROLE_GNSS, VCS_WARNING, "GNSS signal OK but no ToD (wait 12m)", "GNSS", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_INTEGRITY_ERROR, VCS_ROLE_GNSS, VCS_WARNING, "GNSS OK but no integrity", "GNSS", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_LOW_SIGNAL, VCS_ROLE_GNSS, VCS_WARNING,"GNSS low signal", "GNSS", -1),
	VCS_TABLE_SENTRY(VCS_GNSS_JAMMING, VCS_ROLE_GNSS, VCS_WARNING, "GNSS jamming detected", "GNSS", -1),
	// Manual FR use cases
	VCS_TABLE_SENTRY(VCS_MANUAL_FR_OK, VCS_ROLE_FR_HO, VCS_OK, "Manual Free-running", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_FR_EXPIRED, VCS_ROLE_FR_HO, VCS_CRITICAL, "Free-running/Holdover Expired", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_FR_MAINTENANCE, VCS_ROLE_FR_HO, VCS_CRITICAL, "Maintenance terminated", "Internal Oscillator", -1),
	VCS_TABLE_SENTRY(VCS_FR_FAIL, VCS_ROLE_FR_HO, VCS_WARNING, NULL, NULL, -1),
};

/**
 * @brief Get a VCS item from VCS global table
 * @param code VCS code to search in VCS table
 * @return VCS entry if found and NULL otherwise
 */
static const struct tmgr_vcs_item *get_vcs_item(enum tmgr_vcs_code code)
{
	int nentries = sizeof(_vcs_table)/sizeof(_vcs_table[0]);
	int found = 0;
	const struct tmgr_vcs_item *item;
	int i;

	for(i = 0 ; i < nentries ; i++) {
		item = &_vcs_table[i];
		if(item->code == code) {
			found = 1;
			break;
		}
	}

	if(!found)
		item = NULL;

	return item;
}

/**
 * @brief Convert from tmgr_vcs_state structure into vc_status one
 * @param code VCS code
 * @return vc_status code or VC_STATUS_ERROR if VCS is not found
 */
enum vc_status convert_vcs_state_into_vc_status(enum tmgr_vcs_code code)
{
	enum vc_status status = VC_STATUS_ERROR;
	const struct tmgr_vcs_item *item = get_vcs_item(code);

	if (!item)
		return status;

	switch(item->state) {
	case VCS_OK:
		status = VC_STATUS_OK;
		break;
	case VCS_WARNING:
	case VCS_CRIT_WARN:
		status = VC_STATUS_WARNING;
		break;
	case VCS_CRITICAL:
	default:
		status = VC_STATUS_ERROR;
		break;
	};

	return status;
}

/**
 * @brief Retrieve priority0 for specific VCS code
 * @param code VCS code
 * @return priority0 field of VCS code or -1 if VCS is not found
 */
signed char get_vcs_prio0(enum tmgr_vcs_code code)
{
	const struct tmgr_vcs_item *item = get_vcs_item(code);

	if (!item)
		return -1;

	return item->priority0;
}

/**
 * @brief Insert extra string arguments in a base string with wildcard chars
 * @param orig Original string with wildcard chars
 * @param args Extra arguments to be inserted in destination buffer
 * @param nargs Number of extra arguments
 * @param dest Destination buffer
 * @return 0 if success and 1 otherwise
 */
static int insert_vcs_string_args(const char *orig, const char **args, const int nargs, char *dest)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int iarg = 0;
	int ret = 0;

	while(orig[i]) {
		if(orig[i] == '%') {
			if (iarg < nargs) {
				for(j = 0 ; args[iarg][j] ; j++, k++) {
					dest[k] = args[iarg][j];
				}
				iarg++;
				i++;
			} else {
				ret = 1;
				break;
			}
		} else {
			dest[k] = orig[i];
			k++;
			i++;
		}
	}

	dest[k] = 0;

	return ret;
}

/**
 * @brief Insert extra string arguments in a VCS msg buffer with wildcard chars
 * @param code VCS code to search msg buffer
 * @param args Extra arguments to be inserted in destination buffer
 * @param nargs Number of extra arguments
 * @param msg Destination buffer
 * @return
 *        *  0: Ok
 *        * -1: Null entry error
 *        * -2: msg arg is NULL
 *        *  1: internal error of insertion function
 */
int insert_vcs_msg_string_args(enum tmgr_vcs_code code, const char **args, const int nargs, char *msg)
{
	const struct tmgr_vcs_item *item = get_vcs_item(code);
	int ret = 0;

	if(!item)
		return -1;
	if(!item->msg)
		return -2;

	if(item->msg_args <= 0) {
		strncpy(msg, item->msg, MAX_STR_LEN-1);
		ret = 0;
	}
	else {
		ret = insert_vcs_string_args(item->msg, args, nargs, msg);
	}

	return ret;
}

/**
 * @brief Insert extra string arguments in a VCS act_ref buffer with wildcard chars
 * @param code VCS code to search act_ref buffer
 * @param args Extra arguments to be inserted in destination buffer
 * @param nargs Number of extra arguments
 * @param act_ref Destination buffer
 * @return
 *        *  0: Ok
 *        * -1: Null entry error
 *        * -2: act_ref arg is NULL
 *        *  1: internal error of insertion function
 */
int insert_vcs_act_ref_string_args(enum tmgr_vcs_code code, const char **args, const int nargs, char *act_ref)
{
	const struct tmgr_vcs_item *item = get_vcs_item(code);
	int ret = 0;

	if(!item)
		return -1;
	if(!item->act_ref)
		return -2;

	if(item->act_ref_args <= 0) {
		strncpy(act_ref, item->act_ref, MAX_STR_LEN-1);
		ret = 0;
	}
	else {
		ret = insert_vcs_string_args(item->act_ref, args, nargs, act_ref);
	}

	return ret;
}


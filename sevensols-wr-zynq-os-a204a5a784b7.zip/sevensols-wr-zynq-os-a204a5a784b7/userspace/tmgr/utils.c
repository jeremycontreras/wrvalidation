/*
 * utils.c
 *
 * Utilitiy functions for Time Manager.
 *
 *
 * Author: Ricardo Canuelo <ricardo.canuelo@sevensols.com>
 * Author: Miguel Jimenez Lopez <miguel.jimenez@sevensols.com>
 * copyright Copyright (c) 2020 Seven Solutions S.L. - All Rights Reserved
 *
 * Created: May 30, 2019
 * Last modified: Mar 31, 2020
 *
 * This file is part of wr-zynq-os.
 * You may use, distribute and modify this code under the
 * terms of the LICENSE.txt provided  within the project: wr-zynq-os-2.
 * If you haven't received a copy of LICENSE.txt along with
 * this file please write to info@sevensols.com.
 */

#include <string.h>
#include <stdio.h>
#include <glob.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <libgen.h>
#include <ctype.h>

#include <libgpa.h>

#include "commondefs.h"
#include "utils.h"


/*
 * Comparison function for sorting network interface names.
 * This function complies with the qsort api and makes it sort interface names
 * by their number, assuming they all have the same alphabetical prefix.
 *
 * Example: if a is wr10 and b is wr1, then a > b
 */
static int iface_name_cmp(const void *a, const void *b)
{
	const char *iface_a = *((const char**)a);
	const char *iface_b = *((const char**)b);
	long int iface_num_a;
	long int iface_num_b;

	while(isalpha(*iface_a))
		iface_a++;
	while(isalpha(*iface_b))
		iface_b++;

	iface_num_a = strtol(iface_a, 0, 0);
	iface_num_b = strtol(iface_b, 0, 0);

	return (iface_num_a > iface_num_b) ? 1 : -1;
}

/*
 * find_file_matches
 *
 * Looks for files matching wildcard pattern <pattern> and saves the basename of
 * each matching file to the <names> string array.
 *
 * Parameters:
 *   pattern (in): The pattern to look for. It may contain simple wildcards.
 *   names (out):  The string array where to save the file names. It must be a
 *                 already allocated and able to hold the file names.
 *   max_matches (in): Number of strings allocated in <names>.
 *
 * Returns: The number of matches found, or -1 if error.
 */
static int find_file_matches(char *pattern, char **names, int max_matches)
{
	glob_t globdata;
	int matches = 0;
	int i;

	if (glob(pattern, GLOB_ERR, 0, &globdata) == 0 && globdata.gl_pathc > 0) {
		if (globdata.gl_pathc > max_matches) {
			pr_warning("<names> array is not big enough "
				"to hold all the matches\n");
			return -1;
		}
		for (i = 0; i < globdata.gl_pathc; i++) {
			if (names) {
				memset(names[matches], 0, MAX_STR_LEN);
				strncpy(names[matches],
					basename(globdata.gl_pathv[i]),
					MAX_STR_LEN - 1);
			}
			matches++;
		}
		globfree(&globdata);
	} else {
		return -1;
	}

	return matches;
}


int find_ports(unsigned char type, char names[][MAX_STR_LEN], int max_ports)
{
	char pattern[MAX_STR_LEN] = {0};
	int ports = 0;
	char **aux_names;
	int i;
	int ret = 0;

	if (type == 0 || type > PORT_TYPE_VALID) {
		pr_warning("Invalid port type %d\n", type);
		return 0;
	}

	aux_names = calloc(max_ports, sizeof(char*));
	if (!aux_names) {
		pr_warning("Error allocating memory\n");
		return -1;
	}
	for (i = 0; i < max_ports; i++)
		aux_names[i] = calloc(1, MAX_STR_LEN);


	if (type & PORT_TYPE_WR) {
		int matches;

		snprintf(pattern, MAX_STR_LEN-1, "%s/wr*", SYSFS_PORT_PATH);
		matches = find_file_matches(pattern, aux_names, max_ports);
		if (matches < 0) {
			pr_warning("Error finding ports in sysfs\n");
			ret = -1;
			goto error;
		}

		qsort(aux_names, matches, sizeof(char *), iface_name_cmp);
		for (i = 0; i < matches; i++) {
			strncpy(names[i], aux_names[i], MAX_STR_LEN-1);
			memset(aux_names[i], 0, MAX_STR_LEN);
		}

		ports += matches;
		memset(pattern, 0, MAX_STR_LEN);
	}

	if (type & PORT_TYPE_ETH) {
		int matches;

		snprintf(pattern, MAX_STR_LEN-1, "%s/eth*", SYSFS_PORT_PATH);
		matches = find_file_matches(pattern, aux_names, max_ports);
		if (matches < 0) {
			pr_warning("Error finding ports in sysfs\n");
			ret = -1;
			goto error;
		}

		qsort(aux_names, matches, sizeof(char *), iface_name_cmp);
		for (i = 0; i < matches; i++) {
			strncpy(names[ports + i], aux_names[i], MAX_STR_LEN-1);
			memset(aux_names[i], 0, MAX_STR_LEN);
		}

		ports += matches;
		memset(pattern, 0, MAX_STR_LEN);
	}
	ret = ports;

error:
	for (i = 0; i < max_ports; i++)
		free(aux_names[i]);
	free(aux_names);

	return ret;
}




int daemonize(int flags)
{
	int maxfd;
	int fd;

	/* Fork current process and exit, continue as the child process. */
	switch (fork()) {
	case -1:
		return -1;
	case 0:
		break;
	default:
		exit(0);
	}

	/* Become leader of new session */
	if (setsid() == -1)
		return -1;

	/*
	 * Ensure we're note session leader (avoid the process from reacquiring
	 * a controlling terminal).
	 */
	switch (fork()) {
	case -1:
		return -1;
	case 0:
		break;
	default:
		exit(0);
	}

	if (!(flags & DAEMONIZE_NO_UMASK0))
		umask(0);

	if (!(flags & DAEMONIZE_NO_CHDIR))
		chdir("/");

	if (!(flags & DAEMONIZE_NO_CLOSE_FILES)) {
		maxfd = sysconf(_SC_OPEN_MAX);
		if (maxfd < 0)
			maxfd = DAEMONIZE_MAX_CLOSE;

		for (fd = 0; fd < maxfd; fd++)
			close(fd);
	}

	if (!(flags & DAEMONIZE_NO_REOPEN_STD_FDS)) {
		close(STDIN_FILENO);

		fd = open("/dev/null", O_RDWR);

		if (fd != STDIN_FILENO)
			return -1;
		if (dup2(STDIN_FILENO, STDOUT_FILENO) != STDOUT_FILENO)
			return -1;
		if (dup2(STDIN_FILENO, STDERR_FILENO) != STDERR_FILENO)
			return -1;
	}

	return 0;
}

/*
 * util.c
 *
 *  Created on: Apr 27, 2016
 *      Author: neub
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>

#include <libwrz/util.h>
#include <libwrz/wrz-msg.h>


static int loops_per_msec = -1;
char strbits[33] = {0};

//------------------------------------------------------------ string

int atoideflim(char* arg,int defval,int min, int max)
{
	int ret=atoi(arg);
	if(min <= ret && ret <= max) return ret;
	pr_warn("Value %d is outrange [%d,%d] using default=%d",ret,min,max,defval);
	return defval;
}


//------------------------------------------------------------ bit


/**
 * count the number of 1 in a 32-bit register
 */
uint32_t wrz_bits_nbset(uint32_t i)
{
	// Java: use >>> instead of >>
	// C or C++: use uint32_t
	i = i - ((i >> 1) & 0x55555555);
	i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
	return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}


/**
 * return the bit representation of x
 *
 *         wrz_bits_strpad(buf,25,8)
 *         //return 0b00011001
 *
 * @param buf: the buffer where to store the string
 * @param x: the value to convert to string
 * @param pad: the minimun number of zero to display
 * @return a string with the bit representation of x
 */
const char* wrz_bits_strpad(char *buf,uint32_t x,uint8_t pad)
{
	char *c=(char*)buf;
	uint32_t mask=0x80000000;
	uint8_t r = 0;
	pad=(pad<32)?pad:32;
	for(r=0;r<pad;r++) c[r]='0';

	if (x > 0)
	{
		for(;(x & mask)==0 && mask >= (1<<pad); mask>>=1) { } //do nothing
		for(;mask>0; mask>>=1,c++)
		{
			*c=(x & mask)?'1':'0';
		}
	}
	else
	{
		for(r=0;r<pad;r++) *(c++)='0';
	}
	*c='\0';
	return buf;
}


/**
 * return the bit representation of x (simple version)
 *
 * This function use an internal buffer
 *
 * @warning this function is not thread safe, you should not use twice in a printf
 * @ref wrz_bits_strpad()
 */
const char* wrz_bits_str(uint32_t x)
{
	return wrz_bits_strpad(strbits,x,0);
}


//------------------------------------------------------------ delay

/* Calculate how many loops per millisecond we make in this CPU */
void wrz_udelay_init(void)
{
	volatile int i;
	int j, cur, min = 0;
	struct timeval tv1, tv2;
	for (j = 0; j < 10; j++) {
		gettimeofday(&tv1, NULL);
		for (i = 0; i < 100*1000; i++)
			;
		gettimeofday(&tv2, NULL);
		cur = (tv2.tv_sec - tv1.tv_sec) * 1000 * 1000
			+ tv2.tv_usec - tv1.tv_usec;
		/* keep minimum time, assuming we were scheduled-off less */
		if (!min || cur < min)
			min = cur;
	}
	loops_per_msec = i * 1000 / min;

	if (0)
		printf("loops per msec %i\n", loops_per_msec);
	/*
	 * I get 39400 more or less; it makes sense at 197 bogomips.
	 * The loop is 6 instructions with 3 (cached) memory accesses
	 * and 1 jump.  197/39.4 = 5.0 .
	 */
}
/*
 * This function is needed to for slow delays to overcome the jiffy-grained
 * delays that the kernel offers. We can't wait for 1ms when needing 4us.
 */
void wrz_udelay(uint32_t microseconds)
{
	volatile int i;

	if (loops_per_msec < 0)
		wrz_udelay_init();

	if (microseconds > 1000) {
		usleep(microseconds);
		return;
	}
	for (i = 0; i < loops_per_msec * microseconds / 1000; i++)
		;
}

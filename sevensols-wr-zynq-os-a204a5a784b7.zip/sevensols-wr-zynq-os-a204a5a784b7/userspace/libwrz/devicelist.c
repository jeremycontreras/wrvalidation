/*
 * devicelist.c
 *
 * This work is part of the White Rabbit project
 *
 * Copyright (C) 2014 CERN (www.cern.ch)
 * Author: Alessandro Rubini <rubini@gnudd.com>
 * Author: Benoit Rat <benoit@sevensols.com>
 *
 * Released according to the GNU GPL, version 2 or any later version.
 */

#include <libwrz.h>
#define SDBFS_BIG_ENDIAN
#include <libsdbfs.h>
#include <stdlib.h>

/* The following pointers are exported */
unsigned char *BASE_GW_VERSION=0;
unsigned char *BASE_SPI_AD9516=0;
unsigned char *BASE_WRC_SOFTPLL=0;
unsigned char *BASE_WRC_PPS_GEN=0;
unsigned char *BASE_WRC_SYSCON=0;
unsigned char *BASE_WRC_UART=0;
unsigned char *BASE_WRC_ONEWIRE=0;
unsigned char *BASE_WRC_GPIO_PORT=0;

/* The sdb filesystem itself */
static struct sdbfs wrz_fpga_sdb = {
	.name = "fpga-area",
	.blocksize = 1, /* Not currently used */
	.entrypoint = SDB_ADDRESS,
	.data = 0,
	.flags = SDBFS_F_ZEROBASED,
};

void *fru_alloc(size_t size)
{
	return malloc(size);
}


/* called by outside, at boot time */
void sdb_print_devices(void)
{
	struct sdb_device *d;
	int new = 1;
	while ( (d = sdbfs_scan(&wrz_fpga_sdb, new)) != NULL) {
		/*
		 * "%.19s" is not working for XINT printf, and zeroing
		 * d->sdb_component.product.record_type won't work, as
		 * the device is read straight from fpga ROM registers
		 */
		const int namesize = sizeof(d->sdb_component.product.name);
		char name[namesize + 1];

		memcpy(name, d->sdb_component.product.name, sizeof(name));
		name[namesize] = '\0';
		printf(" * 0x%06llx:0x%08x @ %06lx, %s\n",
				ntohll(d->sdb_component.product.vendor_id),
				ntohl(d->sdb_component.product.device_id),
				wrz_fpga_sdb.f_offset, name);
		new = 0;
	}
}

/* To save a little size, we enumerate our vendors */
#define VID_CERN	0x0000ce42LL
#define VID_GSI		0x00000651LL
#define VID_7S		0x00007501LL
#define VID_UGR		0x00001164LL

struct wrz_device {
	unsigned char **base;
	uint64_t vid;
	uint32_t did;
	uint32_t pos;
};

struct wrz_device devs[] = {
	{&BASE_WRC_SOFTPLL,       VID_CERN,	0x65158dc0,0},
	{&BASE_WRC_PPS_GEN,       VID_CERN,	0xde0d8ced,0},
	{&BASE_WRC_SYSCON,        VID_CERN,	0xff07fc47,0},
	{&BASE_WRC_UART,          VID_CERN,	0xe2d13d04,0},
	{&BASE_WRC_ONEWIRE,       VID_CERN,	0x779c5443,0},
	{&BASE_SPI_AD9516,        VID_CERN,	0xe503947e,0},
	{&BASE_WRC_GPIO_PORT,     VID_CERN,	0x441c5143,0},
	{&BASE_GW_VERSION,        0x75cb,	0xc1f77c10,0},
	{&BASE_GW_VERSION,        VID_7S,	0xc1f77c10,0},
};

int sdb_find_devices(void)
{
	struct wrz_device *d;
	static int done;
	int i,ret;
	unsigned long addr;

	if(_fpga_base_virt==NULL) {
		pr_error("fpga_base is NULL");
		return -1;
	}
	wrz_fpga_sdb.data=(void*)_fpga_base_virt;

	if (!done) {
		ret=sdbfs_dev_create(&wrz_fpga_sdb);
		if(ret) {
			pr_debug("sdbfs_dev_created() %d\n",ret);
			return ret;
		}
		done++;
	}
	for (d = devs, i = 0; i < ARRAY_SIZE(devs); d++, i++)
	{
		addr=sdbfs_find_id(&wrz_fpga_sdb,d->vid, d->did);
		if((int)addr==-ENOENT) {
			if(d->did==0xc1f77c10) continue;
			else if(d->did==0xe503947e) pr_info("Could not find %06llx:%08x in SDB\n",d->vid, d->did);
			else pr_warn("Could not find %06llx:%08x in SDB\n",d->vid, d->did);
			continue;
		}
		pr_debug("%d: %06llx %08x @ 0x%08lx\n",i,d->vid, d->did,addr);
		*(d->base) = (void *)addr;
	}
	return 0;
}




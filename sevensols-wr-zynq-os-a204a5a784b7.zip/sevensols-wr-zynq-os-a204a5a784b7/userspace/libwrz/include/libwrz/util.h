#ifndef __LIBWR_HW_UTIL_H
#define __LIBWR_HW_UTIL_H

#include <stdio.h>
#include <inttypes.h>

//String manip
#define atoidef(str,def) (str)?atoi(str):def
int atoideflim(char* arg,int defval,int min, int max);

//Bit manip
const char* wrz_bits_strpad(char *buf,uint32_t x,uint8_t pad);
const char* wrz_bits_str(uint32_t x);
uint32_t wrz_bits_nbset(uint32_t val);

//Delay manip
void wrz_udelay_init(void);
void wrz_udelay(uint32_t microseconds);

#endif /* __LIBWR_HW_UTIL_H */

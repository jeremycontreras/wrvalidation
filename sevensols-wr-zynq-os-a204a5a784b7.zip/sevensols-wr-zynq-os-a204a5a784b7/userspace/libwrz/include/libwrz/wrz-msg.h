/*
 * A replacement for TRACE, which is different things to different people;
 * with no ifdef but only run-time conditionals -- so all code is built
 * and we don't risk rusting unused messages.
 *
 * Unfortunately this is part of libwrz, so tools will need to link in
 * libwrz. Otherwise we could not host state or hide the varargs things.
 *
 * Some of the things were already done right in <libwrz/trace.h>,
 * like choosing a file a runtime etc. Those are preserved here.
 */
#ifndef __WRZ_MSG_H__
#define __WRZ_MSG_H__

#include <stdio.h>
#include <syslog.h> /* for LOG_ERR, LOG_WARNING etc */
#include <errno.h>

/* We use stderr by default, but we may change file -- or use syslog, later */
extern void wrz_msg_file(FILE *target);
extern void wrz_msg_filename(char *name);

/*
 * The loglevel is global, default to warning, or getenv(); raised/lowered
 * by -v and -q, possibly twice (levels: debug, info, warn, err, nothing).
 * Also, wrz_msg_set_logvelel installs SIGUSR1 and SIGUSR2 handlers;
 * where the former makes more verbose, the letter less verbose
 */
extern int wrz_msg_level; /* user can set it in main() or whatever */

/* Optional: prepare all defaults. Like argv[0] to be prefixed, signals... */
extern void wrz_msg_init(int argc, char **argv);

#ifdef DEBUG /* We had it, so let's keep this build-time thing */
#  define WRZ_MSG_DEFAULT_LEVEL    LOG_DEBUG
#else
#  define WRZ_MSG_DEFAULT_LEVEL    LOG_WARNING
#endif

#define WRZ_MSG_DETAILS_AT  LOG_INFO /* >= info (so, debug) use __LINE__ */

/* This is the external function for it all */
extern void __wrz_msg(int level, const char *func, int line,
		      const char *fmt, ...)
	__attribute__((format(printf,4,5)));

/* The suggested use */
#define wrz_msg(lev, ...) __wrz_msg(lev, __func__, __LINE__, __VA_ARGS__)

/* And shortands for people using autocompletion -- but not all levels */
#define pr_error(...)	wrz_msg(LOG_ERR, __VA_ARGS__)
#define pr_err(...)	wrz_msg(LOG_ERR, __VA_ARGS__)
#define pr_warning(...)	wrz_msg(LOG_WARNING, __VA_ARGS__)
#define pr_warn(...)	wrz_msg(LOG_WARNING, __VA_ARGS__)
#define pr_info(...)	wrz_msg(LOG_INFO, __VA_ARGS__)
#define pr_debug(...)	wrz_msg(LOG_DEBUG, __VA_ARGS__)

#define assert_init(proc) { \
	int ret = proc; \
	if (ret < 0) { \
		pr_error("Error in function "#proc" ret = %d\n", ret); \
		return ret; \
	} \
}

#define wrz_msg_checklvl(level) (level <= wrz_msg_level)

#define WRZ_RETCHECK_MSG(assert_expr,ret,str) { if(!(assert_expr)) { pr_warn(str); return ret; } }
#define WRZ_RETCHECK_MSGVA(assert_expr,ret,str,...) { if(!(assert_expr)) { pr_warn(str,__VA_ARGS__); return ret; } }
#define WRZ_RETCHECK_PTR(ptr, ret) { if(ptr==0) { pr_warn("%s is NULL",#ptr); return ret; }} //-EFAULT


#define WRZ_STRINGIFY(x) #x
#define WRZ_TOSTRING(x) WRZ_STRINGIFY(x)

#endif /* __WRZ_MSG_H__ */

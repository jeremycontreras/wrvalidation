/*
 * wrzen.h
 *
 *  Created on: Apr 22, 2016
 *      Author: Benoit Rat
 */

#ifndef LIBWRZ_INCLUDE_HW_WRZEN_H_
#define LIBWRZ_INCLUDE_HW_WRZEN_H_

//Memory layout
extern unsigned char *BASE_GW_VERSION;
extern unsigned char *BASE_SPI_AD9516;
extern unsigned char *BASE_WRC_MINIC;
extern unsigned char *BASE_WRC_EP;
extern unsigned char *BASE_WRC_SOFTPLL;
extern unsigned char *BASE_WRC_PPS_GEN;
extern unsigned char *BASE_WRC_SYSCON;
extern unsigned char *BASE_WRC_UART;
extern unsigned char *BASE_WRC_ONEWIRE;
extern unsigned char *BASE_WRC_ETHERBONE_CFG;
extern unsigned char *BASE_WRC_GPIO_PORT;


// Access to the FPGA
#define FPGA_AXI_BASE_ADDR   0x43c00000
#define FPGA_AXI_MMAP_SIZE     0x100000

#define ZEN_DEV_FILE        "/dev/zen"

#define SDB_ADDRESS 0x70000

//Access to GPIOs
#define SYSFS_GPIO_BASEDIR  "/sys/class/gpio"
#define SYSFS_GPIO_OFFSET 906
#define SYSFS_GPIO_EMIO_AD9516   "961"
#define SYSFS_GPIO_EMIO_LCDRST   "964"


//Access to EEPROM
#define SYSFS_EEPROM_MAIN_FILE   "/sys/devices/soc0/amba_pl/43c00000.zen_base/eeprom"
#define SYSFS_EEPROM_TPEXP_FILE  "/sys/bus/i2c/devices/1-0052/eeprom"
#define SYSFS_EEPROM_MODBP_FILE  "/sys/bus/i2c/devices/1-0053/eeprom"
#define SYSFS_EEPROM_FMC_DIR     "/sys/bus/fmc/devices/"




#endif /* USERSPACE_LIBWRZ_INCLUDE_HW_WRZEN_H_ */

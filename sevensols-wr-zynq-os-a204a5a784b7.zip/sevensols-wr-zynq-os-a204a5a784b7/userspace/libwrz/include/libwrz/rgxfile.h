/*
 * rgxfile.h
 *
 *  Created on: Apr 25, 2016
 *      Author: neub
 */

#ifndef USERSPACE_LIBWRZ_INCLUDE_LIBWRZ_RGXFILE_H_
#define USERSPACE_LIBWRZ_INCLUDE_LIBWRZ_RGXFILE_H_

#include <stdio.h>
#include <regex.h>
#include <libwrz.h>

#define WRZ_RGXF_MAXLINE 256

//------- Rgx File parser

struct wrz_rgxf_handler {
	FILE *fp;     //!< the pointer on the file.
	regex_t rgx;  //!< the regular expression.
	char* cvt;    //!< the conversion type between matching groups and column of .data.
	uint32_t len; //!< the size of the array
	void *data;   //!< an array of len elements with 32b size each (int32_t,float,char*)
};

/**
 * Initiate the regex file parsing
 *
 * The `cvt` parameter is one of the most important, if we say that
 * cvt="dx" this means that the h->data will have an array of two integer (integer,integer but parsed as hexadecimal)
 *
 * Below we have written a small config sample file:
 *
 * ~~~~~~{.conf}
 * R01,"RGS",0xFEAD
 * R02,,0xAB01
 * R03,"STR",0x1010
 * ...
 * ~~~~~~~~~~
 *
 * So in order to use we must call the function as follow:
 *
 *      struct wrz_rgxf_handler h = {0};
 *      wrz_rgxf_init(&h,"sample.conf",([0-9]+),([^,]*),0x([0-9A-Fa-f]+)","dsx");

 *
 * Then by calling
 *
 *      wrz_rgxf_get_integer(&h,1,0)  //return 2
 *      wrz_rgxf_get_integer(&h,2,3)  //return 0x1010
 *      wrz_rgxf_get_string(&h,0,1)   //return "RGS"
 *
 * @param h: is the rgxf handler that store all the parameters for this parsing instance
 * @param fpath: the file path from which to parse
 * @param pattern: the pattern of the regular expression
 * @param cvt: the string that tell how to convert each group that will be return in h->data.
 * it can be `x`: hexadecimal, `d`: integer, `f`: floating point, `s`: string.
 * @return: 0 if OK, an error code otherwise.
 * @warning: the handler must be freed with the function wrz_rgxf_close().
 */
int wrz_rgxf_init(struct wrz_rgxf_handler* h, const char *fpath, const char* pattern, const char *cvt);
int wrz_rgxf_close(struct wrz_rgxf_handler* h);
int wrz_rgxf_read(struct wrz_rgxf_handler* h);
int wrz_rgxf_get_integer(struct wrz_rgxf_handler* h, int r, int c);
float wrz_rgxf_get_float(struct wrz_rgxf_handler* h, int r, int c);
const char* wrz_rgxf_get_string(struct wrz_rgxf_handler* h, int r, int c);


#endif /* USERSPACE_LIBWRZ_INCLUDE_LIBWRZ_RGXFILE_H_ */

/*
 * wrz.h
 *
 *  Created on: Apr 22, 2016
 *      Author: Benoit Rat
 */

#ifndef LIBWRZ_INCLUDE_WRZ_H_
#define LIBWRZ_INCLUDE_WRZ_H_

#include <inttypes.h>
#include <libwrz/wrz-msg.h>

//------- Generic defines

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a)/sizeof(a[0]))
#endif

//------ Exit codes

#define WRZ_EXIT_OK     0
#define WRZ_EXIT_MMAP   1
#define WRZ_EXIT_SDB    2
#define WRZ_EXIT_CONF   3
#define WRZ_EXIT_ERR    255

//------- Memory layout (devicelist.c)
#include <libwrz/hw/wr-zen.h>

int sdb_find_devices(void);
void sdb_print_devices(void);


//------- FPGA access (fpga_io.c)

#define HAL_DEV_NAME_PATH "/proc/device-tree/dev_info/devname"
enum HAL_DEV_FAMILY
{
	HAL_DEV_FAMILY_UNKNOW=-1,
	HAL_DEV_FAMILY_ZEN=0,
	HAL_DEV_FAMILY_LENP,
	HAL_DEV_FAMILY_Z16,
	_HAL_DEV_FAMILY_LAST,
};


#define WRZ_FPGA_MAP_AUTO 0
#define WRZ_FPGA_MAP_DEVMEM 1
#define WRZ_FPGA_MAP_DEVZEN 2
#define WRZ_FPGA_MAP_DEVSPI_0 3
#define WRZ_FPGA_MAP_DEVSPI_1 4
#define WRZ_FPGA_MAP_DEVSPI_2 5
#define WRZ_FPGA_MAP_RTSUBSYS_Z16 6
#define WRZ_FPGA_MAP_RTSUBSYS_ZEN 7

extern volatile void*  _fpga_base_virt;

#define FPGA_BASE_ADDR _fpga_base_virt


#define _fpga_writel(reg, val) \
	(*(volatile uint32_t *)(FPGA_BASE_ADDR + (reg)) = (val))
#define _fpga_readl(reg) \
	(*(volatile uint32_t *)(FPGA_BASE_ADDR + (reg)))

int wrz_dev_get_family(void);
int wrz_fpga_mmap_init(int dev_type);
void wrz_fpga_munmap(void);

#define FPGA_LM32_RESET_MASK 0x0deadbee

#endif /* LIBWRZ_INCLUDE_WRZ_H_ */

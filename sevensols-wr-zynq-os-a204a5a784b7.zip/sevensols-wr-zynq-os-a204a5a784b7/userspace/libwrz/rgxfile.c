/*
 * rgxfile.c
 *
 *  Created on: Apr 25, 2016
 *      Author: neub
 */

#include <libwrz/rgxfile.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

/**
 * Improve function of strncpy with size of from and to buffer.
 *
 * This function is useful when we want to substr from another string
 */
int wrz_strncpy(char * to, const char * from, size_t to_size, size_t from_size)
{
	size_t maxsize=(from_size<to_size)?from_size:to_size;
	strncpy(to,from,maxsize);
	to[maxsize]='\0';
	return maxsize;
}


int wrz_rgxf_init(struct wrz_rgxf_handler* h, const char *fpath, const char* rgex_str, const char *cvt)
{
	int ret=0,i=0;

	if(h==NULL) { pr_err("h is NULL"); return -1;}
	if(fpath==NULL) { pr_err("fpath is NULL"); return -1;}
	if(h->fp) { pr_err("The file %p is already opened\n",h->fp); return -1; }
	h->data=0;
	h->cvt=0;

	//This is a check in case we move to 64-bit architecture
	if((sizeof(char*) != sizeof(int32_t))
			|| (sizeof(int32_t) != sizeof(float)))
	{
		pr_err("Size of internal strcuture must be the same: "
				"char* (%d), int32_t (%d), float (%d)\n",
				sizeof(char*),sizeof(int32_t),sizeof(float));
		return 1;
	}


	h->fp = fopen (fpath,"r");
	if (h->fp == NULL) {
		pr_err("File not created okay: #%d (%s)\n", errno,strerror(errno));
		return -1;
	}

	//clean the previous structure
	memset((void*)&(h->rgx),0,sizeof(h->rgx));
	ret = regcomp(&(h->rgx), rgex_str,  REG_EXTENDED);
	if(ret!=0)
	{
		pr_err("Could not apply regex %s: #%d (%s)\n", rgex_str,errno,strerror(errno));
		wrz_rgxf_close(h);
		return -1;
	}


	//Reserve the memory for the next structure
	for(i=0;i<strlen(cvt);i++)
	{
		if(cvt[i]!='s' && cvt[i]!='d' && cvt[i]!='x' && cvt[i]!='f')
		{
			pr_err("Unknown type %c in ctv=%s\n",cvt[i],cvt);
			wrz_rgxf_close(h);
			return -1;
		}
	}

	pr_info("loading from: %s (%s)\n",fpath,cvt);

	h->cvt=malloc(sizeof(cvt));
	h->cvt=strcpy(h->cvt,cvt);
	h->data=calloc(WRZ_RGXF_MAXLINE*strlen(cvt),sizeof(int32_t));

	return 0;
}


int wrz_rgxf_read(struct wrz_rgxf_handler* h)
{
	if(h->rgx.re_nsub<=0)
		pr_err("Regex was not compiled correctly\n");

	h->len=0;
	int32_t *pline_i=h->data;
	float *pline_f=h->data;
	char **pline_s=h->data;

	uint32_t ngroups=strlen(h->cvt);
	int g;
	char tmp[256];
	size_t ssize;
	char * line = NULL;
	size_t llen = 0;
	ssize_t read;
	uint32_t isempty=0;

	/* Execute regular expression */
	regmatch_t pMatch[h->rgx.re_nsub+1];
	while ((read = getline(&line, &llen, h->fp)) != -1)
	{
		int reti = regexec(&(h->rgx),line,h->rgx.re_nsub+1, pMatch, 0);
		if (!reti) {
			if(h->rgx.re_nsub>ngroups)
			{
				pr_err("Regex has more group %d, than h->cvt %d ('%s')\n",h->rgx.re_nsub,ngroups,h->cvt);
				return -1;
			}
			else
			{
				if(h->rgx.re_nsub<ngroups)
				{
					pr_warn("Not all groups (%d<%d) where found in %s\n",h->rgx.re_nsub,ngroups,line);
				}

				isempty=1;
				for(g=1;g<h->rgx.re_nsub+1;g++)
				{
					//substr
					ssize=wrz_strncpy(tmp,line+pMatch[g].rm_so,sizeof(tmp),pMatch[g].rm_eo-pMatch[g].rm_so);
					isempty&=(ssize==0);
					pr_debug("#%2d,g:%d (%02d:%02d,%02d) #%c => '%s'\n",h->len,g,pMatch[g].rm_so,pMatch[g].rm_eo,ssize,h->cvt[g-1],tmp);


					switch(h->cvt[g-1])
					{
					case 'd': pline_i[g-1]=(int32_t)strtol(tmp,NULL,10); break;
					case 'x': pline_i[g-1]=(uint32_t)strtoul(tmp,NULL,16); break;
					case 'f': pline_f[g-1]=(float)strtof(tmp,NULL); break;
					case 's':
						pline_s[g-1]=0;
						if(ssize==0) break;
						pline_s[g-1]=malloc(ssize);
						pline_s[g-1]=strcpy(pline_s[g-1],tmp);
						break;
					default: pr_warn("Not implemented\n");
					}
				}
				if(!isempty)
				{
					//move the pointers
					pline_i+=ngroups;
					pline_f+=ngroups;
					pline_s+=ngroups;
					h->len++;
				}
			}

		}
		else if (reti == REG_NOMATCH)
		{
			pr_debug("No regex match found in %s",line);
		}
		else {
			char emsgbuf[256];
			regerror(reti, &(h->rgx), emsgbuf, sizeof(emsgbuf));
			pr_err("Regex match failed: %s",emsgbuf);
			return -1;
		}
	}
	if (line) free(line);
	return 0;
}

int wrz_rgxf_get_integer(struct wrz_rgxf_handler* h, int r, int c)
{
	uint32_t ngroups=strlen(h->cvt);
	int *pData=(int*)h->data;

	return pData[ngroups*r+c];

}

float wrz_rgxf_get_float(struct wrz_rgxf_handler* h, int r, int c)
{
	uint32_t ngroups=strlen(h->cvt);
	float *pData=(float*)h->data;

	return pData[ngroups*r+c];
}


const char* wrz_rgxf_get_string(struct wrz_rgxf_handler* h, int r, int c)
{
	uint32_t pos=strlen(h->cvt)*r+c;
	const char **pData=(const char**)h->data;
	if(pData[pos])
	{
		return pData[pos];
	}
	else
	{
		pr_warn("Not valid string %d,%d -> %d (@%p)\n",r,c,pos,&(pData[pos]));
	}
	return "";
}


int wrz_rgxf_close(struct wrz_rgxf_handler* h)
{
	size_t r,w,c,pos;
	char **pData;
	if(!h) return -1;
	if(h->fp) fclose (h->fp);

	//Free the string allocated into the matrix
	if(h->cvt && strchr(h->cvt,'s'))
	{
		w=strlen(h->cvt);
		pData=(char **)h->data;
		for(r=0;r<h->len;r++)
		{
			for(c=0;c<w;c++)
			{
				if(h->cvt[c]!='s') continue;
				pos=w*r+c;
				if(pData[pos])
				{
					free((void*)pData[pos]);
					pData[pos]=0;
				}
			}
		}
	}

	//Free the other part of the structure
	if(h->data) free(h->data);
	if(h->cvt) free(h->cvt);

	regfree(&(h->rgx));
	pr_debug("Closing...\n");

	//clearing all value
	h->fp=NULL;


	return 0;
}

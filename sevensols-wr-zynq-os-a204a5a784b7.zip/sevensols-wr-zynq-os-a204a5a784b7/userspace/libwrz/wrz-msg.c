/* A replacement for TRACE with only run-time conditionals */
#define _GNU_SOURCE /* asprintf */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <signal.h>

#include <libwrz/wrz-msg.h>

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a)/sizeof(a[0]))
#endif

int wrz_msg_level = WRZ_MSG_DEFAULT_LEVEL;

/* We use debug, info, warning, error and "silent" */
static int wrz_msg_used_levels[] = {
	LOG_ALERT, /* more silent then ERR, but "1" not 0 */
	LOG_ERR,
	LOG_WARNING,
	LOG_INFO,
	LOG_DEBUG,
};
static int wrz_msg_pos;

void wrz_msg_sighandler(int sig)
{
	if (sig == SIGUSR1 && wrz_msg_pos < ARRAY_SIZE(wrz_msg_used_levels) - 1)
		wrz_msg_pos++;
	if (sig == SIGUSR2 && wrz_msg_pos > 0)
		wrz_msg_pos--;
	wrz_msg_level = wrz_msg_used_levels[wrz_msg_pos];
	wrz_msg(LOG_INFO, "pos: %i, level %i\n", wrz_msg_pos, wrz_msg_level);
}


static FILE *wrz_msg_f = (FILE *)-1; /* Means "not yet set" */
static char *prgname; /* always print argv[0], or we get lost */

/* This function is optional, up to the user whether to call it or not */
void wrz_msg_init(int argc, char **argv)
{
	int i;
	int max = ARRAY_SIZE(wrz_msg_used_levels) - 1;
	char *e;

	prgname = argv[0];
	wrz_msg_f = stderr;

	e = getenv("WRS_MSG_LEVEL");
	if (e) {
		i = atoi(e);
		if (i) /* not 0 (EMERG) as atoi returns 0 on error */
			wrz_msg_level = i;
	}

	/* Start at this level, then scan for individual "-v" or "-q" */
	for (wrz_msg_pos = 0; wrz_msg_pos < max; wrz_msg_pos++)
		if (wrz_msg_used_levels[wrz_msg_pos] >= wrz_msg_level)
			break;
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "-q") && wrz_msg_pos > 0)
			wrz_msg_pos--;
		if (!strcmp(argv[i], "-v") && wrz_msg_pos < max)
			wrz_msg_pos++;
		if (!strcmp(argv[i], "-V") && wrz_msg_pos < max)
			wrz_msg_pos+=2;
	}

	wrz_msg_level = wrz_msg_used_levels[wrz_msg_pos];

	/* Prepare for run-time changes */
	signal(SIGUSR1, wrz_msg_sighandler);
	signal(SIGUSR2, wrz_msg_sighandler);
}

void wrz_msg_file(FILE *target)
{
	wrz_msg_f = target;
}

void wrz_msg_filename(char *name)
{
	FILE *f = fopen(name, "a");

	if (f)
		wrz_msg_f = f;
}

void __wrz_msg(int level, const char *func, int line, const char *fmt, ...)
{
	va_list args;
	static char *header_string[] = {
		[LOG_ALERT] = "# Alert:",
		[LOG_ERR] = "# Error: ",
		[LOG_WARNING] = "#W: ",
		[LOG_INFO] = "#I: ",
		[LOG_DEBUG] = "#D: "
	};

	/* If the user didn't set the file, nor init, enforce default now */
	if (wrz_msg_f == (FILE *)-1)
		wrz_msg_f = stderr;

	if (level > wrz_msg_level)
		return;

	/* Same for the name: a pid is better than nothing */
	if (!prgname)
		asprintf(&prgname, "<pid-%i>", getpid());

	/* Program name and header, and possibly function and line too */
	fprintf(wrz_msg_f, "%s%s", prgname, header_string[level]);
	if (level >= WRZ_MSG_DETAILS_AT)
		fprintf(wrz_msg_f, "%s:%i: ", func, line);

	/* The actual message */
	va_start(args, fmt);
	vfprintf(wrz_msg_f, fmt, args);
	va_end(args);
	fflush(wrz_msg_f);
}



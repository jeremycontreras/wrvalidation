/* Userspace /dev/mem I/O functions for accessing the Main FPGA */

#include <stdio.h>
#include <unistd.h>

#include <unistd.h>
#include <sys/mman.h>
#include <inttypes.h>
#include <fcntl.h>
#include <poll.h>

#include <libwrz.h>
#include <libwrz/wrz-msg.h>

#include <stdio.h>
#include <string.h>



/* Virtual base address of the Main FPGA address space. */
volatile void *_fpga_base_virt;
static uint32_t size_map;


int wrz_dev_get_family(void)
{
	int family=HAL_DEV_FAMILY_UNKNOW;
	char str[64];
	FILE * file;
	file = fopen(HAL_DEV_NAME_PATH, "r");
	if (file) {
		fscanf(file, "%63[^\n]", str);
		if(strcmp(str,"WR-ZEN")==0)
		{
			family=HAL_DEV_FAMILY_ZEN;
		}
		else if(strcmp(str,"WR-Z16")==0)
		{
			family=HAL_DEV_FAMILY_Z16;
		}
		else if(strcmp(str,"WR-LEN+")==0)
		{
			family=HAL_DEV_FAMILY_LENP;
		}
		else
		{
			pr_warning("Could not detect device family '%s'",str);
		}
		fclose(file);
	}
	else
	{
		pr_error("Could not open %s",HAL_DEV_NAME_PATH);
	}
	return family;
}


/**
 * Initializes the mapping of the Main FPGA to the CPU address space.
 *
 * @param dev_type: the type of device used to connected to the FPGA
 * dev_type={WRZ_FPGA_MAP_AUTO,WRZ_FPGA_MAP_ZENMEM, WRZ_FPGA_MAP_DEVMEM}
 * @return 0 if OK, -1 otherwise
 */
int wrz_fpga_mmap_init(int dev_type)
{
	int fd=0;
	uint32_t offset;
	const char *devfile;

	pr_debug("Initializing FPGA memory mapping (%d).\n",dev_type);

	//Try open on /dev/zen
	if(fd<=0 && ((dev_type==WRZ_FPGA_MAP_DEVZEN) || (dev_type==WRZ_FPGA_MAP_AUTO)))
	{
		devfile="/dev/zen";
		fd = open(devfile, O_RDWR | O_SYNC);
		offset=0;
		if(dev_type==WRZ_FPGA_MAP_AUTO && (fd < 0))
			pr_debug("Could not open %s\n",devfile);
	}
	//Try open on /dev/mem
	if(fd<=0 && dev_type!=WRZ_FPGA_MAP_DEVZEN)
	{
		devfile="/dev/mem";
		fd = open(devfile, O_RDWR | O_SYNC);
		offset=FPGA_AXI_BASE_ADDR;
	}
	//Return if device is not opened
	if (fd < 0) {
		pr_error("Could not open %s",devfile);
		return -1;
	}

	if(dev_type==WRZ_FPGA_MAP_DEVSPI_0)
	{
		size_map=64*1024;
		offset=0x81E00000;
	}
	else if(dev_type==WRZ_FPGA_MAP_DEVSPI_1)
	{
		size_map=64*1024;
		offset=0x81E10000;
	}
	else if(dev_type==WRZ_FPGA_MAP_DEVSPI_2)
	{
		size_map=64*1024;
		offset=0x81E20000;
	}
	else if(dev_type==WRZ_FPGA_MAP_RTSUBSYS_ZEN)
	{
		size_map=0x100000; //0x000FFFFF+1
		offset=0x43C00000;
	}
	else if(dev_type==WRZ_FPGA_MAP_RTSUBSYS_Z16)
	{
		size_map=0x100000; //0x000FFFFF+1
		offset=0x43D00000;
	}
	else
	{
		size_map=FPGA_AXI_MMAP_SIZE & ~(getpagesize()-1);
	}
	_fpga_base_virt = (volatile void*)
				mmap(NULL,size_map, PROT_READ | PROT_WRITE, MAP_SHARED,
						fd,offset);
	close(fd);

	if (_fpga_base_virt == MAP_FAILED) {
		pr_error("mmap()");
		return -1;
	}

	pr_info("FPGA virtual base = %p (%s @ 0x%x+x%x)\n", _fpga_base_virt,devfile,offset,size_map);

	return 0;

}

void wrz_fpga_munmap(void) {

	pr_debug("Unmapping FPGA memory\n");
	if(_fpga_base_virt)
		munmap((void*)_fpga_base_virt,size_map);
	_fpga_base_virt=0;
}

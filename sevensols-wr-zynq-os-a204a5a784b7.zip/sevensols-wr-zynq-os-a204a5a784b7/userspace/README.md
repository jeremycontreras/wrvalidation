Code at the userspace level: libraries, tools, etc.

#!/bin/bash

# process_rrd.sh
#
# Converts a set of rrd files (ARM little-endian 32bit) contained in a logdump
# package into amd64 format.  It uses a remote WR board to export the original
# rrd files to xml.
#
# It needs user interaction to log in to the remote board and to transfer files
# to/from it.
#
# Usage:
#
#         ./process_rrd.sh <logdump_package> <remote_board_ip>
#
# Author: Ricardo Canuelo Navarro <ricardo.canuelo@sevensols.com>
# Copyright (c) 2019 Seven Solutions S.L. (www.sevensols.com)
#
# This file is part of wr-zynq-os
# You might use, distribute and modify this code and its resulting
# binary form under the terms of the LICENSE.txt provided within the
# module/project: wr-zynq-os.
#
# If you do not have received a copy of the LICENSE.txt along with
# this file please write to info@sevensols.com and consider that
# this file can not be copied and/or distributed in any forms.

if [ "$#" -ne 2 ]; then
	echo -e "Wrong number of parameters\n"
	echo -e "Usage:"
	echo -e "./process_rrd.sh <logdump_package> <remote_board_ip>\n"
	exit 1
fi

cleanup()
{
	rm dumprrd.sh
	rm collectd_rrd.tar
}

# Remote script:
# Extracts the logdump package (passed as a parameter)
# Exports all the rrd files as xml and gzips the results

cat > dumprrd.sh << 'EOF'
#!/bin/sh

pkg=$1
# Logdump file must have a .tar.gz suffix. Rename it if necessary
suffix=`echo $pkg | awk -F . '{print $(NF-1) "." $NF}'`
if [[ $suffix != "tar.gz" ]]; then
	mv /tmp/$pkg /tmp/$pkg.tar.gz
	pkg=$1.tar.gz
fi

gunzip -c /tmp/$pkg > /tmp/logdump_pkg.tar
tar -xvf /tmp/logdump_pkg.tar -C /tmp
cd /tmp/tmp/wrz_logdump*/collectd_rrd

# Dump all rrd files to xml and compress them
for f in `find . -name '*.rrd'`; do rrdtool dump $f ${f%.rrd}; gzip ${f%.rrd}; rm $f; done
cd ..
tar -cf /tmp/collectd_rrd.tar collectd_rrd

# Remove all temporary files
cd
rm -r /tmp/tmp
rm /tmp/logdump_pkg.tar
rm /tmp/$pkg
rm /tmp/dumprrd.sh
EOF

chmod +x dumprrd.sh

# Copy the logdump package and remote script to the remote board
# Run the remote script, bring back the results and process the files in
# this machine.
scp $1 dumprrd.sh root@$2:/tmp
pkg_name=`basename $1`
ssh root@$2 "/tmp/dumprrd.sh $pkg_name"
scp root@$2:/tmp/collectd_rrd.tar .
tar -xvf collectd_rrd.tar
if [ $? -ne 0 ]; then
	cleanup
	exit 1
fi

cd collectd_rrd
for f in `find . -name "*.gz"`; do gunzip $f; done
for f in `find . -type f`; do rrdtool restore $f $f.rrd; rm $f; done
cd ..

cleanup

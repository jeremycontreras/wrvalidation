Developper/Support Tools
========================

These tools/script utilities have been designed to
ease the job for developper and support team.

sysmon
----------

A set of bash, matlab scripts in order to parse the `wrz_sysmon.log` file
and plot the local memory stats from it.

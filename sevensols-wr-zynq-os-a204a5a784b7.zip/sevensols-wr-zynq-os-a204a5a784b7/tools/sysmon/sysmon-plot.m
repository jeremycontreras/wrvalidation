close all;
clear all;

M=load('wrz_sysmon-mstat.csv');

lgd={
'Time(s)',
'MemTotal',
'MemFree',
'MemAvailable',
'Buffers',
'Cached',
'SwapCached',
'Active',
'Inactive',
'Active(anon)',
'Inactive(anon)',
'Active(file)',
'Inactive(file)',
'Unevictable',
'Mlocked',
'HighTotal',
'HighFree',
'LowTotal',
'LowFree',
'SwapTotal',
'SwapFree',
'Dirty',
'Writeback',
'AnonPages',
'Mapped',
'Shmem',
'Slab',
'SReclaimable',
'SUnreclaim',
'KernelStack',
'PageTables',
'NFS_Unstable',
'Bounce',
'WritebackTmp',
'CommitLimit',
'Committed_AS',
'VmallocTotal',
'VmallocUsed',
'VmallocChunk',
'CmaTotal',
'CmaFree'};



nzidx=find(std(M(:,2:end))!=0)+1;

lgd2=lgd(nzidx,1);
M2=M(:,nzidx);

for idx=nzidx
    figure(idx)
    plot((M(:,1)-M(1,1))/3600,M(:,idx));
    title([lgd{idx,1},' (#',num2str(idx),')']);
    xlabel(['hours since ',strftime('%F %T',localtime(M(1,1)))]);
    ylabel('kB');
end

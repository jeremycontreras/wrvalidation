#!/bin/sh

grep MSTAT: $1 | sed 's/MSTAT: //g' > wrz_sysmon-mstat.csv


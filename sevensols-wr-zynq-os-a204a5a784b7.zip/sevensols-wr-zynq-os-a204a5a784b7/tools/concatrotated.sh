#! /bin/sh
#
# Developper/Support tool to concatenate logrotated files in a big file
#
# Authors:
#	- Benoit Rat (Seven Solutions, www.sevensols.com)
# Copyright (c) 2017 Seven Solutions S.L (www.sevensols.com)
#
# This file is part of wr-zynq-os
# You might use, distribute and modify this code and its resulting
# binary form under the terms of the LICENSE.txt provided within the
# module/project: wr-zynq-os.
#
# If you do not have received a copy of the LICENSE.txt along with
# this file please write to info@sevensols.com and consider that
# this file can not be copied and/or distributed in any forms.

help()
{
cat << EOF
Usage: $(basename $0)  <Dir/FilePattern>

This small script help you to concatenate all logrotated files into one big file.
Its uniq argument that can be a directory or a specific file pattern

For example if we want to concate all rotated log files in a directory:

~~~~~~~{.sh}
> ./concatrotated.sh tmp/
tmp/access_lighttpd.log.2.gz+tmp/access_lighttpd.log.1.gz+tmp/access_lighttpd.log.0.gz               > tmp/access_lighttpd.log.all    (14M)
tmp/dmesg.log.0.gz                                                                                   > tmp/dmesg.log.all              (20K)
tmp/wrz_sysmon.log.3.gz+tmp/wrz_sysmon.log.2.gz+tmp/wrz_sysmon.log.1.gz+tmp/wrz_sysmon.log.0.gz      > tmp/wrz_sysmon.log.all         (18M)
~~~~~~~

or if the user want to concate only by searching a specific pattern:

~~~~~~~{.sh}
> ./concatrotated.sh tmp/wrz_sysmon.log*
tmp/wrz_sysmon.log.3.gz+tmp/wrz_sysmon.log.2.gz+tmp/wrz_sysmon.log.1.gz+tmp/wrz_sysmon.log.0.gz      > tmp/wrz_sysmon.log.all         (18M)
~~~~~~~

EOF
exit 1
}


if [ "x$1" = "x-h" ]; then
    help
fi
if [ $# -lt 1 ]; then
    echo "ERROR: Need one argument !!!"
    echo ""
    help;
fi

LOGPATTERN=${1}
LOGFILE=$(find ${LOGPATTERN} -type f | grep log.*.gz | sed 's/\.[0-9]*\.gz//g' | sort | uniq)
for l in ${LOGFILE}; do
    test -f ${l}.all && rm ${l}.all;
    ls -1r ${l}* | xargs zcat -f >> $l.all
    printf "%-100s > %-30s (%s)\n" $(ls -1r ${l}* | grep -v .all | tr '\n' '+' | sed 's/.$//') $l.all $(du -ah $l.all | cut -f1)
done

